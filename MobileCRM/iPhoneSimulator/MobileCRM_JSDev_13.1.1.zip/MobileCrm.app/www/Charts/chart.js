﻿function Settings() {
	/// <summary>Constructor of the Settings object that stores data related to chart settings.</summary>
	/// usefull tricks https://leanpub.com/D3-Tips-and-Tricks/read

	var _this = this;
	this.isVisible = false;
	this.name = "";
	this.noDataText = "";
	this.seriesColors = {}
	this.seriesTitles = {}
	this.title = "";
	this.type = new Number();
	this.labelAxisTitle = "";
	this.valueAxisTitle = "";
	this.currency = "";
	this.currencySymbol = "";
	this.thousandSeparator = "";
	this.valuePrecision = new Number();
	this.pieDonutRatio = 70;
	this.pieLabelStyle = 0;
	this.chartStyle = 0;
	this.disableDrilldown = false;
	this.backColor = undefined;
	this.foreColor = undefined;
	this.textColors = [];
	this.localeOptions = {
		minimumFractionDigits: undefined,
		maximumFractionDigits: undefined,
		style: undefined,
		currency: undefined,
		currencySymbol: undefined,
		useGrouping: undefined
	};
	this.seriesFormattingInfo = [];

	this.jsonData = {};
	this.chartWrapper = {};
	this.chartWrapperMargin = 20;

	this.height = 0,
		this.width = 0,
		this.maxXLabelLength = 0,
		this.maxYLabelLength = 0,
		this.maxLabelsLength = 15; // @JC x and y axis labels longer than 'settings.maxLabelsLength' will be abbreviated to 'settings.maxLabelsLength' characters and "..." string will be added to the end of the label.
	this.angle = 0,
		this.letterPixelSize = 8;
	this.letterHeight = this.letterPixelSize * 2; // @JC constant value used as height of letters used in chart computing
	this.xComponentOfLetterHeight = this.letterHeight / 1.4142; //@JC Length component of the text height rotated under -45 degree. This length component is different for different rotation angle!
	this.minItemSize = this.letterHeight * 1.2; //@JC "letterHeight" value is default value for column bars, horizontal bars, line and area point items to keep axis labels readable. The value is forced to 0 if less than 14 items are used, to ensure that at least 13 bars or points will be visible.
	this.maxItemSize = 200; // @JC maximal width of column bar, line and area item or maximal height of horizontal bar (what represents bar's width in this case). This maxItemSize is used to avoid too wide (ugly) bars and line and area items.
	this.minimumXaxisMargin = 30;
	this.minimumYaxisMargin = 30;
	this.minRoundingMargin = 1; // @JC minimal margin that needs to be used for charts to avoid showing scrollbars that appear due to greater background size caused by rounding (0.0 <= 0.4999, 0.4999999999 => 1.0)
	this.windowRatio = 0;
	this.isStacked;
	this.showRecords;
	//this.translateShowControls = "translate(0,0)"; // for isStacked buttons translation. // @JC: Translation of controls can not be used more, because it influences chart's availableHeight and thus causes inaccurate chart layout. Controls layout was remade, so its manual translation is not more needed.
	this.gaugeTarget;   // @JM constant values for gauge chart (if provided)
	this.gaugeMin;
	this.gaugeMax;

	// public functions to keep computation got from d3.min on one place.
	// computation is made by the same way like in the d3.svg.axis function where rangeBand is used for this computation.
	this.getItemSize = fGetItemSize;
	this.getItemGroupSpacingSize = fGetItemGroupSpacingSize;
	this.getWidthFromItemSize = fGetWidthFromItemSize;

	this.multipleSeriesTitles = {}
	this.offlineJsonData = null;
	this.selectedName = "";
	this.groupPropertyName = "";
	this.style = 0;
	this.showControls = false;
	this.DateGrouped = "";
	this.isGroupingStacked = false;


	function fGetItemSize(chartAreaWidth, valuesCount, groupSpacing) {
		var step = chartAreaWidth / (valuesCount + groupSpacing);
		var barWidth = step * (1 - groupSpacing);
		return barWidth;
	}

	function fGetItemGroupSpacingSize(chartAreaWidth, valuesCount, groupSpacing) {
		var step = chartAreaWidth / (valuesCount + groupSpacing);
		var groupSpacingWidth = step * groupSpacing;
		return groupSpacingWidth;
	}

	function fGetWidthFromItemSize(itemSize, valuesCount, groupSpacing) {
		var step = (valuesCount + groupSpacing);
		var width = (itemSize * step) / (1 - groupSpacing);
		return width;
	}
}

Settings.prototype.updateProperties = function (json) {
	/// <summary> Public method of the Settings object that updates all fields of Settings object, that are included as function parameter. </summary>
	/// <param name="json" type="Object">Object obtained from JSBridge with properties of the chart</param>

	this.isVisible = json.isVisible;
	this.labelAxisTitle = json.labelAxisTitle;
	this.name = json.name;
	this.noDataText = json.noDataText;
	this.seriesColors = json.seriesColors;
	this.seriesTitles = json.seriesTitles;
	this.multipleSeriesTitles = json.multipleSeriesTitles;
	this.offlineJsonData = json.jsonOfflineData;
	this.title = json.title;
	this.type = json.type;
	this.selectedName = json.selectedName;
	this.groupPropertyName = json.groupPropertyName;
	this.DateGrouped = json.dateGrouped;
	this.isGroupingStacked = json.isGroupingStacked;
	this.valueAxisTitle = json.valueAxisTitle;
	this.currency = json.currency;
	this.currencySymbol = json.currencySymbol;
	this.seriesFormattingInfo = json.seriesFormattingInfo;
	this.thousandSeparator = json.thousandSeparator;
	this.valuePrecision = new Number(json.valuePrecision);
	this.showRecords = json.showRecords;
	this.isStacked = json.isStacked;
	this.chartsLocalization = json.chartsLocalization;
	this.cmdLocalization = json.cmdLocalization;


	if (json.hasOwnProperty("backColor")) {
		this.backColor = json.backColor;
		this.foreColor = json.foreColor;
	}
	if (json.settings) { // @MS specific chart setting coming with version 5
		this.disableDrilldown = json.settings.disableDrilldown;
		this.pieLabelStyle = json.settings.labelStyle;
		this.pieDonutRatio = json.settings.donutRatio;

		this.chartStyle = json.settings.style;      // 0-user select, 1-grouped, 2-stacked
		if (this.chartStyle === 0 && (json.type === 0 || json.type === 1)) {     // @MS if neibor bars in bar or collumn chart has some color, only grouped mode is logic
			if (this.isStacked === false)
				this.chartStyle = 2;                // stacked mode
			else if (this.chartStyle !== 0)
				this.isStacked = this.chartStyle === 2;
		}
		// @JM set additional parameters for gauge chart
		if (json.type === 6) {
			this.gaugeTarget = json.settings.targetValue;
			this.gaugeMin = json.settings.minValue;
			this.gaugeMax = json.settings.maxValue;
		}
	}

	if (!isNaN(this.valuePrecision) && this.valuePrecision >= 0) {
		this.localeOptions.minimumFractionDigits = this.valuePrecision;
		this.localeOptions.maximumFractionDigits = this.valuePrecision;
		this.localeOptions.thousandSeparator = this.thousandSeparator;
	}
	if (this.currency) {
		this.localeOptions.style = "currency";
		this.localeOptions.currency = this.currency;
		this.localeOptions.currencySymbol = this.currencySymbol;
	}
	else
		this.localeOptions.useGrouping = false;

	if (json.decimalSeparator && json.decimalSeparator !== ".")
		this.localeOptions.decimalSeparator = json.decimalSeparator;

	// convert colors
	if (this.seriesColors != undefined) {
		var colors = [];
		for (var i = 0; i < this.seriesColors.length; i++) {
			colors[i] = '#' + ('000000' + (this.seriesColors[i] & 0xFFFFFF).toString(16)).slice(-6);
			this.textColors.push(invertColor(colors[i]));
		}
		this.seriesColors = colors;
	}

	// change text color to assure readability
	function invertColor(color) {
		var c = color;

		c = c.substring(1);      // strip #
		var rgb = parseInt(c, 16);   // convert rrggbb to decimal
		var r = (rgb >> 16) & 0xff;  // extract red
		var g = (rgb >> 8) & 0xff;  // extract green
		var b = (rgb >> 0) & 0xff;  // extract blue

		var luma = 0.2126 * r + 0.7152 * g + 0.0722 * b; // per ITU-R BT.709

		return luma < 40 ? "#FFFFFF" : "#000000";
	}
}


function JSChart() {
	/// <summary>Main constructor of the JSChart object. Object has one property where are saved all settings of the chart  
	/// and seccond property of the nvchart object.</summary>

	var _this = this;
	this.settings = new Settings();
	this.nvChart = {};
}


JSChart.prototype.createChart = function () {
	/// <summary>Public method of JSChart object that create default chart by type.</summary>

	switch (this.settings.type) {
		case 0:
			this.nvChart = nv.models.multiBarChart();
			break;
		case 1:
			this.nvChart = nv.models.multiBarHorizontalChart();
			break;
		case 2:
			this.nvChart = nv.models.lineChart();
			break;
		case 3:
			this.nvChart = nv.models.pieChart();
			break;
		case 5:
			this.nvChart = nv.models.pieChart();
			break;
		case 6:
			// @MS Gauge chart
			this.nvChart = nv.models.pieChart();
			break;
		case 7:
			// @MS Stack area chart
			this.nvChart = nv.models.stackedAreaChart();
			break;
	}
}


JSChart.prototype.drawChart = function (json) {
	/// <summary>Public method of JSChart object that updates nvchart object by settings and adds graph into SVG element. This method has several other private methods.</summary>
	/// <param name="json" type="Object">Object where is saved chart dataset.</param>

	var minWindowSize = 300;  // minimum size of graph, width or height can't be smaller.
	// setting default values for width and height
	var size = nv.utils.windowSize();
	this.settings.width = size.width >= minWindowSize ? size.width : minWindowSize;
	this.settings.height = size.height >= minWindowSize ? size.height : minWindowSize;
	this.settings.jsonData = json; // saved parameter to the chart.settings property 
	this.settings.windowRatio = (size.width / size.height).toFixed(1);  // default ratio for real window size (this is important for rotation and redrawing of the graph)

	d3.selectAll("#chartWrapper svg > *").remove();   // remove previous content of svg element
	this.settings.chartWrapper = document.getElementById("chartWrapper");
	var chartData = {};

	// method that update chart and make some changes, if are necessary, in the dataset. 
	function updateChart(chart, settings) {

		function parseJson(jsonData, seriesTitles, multipleSeriesTitles, seriesColors, textColors) {



			function setGroupValues(count, index, textColor, on) {

				values = []
				for (var i = 0; i < count; i++) {
					values.push({
						x: i == on ? i : undefined,
						y: i == on ? jsonData[i].values[index] : undefined,
						label: jsonData[i].key,
						textColor: textColor,
						backgroundColor: undefined
					})
				}
				return values;
			}


			function findIndexOf(data, multipleSeriesTitlesLabel) {
				var returnValue = -1;

				for (var index = 0; index < data.length; ++index) {
					if (data[index].key === multipleSeriesTitlesLabel) {
						returnValue = index;
						break;
					}
				}

				return returnValue;
			}


			function setValues(count, index, textColor) {
				/// <summary>Create object of values for chart.</summary>
				/// <param name="count" type="Integer">Count of series.</param>
				/// <param name="index" type="Integer">Index for a specific serie.</param>
				/// <param name="textColors" type="Array<String>">List of colors for text in series.</param>
				/// <returns type="Object">Object of the values for specific serie with x, y and label for every value.</returns>

				values = []
				for (var i = 0; i < count; i++) {

					var jsonDataValues = jsonData[i].values[index];;

					if (multipleSeriesTitles != undefined && i != 0) {
						jsonDataValues = undefined;
					}

					values.push({
						x: i,
						y: jsonDataValues,
						label: jsonData[i].key,
						textColor: textColor
					})
				}

				return values;
			}

			data = [];
			if (jsonData.length > 0) {

				var nSeries = jsonData[0].values.length;
				for (var i = 0; i < nSeries; i++) {

					var title = "";
					var chColor = "";
					if (seriesTitles != undefined) {
						title = seriesTitles[i];
					} else if (multipleSeriesTitles != undefined) {
						title = multipleSeriesTitles[0][i];
					}

					chColor = (seriesColors != undefined) ? seriesColors[i] : "";

					data.push({
						key: title,
						index: i,
						values: setValues(jsonData.length, i, textColors[i]),
						color: chColor,
					});
				}

				if (multipleSeriesTitles != undefined) {

					for (var jd = 1; jd < jsonData.length; jd++) {

						var datavalue = null;
						var isMatch = false;

						for (var i = 0; i < jsonData[jd].values.length; i++) {

							var multipleSeriesTitlesLabel = multipleSeriesTitles[jd][i];

							datavalue = findIndexOf(data, multipleSeriesTitlesLabel);

							if (datavalue == -1) {
								data.push({
									key: multipleSeriesTitlesLabel,
									index: data.length + 1,
									values: setGroupValues(jsonData.length, i, undefined, jd),
									color: undefined,
								});

								datavalue = findIndexOf(data, multipleSeriesTitlesLabel);
							}

							for (var n = 0; n < data.length; n++) {
								if (datavalue == n) {
									data[n].values[jd] = ({ x: 1, y: jsonData[jd].values[i], label: jsonData[jd].key, textColor: undefined });
									isMatch = true;
								}
							}
						}
					}
				}
			}

			return data;



			///// <summary>Function create data object according to requirements NVD3 charts.</summary>
			///// <param name="jsonData" type="Object">Object with original data from MCRM.</param> 
			///// <param name="seriesTitles" type="Array<String>">List of titles for series.</param>
			///// <param name="seriesColors" type="Array<String>">List of colors for series.</param>
			///// <param name="textColors" type="Array<String>">List of colors for text in series.</param>
			///// <returns  type="Object">Object of series data where are defined key, index, values and color for every serie.</returns>

			//function setValues(count, index, textColor) {
			//	/// <summary>Create object of values for chart.</summary>
			//	/// <param name="count" type="Integer">Count of series.</param>
			//	/// <param name="index" type="Integer">Index for a specific serie.</param>
			//	/// <param name="textColors" type="Array<String>">List of colors for text in series.</param>
			//	/// <returns type="Object">Object of the values for specific serie with x, y and label for every value.</returns>
			//	values = []
			//	for (var i = 0; i < count; i++) {
			//		values.push({
			//			x: i,
			//			y: jsonData[i].values[index],
			//			label: jsonData[i].key,
			//			textColor: textColor
			//		})
			//	}
			//	return values;
			//}

			//data = [];
			//if (jsonData.length > 0) {
			//	var nSeries = jsonData[0].values.length;
			//	for (var i = 0; i < nSeries; i++) {
			//		data.push({
			//			key: (seriesTitles != undefined) ? seriesTitles[i] : "",
			//			index: i,
			//			values: setValues(jsonData.length, i, textColors[i]),
			//			color: (seriesColors != undefined) ? seriesColors[i] : "",
			//		});
			//	}
			//}
			//return data;
		}

		function getValuesX(data) {
			/// <summary>Get array of labels from data object for locale formatting of axis labels.<summary>
			/// <param name="data" value="Object">Created specific data object.</param>
			/// <returns type="Array<String>">Array of strings with labels values.</returns>
			var valueArray = [];
			if (data != undefined)
				for (var i = 0; i < data.values.length; i++)
					valueArray[i] = data.values[i].label;
			return valueArray;
		}

		function getMaxLabelLength(chartData) {
			/// <summary>
			///		Find out maximum length of the lables for x and y axis. Cut every labels longer than 'settings.maxLabelsLength' characters and add to the end of label "..." 
			///		Method set this values for private variable of update function.
			/// </summary>
			/// <param name="chartData" type="Object">Specific data object.</param>
			var max = settings.maxLabelsLength;
			for (var i = 0; i < chartData.length; i++) {
				for (var j = 0; j < chartData[i].values.length; j++) {
					var val = chartData[i].values[j].label;
					var valLength = val.length;

					if (valLength > max) {
						valLength = max + 3; // Add 3 chars for ...
						chartData[i].values[j].label = val.substring(0, max) + "...";
					}

					if (maxXLabelLength < valLength) {
						maxXLabelLength = valLength;
					}
				}
			}
			// @MP: Value Axis is numeric
			maxYLabelLength = 4; // We use d3.format('2s') thus we will have 14K, 1.4K, 0.14K, so lets go with the conservative max length 4
			if (settings.localeOptions.currencySymbol) // Add 2 chars for $_
				maxYLabelLength += settings.localeOptions.currencySymbol.length + 1;
		}

		function getFirstLabelOffset(chartAreaWidth, valuesCount, groupSpacing) {
			// @JC getFirstLabelOffset is computated by the same way like in the d3.svg.axis function where rangeBand is used for this computation.
			// Computation is optimize therefore it is necessary to look for "scale.rangeBands = function(x, padding, outerPadding)" string in d3.js, that served as original pattern.
			var barWidth = _chart.settings.getItemSize(chartAreaWidth, valuesCount, groupSpacing);
			var groupSpacingWidth = _chart.settings.getItemGroupSpacingSize(chartAreaWidth, valuesCount, groupSpacing);
			var labelsOffset = groupSpacingWidth + barWidth / 2;
			return labelsOffset;
		}

		function prepareMinAxisMargins(customMargin, numOfSeries, valuesCount) {
			minXAxisMargin = settings.maxXLabelLength;
			minYAxisMargin = settings.maxYLabelLength;

			if (settings.labelAxisTitle)
				minXAxisMargin += settings.letterHeight + chart.xAxis.axisLabelDistance(); // @JC: Increase bottom margin if we are going to show the axisX title. (Letter height is twice to letter width, therefore value 2 is used.)

			if (settings.valueAxisTitle)
				minYAxisMargin += settings.letterHeight + chart.yAxis.axisLabelDistance(); // @MP: Increase left margin if we are going to show the axisY title. (!multiple series)

			var labelsOffset = getLabelsOffset(customMargin, numOfSeries, valuesCount);

			var firstLabelBeginningOverhang = (settings.maxXLabelLength - settings.xComponentOfLetterHeight) - labelsOffset; // @JC Label is anchored at right top corner, therefore we must substract x component of label's height rotated under -45 degree.
			if ((settings.angle % 360) != 0) { // @JC Now works properly only for -45 degree. In other case replace 1.412 constant with proper cos function.
				minRightMargin = settings.xComponentOfLetterHeight - labelsOffset; // @JC Label is anchored at right top corner, therefore we must include x component of label's height rotated under -45 degree into right margin space.
				if (minRightMargin < 0)
					minRightMargin = 0;
				if (firstLabelBeginningOverhang > minYAxisMargin) { //@JC if ([x component of axisX label length rotated under -45 degree] > minYAxisMargin) {minYAxisMargin = [x component of axisX label length rotated under -45 degree];}
					minYAxisMargin = firstLabelBeginningOverhang;
				}
			}

			//// if minXAxisMargin is long add to the height of window half of minXAxisMargin //@JC:START:REMOVED
			//if (minXAxisMargin > settings.height - minXAxisMargin) {
			//    var constant = settings.type == 2 || settings.type == 7 ? 2 : 1.2;
			//    settings.height += (minXAxisMargin / constant);
			//} //@JC:END

			// if vertical margins are longer than container height, enlarge the window height. //@JC:START
			var verticalMargins = (settings.minRoundingMargin + customMargin.top) + (settings.minRoundingMargin + minXAxisMargin + customMargin.bottom);
			if (verticalMargins > (settings.height - verticalMargins)) {
				settings.height += verticalMargins / 2; // @JC Constant 2 has the same behavior for column, horizontal bar, line and area charts, what looks consistently when charts are used.
			} //@JC:END

			function getLabelsOffset(customMargin, numOfSeries, valuesCount) { // @JC Compute first/last label offset from the beggining/ending border of the chart area.
				var labelsOffset = 0;
				if (settings.type === 0) {
					var marginH = { // @JC Horizontal part of chart margin without axis space.
						left: settings.minRoundingMargin + customMargin.left,
						bottom: 0,
						top: 0,
						right: settings.minRoundingMargin + (customMargin.right > minRightMargin ? customMargin.right : minRightMargin),
					}
					var precomputedWidth = getPrecomputedAvailableWidthForBars(numOfSeries, valuesCount); // @JC Compute svg container width that will be used for the chart.
					precomputedWidth = precomputedWidth - (marginH.left + minYAxisMargin) - marginH.right; //@JC Apply multiBarChart margins
					labelsOffset = getFirstLabelOffset(precomputedWidth, valuesCount, chart.groupSpacing()); // @JC:HACK: labelsOffset = groupSpacingWidth + barWidth / 2;
				}
				else if (settings.type === 1) {
					var marginV = { // @JC Vertical part of chart margin without axis space.
						left: 0,
						bottom: settings.minRoundingMargin + customMargin.bottom,
						top: settings.minRoundingMargin + customMargin.top, // @JC If legend is shown, top part of margin is always increased to legend height internally.
						right: 0,
					}
					var precomputedHeight = getPrecomputedAvailableHeightForBars(numOfSeries, valuesCount); // @JC Compute svg container height that will be used for the chart.
					precomputedHeight = precomputedHeight - (marginV.bottom + minYAxisMargin) - marginV.top; //@JC Apply multiBarChart margins
					labelsOffset = getFirstLabelOffset(precomputedHeight, valuesCount, chart.groupSpacing()); // @JC:HACK: labelsOffset = groupSpacingWidth + barWidth / 2;
				}
				return labelsOffset;
			}
		}

		function getMinChartAreaWidth() {
			// computes minimal necessary width that is required for drawing column bars or line and area items.
			//@JC !!! if there is less than 14 items used, it is necessary to force minimal required chart area width to 0, to ensure that at least 13 bars or points will be visible. (View of all months of one year is required.) !!!
			if (valuesCount > 13) {
				if (settings.type === 0) {
					return _chart.settings.getWidthFromItemSize(settings.minItemSize, valuesCount, chart.groupSpacing());
				}
				else if (settings.type === 2 || settings.type === 7) {
					return settings.minItemSize * valuesCount;
				}
			}
			return 0;
		}

		function getMinChartAreaHeight() {
			// computes minimal necessary height that is required for drawing horizontal bars
			//@JC !!! if there is less than 14 items used, it is necessary to force minimal required chart area height to 0, to ensure that at least 13 bars will be visible. (View of all months of one year is required.) !!!
			if (valuesCount > 13) { //@JC forces minimal required chart area width to 0 if less than 14 items are used, to ensure that at least 13 bars or points will be visible.
				return _chart.settings.getWidthFromItemSize(settings.minItemSize, valuesCount, chart.groupSpacing());
			}
			return 0;
		}

		function getPrecomputedAvailableWidthForBars(numOfSeries, valuesCount) { //@JC This available width must be computed by the same way like settings.chartWrapper.style.width is computed  below!
			// computes minimal necessary width that is required for drawing column bars or line and area items.
			var minChartAreaWidth = getMinChartAreaWidth();
			return (minChartAreaWidth >= settings.width) ? (minChartAreaWidth - settings.chartWrapperMargin) : (settings.width - settings.chartWrapperMargin);
		}

		function getPrecomputedAvailableHeightForBars(numOfSeries, valuesCount) { //@JC This available height must be computed by the same way like settings.chartWrapper.style.height is computed  below!
			// computes minimal necessary height that is required for drawing horizontal bars
			var minChartAreaHeight = getMinChartAreaHeight();
			return (minChartAreaHeight >= settings.height) ? (minChartAreaHeight - settings.chartWrapperMargin) : (settings.height - settings.chartWrapperMargin);
		}

		var maxXLabelLength = 0;    // private field where is saved maximum length of label for labelAxis.
		var maxYLabelLength = 0;    // private field where is saved maximum length of label for valueAxis.
		var minXAxisMargin = 0;         // private field where is saved minimum space necessary for labels and title of the axis X.
		var minYAxisMargin = 0;         // private field where is saved minimum space necessary for labels and title of the axis Y.
		var minRightMargin = 0;     // private field where is saved minimum space necessary for last label ending overhang (of the axis X), that occurs when label is rotated.
		var minChartAreaWidth = 0;     // calculate required chart area width
		var minChartAreaHeight = 0;

		chartData = parseJson(settings.jsonData, settings.seriesTitles, settings.multipleSeriesTitles, settings.seriesColors, settings.textColors);  // create of dataset according to the requirements nvd3 chart

		// update all chart parameters only if data are not empty.
		if (settings.jsonData.length > 0) {
			var numOfSeries = chartData.length;
			var valuesCount = numOfSeries === 0 ? 0 : chartData[0].values.length;  // private field for saving count of all values for chart. It important for compute maximum optimum size of labelAxis.
			var stack = false;

			if (settings.type === 3 ||           // PieChart - case 3 sets specific properties for pieChart. 
				settings.type === 5) {           // DonutChart - case 5 sets specific properties for pieChart. 
				chartData = chartData.length > 0 ? chartData[0].values : []; // set dataset first serie.
				setupPieChart(chartData);
			}
			else if (settings.type === 6)        // Gauge chart
				setupGaugeChart(chartData);
			else if (settings.type === 1)        // Bar chart 
				minChartAreaHeight = setupBarChart(chartData);
			else {                               // rest of AxisXY chats
				getMaxLabelLength(chartData);
				var labels = getValuesX(numOfSeries > 0 ? chartData[0] : undefined);

				// @MP We already clamp the maximum label length in the above method.
				settings.maxXLabelLength = (maxXLabelLength * settings.letterPixelSize);// + settings.minimumXaxisMargin;
				settings.maxYLabelLength = (maxYLabelLength * settings.letterPixelSize);

				calculateLabelAngle(valuesCount); // Adjusts settings.maxXLabelLength according to rotation under settings.angle.

				switch (settings.type) {
					// ColumnChart - case 0 sets specific properties for columnChart. 
					case 0:
						// set properties for columnChart
						// @JC Please use customMargin variable to set custom margins for the chart!
						var customMargin = { // last part of addition represents custom margin you want to use to adjust chart appearance
							left: 0,
							bottom: 0,
							top: 20, // @JC If legend or/and controls are shown, top part of margin is always increased at least to legend or controls height internally.
							right: 20, // @MP More space because the label starts to the right of the last line DOT on the  horizontal axis // @JC Please use rightChartMargin variable to set custom right margin of the chart!
						}

						chart
							.foreColor(settings.foreColor)
							.valueToString(valueToString) // @MP - value formatting.
							.duration(0)
							.reduceXTicks(false) // turn off reducing of ticks on the xAxis, show all ticks from dataset
							.showLegend(numOfSeries > 1)  // show legend only if count of series is 2 or more
							.showValues(true) // turn on showing values at each column
							.noData(settings.noDataText); // set noData message
						//.tooltip.enabled(false); // turn off tooltips for chart //@JC

						// set specific properties for xAxis
						chart.xAxis
							.axisLabel(settings.labelAxisTitle) //set main label
							.rotateLabels(settings.angle) // set angle of rotation all labels
							.showMaxMin(false) // turn off showing minimum and maximum value
							.useLocaleOptions(false) // turn off using locale format of labels on this axis
							.axisLabelDistance(0) // set distance of main axis label
							.tickFormat(function (d, i) {
								return labels[i];
							})
							.highlightZero(false);	// turn off highlighting of zero value

						// set specific properties of yAxis
						chart.yAxis
							.axisLabel(settings.valueAxisTitle) // set label
							.showMaxMin(false) // turn off showing minumum and maximum value on this axis
							.highlightZero(false) // turn off highlighting zero vlaue
							.useLocaleOptions(true) // allow format of tick labels by locale options
							.axisLabelDistance(0) // set distance of main axis label from axis
							.localeOptions(settings.localeOptions); // set locale options
						//.rotateYLabel(true); // turn on rotation of tick labels // @JC This is not necessary, becuase rotateYLabel is set to true by default internally.
						if (settings.chartStyle === 1) {
							chart.multibar.stacked(true);
							chart.showControls(false);
						}
						else if (settings.chartStyle === 2) {
							chart.multibar.stacked(false);
							chart.showControls(false);
						}
						else
							chart.showControls(numOfSeries > 1);

						chart.multibar.localeOptions(settings.localeOptions); // set locale options for columns value
						//chart.multibar.valuePadding(settings.maxYLabelLength - (settings.minimumYaxisMargin)); // set upper space between column and legend

						prepareMinAxisMargins(customMargin, numOfSeries, valuesCount); // @JC: This function must be called after all settings of the chast are set and before margins of the chart are set!

						chart
							.margin({ // last part of addition represents custom margin you want to use to adjust chart appearance
								left: settings.minRoundingMargin + minYAxisMargin + customMargin.left,
								bottom: settings.minRoundingMargin + minXAxisMargin + customMargin.bottom,
								top: settings.minRoundingMargin + customMargin.top, // @JC If legend is shown, top part of margin is always increased to legend height internally.
								right: settings.minRoundingMargin + (customMargin.right > minRightMargin ? customMargin.right : minRightMargin),
							})

						// computes minimal necessary width that is required for drawing column bars
						//@JC When lines below are changed, it is necessary to made the same change in the getPrecomputedAvailableWidthForBars() function!
						minChartAreaWidth = getMinChartAreaWidth();

						// call OnClick function after click on the column
						chart.multibar.dispatch.on('elementClick', function (d) {
							onClick(d.data.series, d.index); //@JC
						});
						break;

					// LineChart - case 2 sets specific properties for lineChart. 
					case 2:
						function getIndexies(data) {
							/// <summary>Function which return array of indexies</summary>
							var indexArray = [];
							if (data != undefined)
								for (var i = 0; i < data.values.length; i++)
									indexArray[i] = i;
							return indexArray;
						}

						// set specific properties for lineChart
						// @JC Please use customMargin variable to set custom margins for the chart!
						var customMargin = { // last part of addition represents custom margin you want to use to adjust chart appearance
							left: 0,
							bottom: 0,
							top: 20, // @JC If legend or/and controls are shown, top part of margin is always increased at least to legend or controls height internally.
							right: 20, // @MP More space because the label starts to the right of the last line DOT on the  horizontal axis // @JC Please use rightChartMargin variable to set custom right margin of the chart!
						}

						chart
							.foreColor(settings.foreColor)
							.noData(settings.noDataText)
							.duration(0)
							.showLegend(numOfSeries > 1) // turn on showing legend only if count of series is 2 or more.
							.clipEdge(false); // @JC If it is set to false, scatter points are not clipped at borders, similar like in the area chart, where clipEdge property is not supported.
						//.tooltip.enabled(false); // turn off tooltip for this chart //@JC

						// set specific properties for xAxis of line chart
						chart.xAxis
							.axisLabel(settings.labelAxisTitle)	// set xAxis label
							.rotateLabels(settings.angle) // set angle of rotation all labels, @MP: always rotate the labels!
							.useLocaleOptions(false)	// turn off for this axis using locale formatting
							// change tickValues to array of dataset indexies (it used because lineChart default remove some xAxis tick Labels)
							.tickValues(function (d, i) {
								return getIndexies(numOfSeries > 0 ? chartData[0] : undefined);
							})
							// change format of tick and replace indexies by labels (it uses because formatted labels were removed)
							.tickFormat(function (d, i) {
								return labels[i];
							})
							.axisLabelDistance(0) // set distance of main xAxis label from bottom side. // @JC axisLabelDistance can be used, but it is not included into minXAxisMargin, because it is not known yet when minXAxisMargin is computed.
							.showMaxMin(false) // turn off showing bold minimum and maximum value
							.highlightZero(false);	// turn off highlight of zero value

						// set specific properties for yAxis of line chart
						chart.yAxis
							.axisLabel(settings.valueAxisTitle)  // set yAxis label
							.showMaxMin(false)	// turn off showing bold minimum and maximum value
							.highlightZero(false)	// turn off highlighting zero value
							//.rotateYLabel(true)	// turn on rotation main label of yAxis // @JC This is not necessary, becuase rotateYLabel is set to true by default internally.
							.useLocaleOptions(true)	// turn on using locale value of yAxis tickLabels 
							.localeOptions(settings.localeOptions) // set parametes by that will be changed tick labels.
							.axisLabelDistance(0); // set distance of main yAxis label from the left side. // @JC axisLabelDistance can be used, but it is not included into minYAxisMargin, because it is not known yet when minYAxisMargin is computed.

						prepareMinAxisMargins(customMargin, numOfSeries, valuesCount); // @JC: This function must be called after all settings of the chast are set and before margins of the chart are set!

						chart
							.margin({ // last part of addition represents custom margin you want to use to adjust chart appearance
								left: settings.minRoundingMargin + minYAxisMargin + customMargin.left,
								bottom: settings.minRoundingMargin + minXAxisMargin + customMargin.bottom,
								top: settings.minRoundingMargin + customMargin.top, // @JC If legend is shown, top part of margin is always increased to legend height internally.
								right: settings.minRoundingMargin + (customMargin.right > minRightMargin ? customMargin.right : minRightMargin),
							})

						// computes minimal necessary width that is required for drawing column bars
						//@JC When lines below are changed, it is necessary to made the same change in the getPrecomputedAvailableWidthForBars() function!
						minChartAreaWidth = getMinChartAreaWidth();

						// call OnClick function after click on the line.
						chart.lines.dispatch.on('elementClick', function (d) {
							onClick(d.data.series, d.index); //@JC
						});
						break;

					// @MS stack area chart
					case 7:
						// set specific properties for stackedAreaChart
						// @JC Please use customMargin variable to set custom margins for the chart!
						var customMargin = { // last part of addition represents custom margin you want to use to adjust chart appearance
							left: 0,
							bottom: 0,
							top: 20, // @JC If legend or/and controls are shown, top part of margin is always increased at least to legend or controls height internally.
							right: 20, // @MP More space because the label starts to the right of the last line DOT on the  horizontal axis // @JC Please use rightChartMargin variable to set custom right margin of the chart!
						}

						chart
							//.valueToString(valueToString) // @MP - value formatting.
							.foreColor(settings.foreColor)
							.showTotalInTooltip(false)
							.duration(0)
							.showLegend(numOfSeries > 1) // condition for showing legend only if # series is  2 or more
							.showYAxis(true) // turn on showing labels on yAxis
							.noData(settings.noDataText);	// set noData message

						if (settings.chartStyle === 1) {
							chart
								.showControls(false)
								.style('stack');
						}
						else if (settings.chartStyle === 2) {
							chart
								.showControls(false)
								.style('expand');
						}
						else
							chart.showControls(numOfSeries > 1);

						// specific properties of xAxis
						chart.xAxis
							.axisLabel(settings.labelAxisTitle)	// set xAxis label
							.rotateLabels(settings.angle) // set angle of rotation each label, @MP: alwasy rotate labels!
							.showMaxMin(false) // furn off showing minimum and maximum value
							.useLocaleOptions(false) // turn on using locale value of yAxis tickLabels
							.axisLabelDistance(0) // set distance of main axis label // @JC axisLabelDistance can be used, but it is not included into minXAxisMargin, because it is not known yet when minXAxisMargin is computed.
							.tickFormat(function (d, i) {
								return labels[i];
							})
							.highlightZero(false); // turn off highlighting of zero value

						// specific properties of yAxis
						chart.yAxis
							.axisLabel(settings.valueAxisTitle) // set yAxis label
							.showMaxMin(false) // turn off showing bold minimum and maximum value
							.highlightZero(false) // turn off highlight of zero value
							.useLocaleOptions(true)
							.axisLabelDistance(0) // @JC axisLabelDistance can be used, but it is not included into minYAxisMargin, because it is not known yet when minYAxisMargin is computed.
							.localeOptions(settings.localeOptions); // set parameters by that will be changed tick labels.
						//.rotateYLabel(true);  // turn on rotation main of yAxis // @JC This is not necessary, becuase rotateYLabel is set to true by default internally.

						prepareMinAxisMargins(customMargin, numOfSeries, valuesCount); // @JC: This function must be called after all settings of the chast are set and before margins of the chart are set!

						chart
							.margin({ // last part of addition represents custom margin you want to use to adjust chart appearance
								left: settings.minRoundingMargin + minYAxisMargin + customMargin.left,
								bottom: settings.minRoundingMargin + minXAxisMargin + customMargin.bottom,
								top: settings.minRoundingMargin + customMargin.top, // @JC If legend is shown, top part of margin is always increased to legend height internally.
								right: settings.minRoundingMargin + (customMargin.right > minRightMargin ? customMargin.right : minRightMargin),
							})

						// computes minimal necessary width that is required for drawing column bars
						//@JC When lines below are changed, it is necessary to made the same change in the getPrecomputedAvailableWidthForBars() function!
						minChartAreaWidth = getMinChartAreaWidth();

						// call OnClick function after click on the bar.
						chart.stacked.dispatch.on('elementClick', function (d) {
							onClick(d.data.series, d.index); //@JC
						});
						break;
				}
			}

			settings.chartWrapper.style.width = (minChartAreaWidth >= settings.width) ? (minChartAreaWidth - settings.chartWrapperMargin) + "px" : (settings.width - settings.chartWrapperMargin) + "px";
			settings.chartWrapper.style.height = (minChartAreaHeight >= settings.height) ? (minChartAreaHeight - settings.chartWrapperMargin) + "px" : (settings.height - settings.chartWrapperMargin) + "px";
		}
		// set default settings for all charts if they have no data.
		else {
			chart.noData(settings.noDataText);
			chart.margin({ left: 0, top: 0, right: 0, bottom: 0 });

			var size = nv.utils.windowSize();
			settings.chartWrapper.style.width = (size.width - settings.chartWrapperMargin) + "px";
			settings.chartWrapper.style.height = (size.height - settings.chartWrapperMargin) + "px";
		}

		function setupBarChart(chartData) {
			getMaxLabelLength(chartData);
			var labels = getValuesX(numOfSeries > 0 ? chartData[0] : undefined);

			// @MP We already clamp the maximum label length in the above method.
			settings.maxXLabelLength = (maxXLabelLength * settings.letterPixelSize);// + settings.minimumXaxisMargin;
			settings.maxYLabelLength = settings.letterHeight;

			calculateLabelAngle(valuesCount); // Adjusts settings.maxXLabelLength according to rotation under settings.angle.

			// set specific properties for barChart
			// @JC Please use customMargin variable to set custom margins for the chart!
			var customMargin = { // last part of addition represents custom margin you want to use to adjust chart appearance
				left: 0,
				bottom: 0,
				top: 20, // @JC If legend or/and controls are shown, top part of margin is always increased at least to legend or controls height internally.
				right: 20, // @MP More space because the label starts to the right of the last line DOT on the  horizontal axis // @JC Please use rightChartMargin variable to set custom right margin of the chart!
			}

			chart
				.foreColor(settings.foreColor)
				.valueToString(valueToString)   // @MP - value formatting.
				.noData(settings.noDataText)	// set noData message
				.duration(0)
				.showLegend(numOfSeries > 1) // condition for showing legend only if # series is  2 or more
				.showBarLabels(false) // turn off showing on left side xAxis next labels with same size.
				.showValues(true) // turn on showing vlaues by each bar
				.showYAxis(true) // turn on showing labels on yAxis
			//.tooltip.enabled(false);	// turn off tooltip for this type of chart. //@JC

			if (settings.chartStyle === 1) {
				chart.multibar.stacked(true);
				chart.showControls(false);
			}
			else if (settings.chartStyle === 2) {
				chart.multibar.stacked(false);
				chart.showControls(false);
			}
			else
				chart.showControls(numOfSeries > 1);

			// specific properties of xAxis
			chart.xAxis
				.rotateLabels(settings.angle) // set angle of rotation each label, @MP: alwasy rotate labels!
				.axisLabel(settings.labelAxisTitle)	// set xAxis label
				.axisLabelDistance(0) //@JC
				//.isHorizontalBarAxis(true) // @JC: isHorizontalBarAxis function can not be used more, because chart orientation is now detected from chart.settings.type property automatically.
				.useLocaleOptions(false) // turn on using locale value of yAxis tickLabels
				// change format of tick and replace indexies by labels (it uses because formatted labels were removed)
				.tickFormat(function (d, i) {
					return labels[i];
				})
				.showMaxMin(false) // furn off showing minimum and maximum value
				.highlightZero(false); // turn off highlighting of zero value
			//.rotateYLabel(true); // turn on rotation main of yAxis //@JC If chart type is multiBarHorizontalChart, rotateYLabel must be set to true at xAxis, because xAsis is used as Y Axis (and yAxis is use as XAxis) in this case. // @JC This is not necessary, becuase rotateYLabel is set to true by default internally.

			// specific properties of yAxis
			chart.yAxis
				.axisLabel(settings.valueAxisTitle) // set yAxis label
				.showMaxMin(false) // turn off showing bold minimum and maximum value
				.highlightZero(false) // turn off highlight of zero value
				.axisLabelDistance(0) //@JC
				.useLocaleOptions(true) // turn on using locale value of yAxis tickLabels
				.localeOptions(settings.localeOptions); // set parametes by that will be changed tick labels.
			//.rotateYLabel(true);  // turn on rotation main of yAxis // @JC This is not necessary, becuase rotateYLabel is set to true by default internally.

			chart.multibar.localeOptions(settings.localeOptions); // Change format by locale options of labels showing values after bar.

			prepareMinAxisMargins(customMargin, numOfSeries, valuesCount); // @JC: This function must be called after all settings of the chast are set and before margins of the chart are set!

			chart
				.margin({ // last part of addition represents custom margin you want to use to adjust chart appearance
					left: settings.minRoundingMargin + minXAxisMargin + customMargin.left,
					bottom: settings.minRoundingMargin + minYAxisMargin + customMargin.bottom,
					top: settings.minRoundingMargin + (customMargin.top > minRightMargin ? customMargin.top : minRightMargin), // @JC If legend is shown, top part of margin is always increased to legend height internally.
					right: settings.minRoundingMargin + customMargin.right,
				})

			// call OnClick function after click on the bar.
			chart.multibar.dispatch.on('elementClick', function (d) {
				onClick(d.data.series, d.index); //@JC
			});

			// computes minimal necessary height that is required for drawing horizontal bars
			//@JC When lines below are changed, it is necessary to made the same change in the getPrecomputedAvailableHeightForBars() function!
			return getMinChartAreaHeight();
		}

		function setupPieChart(chartData) {
			// find out which labels are longer as 30 characters, and cut it.
			for (var i = 0; i < chartData.length; i++) {
				if ((chartData[i].label.length) > 30)
					chartData[i].label = chartData[i].label.substring(0, 30) + "...";
			}
			var legendEnabled = false; // field that says chart about enabling of legend by the size of window and number of values.
			if (chartData.length <= 10)
				legendEnabled = true;
			else if ((chartData.length <= 25) && ((settings.height > 400 && settings.width > 300) || (settings.height > 300 && settings.width > 400)))
				legendEnabled = true;
			else if ((chartData.length <= 50) && ((settings.height > 600 && settings.width > 400) || (settings.height > 400 && settings.width > 600)))
				legendEnabled = true;
			else if ((chartData.length <= 100) && ((settings.height > 900 && settings.width > 600) || (settings.height > 600 && settings.width > 900)))
				legendEnabled = true;
			chart
				.x(function (d) { return d.label })	// set label for every pie for piechart
				.y(function (d) { return d.y })	// set value for every pie of pieChart
				.showLegend(legendEnabled)	// enabled / disabled legend of chart.
				.showLabels(settings.pieLabelStyle !== 2)	// @MS turn on labels for chart.
				.labelType("value")	// turn specific type of showing labels another types are for example percentage.
				.valueToString(valueToString) // @MP - value formatting.
				.noData(settings.noDataText)
				.duration(0)
				.foreColor(settings.foreColor)
			//.tooltip.enabled(false); // turn off tooltips for this chart. //@JC

			chart.pie.localeOptions(settings.localeOptions); // Change format by locale options of labels showing values next the pie.

			if (settings.type === 5) {
				var donutRatio = settings.pieDonutRatio / 100;
				chart.pie
					.donut(true)
					//.cornerRadius(5)
					//.padAngle(.2) 
					.donutRatio(donutRatio);   // donuts ratio is in percentage. needs to be converted
			}
			if (settings.pieLabelStyle === 0) {
				chart.pie
					.pieLabelsOutside(false)
					.donutLabelsOutside(false);
			}
			else if (settings.pieLabelStyle === 1) {
				chart.pie
					.pieLabelsOutside(true)
					.donutLabelsOutside(true);
			}

			// call OnClick function after click on the pie.
			chart.pie.dispatch.on('elementClick', function (d) {
				onClick(0, d.index);
			});
		}

		// @JM implementation
		function setupGaugeChart(chatData) {
			// prepare data
			var _gValue = 0; // value must be provided
			var _gTarget = null;
			var _gMax = null;
			var _gMin = null;

			// check for value and if target, mix or max comes from entity / fetch
			for (var i = 0; i < chartData.length; i++) {
				switch (chartData[i].key) {
					case "MinValue":
						_gMin = chartData[i].values[0].y;
						break;
					case "MaxValue":
						_gMax = chartData[i].values[0].y;
						break;
					case "TargetValue":
						_gTarget = chartData[i].values[0].y;
						break;
					case "chartseries0":
					default:
						_gValue = chartData[i].values[0].y;
						break;
				}
			}

			// if target, mix or max comes from constant - zero is the default value
			_gMin = (_gMin ? _gMin : settings.gaugeMin);
			_gMax = (_gMax ? _gMax : settings.gaugeMax);
			_gTarget = (_gTarget ? _gTarget : (settings.gaugeTarget === 0 ? null : settings.gaugeTarget)); // don't use target if set to default

			var _gTaragetText = _gTarget;
			var _gValueText = _gValue;

			// prepare the values 
			_gMax = (_gMax ? _gMax : _gValue * 2);
			if (_gTarget && _gTarget > _gMax)
				_gMax = _gTarget;

			if (_gValue > _gMax)
				_gMax = _gValue;

			if (_gMin) {
				_gValue -= _gMin;
				_gMax -= _gMin;
				if (_gTarget) {
					_gTarget -= _gMin;
					_gTarget = (_gTarget < 0 ? 0 : _gTarget);
				}

				// don't allow negative values
				_gValue = (_gValue < 0 ? 0 : _gValue);
				_gMax = (_gMax < 0 ? 0 : _gMax);
			}

			_gMin = (_gMin ? _gMin : 0);

			// create pseudo data for the chart
			if (_gTarget || _gTarget == 0) {

				// !! handle chart size so that bottom half is not empty

				var _cNormalizer = _gMax / 1000.0; // normalize the values to 1000 as max
				var _c1, _c2, _c3;
				var _targetWidth = 5;

				// target can fall either in the value or after it
				if (_gTarget < _gValue) {
					_c1 = _gTarget / _cNormalizer;
					_c2 = (_gValue - _gTarget) / _cNormalizer;
					_c3 = (_gMax - _gValue) / _cNormalizer;
					chartData = [
						{ label: "", x: 0, y: _c1, color: "#00B8AA" },
						{ label: "" + _gTaragetText, x: 1, y: _targetWidth, color: "#000000" },
						{ label: "", x: 2, y: _c2, color: "#00B8AA" },
						{ label: "", x: 3, y: _c3, color: "#EEEEEE" }
					];
				} else {
					_c1 = _gValue / _cNormalizer;
					_c2 = (_gTarget - _gValue) / _cNormalizer;
					_c3 = (_gMax - _gTarget) / _cNormalizer;
					chartData = [
						{ label: "", x: 0, y: _c1, color: "#00B8AA" },
						{ label: "", x: 1, y: _c2, color: "#EEEEEE" },
						{ label: "" + _gTaragetText, x: 2, y: _targetWidth, color: "#000000" },
						{ label: "", x: 3, y: _c3, color: "#EEEEEE" }
					];
				}


			} else {
				// no target was specified, therefore it is a gauge without the marker - two chart parts only
				var _cNormalizer = _gMax / 1000.0; // normalize the values to 1000 as max
				var _c1 = _gValue / _cNormalizer;
				var _c2 = (_gMax - _gValue) / _cNormalizer;
				chartData = [{ label: "", x: 0, y: _c1, color: "#00B8AA" }, { label: "", x: 1, y: _c2, color: "#EEEEEE" }];
			}

			// prepare the chart
			chart
				.x(function (d) { return (d.label ? valueToString(d.label) : d.label) })
				.y(function (d) { return d.y })
				.donut(true)
				.foreColor(settings.foreColor)
				.showTooltipPercent(false)
				.showLegend(false)      // no legend
				.growOnHover(false)
				.valueToString(valueToString)
				.noData(settings.noDataText)
				.labelThreshold(0.001)  // show label for the marker
				.titleOffset(Math.round((settings.width > settings.height ? settings.height : settings.width) / 10))   // @JM - offset the title relatively to chart size
				.id('gauge'); // allow custom CSS for this one svg

			// set the chart so that it shows donut in the top half
			chart.pie.donutLabelsOutside(true)
				.startAngle(function (d) {
					return (d.startAngle / 2) - Math.PI / 2;
				})
				.endAngle(function (d) {
					return (d.endAngle / 2) - Math.PI / 2;
				})
				.color(function (d, i) {
					return chartData[i].color;
				});

			chart.title(valueToString(_gValueText)); // set value as title


			chart.pie.localeOptions(settings.localeOptions); // Change format by locale options of labels showing values next the pie.

			// no chart click!
		}

		function calculateLabelAngle(valuesCount) {
			settings.angle = -45; // @MP

			if (false) { // @MP: For now always rotate
				if (valuesCount <= 30) {
					if (settings.width / settings.maxXLabelLength > valuesCount) {
						settings.angle = 0;
					}
					else
						settings.angle = -45;
				}
				else
					settings.angle = -45;
			}

			if (settings.angle == 0) {
				settings.maxXLabelLength = settings.minimumXaxisMargin;
			} else if (settings.angle == -45) {
				settings.maxXLabelLength = (settings.maxXLabelLength / 1.4142) + settings.xComponentOfLetterHeight; //@JC If text is rotated, there must be taken in to account length component of the text height also!
			}
		}
		// unused, maybe in the future.
		function calculateYLabelAngle(labelsCount) {
			settings.angle = -45; // @MP

			if (false) {
				if (labelsCount <= 30) {
					if (settings.width / settings.maxYLabelLength > labelsCount) {
						settings.angle = 0;
					}
					else
						settings.angle = -45;
				}
				else
					settings.angle = -45;
			}

			if (settings.angle == 0) {
				settings.maxYLabelLength = settings.minimumYaxisMargin;
			} else if (settings.angle == -45) {
				settings.maxYLabelLength = (settings.maxYLabelLength / 1.4142) + settings.xComponentOfLetterHeight; //@JC If text is rotated, there must be taken in to account length component of the text height also!
			}
		}
		//------------------------------------------------------------

		// @MP
		// Convert number to string. Only show X decimal places, show thousands separator and append currency.
		// For regex explanation see http://stackoverflow.com/questions/2901102/how-to-print-a-number-with-commas-as-thousands-separators-in-javascript
		function valueToString(val, seriesIndex, availWidth) {
			if (typeof val !== "number") {
				val = new Number(val);
			}
			if (isNaN(val))
				return "";

			var currencySymbol = settings.localeOptions.currencySymbol;
			var precision = settings.localeOptions.maximumFractionDigits;

			if (seriesIndex !== undefined && settings.seriesFormattingInfo && seriesIndex >= 0 && seriesIndex < settings.seriesFormattingInfo.length) {
				var si = settings.seriesFormattingInfo[seriesIndex];
				if (!si.IsMoneyAggregate)
					currencySymbol = undefined;
				if (!isNaN(+si.Precision))
					precision = +si.Precision;
			}

			var strVal;
			if (precision !== undefined && precision >= 0)
				strVal = val.toFixed(precision);
			else
				strVal = val.toString();

			var ts = settings.localeOptions.thousandSeparator;
			var ds = settings.localeOptions.decimalSeparator;

			if (ts || ds) {
				var parts = strVal.split(".");
				if (ts)
					parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ts);

				if (!ds)
					ds = ".";

				strVal = parts.join(ds);
			}

			if (currencySymbol)
				strVal = currencySymbol + " " + strVal;

			if (availWidth !== undefined && strVal.length > availWidth) {
				strVal = d3.format(".2s")(val);
				if (currencySymbol)
					strVal = currencySymbol + strVal;
			}
			return strVal;
		}

		return chart;
	}

	var nvChart = updateChart(this.nvChart, this.settings); // update chart and settings of the graph 
	var settings = this.settings;

	// call method of nvd3 lib with our dataset and our updated chart.
	nv.addGraph(function () {
		d3.select("#chartSVG")
			.datum(chartData)  // tell function what is dataset
			.call(nvChart);	   // tell function what draw

		// to handle special styling for gauge chart
		if (settings.type == 6) {

			// don't draw strokes around the arcs / paths
			var elem = $(".nvd3.nv-pie path");
			for (var i = 0; i < elem.length; i++) {
				elem[i].style.strokeWidth = "0px";
			}

			var screenSize = (settings.width > settings.height ? settings.height : settings.width);
			var smallFontsize = Math.round(screenSize / 30);
			var largeFontsize = Math.round(screenSize / 10);

			// label text sizes
			elem = $(".nvd3 text");
			for (var i = 0; i < elem.length; i++) {
				elem[i].style.fontSize = smallFontsize + "px";
			}

			// title text size
			elem = $(".nv-pie-title");
			for (var i = 0; i < elem.length; i++) {
				elem[i].style.fontSize = largeFontsize + "px";
			}

		}

		// 
		window.onresize = function () {
			var newSize = nv.utils.windowSize();
			if ((newSize.width / newSize.height).toFixed(1) != settings.windowRatio) {
				MobileCRM.bridge.command("reload", null);
			}
		};

		return nvChart;
	});
}
