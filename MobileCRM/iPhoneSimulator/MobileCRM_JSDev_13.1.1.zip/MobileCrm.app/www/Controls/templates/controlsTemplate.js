﻿///<reference path="../TypeScriptDefinitions/knockout.d.ts" />

function registerColorPickerComponent() {
    ko.components.register("colorPicker", {
        viewModel: Resco.Controls.ColorPicker,
        template: "\
            <!-- ko ifnot: isOpened() -->\
                <div class='simpleColorPicker' pickerStatus='closed'>\
                    <div class='selectedColor' data-bind='click: openColorPicker'>\
                        <div><span data-bind='text: selectedColor'></span></div>\
                        <div class='color' data-bind='style: { backgroundColor: selectedColor }'></div>\
                    </div>\
                </div>\
            <!-- /ko -->\
            <!-- ko if: isOpened() -->\
                <div class='simpleColorPicker' pickerStatus='opened' data-bind='style: { left: leftPosition() + \"px\", top: topPosition() + \"px\", width: width + \"px\", height: height + \"px\" }' >\
                    <div class='palette'>\
                        <!-- ko foreach: rows -->\
                            <div class='paletteRow' data-bind='style: { height: $parent.colorElementHeight + \"px\"}'>\
                                <!-- ko foreach: $parent.columns -->\
                                    <div class='paletteCell' data-bind='style: { height: $parents[1].colorElementHeight + \"px\", width: $parents[1].colorElementWidth + \"px\" } '>\
                                        <div class='paletteColor' data-bind='click: function(data, event) {$parents[1].closeColorPicker($index(), $parentContext.$index(), data, event) }, style: { backgroundColor: $parents[1].getColor($index(), $parentContext.$index()) }'>\
                                            <!-- ko if: ($parents[1].getColor($index(), $parentContext.$index()) === $parents[1].selectedColor() ) -->\
                                                <div class='selectedMark'></div>\
                                            <!-- /ko -->\
                                        </div>\
                                    </div>\
                                <!-- /ko -->\
                            </div>\
                        <!-- /ko -->\
                    </div>\
                </div>\
                <div class='backend' data-bind='style: { height: sizeMonitor.contentClientHeight() + \"px\", width: sizeMonitor.contentClientWidth() + \"px\" }, click: function(data, event) { closeColorPicker(-1, -1, data, event) } '></div>\
            <!-- /ko -->"
    });
}

function registerSelectionListComponent() {
    ko.components.register('selectionListComponent', {
        viewModel: Resco.Controls.SelectionList,
        template: "\
			<div class='content entitySection' data-bind='style: { height: sizeMonitor.contentHeight() + \"px\", backgroundColor: $root.formBackgroundColor }'>\
			<!-- ko foreach: items -->\
                <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='component' data-bind='click: function(data, event) { $parent.confirmSelectedEntity($index(), data, event) }, style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class='componentPart'>\
						<div class='entityLabel'>\
							<div class='alignBlock'>\
								<span class='blockElement' data-bind='text: displayName'></span>\
							</div>\
						</div>\
					</div>\
				</div>\
			<!-- /ko -->\
			</div>"
    });
}

function registerImageBar() {
    ko.components.register("imageBar", {
        viewModel: Resco.Controls.ImageBar,
        template: "\
			<div class='imageBar' data-bind='style: { backgroundColor: $root.formBackgroundColor }'>\
			<!-- ko foreach: images -->\
                <!-- ko if: enabled() -->\
                    <div class='icon' data-bind='click: $parent.clickOnItem.bind($parent), style: { backgroundImage: path, width: width() + \"px\" }, css: { selectedIcon: selected() }'>\
                    </div>\
                <!-- /ko -->\
                <!-- ko ifnot: enabled() -->\
                    <div class='icon disabled' data-bind='style: { width: width() + \"px\", backgroundImage: path } '></div>\
                <!-- /ko -->\
			<!-- /ko -->\
			</div>"
    });
}

function registerListBox() {
    ko.components.register("list-box", {
        viewModel: Resco.Controls.ListBox,
        template: "\
            <div class='list-box' data-bind='style: { height: height + \"px\", width: width + \"px\", backgroundColor: $root.formItemBackgroundColor }'>\
                <!-- ko foreach: items -->\
                    <!-- ko ifnot: isEnabled() -->\
                        <div class='list-box-item' data-bind='style: { backgroundColor: $root.listBackgroundColor } '>\
                            <!-- ko if: $parent.ownTemplate !== undefined -->\
                                <div class='own-template text' data-bind='html: $parent.ownTemplate'></div>\
                            <!-- /ko -->\
                            <div class='text'>\
                                <span data-bind='text: label, style: {  color: $root.formItemDisabledColor }'></span>\
                            </div>\
                        </div>\
                    <!-- /ko -->\
                    <!-- ko if: isEnabled() -->\
                        <div class='list-box-item' data-bind='click: listBoxItemClicked, style: { backgroundColor: isSelected() ? $root.listSelBackgroundColor : $root.listBackgroundColor } '>\
                            <!-- ko if: $parent.ownTemplate !== undefined -->\
                                <div class='own-template text' data-bind='html: $parent.ownTemplate'></div>\
                            <!-- /ko -->\
                            <div class='text'>\
                                <span data-bind='text: label, style: {  color: isSelected() ? $root.listSelForegroundColor : $root.listForegroundColor }'></span>\
                            </div>\
                        </div>\
                     <!-- /ko -->\
                    <div class='separator' data-bind='style: { backgroundColor: $root.listSeparatorColor }'></div>\
                <!-- /ko -->\
            </div>"
    });
}

function registerComboBox() {
    registerListBox();

    ko.components.register("combo-box", {
        viewModel: Resco.Controls.ComboBox,
        template: "\
            <div class='combo-box'>\
                <div class='display-label' data-bind='click: openComboBox'>\
                    <div class='combo-box-label text' data-bind='style: { backgroundColor: $root.formItemBackgroundColor }, text: displayLabel, attr: { \"comboBoxStatus\": isOpened ? \"open\": \"closed\" }'></div>\
                    <div class='combo-mark'><div class='arrow'></div></div>\
                </div>\
                <!-- ko if: isOpened-->\
                    <list-box params='\
                            dataSource: listBoxParameters.dataSource,\
                            displayMember: listBoxParameters.displayMember,\
                            valueMember: listBoxParameters.valueMember,\
                            statusMember: listBoxParameters.statusMember,\
                            windowMonitor: listBoxParameters.windowMonitor,\
                            width: listBoxParameters.width,\
                            height: listBoxParameters.height,\
                            selectedItem: listBoxParameters.selectedItem,\
                            selectionChanged: onSelectedItemChanged,\
                            dimensionChanged: onListBoxDimensionChanged,\
                            template: listBoxParameters.template'\
                        data-bind='style: { top: position.top() + \"px\", left: position.left() + \"px\" }'>\
                    </list-box>\
                    <div class='backend' data-bind='style: { height: listBoxParameters.windowMonitor.contentClientHeight() + \"px\", width: listBoxParameters.windowMonitor.contentClientWidth() + \"px\" }, click:closeComboBox '></div>\
                <!-- /ko -->\
            </div>"
    });
}

function registerTreeView() {
    var addTemplate = function (templateName, templateMarkup) {
        document.write("<script type='text/html' id='" + templateName + "'>" + templateMarkup + "<" + "/script>");
    };

    addTemplate("treeViewItem",
        "\
        <!-- ko if: parent !== null -->\
            <!-- ko if: $data.hasChildren -->\
                <div class='bindingEntity' data-bind=\"click: treeViewItemClick, style: { paddingLeft: $data.depth + 'em' }\">\
                    <div class='mark' data-bind='css:{ expandedMark: $data.isExpanded() }, style: { borderRightColor : $root.listForegroundColor, borderBottomColor : $root.listForegroundColor } '></div>\
                    <span class='displayNameColumn' data-bind=\"text: $data.label, style: { color:  $root.listForegroundColor } \" ></span>\
                </div>\
            <!-- /ko -->\
            <!-- ko if: !$data.hasChildren -->\
                <div class=\"bindingEntity\" data-bind=\"attr: {'data-isSelected': isSelected() }, click: treeViewItemClick, style: { paddingLeft: $data.depth + 'em', backgroundColor: isSelected() ? $root.listSelBackgroundColor : $root.listBackgroundColor }\">\
                    <div class='text'>\
                        <span class='displayNameColumn' data-bind=\"text: $data.label,  style: { color: $data.isSelected() ? $root.listSelForegroundColor : $root.listForegroundColor } \"></span>\
                    </div>\
                </div>\
            <!-- /ko -->\
            <div class='rowSeparator' data-bind='style: { backgroundColor: $root.listSeparatorColor }'></div>\
        <!-- /ko -->\
        <!-- ko if: $data.children && $data.isExpanded() -->\
            <div class='children'>\
                <!-- ko template: { name: \"treeViewItem\", foreach: $data.children() } --><!-- /ko -->\
            </div>\
        <!-- /ko-->\
    ");


    ko.components.register("tree-view", {
        viewModel: Resco.Controls.TreeView,
        template: "\
            <div class='tree-view'>\
                <div class='display-label' data-bind='click: openTreeView'>\
                    <div class='tree-view-label text' data-bind='style: { backgroundColor: $root.formItemBackgroundColor }, text: displayLabel, attr: { \"comboBoxStatus\": isOpened ? \"open\": \"closed\" }'></div>\
                    <div class='tree-view-mark'><div class='arrow'></div></div>\
                </div>\
                <!-- ko if: isOpened -->\
                    <div class='treeView' treeViewComboBoxStatus='opened' data-bind='style: { backgroundColor: $root.listBackgroundColor, left: position.left() + \"px\", top: position.top() + \"px\", width: dimension.width + \"px\", height: dimension.height + \"px\" }'>\
                        <div class='childrenPart' data-bind='style: { height: isMultiselect ? childrenPartHeight + \"px\" : \"\" }'>\
                            <!-- ko template: { name: \"treeViewItem\", data: rootNote } --><!-- /ko -->\
                        </div>\
                        <!-- ko if: isMultiselect -->\
                            <div class='buttons' data-bind='style: { height: bottomButtonsBarHeight + \"px\" } '>\
                                <div data-bind='click: confirmTreeViewItems'>OK</div>\
                            </div>\
                        <!-- /ko -->\
                    </div>\
                    <div class='backend' data-bind='style: { height: windowMonitor.contentClientHeight() + \"px\", width: windowMonitor.contentClientWidth() + \"px\" }, click:closeTreeView '></div>\
                <!-- /ko -->\
            </div>"
    });
}
