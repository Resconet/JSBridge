﻿///<reference path="../knockout-3.2.0.min.js" />
function showFadeInPost(elem) {
	if (elem.nodeType === 1) {
		$(elem).hide().fadeIn();
	}
}
function writeTemplates() {

    var addTemplate = function (templateName, templateMarkup) {
        $(document.body).append("<script type='text/html' id='" + templateName + "'>" + templateMarkup + "</script>");
    };
    var localize = Chatter.Localization.get;

    //<button data-bind=\"click: showOlder, attr: {disabled: !hasOlderPosts()}\">Show Older Posts</button>\

	addTemplate("tmplChatter",
	"<!-- ko if: navBar.visible() > 0 -->\
		<div align='center' class='side_menu' data-bind='css: { side_menu_open: showChannels() }'>\
            <span class='side_menu_toggle' onclick='topic.toggleChannels()' data-bind='css: { side_menu_toggle_open: showChannels() }'></span>\
			<div align='left' class='side_menu_content scrollable' data-bind='css: { side_menu_content_open: showChannels() }'>\
				<ul id=\"frequent_channels\">\
					<!-- ko if: navBar.showChannels -->\
					<li>" +
						//<span class='navbar-plus' data-bind='click: browseChannels'><img src='images/add.png'/></span>\
						"<div class='navbar-title' data-bind='click: browseChannels'>" + localize("Channels") + "</div>\
					</li>\
					<!-- ko foreach: navBar.visibleChannels -->\
						<!-- ko template: { name: 'tmplChannel' } --><!-- /ko -->\
					<!-- /ko -->\
					<!-- /ko -->\
					<li>"+
						//<span class='navbar-plus' data-bind='click: browseUsers'><img src='images/add.png'/></span>\
						"<div class='navbar-title' data-bind='click: browseUsers'>" + localize("DirectMessages") + "</div>\
					</li>\
					<!-- ko foreach: navBar.visibleUsers -->\
						<!-- ko template: { name: 'tmplChannel' } --><!-- /ko -->\
					<!-- /ko -->\
				</ul>\
			</div>\
		</div>\
	<!-- /ko -->\
    <div class='horizontal-menu' data-bind='click: closeChannels, css: { wall: !(navBar.visible() > 0) }'>\
        <!-- ko if: channelName() -->\
            <div id='topic-name-text' align='center'><span data-bind='text: channelName, click: onHeaderChannelClick, css:{ headerlink: channelType() }'></span><span data-bind='text: channelType'></span></div>\
        <!-- /ko -->\
		<div style='margin: 0;'>"+
	    //<!-- ko if: unreadedMessages() > 0 -->\
	    //    <span onclick=\"topic.ShowNewMessages()\" align=\"center\" id=\"newMessageToaster\" data-bind\"text: unreadedMessagesText\"></span>\
        //<!-- /ko -->\
        "<!-- ko if: showFollowingButton() -->\
	        <span class=\"chatter-link-header chatter-link-text\" data-bind=\"click: toggleFollow, text: followText\"></span>\
        <!-- /ko -->\
        <!-- ko if: isPrivate() -->\
	        <span class=\"chatter-link-header chatter-link-text\" data-bind=\"click: inviteUsers\">" + localize("InviteUsers") + "</span>\
        <!-- /ko -->\
		</div>\
    </div>\
	<div id='chat_view' data-bind=\"css: { standalone: !navBar.visible() }, click: closeChannels\">\
		<div class=\"chatter-window scrollable\" data-bind=\"event: { scroll: onScroll }\">\
            <div id='chatter-header' style='position:relative;min-height:70px' \">\
			    <div id=\"chatter-loader\" style='position:absolute;left:0;right:0;bottom:0' data-bind=\"style: { visibility: hasOlderPosts() ? 'visible' : 'hidden'} \" align=\"center\"><img src=\"./images/loading.gif\" /></div>\
                <div id='initial-message' data-bind=\"style: { visibility: hasOlderPosts() ? 'hidden' : 'visible'}\" ><h2>" + localize('Welcome') + "</h2><p data-bind='text: welcomeMessage()'></p></div>\
            </div>\
		    <div class=\"chatter-posts\" data-bind=\"template: { name : 'tmplPost', foreach: posts }\"></div>\
		</div>\
        <div class='attachment_dropdown' data-bind='click: showAttachmentMenu'>\
	        <span class='attachment_dropdown_toggle'></span>\
		</div>\
        <div class='emoticons_dropdown' aria-haspopup='true' ontouchstart=''>\
                <span class='emoticons_dropdown_toggle' data-bind='css: { wall: !(navBar.visible() > 0) }'></span>\
		        <div class='emoticons_dropdown_content' data-bind='css: { wall: !(navBar.visible() > 0) }'>\
                </div>\
        </div>\
		<div class='post-editor scrollable' data-bind='css: { wall: !(navBar.visible() > 0) }, click: postEditorFocus'>\
			<div contenteditable='true' id='postEditor' placeholder='" + localize('WritePost') + "' data-bind='click: postEditorFocus'></div>\
		</div>\
        <div id='send-message' onclick='topic.submitPost()'>\
            <span id='send-message-button'>Send</span>\
        </div>\
	</div>\
	<!-- ko template: { name: 'tmplChannelBrowser', data: channelBrowser } --><!-- /ko -->\
	<!-- ko template: { name: 'tmplCreateChannel', data: channelBrowser.createChannelFrame } --><!-- /ko -->\
	<!-- ko template: { name: 'tmplAttachmentDlg', data: Chatter.AttachmentDlg.instance } --><!-- /ko -->\
	");

	addTemplate("tmplAttachmentDlg",
		"<!-- ko if: visible() -->\
			<div class='attachmentDlg dlgModal' data-bind='event:{keypress: onKeyPress}'>\
				<img class='btn btnClose' src='images/Back.png' data-bind='click: onClose'/>\
				<div class='dlgHeader'>\
						<div class='attachmentImg'>\
							<img data-bind='attr: {src: imageUrl()}'/>\
							<div class='fileName' data-bind='text: fileName'></div><div data-bind='text: mimeType'></div>\
						</div>\
						<label>Title:</label><input class='attachmentTitle dlgInput' placeholder='Title' data-bind=\"value: title,valueUpdate:'keyup'\" />\
						<label>Comment:</label><input class='attachmentComment dlgInput' placeholder='Comment' data-bind=\"value: comment, valueUpdate:'keyup'\" />\
						<a class='btn right' data-bind='click: onSubmit'>OK</a>\
				</div>\
			</div>\
		<!-- /ko -->\
	");

	addTemplate("tmplChannelBrowser",
		"<!-- ko if: visible() -->\
		<div class='channelBrowser dlgModal' data-bind='event:{keypress: onKeyPress}'>\
			<img class='btn btnClose' src='images/Back.png' data-bind='click: function(){visible(false);}'/>\
			<div class='dlgHeader'>\
				<div class='channelSearch'>\
					<!-- ko if: newChannelCallback -->\
					<img class='btn right btnAdd' src='images/New.png' data-bind='click: createChannel'/>\
					<!-- /ko -->\
					<h2><span data-bind='text: title'></span></h2>\
					<input class='channelSearchInput dlgInput' data-bind=\"value: filterText, valueUpdate:'keyup', event:{keypress: onKeyPress}, attr:{placeholder: placeHolder}\" />\
				</div>\
			</div>\
			<div class='channelBrowserBody'>\
				<div class='channelBrowserList'>\
					<!--ko foreach: itemsVisible-->\
					<!--ko template: { name: 'tmplChannelBrowserItem' } --><!-- /ko-->\
					<!-- /ko-->\
					<!--ko foreach: otherItemsVisible-->\
					<!--ko template: { name: 'tmplChannelBrowserItem' } --><!-- /ko-->\
					<!-- /ko -->\
				</div>\
			</div>\
		</div>\
		<!-- /ko -->\
	");

    addTemplate("tmplChannelBrowserItem",
		"<!-- ko if: title() -->\
		<strong data-bind='text: title' class='channelBrowserSectionHeader'></strong>\
		<!-- /ko-->\
		<div class='channelBrowserItem' data-bind='click: onClick, css: {selected: selected()}'>\
			<img class='channelicon' data-bind='appImage: icon'/>\
			<span class='channelBrowserItemName' data-bind='text: name, visible: visible'></span>\
		</div>\
	");

    addTemplate("tmplCreateChannel",
		"<!-- ko if: visible() -->\
		<div class='createChannelFrame dlgModal' data-bind='event:{keypress: onKeyPress}'>\
		<img class='btn btnClose' src='images/Back.png' data-bind='click: close' />\
		<div class='dlgHeader'>\
			<div class='channelSearch'>\
				<h2><span data-bind='text: title'></span></h2>\
				<input class='createChannelInput dlgInput' placeholder='Channel Name' data-bind=\"value: name, valueUpdate:'keyup', event:{keypress: onKeyPress}\" />\
				<a class='checkbox' data-bind='click: onPrivateBtnClick, attr:{checked: isPrivate()?\"off\":\"on\"}'><span class='checkindicator'></span><span class='checkboxtext' data-bind='text: isPrivateText'></span></a><a class='btn right' data-bind='click: createChannel'>OK</a>\
			</div>\
		</div>\
		</div>\
		<!-- /ko -->\
	");

 
    addTemplate("tmplPost",
			"<div align=\"center\" data-bind=\"visible: showDateHeader\" class =\"dateSplitter\"><span data-bind=\"text: dateHeader\"></span></div>\
			<div class =\"chatter-post\">\
				<div class =\"chatter-post-content\">\
					<span class =\"chatter-post-date\" data-bind=\"visible: showPrefix, text: modifiedOnLabel()\" />\
					<span class =\"chatter-post-date\" data-bind=\"visible: pending(), text: '(" + localize('Pending') + ")'\" />\
				<!--ko if: user() && user().name-->\
					<span class =\"chatter-link chatter-bold chatter-username\" data-bind=\"visible: showPrefix, click: fromClicked, text: user().name, style: {color: user().color} \" />\
				<!-- /ko -->\
				<!--ko if: parseSurvey() -->\
					<br/>\
					<div class='survey'>\
						<img class='survey-logo' src='images/survey-logo.png'>\
						<div class='survey-question'>\
							<strong data-bind='text: surveyQuestion'></strong>\
							<!--ko foreach: surveyOptions -->\
								<!--ko template: { name: 'tmplSurveyOption' } --><!-- /ko-->\
							<!-- /ko -->\
						</div>\
					</div>\
				<!-- /ko -->\
				<!--ko if: attachments().length > 0 -->\
					<div class =\"chatter-post-attachments\">\
						<!--ko foreach: attachments-->\
						<!--ko template: { name: 'tmplPostAttachment' } --><!-- /ko-->\
						<!-- /ko-->\
					</div>\
				<!-- /ko-->\
				<!--ko ifnot: parseSurvey()-->\
					<div class=\"chatter-post-content-html\" data-bind=\"html: content, style: { color: isSending() ? 'darkgrey' : ''}\" ></div>\
				<!-- /ko-->\
				<!--ko if: reactions().length > 0 -->\
					<div class='chatter-post-reactions'>\
						<!--ko foreach: reactions-->\
							<div class='chatter-post-reaction'><span data-bind='text: name'></span>\
							<span class='chatter-post-reaction-count' data-bind='text: users().length'></span>\
							</div>\
						<!-- /ko-->\
					</div>\
				<!-- /ko-->\
			</div>\
		</div>");

    addTemplate("tmplSurveyOption",
		"<div class='survey-opt'><div class='survey-opt-number' data-bind='text: index, click: onClick'></div> <span data-bind='text: text'></span></div>");

    addTemplate("tmplPostAttachment",
	"<span class='chatter-post-attachment'>\
		<span class='chatter-link chatter-bold chatter-attachment-subject' data-bind='click: handleClick, text: subject, css: { topaligned: isImage }'></span>\
		<img class='chatter-post-attachment-img' data-bind='click: handleClick, attr: {src: imageData()}, css: { leftaligned: !isImage }' />\
    </span>");

    addTemplate("tmplChannel",
		"<li class='channel-li' data-bind=\"click: handleClick, css: { unreadchannelli: unread(), selectedchannel: selected() }\">\
			<div class='channel-unread' data-bind='text: (unread() || \"\")'></div>\
			<img class='channelicon' data-bind='appImage: icon' colorize='#99B8D6'/>\
			<div class='channel-button' data-bind='text: name()'></div>\
		</li>\
	");
}

function initTemplates() {
    writeTemplates();
    var templateEngine = ko.nativeTemplateEngine.instance;

    ko.bindingHandlers.chatter = {
        update: function (element, valueAccessor) {
            ko.renderTemplate("tmplChatter", valueAccessor(), { templateEngine: templateEngine }, element, "replaceNode");
        }
    }
}
