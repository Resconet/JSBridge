/// <reference path="MyRoute.ts" />
var RoutePlanner;
(function (RoutePlanner) {
    var Localization = /** @class */ (function () {
        function Localization() {
        }
        Localization.load = function () {
            MobileCRM.Localization.initializeEx("^RoutePlanner\\..*|^Map.CurrentLocation$|^DateTimePicker.Time$|^Cmd\\..*|^Msg\\..*", function (loc) { }, MobileCRM.bridge.alert);
        };
        Localization.get = function (key) {
            return MobileCRM.Localization.get(key);
        };
        Localization.onError = function (text) {
            MobileCRM.bridge.alert(text); // TODO: ???
        };
        // Helper functions
        Localization.secondsToText = function (sec) {
            if (isNaN(sec))
                return "?";
            if (sec < 60)
                return sec.toString() + 's';
            if (sec < 3600)
                return '' + ((sec + 59) / 60).toFixed(0) + "min";
            return '' + (sec / 3600).toFixed(0) + "h " + (sec % 3600 / 60).toFixed(0) + "m";
        };
        Localization.metersToText = function (m) {
            if (isNaN(m))
                return "?";
            if (RoutePlanner.Configuration.instance.useMetricUnits) {
                if (m < 1000)
                    return m.toString() + 'm';
                return '' + (m / 1000).toFixed(2) + "km";
            }
            else if (m < 1609)
                return '' + (m * 1.093613).toFixed() + "yd";
            return '' + (m * 0.00062137).toFixed(2) + "mi";
        };
        Localization.formatDate = function (date, hourFormat) {
            if (hourFormat === void 0) { hourFormat = 0; }
            /// <param name="date" type="Date"/>
            if (date && date.getTime()) {
                var h = date.getHours();
                var m = date.getMinutes();
                var designators = hourFormat == 24 ? null : RoutePlanner.Configuration.instance.timeDesignators;
                if (designators) {
                    // 12 h time
                    return ((h + 11) % 12 + 1) + ':' + (m < 10 ? '0' : '') + m + ' ' + RoutePlanner.Configuration.instance.timeDesignators[h >= 12 ? 1 : 0];
                }
                else {
                    // 24 time
                    return (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m;
                }
            }
            return null;
        };
        Localization.dateToInputString = function (date) {
            /// <param name="date" type="Date"/>
            var m = date.getMonth() + 1;
            var d = date.getDate();
            return date.getFullYear().toString() + '-' + (m < 10 ? '0' : '') + m + '-' + (d < 10 ? '0' : '') + d;
        };
        return Localization;
    }());
    RoutePlanner.Localization = Localization;
})(RoutePlanner || (RoutePlanner = {}));
//# sourceMappingURL=Localization.js.map