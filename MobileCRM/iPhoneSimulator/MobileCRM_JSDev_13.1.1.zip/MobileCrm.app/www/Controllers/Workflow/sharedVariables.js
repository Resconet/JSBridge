/// <reference path="../../Data/metaEntity.ts" />
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var SharedVariables = /** @class */ (function () {
                function SharedVariables() {
                }
                return SharedVariables;
            }());
            Workflow.SharedVariables = SharedVariables;
            var SharedVariable = /** @class */ (function () {
                function SharedVariable() {
                }
                return SharedVariable;
            }());
            Workflow.SharedVariable = SharedVariable;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=sharedVariables.js.map