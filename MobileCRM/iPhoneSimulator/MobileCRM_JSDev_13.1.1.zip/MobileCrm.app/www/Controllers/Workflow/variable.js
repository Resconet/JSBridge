/// <reference path="../../Helpers/exception.ts" />
/// <reference path="../../Data/dynamicEntity.ts" />
/// <reference path="../../Data/fetch.ts" />
/// <reference path="executionContext.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var AbstractVariable = /** @class */ (function () {
                function AbstractVariable() {
                }
                AbstractVariable.prototype.getValue = function (path) {
                    throw new Resco.Exception("Not implemented");
                };
                AbstractVariable.prototype.setValue = function (path, value) {
                    throw new Resco.Exception("Not implemented");
                };
                AbstractVariable.prototype.getValueType = function (path) {
                    throw new Resco.Exception("Not implemented");
                };
                AbstractVariable._getCrmType = function (type) {
                    return MobileCrm.Data.CrmType.Internal;
                };
                AbstractVariable._getObjectValue = function (o, propertyName) {
                    return o[propertyName];
                };
                return AbstractVariable;
            }());
            Workflow.AbstractVariable = AbstractVariable;
            var FormVariable = /** @class */ (function (_super) {
                __extends(FormVariable, _super);
                function FormVariable() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return FormVariable;
            }(AbstractVariable));
            Workflow.FormVariable = FormVariable;
            var EntityVariable = /** @class */ (function (_super) {
                __extends(EntityVariable, _super);
                // TODO: Workflow
                function EntityVariable(entity /*Data.DynamicEntity*/) {
                    var _this = _super.call(this) || this;
                    _this.dynamicPropertyChanged = new Resco.Event(_this);
                    _this.entity = entity;
                    return _this;
                }
                Object.defineProperty(EntityVariable.prototype, "entity", {
                    get: function () {
                        return this.m_entity;
                    },
                    set: function (value) {
                        var _this = this;
                        if (this.m_entity) {
                            //this.m_entity.dynamicPropertyChanged.remove(this, this._m_entity_DynamicPropertyChanged);
                        }
                        this.m_entity = value;
                        if (this.m_entity) {
                            this.entityName = this.m_entity.entityName;
                            // ?? Only register if there is somebody interested in these events. 
                            if (this.dynamicPropertyChanged.count > 0) {
                                //this.m_entity.dynamicPropertyChanged.add(this, this._m_entity_DynamicPropertyChanged);
                            }
                        }
                        if (this.dynamicPropertyChanged.count > 0) {
                            var meta = MobileCrm.Data.MetaData.instance.entities.getValue(this.entityName);
                            meta.properties.getValues().forEach(function (p) { return _this.dynamicPropertyChanged.raise(new Resco.PropertyChangedEventArgs(p.name), _this); }, this);
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                EntityVariable.prototype.registerNotify = function (scope, handler, register) {
                    if (this.m_entity) {
                        //this.m_entity.dynamicPropertyChanged.remove(this, this._m_entity_DynamicPropertyChanged);
                    }
                    if (register) {
                        this.dynamicPropertyChanged.add(scope, handler);
                        if (this.m_entity) {
                            //this.m_entity.dynamicPropertyChanged.add(this, this._m_entity_DynamicPropertyChanged, true);
                        }
                    }
                    else {
                        this.dynamicPropertyChanged.remove(scope, handler);
                    }
                };
                EntityVariable.prototype._m_entity_DynamicPropertyChanged = function (sender, args) {
                    this.dynamicPropertyChanged.raise(args, this);
                };
                EntityVariable.prototype.getValue = function (path) {
                    if (path.length != 2 && path.length != 3) {
                        throw new Resco.Exception("Invalid entity field '" + path.join(".") + "'");
                    }
                    var itemName = path[1];
                    if (itemName == "EntityName") {
                        return this.entity.entityName;
                    }
                    if (itemName == "@this") {
                        return this.entity;
                    }
                    if (!this.m_entity) {
                        throw new Resco.InvalidOperationException("Entity not loaded '" + path.join(".") + "'");
                    }
                    if (itemName == "IsNew") {
                        return this.entity.isNew;
                    }
                    if (itemName == "IsRead") {
                        return this.entity["isRead"]; // email hack
                    }
                    itemName = this._processItemName(itemName);
                    var value;
                    var index = this.m_entity.tryGetPropertyIndex(itemName);
                    if (index >= 0) {
                        var formatted = path.length > 2 && path[2] == "formatted";
                        value = this.m_entity.getPropertyValue(index, formatted);
                    }
                    else {
                        value = AbstractVariable._getObjectValue(this.m_entity, itemName);
                    }
                    return value;
                };
                EntityVariable.prototype._processItemName = function (itemName) {
                    // TODO: Workflow
                    /*if (itemName.indexOf(".") >= 0) {
                        var pp = itemName.split(".");
                        if (pp.length >= 3) {
                            var alias = EntityVariable._findAlias(this.entity.repository.fetch.entity, pp, 0);
                            if (alias) {
                                return alias + "." + pp[pp.length - 1];
                            }
                        }
                    }*/
                    return itemName;
                };
                EntityVariable._findAlias = function (fetch, pp, index) {
                    if (fetch.links) {
                        var propName = pp[index];
                        var entityName = pp[index + 1];
                        for (var i = 0; i < fetch.links.length; i++) {
                            var l = fetch.links[i];
                            if (l.name == entityName && l.to == propName) {
                                if (index == pp.length - 3) {
                                    return l.alias;
                                }
                                return EntityVariable._findAlias(l, pp, index + 2);
                            }
                        }
                    }
                    return null;
                };
                EntityVariable.prototype.setValue = function (path, value) {
                    if (path.length != 2) {
                        throw new Resco.Exception("Invalid entity field '" + path.join(".") + "'");
                    }
                    var itemName = path[1];
                    if (itemName == "IsNew") {
                        return; // Cannot set
                    }
                    if (itemName == "@this") {
                        this.entity = MobileCrm.Data.DynamicEntity.as(value);
                        return;
                    }
                    itemName = this._processItemName(itemName);
                    if (this.entity.tryGetPropertyIndex(itemName) < 0) {
                        throw new Resco.Exception("Entity field not found '" + itemName + "'");
                    }
                    else {
                        this.entity.trySetValue(itemName, value);
                    }
                };
                EntityVariable.prototype.getValueType = function (path) {
                    if (path.length != 2) {
                        throw new Resco.Exception("Invalid entity field '" + path.join(".") + "'");
                    }
                    var itemName = path[1];
                    if (itemName == "IsNew" || itemName == "IsRead") {
                        return MobileCrm.Data.CrmType.Boolean;
                    }
                    if (itemName == "EntityName") {
                        return MobileCrm.Data.CrmType.String;
                    }
                    if (itemName == "@this") {
                        return MobileCrm.Data.CrmType.Entity;
                    }
                    var index = this.entity.repository.getPropertyIndex(itemName);
                    if (index < 0) {
                        throw new Resco.Exception("Entity field not found '" + itemName + "'");
                    }
                    // TODO: Workflow
                    return this.entity.repository.properties[index].type; //.metaProperty.type;
                };
                Object.defineProperty(EntityVariable.prototype, "primaryKey", {
                    get: function () {
                        return this.entity.id;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(EntityVariable.prototype, "primaryName", {
                    get: function () {
                        return this.entity.primaryName;
                    },
                    enumerable: true,
                    configurable: true
                });
                return EntityVariable;
            }(AbstractVariable));
            Workflow.EntityVariable = EntityVariable;
            var TabVariable = /** @class */ (function (_super) {
                __extends(TabVariable, _super);
                function TabVariable() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return TabVariable;
            }(AbstractVariable));
            Workflow.TabVariable = TabVariable;
            var SimpleVariable = /** @class */ (function (_super) {
                __extends(SimpleVariable, _super);
                function SimpleVariable(name, type, value) {
                    var _this = _super.call(this) || this;
                    _this.name = name;
                    _this.type = type;
                    _this.value = value;
                    return _this;
                }
                SimpleVariable.prototype.getValue = function (path) {
                    if (path.length > 1) {
                        throw new Resco.Exception("No such property '" + path.join(".") + "'");
                    }
                    return this.value;
                };
                SimpleVariable.prototype.setValue = function (path, value) {
                    if (path.length > 1) {
                        throw new Resco.Exception("No such property '" + path.join(".") + "'");
                    }
                    this.value = value;
                };
                SimpleVariable.prototype.getValueType = function (path) {
                    if (path.length > 1) {
                        throw new Resco.Exception("No such property '" + path.join(".") + "'");
                    }
                    return this.type;
                };
                return SimpleVariable;
            }(AbstractVariable));
            Workflow.SimpleVariable = SimpleVariable;
            var TemporaryVariable = /** @class */ (function (_super) {
                __extends(TemporaryVariable, _super);
                function TemporaryVariable(name, type) {
                    var _this = _super.call(this, name, type, null) || this;
                    _this.m_items = new Array();
                    return _this;
                }
                TemporaryVariable.prototype.getValue = function (path) {
                    if (this.type == MobileCrm.Data.CrmType.StringList) {
                        return this.m_items;
                    }
                    return this.value;
                };
                TemporaryVariable.prototype.setValue = function (path, value) {
                    if (this.type == MobileCrm.Data.CrmType.StringList) {
                        this.m_items = value;
                    }
                    this.value = value;
                };
                TemporaryVariable.prototype.getValueType = function (path) {
                    return this.type;
                };
                TemporaryVariable.as = function (obj) {
                    if (obj instanceof TemporaryVariable) {
                        return obj;
                    }
                    return null;
                };
                return TemporaryVariable;
            }(SimpleVariable));
            Workflow.TemporaryVariable = TemporaryVariable;
            var RelationshipVariable = /** @class */ (function (_super) {
                __extends(RelationshipVariable, _super);
                function RelationshipVariable() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return RelationshipVariable;
            }(AbstractVariable));
            Workflow.RelationshipVariable = RelationshipVariable;
            var EntityCustomVariable = /** @class */ (function (_super) {
                __extends(EntityCustomVariable, _super);
                function EntityCustomVariable() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return EntityCustomVariable;
            }(AbstractVariable));
            Workflow.EntityCustomVariable = EntityCustomVariable;
            /*export class SharedComplexProperty extends Data.CustomEntityProperty {
                constructor(v: EntityVariable, name: string, t: Data.CrmType) {
                    var varName = v.variableName;
                    super(varName + "." + name, t);
                    this.m_variable = v;
                    this.path = [varName, name];
                }
        
                protected getValue(): any {
                    return this.m_variable.getValue(this.path);
                }
        
                public setValue(value: any): boolean {
                    this.m_variable.setValue(this.path, value);
                    return false;
                }
                
                private m_variable: EntityVariable;
                public path: string[];
            }*/
            var ConfigurationVariable = /** @class */ (function (_super) {
                __extends(ConfigurationVariable, _super);
                function ConfigurationVariable() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return ConfigurationVariable;
            }(AbstractVariable));
            Workflow.ConfigurationVariable = ConfigurationVariable;
            var CommandVariable = /** @class */ (function (_super) {
                __extends(CommandVariable, _super);
                function CommandVariable() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return CommandVariable;
            }(AbstractVariable));
            Workflow.CommandVariable = CommandVariable;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=variable.js.map