/// <reference path="./QueryBuilder.ts" />
/// <reference path="./ConditionOperator.ts" />
/// <reference path="./LinkAlias.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var CrmType;
(function (CrmType) {
    /// <summary>Boolean property; <see cref="bool"/>.</summary>
    CrmType[CrmType["Boolean"] = 0] = "Boolean";
    /// <summary>Customer, special kind of <i>Lookup</i> property, only for <i>Accounts</i> and <i>Contacts</i>; <see cref="Guid"/>.</summary>
    CrmType[CrmType["Customer"] = 1] = "Customer";
    /// <summary>Date property; <see cref="DateTime"/>.</summary>
    CrmType[CrmType["DateTime"] = 2] = "DateTime";
    /// <summary>Decimal property; <see cref="decimal"/>.</summary>
    CrmType[CrmType["Decimal"] = 3] = "Decimal";
    /// <summary>Float property; <see cref="float"/>.</summary>
    CrmType[CrmType["Float"] = 4] = "Float";
    /// <summary>Integer property; <see cref="int"/>.</summary>
    CrmType[CrmType["Integer"] = 5] = "Integer";
    /// <summary>Internal property.</summary>
    CrmType[CrmType["Internal"] = 6] = "Internal";
    /// <summary>Lookup property, generally used for foreign keys; <see cref="Guid"/>.</summary>
    CrmType[CrmType["Lookup"] = 7] = "Lookup";
    /// <summary>Memo property, large string; <see cref="string"/>.</summary>
    CrmType[CrmType["Memo"] = 8] = "Memo";
    /// <summary>Money property; <see cref="decimal"/>.</summary>
    CrmType[CrmType["Money"] = 9] = "Money";
    /// <summary>Owner property.</summary>
    CrmType[CrmType["Owner"] = 10] = "Owner";
    /// <summary>PartyList property.</summary>
    CrmType[CrmType["PartyList"] = 11] = "PartyList";
    /// <summary>Picklist property, allows to pick a value from a list; <see cref="int"/>.</summary>
    CrmType[CrmType["Picklist"] = 12] = "Picklist";
    /// <summary>Primary key property; <see cref="Guid"/>.</summary>
    CrmType[CrmType["PrimaryKey"] = 13] = "PrimaryKey";
    /// <summary>State property; Must not be used.</summary>
    CrmType[CrmType["State"] = 14] = "State";
    /// <summary>Status property, special kind of Picklist; <see cref="int"/>.</summary>
    CrmType[CrmType["Status"] = 15] = "Status";
    /// <summary>String property; <see cref="string"/>.</summary>
    CrmType[CrmType["String"] = 16] = "String";
    /// <summary>Unique identifier; <see cref="Guid"/>.</summary>
    CrmType[CrmType["UniqueIdentifier"] = 17] = "UniqueIdentifier";
    /// <summary>Virtual property.</summary>
    CrmType[CrmType["Virtual"] = 18] = "Virtual";
    /// <summary>CalendarRules property.</summary>
    CrmType[CrmType["CalendarRules"] = 19] = "CalendarRules";
    /// <summary>EntityName property; Must not be used.</summary>
    CrmType[CrmType["EntityName"] = 20] = "EntityName";
    /// <summary>BigInt property; CRM2011 specific. Used for version number instead of String in CRM4</summary>
    CrmType[CrmType["BigInt"] = 21] = "BigInt";
    /// <summary>Double property; CRM2011 specific. Specifies a double attribute.</summary>
    CrmType[CrmType["Double"] = 22] = "Double";
    /// <summary>Special type used for workflows; Must not be used.</summary>
    CrmType[CrmType["PicklistArray"] = 4096] = "PicklistArray";
    /// <summary>Special type used in RescoXRM.</summary>
    CrmType[CrmType["RowVersion"] = 524288] = "RowVersion";
    /// <summary>Special type used in RescoXRM.</summary>
    CrmType[CrmType["Binary"] = 524289] = "Binary";
    /// <summary>Special type used as a List Temporary Variable in Rules</summary>
    CrmType[CrmType["StringList"] = 524290] = "StringList";
    /// <summary>Special type used as a Lookup Temporary Variable in Rules</summary>
    CrmType[CrmType["Entity"] = 524291] = "Entity";
    /// <summary>Special type used as a Lookup Temporary Variable in Rules</summary>
    CrmType[CrmType["Fetch"] = 524292] = "Fetch";
})(CrmType || (CrmType = {}));
var CrmDisplayFormat;
(function (CrmDisplayFormat) {
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["Default"] = 0] = "Default";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["Duration"] = 1] = "Duration";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["TimeZone"] = 2] = "TimeZone";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["Language"] = 3] = "Language";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["Locale"] = 4] = "Locale";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["Email"] = 5] = "Email";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["Text"] = 6] = "Text";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["TextArea"] = 7] = "TextArea";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["Url"] = 8] = "Url";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["TickerSymbol"] = 9] = "TickerSymbol";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["PhoneticGuide"] = 10] = "PhoneticGuide";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["DateOnly"] = 11] = "DateOnly";
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["DateAndTime"] = 12] = "DateAndTime";
    // Custom - not available in CRM
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["PhoneNumber"] = 13] = "PhoneNumber";
    // CRM2011 Specific
    /// <remarks/>
    CrmDisplayFormat[CrmDisplayFormat["VersionNumber"] = 14] = "VersionNumber";
    /// <remarks>
    /// Custom - not available in CRM. Field with this format enables barcode scanning in MobileCRM Lookup form.
    /// </remarks>
    CrmDisplayFormat[CrmDisplayFormat["Barcode"] = 15] = "Barcode";
    /// <remarks>
    /// Custom - not available in CRM. Field with this format uses HTML control for display (or the HTML is stripped if HTML display is not supported on the platform).
    /// This also implies multiline display.
    /// </remarks>
    CrmDisplayFormat[CrmDisplayFormat["Html"] = 16] = "Html";
    /// <summary>String field with a single choice from list.</summary>
    CrmDisplayFormat[CrmDisplayFormat["StringList"] = 17] = "StringList";
    /// <summary>String field with multiple choices from list, separated by ';'.</summary>
    CrmDisplayFormat[CrmDisplayFormat["StringListInput"] = 18] = "StringListInput";
    /// <summary>String field with a single choice from list or free input.</summary>
    CrmDisplayFormat[CrmDisplayFormat["MultiStringList"] = 19] = "MultiStringList";
    /// <summary>String field with multiple choices from list or free input, separated by ';'.</summary>
    CrmDisplayFormat[CrmDisplayFormat["MultiStringListInput"] = 20] = "MultiStringListInput";
})(CrmDisplayFormat || (CrmDisplayFormat = {}));
var EditorType;
(function (EditorType) {
    EditorType[EditorType["Empty"] = 0] = "Empty";
    EditorType[EditorType["String"] = 1] = "String";
    EditorType[EditorType["Number"] = 2] = "Number";
    EditorType[EditorType["Date"] = 4] = "Date";
    EditorType[EditorType["Picklist"] = 8] = "Picklist";
    EditorType[EditorType["Lookup"] = 16] = "Lookup";
})(EditorType || (EditorType = {}));
var FetchQueryBuilder;
(function (FetchQueryBuilder) {
    var OSelect = /** @class */ (function () {
        function OSelect() {
            var _this = this;
            this.isSelected = ko.computed(function () {
                return FetchQueryBuilder.QueryBuilder.getInstance().getSelectedItems()().some(function (v, i, a) {
                    return v.target == _this;
                });
            });
        }
        return OSelect;
    }());
    FetchQueryBuilder.OSelect = OSelect;
    var OFetch = /** @class */ (function (_super) {
        __extends(OFetch, _super);
        function OFetch(fetch) {
            var _this = _super.call(this) || this;
            _this.count = fetch.count;
            _this.page = fetch.page;
            _this.aggregate = fetch.aggregate;
            _this.entity = ko.observable(new OEntity(fetch.entity));
            return _this;
        }
        OFetch.prototype.toFetch = function () {
            var fetch = new MobileCRM.FetchXml.Fetch(this.entity().toEntity(), this.count, this.page);
            fetch.aggregate = this.aggregate;
            return fetch;
        };
        return OFetch;
    }(OSelect));
    FetchQueryBuilder.OFetch = OFetch;
    var OEntity = /** @class */ (function (_super) {
        __extends(OEntity, _super);
        function OEntity(entity) {
            if (entity === void 0) { entity = null; }
            var _this = _super.call(this) || this;
            if (!entity) {
                _this.name = null;
                _this.attributes = ko.observableArray(null);
                _this.order = ko.observableArray(null);
                _this.filter = ko.observable();
                _this.linkentities = ko.observableArray(null);
                return _this;
            }
            _this.name = entity.name;
            _this.attributes = ko.observableArray(entity.attributes);
            _this.order = ko.observableArray(null);
            if (entity.order) {
                _this.order([]);
                for (var _i = 0, _a = entity.order; _i < _a.length; _i++) {
                    var o = _a[_i];
                    _this.order.push(new OOrder(o));
                }
            }
            _this.filter = ko.observable(new OFilter(_this.name, entity.filter));
            _this.linkentities = ko.observableArray(null);
            if (entity.linkentities) {
                _this.linkentities([]);
                for (var _b = 0, _c = entity.linkentities; _b < _c.length; _b++) {
                    var l = _c[_b];
                    _this.linkentities.push(new OLinkEntity(l));
                }
            }
            return _this;
        }
        OEntity.prototype.toEntity = function () {
            var entity = new MobileCRM.FetchXml.Entity(this.name);
            entity.attributes = this.attributes();
            entity.order = null;
            if (this.order()) {
                entity.order = [];
                for (var o in this.order()) {
                    entity.order.push(this.order()[o].toOrder());
                }
            }
            entity.filter = this.filter().toFilter();
            entity.linkentities = null;
            if (this.linkentities()) {
                entity.linkentities = [];
                for (var le in this.linkentities()) {
                    entity.linkentities.push(this.linkentities()[le].toLinkEntity());
                }
            }
            return entity;
        };
        return OEntity;
    }(OSelect));
    FetchQueryBuilder.OEntity = OEntity;
    var OLinkEntity = /** @class */ (function (_super) {
        __extends(OLinkEntity, _super);
        function OLinkEntity(linkEntity) {
            if (linkEntity === void 0) { linkEntity = null; }
            var _this = _super.call(this, linkEntity) || this;
            if (!linkEntity) {
                _this.from = ko.observable();
                _this.to = ko.observable();
                _this.linktype = ko.observable();
                _this.alias = ko.observable();
                return _this;
            }
            _this.from = ko.observable(linkEntity.from);
            _this.to = ko.observable(linkEntity.to);
            _this.linktype = ko.observable(linkEntity.linktype);
            _this.alias = ko.observable(linkEntity.alias);
            return _this;
        }
        OLinkEntity.prototype.toLinkEntity = function () {
            var linkEntity = new MobileCRM.FetchXml.LinkEntity(this.name);
            linkEntity.attributes = this.attributes();
            linkEntity.order = null;
            if (this.order()) {
                linkEntity.order = [];
                for (var o in this.order()) {
                    linkEntity.order.push(this.order()[o].toOrder());
                }
            }
            linkEntity.filter = this.filter().toFilter();
            linkEntity.linkentities = null;
            if (this.linkentities()) {
                linkEntity.linkentities = [];
                for (var le in this.linkentities()) {
                    linkEntity.linkentities.push(this.linkentities()[le].toLinkEntity());
                }
            }
            linkEntity.from = this.from();
            linkEntity.to = this.to();
            linkEntity.linktype = this.linktype();
            linkEntity.alias = this.alias();
            return linkEntity;
        };
        return OLinkEntity;
    }(OEntity));
    FetchQueryBuilder.OLinkEntity = OLinkEntity;
    var OOrder = /** @class */ (function (_super) {
        __extends(OOrder, _super);
        function OOrder(order) {
            if (order === void 0) { order = null; }
            var _this = _super.call(this) || this;
            if (!order) {
                _this.attribute = ko.observable();
                _this.alias = ko.observable();
                _this.descending = ko.observable();
                return _this;
            }
            _this.attribute = ko.observable(order.attribute);
            _this.alias = ko.observable(order.alias);
            _this.descending = ko.observable(order.descending);
            return _this;
        }
        OOrder.prototype.toOrder = function () {
            var order = new MobileCRM.FetchXml.Order(this.attribute(), this.descending());
            order.alias = this.alias();
            return order;
        };
        return OOrder;
    }(OSelect));
    FetchQueryBuilder.OOrder = OOrder;
    var OFilter = /** @class */ (function (_super) {
        __extends(OFilter, _super);
        function OFilter(parentEntityName, filter) {
            if (filter === void 0) { filter = null; }
            var _this = _super.call(this) || this;
            if (!filter) {
                _this.type = ko.observable("and");
                _this.conditions = ko.observableArray(null);
                _this.filters = ko.observableArray(null);
                return _this;
            }
            _this.type = ko.observable(filter.type);
            _this.conditions = ko.observableArray(null);
            if (filter.conditions) {
                _this.conditions([]);
                for (var _i = 0, _a = filter.conditions; _i < _a.length; _i++) {
                    var c = _a[_i];
                    _this.conditions.push(new OCondition(parentEntityName, c));
                }
            }
            _this.filters = ko.observableArray(null);
            if (filter.filters) {
                _this.filters([]);
                for (var _b = 0, _c = filter.filters; _b < _c.length; _b++) {
                    var f = _c[_b];
                    _this.filters.push(new OFilter(parentEntityName, f));
                }
            }
            return _this;
        }
        OFilter.prototype.toFilter = function () {
            var filter = new MobileCRM.FetchXml.Filter();
            filter.type = this.type();
            filter.conditions = null;
            if (this.conditions()) {
                filter.conditions = [];
                for (var c in this.conditions()) {
                    filter.conditions.push(this.conditions()[c].toCondition());
                }
            }
            filter.filters = null;
            if (this.filters) {
                filter.filters = [];
                for (var f in this.filters()) {
                    filter.filters.push(this.filters()[f].toFilter());
                }
            }
            return filter;
        };
        return OFilter;
    }(OSelect));
    FetchQueryBuilder.OFilter = OFilter;
    var OCondition = /** @class */ (function (_super) {
        __extends(OCondition, _super);
        function OCondition(parentEntityName, condition) {
            if (condition === void 0) { condition = null; }
            var _this = _super.call(this) || this;
            _this.parentEntityName = parentEntityName;
            _this.attribute = ko.observable();
            _this.entityname = ko.observable();
            _this.operator = ko.observable();
            _this.uitype = ko.observable();
            _this.uiname = ko.observable();
            _this.value = ko.observable();
            _this.values = ko.observableArray();
            _this.stringOperator = ko.observable();
            _this.isValueEditable = ko.observable();
            if (condition) {
                _this.attribute = ko.observable(condition.attribute);
                _this.entityname = ko.observable(condition.entityname);
                _this.operator = ko.observable(condition.operator);
                _this.uitype = ko.observable(condition.uitype);
                _this.uiname = ko.observable(condition.uiname);
                _this.value = ko.observable(condition.value);
                _this.values = ko.observableArray(condition.values);
                _this.stringOperator = ko.observable(condition.stringOperator);
                _this.isValueEditable = ko.observable(FetchQueryBuilder.ConditionOperator.getArity(condition.operator) != 0);
            }
            _this.displayValue = ko.computed(function () {
                if (FetchQueryBuilder.ConditionOperator.getArity(_this.operator()) === 0) {
                    return [""];
                }
                var values = !_this.value() ? _this.values() : [_this.value()];
                var returnValues = [];
                if (values && _this.operator() === FetchQueryBuilder.ConditionOperator.operators.Contain.Value || _this.operator() === FetchQueryBuilder.ConditionOperator.operators.NotContain.Value) {
                    for (var v_1 = 0; v_1 < values.length; v_1++) {
                        if (values.length === 0)
                            break;
                        values[v_1] = FetchQueryBuilder.QueryBuilder.getInstance().removeWildcards(values[v_1]);
                        if (values[v_1] === "" || values[v_1] === null)
                            values.splice(v_1--, 1);
                    }
                }
                if (values === null || values.length === 0) {
                    return [FetchQueryBuilder.QueryBuilder.getInstance().editorPlaceholder];
                }
                //let entityName = this.getLinkedEntityByAlias(FetchQueryBuilder.QueryBuilder.getInstance().getFetch().entity, this.entityname()).name;
                var meta = FetchQueryBuilder.QueryBuilder.getInstance().metadata[_this.parentEntityName];
                if (meta) {
                    var attribute = meta.getProperty(_this.attribute());
                    if (attribute) {
                        if (attribute.isPicklist) {
                            for (var v in values) {
                                if (attribute.options && attribute.options.hasOwnProperty(values[v])) {
                                    var text = attribute.options[values[v]];
                                    returnValues.push(text);
                                }
                            }
                        }
                        else if (attribute.isReference || attribute.type === CrmType.PrimaryKey) {
                            if (_this.uiname()) {
                                returnValues.push(_this.uiname());
                            }
                            else {
                                returnValues.push(_this.value());
                            }
                        }
                    }
                }
                return returnValues && returnValues.length > 0 ? returnValues : values;
            });
            return _this;
        }
        OCondition.prototype.toCondition = function () {
            var condition = new MobileCRM.FetchXml.Condition();
            condition.attribute = this.attribute();
            condition.entityname = this.entityname();
            condition.operator = this.operator();
            condition.uitype = this.uitype();
            condition.uiname = this.uiname();
            condition.value = this.value();
            condition.values = this.values();
            return condition;
        };
        OCondition.prototype.getOperators = function (attributeMeta) {
            var ops = [];
            var type = attributeMeta.type;
            if (attributeMeta.targets != null && this.containsTarget(attributeMeta.targets, function (v) { return v == "systemuser"; }))
                this.addOperators(ops, [FetchQueryBuilder.ConditionOperator.operators.EqualUser, FetchQueryBuilder.ConditionOperator.operators.NotEqualUser]);
            if (attributeMeta.targets != null && this.containsTarget(attributeMeta.targets, function (v) { return v == "team"; }))
                this.addOperators(ops, [FetchQueryBuilder.ConditionOperator.operators.EqualUserTeam, FetchQueryBuilder.ConditionOperator.operators.EqualUserOrUserTeam]);
            // The customerId is not limited to built-in entities, so allow any reference or primary key.
            // Not very likely to happen
            /*if (attributeMeta.isReference || type === CrmType.PrimaryKey)
                this.addOperators(ops, [FetchQueryBuilder.ConditionOperator.operators.EqualCustomer]);*/
            if (type === CrmType.DateTime) {
                this.addOperators(ops, FetchQueryBuilder.ConditionOperator.getOperators("DateOps"));
            }
            else {
                if (type !== CrmType.UniqueIdentifier || type === CrmType.PrimaryKey) {
                    var group = !this.values || this.values.length === 0 ? "EqOps" : "InOps";
                    this.addOperators(ops, FetchQueryBuilder.ConditionOperator.getOperators(group));
                }
                if (!attributeMeta.isPicklist && (type === CrmType.Integer || type === CrmType.Float || type === CrmType.Double || type === CrmType.Decimal || type === CrmType.Money)) {
                    this.addOperators(ops, FetchQueryBuilder.ConditionOperator.getOperators("NumberOps"));
                }
            }
            this.addOperators(ops, [FetchQueryBuilder.ConditionOperator.operators.NotNull, FetchQueryBuilder.ConditionOperator.operators.Null]);
            if (type === CrmType.String || attributeMeta.isReference || attributeMeta.isPicklist) {
                this.addOperators(ops, FetchQueryBuilder.ConditionOperator.getOperators("TextOps"));
            }
            return ops;
        };
        OCondition.prototype.addOperators = function (ops, src) {
            for (var i = 0; i < src.length; i++) {
                ops.push(src[i]);
            }
        };
        OCondition.prototype.containsTarget = function (targets, method) {
            for (var i = 0; i < targets.length; i++) {
                if (method(targets[i])) {
                    return true;
                }
            }
            return false;
        };
        OCondition.prototype.getLinkedEntityByAlias = function (parent, alias) {
            if (!alias)
                return parent;
            var res = null;
            for (var l in parent.linkentities) {
                if (alias === parent.linkentities[l].alias)
                    return parent.linkentities[l];
                if (parent.linkentities[l].linkentities && parent.linkentities[l].linkentities.length > 0)
                    res = this.getLinkedEntityByAlias(parent.linkentities[l], alias);
            }
            return res;
        };
        return OCondition;
    }(OSelect));
    FetchQueryBuilder.OCondition = OCondition;
})(FetchQueryBuilder || (FetchQueryBuilder = {}));
//# sourceMappingURL=Utils.js.map