//import { ILocalizationProvider } from "Resco/UI/IView/iLocalizationProvider";
//import { Dictionary } from "Resco/common/dictionary";
//import { CultureInfo } from "MobileCrm/localization/cultureInfo";
//import { StringComparer } from "Resco/common/stringComparer";
//import { Configuration } from "MobileCrm/configuration/configuration";
//import { CSInvokeMapper } from "MobileCrm/UI/Web/jsBridgeSerializer/cSInvokeMapper";
/// <reference path="../Helpers/common.ts" />
var MobileCrm;
(function (MobileCrm) {
    var Data;
    (function (Data) {
        var Localization = /** @class */ (function () {
            function Localization() {
                //	static s_cultureInfo: Dictionary<string, CultureInfo>;
                //	static get cultureInfo(): Dictionary<string, CultureInfo> {
                //		if (!Localization.s_cultureInfo) {
                //			Localization.s_cultureInfo = new Dictionary<string, CultureInfo>(StringComparer.IgnoreCase);
                //			Localization.s_cultureInfo.add("ar", new CultureInfo("ar", "Arabic"));
                //			Localization.s_cultureInfo.add("bg", new CultureInfo("bg", "Bulgarian"));
                //			Localization.s_cultureInfo.add("ca", new CultureInfo("ca", "Catalan"));
                //			Localization.s_cultureInfo.add("zh-CHS", new CultureInfo("zh-CHS", "Chinese (Simplified)"));
                //			Localization.s_cultureInfo.add("cs", new CultureInfo("cs", "Czech"));
                //			Localization.s_cultureInfo.add("da", new CultureInfo("da", "Danish"));
                //			Localization.s_cultureInfo.add("de", new CultureInfo("de", "German"));
                //			Localization.s_cultureInfo.add("el", new CultureInfo("el", "Greek"));
                //			Localization.s_cultureInfo.add("en", new CultureInfo("en", "English"));
                //			Localization.s_cultureInfo.add("es", new CultureInfo("es", "Spanish"));
                //			Localization.s_cultureInfo.add("fi", new CultureInfo("fi", "Finnish"));
                //			Localization.s_cultureInfo.add("fr", new CultureInfo("fr", "French"));
                //			Localization.s_cultureInfo.add("he", new CultureInfo("he", "Hebrew"));
                //			Localization.s_cultureInfo.add("hu", new CultureInfo("hu", "Hungarian"));
                //			Localization.s_cultureInfo.add("is", new CultureInfo("is", "Icelandic"));
                //			Localization.s_cultureInfo.add("it", new CultureInfo("it", "Italian"));
                //			Localization.s_cultureInfo.add("ja", new CultureInfo("ja", "Japanese"));
                //			Localization.s_cultureInfo.add("ko", new CultureInfo("ko", "Korean"));
                //			Localization.s_cultureInfo.add("nl", new CultureInfo("nl", "Dutch"));
                //			Localization.s_cultureInfo.add("no", new CultureInfo("no", "Norwegian"));
                //			Localization.s_cultureInfo.add("pl", new CultureInfo("pl", "Polish"));
                //			Localization.s_cultureInfo.add("pt", new CultureInfo("pt", "Portuguese"));
                //			Localization.s_cultureInfo.add("ro", new CultureInfo("ro", "Romanian"));
                //			Localization.s_cultureInfo.add("ru", new CultureInfo("ru", "Russian"));
                //			Localization.s_cultureInfo.add("hr", new CultureInfo("hr", "Croatian"));
                //			Localization.s_cultureInfo.add("sk", new CultureInfo("sk", "Slovak"));
                //			Localization.s_cultureInfo.add("sq", new CultureInfo("sq", "Albanian"));
                //			Localization.s_cultureInfo.add("sv", new CultureInfo("sv", "Swedish"));
                //			Localization.s_cultureInfo.add("th", new CultureInfo("th", "Thai"));
                //			Localization.s_cultureInfo.add("tr", new CultureInfo("tr", "Turkish"));
                //			Localization.s_cultureInfo.add("ur", new CultureInfo("ur", "Urdu"));
                //			Localization.s_cultureInfo.add("id", new CultureInfo("id", "Indonesian"));
                //			Localization.s_cultureInfo.add("uk", new CultureInfo("uk", "Ukrainian"));
                //			Localization.s_cultureInfo.add("be", new CultureInfo("be", "Belarusian"));
                //			Localization.s_cultureInfo.add("sl", new CultureInfo("sl", "Slovenian"));
                //			Localization.s_cultureInfo.add("et", new CultureInfo("et", "Estonian"));
                //			Localization.s_cultureInfo.add("lv", new CultureInfo("lv", "Latvian"));
                //			Localization.s_cultureInfo.add("lt", new CultureInfo("lt", "Lithuanian"));
                //			Localization.s_cultureInfo.add("fa", new CultureInfo("fa", "Persian"));
                //			Localization.s_cultureInfo.add("vi", new CultureInfo("vi", "Vietnamese"));
                //			Localization.s_cultureInfo.add("hy", new CultureInfo("hy", "Armenian"));
                //			Localization.s_cultureInfo.add("az", new CultureInfo("az", "Azerbaijani"));
                //			Localization.s_cultureInfo.add("eu", new CultureInfo("eu", "Basque"));
                //			Localization.s_cultureInfo.add("mk", new CultureInfo("mk", "Macedonian"));
                //			Localization.s_cultureInfo.add("af", new CultureInfo("af", "Afrikaans"));
                //			Localization.s_cultureInfo.add("ka", new CultureInfo("ka", "Georgian"));
                //			Localization.s_cultureInfo.add("fo", new CultureInfo("fo", "Faroese"));
                //			Localization.s_cultureInfo.add("hi", new CultureInfo("hi", "Hindi"));
                //			Localization.s_cultureInfo.add("ms", new CultureInfo("ms", "Malay"));
                //			Localization.s_cultureInfo.add("kk", new CultureInfo("kk", "Kazakh"));
                //			Localization.s_cultureInfo.add("ky", new CultureInfo("ky", "Kyrgyz"));
                //			Localization.s_cultureInfo.add("sw", new CultureInfo("sw", "Kiswahili"));
                //			Localization.s_cultureInfo.add("uz", new CultureInfo("uz", "Uzbek"));
                //			Localization.s_cultureInfo.add("tt", new CultureInfo("tt", "Tatar"));
                //			Localization.s_cultureInfo.add("pa", new CultureInfo("pa", "Punjabi"));
                //			Localization.s_cultureInfo.add("gu", new CultureInfo("gu", "Gujarati"));
                //			Localization.s_cultureInfo.add("ta", new CultureInfo("ta", "Tamil"));
                //			Localization.s_cultureInfo.add("te", new CultureInfo("te", "Telugu"));
                //			Localization.s_cultureInfo.add("kn", new CultureInfo("kn", "Kannada"));
                //			Localization.s_cultureInfo.add("mr", new CultureInfo("mr", "Marathi"));
                //			Localization.s_cultureInfo.add("sa", new CultureInfo("sa", "Sanskrit"));
                //			Localization.s_cultureInfo.add("mn", new CultureInfo("mn", "Mongolian"));
                //			Localization.s_cultureInfo.add("gl", new CultureInfo("gl", "Galician"));
                //			Localization.s_cultureInfo.add("kok", new CultureInfo("kok", "Konkani"));
                //			Localization.s_cultureInfo.add("syr", new CultureInfo("syr", "Syriac"));
                //			Localization.s_cultureInfo.add("dv", new CultureInfo("dv", "Divehi"));
                //			Localization.s_cultureInfo.add("", new CultureInfo("", "Invariant Language (Invariant Country)"));
                //			Localization.s_cultureInfo.add("ar-SA", new CultureInfo("ar-SA", "Arabic (Saudi Arabia)"));
                //			Localization.s_cultureInfo.add("bg-BG", new CultureInfo("bg-BG", "Bulgarian (Bulgaria)"));
                //			Localization.s_cultureInfo.add("ca-ES", new CultureInfo("ca-ES", "Catalan (Catalan)"));
                //			Localization.s_cultureInfo.add("zh-TW", new CultureInfo("zh-TW", "Chinese (Traditional, Taiwan)"));
                //			Localization.s_cultureInfo.add("cs-CZ", new CultureInfo("cs-CZ", "Czech (Czech Republic)"));
                //			Localization.s_cultureInfo.add("da-DK", new CultureInfo("da-DK", "Danish (Denmark)"));
                //			Localization.s_cultureInfo.add("de-DE", new CultureInfo("de-DE", "German (Germany)"));
                //			Localization.s_cultureInfo.add("el-GR", new CultureInfo("el-GR", "Greek (Greece)"));
                //			Localization.s_cultureInfo.add("en-US", new CultureInfo("en-US", "English (United States)"));
                //			Localization.s_cultureInfo.add("fi-FI", new CultureInfo("fi-FI", "Finnish (Finland)"));
                //			Localization.s_cultureInfo.add("fr-FR", new CultureInfo("fr-FR", "French (France)"));
                //			Localization.s_cultureInfo.add("he-IL", new CultureInfo("he-IL", "Hebrew (Israel)"));
                //			Localization.s_cultureInfo.add("hu-HU", new CultureInfo("hu-HU", "Hungarian (Hungary)"));
                //			Localization.s_cultureInfo.add("is-IS", new CultureInfo("is-IS", "Icelandic (Iceland)"));
                //			Localization.s_cultureInfo.add("it-IT", new CultureInfo("it-IT", "Italian (Italy)"));
                //			Localization.s_cultureInfo.add("ja-JP", new CultureInfo("ja-JP", "Japanese (Japan)"));
                //			Localization.s_cultureInfo.add("ko-KR", new CultureInfo("ko-KR", "Korean (Korea)"));
                //			Localization.s_cultureInfo.add("nl-NL", new CultureInfo("nl-NL", "Dutch (Netherlands)"));
                //			Localization.s_cultureInfo.add("nb-NO", new CultureInfo("nb-NO", "Norwegian, Bokmål (Norway)"));
                //			Localization.s_cultureInfo.add("pl-PL", new CultureInfo("pl-PL", "Polish (Poland)"));
                //			Localization.s_cultureInfo.add("pt-BR", new CultureInfo("pt-BR", "Portuguese (Brazil)"));
                //			Localization.s_cultureInfo.add("ro-RO", new CultureInfo("ro-RO", "Romanian (Romania)"));
                //			Localization.s_cultureInfo.add("ru-RU", new CultureInfo("ru-RU", "Russian (Russia)"));
                //			Localization.s_cultureInfo.add("hr-HR", new CultureInfo("hr-HR", "Croatian (Croatia)"));
                //			Localization.s_cultureInfo.add("sk-SK", new CultureInfo("sk-SK", "Slovak (Slovakia)"));
                //			Localization.s_cultureInfo.add("sq-AL", new CultureInfo("sq-AL", "Albanian (Albania)"));
                //			Localization.s_cultureInfo.add("sv-SE", new CultureInfo("sv-SE", "Swedish (Sweden)"));
                //			Localization.s_cultureInfo.add("th-TH", new CultureInfo("th-TH", "Thai (Thailand)"));
                //			Localization.s_cultureInfo.add("tr-TR", new CultureInfo("tr-TR", "Turkish (Turkey)"));
                //			Localization.s_cultureInfo.add("ur-PK", new CultureInfo("ur-PK", "Urdu (Pakistan)"));
                //			Localization.s_cultureInfo.add("id-ID", new CultureInfo("id-ID", "Indonesian (Indonesia)"));
                //			Localization.s_cultureInfo.add("uk-UA", new CultureInfo("uk-UA", "Ukrainian (Ukraine)"));
                //			Localization.s_cultureInfo.add("be-BY", new CultureInfo("be-BY", "Belarusian (Belarus)"));
                //			Localization.s_cultureInfo.add("sl-SI", new CultureInfo("sl-SI", "Slovenian (Slovenia)"));
                //			Localization.s_cultureInfo.add("et-EE", new CultureInfo("et-EE", "Estonian (Estonia)"));
                //			Localization.s_cultureInfo.add("lv-LV", new CultureInfo("lv-LV", "Latvian (Latvia)"));
                //			Localization.s_cultureInfo.add("lt-LT", new CultureInfo("lt-LT", "Lithuanian (Lithuania)"));
                //			Localization.s_cultureInfo.add("fa-IR", new CultureInfo("fa-IR", "Persian"));
                //			Localization.s_cultureInfo.add("vi-VN", new CultureInfo("vi-VN", "Vietnamese (Vietnam)"));
                //			Localization.s_cultureInfo.add("hy-AM", new CultureInfo("hy-AM", "Armenian (Armenia)"));
                //			Localization.s_cultureInfo.add("az-Latn-AZ", new CultureInfo("az-Latn-AZ", "Azerbaijani (Latin, Azerbaijan)"));
                //			Localization.s_cultureInfo.add("eu-ES", new CultureInfo("eu-ES", "Basque (Basque)"));
                //			Localization.s_cultureInfo.add("mk-MK", new CultureInfo("mk-MK", "Macedonian (Former Yugoslav Republic of Macedonia)"));
                //			Localization.s_cultureInfo.add("af-ZA", new CultureInfo("af-ZA", "Afrikaans (South Africa)"));
                //			Localization.s_cultureInfo.add("ka-GE", new CultureInfo("ka-GE", "Georgian (Georgia)"));
                //			Localization.s_cultureInfo.add("fo-FO", new CultureInfo("fo-FO", "Faroese (Faroe Islands)"));
                //			Localization.s_cultureInfo.add("hi-IN", new CultureInfo("hi-IN", "Hindi (India)"));
                //			Localization.s_cultureInfo.add("ms-MY", new CultureInfo("ms-MY", "Malay (Malaysia)"));
                //			Localization.s_cultureInfo.add("kk-KZ", new CultureInfo("kk-KZ", "Kazakh (Kazakhstan)"));
                //			Localization.s_cultureInfo.add("ky-KG", new CultureInfo("ky-KG", "Kyrgyz (Kyrgyzstan)"));
                //			Localization.s_cultureInfo.add("sw-KE", new CultureInfo("sw-KE", "Kiswahili (Kenya)"));
                //			Localization.s_cultureInfo.add("uz-Latn-UZ", new CultureInfo("uz-Latn-UZ", "Uzbek (Latin, Uzbekistan)"));
                //			Localization.s_cultureInfo.add("tt-RU", new CultureInfo("tt-RU", "Tatar (Russia)"));
                //			Localization.s_cultureInfo.add("pa-IN", new CultureInfo("pa-IN", "Punjabi (India)"));
                //			Localization.s_cultureInfo.add("gu-IN", new CultureInfo("gu-IN", "Gujarati (India)"));
                //			Localization.s_cultureInfo.add("ta-IN", new CultureInfo("ta-IN", "Tamil (India)"));
                //			Localization.s_cultureInfo.add("te-IN", new CultureInfo("te-IN", "Telugu (India)"));
                //			Localization.s_cultureInfo.add("kn-IN", new CultureInfo("kn-IN", "Kannada (India)"));
                //			Localization.s_cultureInfo.add("mr-IN", new CultureInfo("mr-IN", "Marathi (India)"));
                //			Localization.s_cultureInfo.add("sa-IN", new CultureInfo("sa-IN", "Sanskrit (India)"));
                //			Localization.s_cultureInfo.add("mn-MN", new CultureInfo("mn-MN", "Mongolian (Cyrillic, Mongolia)"));
                //			Localization.s_cultureInfo.add("gl-ES", new CultureInfo("gl-ES", "Galician (Galician)"));
                //			Localization.s_cultureInfo.add("kok-IN", new CultureInfo("kok-IN", "Konkani (India)"));
                //			Localization.s_cultureInfo.add("syr-SY", new CultureInfo("syr-SY", "Syriac (Syria)"));
                //			Localization.s_cultureInfo.add("dv-MV", new CultureInfo("dv-MV", "Divehi (Maldives)"));
                //			Localization.s_cultureInfo.add("ar-IQ", new CultureInfo("ar-IQ", "Arabic (Iraq)"));
                //			Localization.s_cultureInfo.add("zh-CN", new CultureInfo("zh-CN", "Chinese (Simplified, China)"));
                //			Localization.s_cultureInfo.add("de-CH", new CultureInfo("de-CH", "German (Switzerland)"));
                //			Localization.s_cultureInfo.add("en-GB", new CultureInfo("en-GB", "English (United Kingdom)"));
                //			Localization.s_cultureInfo.add("es-MX", new CultureInfo("es-MX", "Spanish (Mexico)"));
                //			Localization.s_cultureInfo.add("fr-BE", new CultureInfo("fr-BE", "French (Belgium)"));
                //			Localization.s_cultureInfo.add("it-CH", new CultureInfo("it-CH", "Italian (Switzerland)"));
                //			Localization.s_cultureInfo.add("nl-BE", new CultureInfo("nl-BE", "Dutch (Belgium)"));
                //			Localization.s_cultureInfo.add("nn-NO", new CultureInfo("nn-NO", "Norwegian, Nynorsk (Norway)"));
                //			Localization.s_cultureInfo.add("pt-PT", new CultureInfo("pt-PT", "Portuguese (Portugal)"));
                //			Localization.s_cultureInfo.add("sr-Latn-CS", new CultureInfo("sr-Latn-CS", "Serbian (Latin, Serbia and Montenegro (Former))"));
                //			Localization.s_cultureInfo.add("sv-FI", new CultureInfo("sv-FI", "Swedish (Finland)"));
                //			Localization.s_cultureInfo.add("az-Cyrl-AZ", new CultureInfo("az-Cyrl-AZ", "Azerbaijani (Cyrillic, Azerbaijan)"));
                //			Localization.s_cultureInfo.add("ms-BN", new CultureInfo("ms-BN", "Malay (Brunei Darussalam)"));
                //			Localization.s_cultureInfo.add("uz-Cyrl-UZ", new CultureInfo("uz-Cyrl-UZ", "Uzbek (Cyrillic, Uzbekistan)"));
                //			Localization.s_cultureInfo.add("ar-EG", new CultureInfo("ar-EG", "Arabic (Egypt)"));
                //			Localization.s_cultureInfo.add("zh-HK", new CultureInfo("zh-HK", "Chinese (Traditional, Hong Kong SAR)"));
                //			Localization.s_cultureInfo.add("de-AT", new CultureInfo("de-AT", "German (Austria)"));
                //			Localization.s_cultureInfo.add("en-AU", new CultureInfo("en-AU", "English (Australia)"));
                //			Localization.s_cultureInfo.add("es-ES", new CultureInfo("es-ES", "Spanish (Spain, International Sort)"));
                //			Localization.s_cultureInfo.add("fr-CA", new CultureInfo("fr-CA", "French (Canada)"));
                //			Localization.s_cultureInfo.add("sr-Cyrl-CS", new CultureInfo("sr-Cyrl-CS", "Serbian (Cyrillic, Serbia and Montenegro (Former))"));
                //			Localization.s_cultureInfo.add("ar-LY", new CultureInfo("ar-LY", "Arabic (Libya)"));
                //			Localization.s_cultureInfo.add("zh-SG", new CultureInfo("zh-SG", "Chinese (Simplified, Singapore)"));
                //			Localization.s_cultureInfo.add("de-LU", new CultureInfo("de-LU", "German (Luxembourg)"));
                //			Localization.s_cultureInfo.add("en-CA", new CultureInfo("en-CA", "English (Canada)"));
                //			Localization.s_cultureInfo.add("es-GT", new CultureInfo("es-GT", "Spanish (Guatemala)"));
                //			Localization.s_cultureInfo.add("fr-CH", new CultureInfo("fr-CH", "French (Switzerland)"));
                //			Localization.s_cultureInfo.add("ar-DZ", new CultureInfo("ar-DZ", "Arabic (Algeria)"));
                //			Localization.s_cultureInfo.add("zh-MO", new CultureInfo("zh-MO", "Chinese (Traditional, Macao SAR)"));
                //			Localization.s_cultureInfo.add("de-LI", new CultureInfo("de-LI", "German (Liechtenstein)"));
                //			Localization.s_cultureInfo.add("en-NZ", new CultureInfo("en-NZ", "English (New Zealand)"));
                //			Localization.s_cultureInfo.add("es-CR", new CultureInfo("es-CR", "Spanish (Costa Rica)"));
                //			Localization.s_cultureInfo.add("fr-LU", new CultureInfo("fr-LU", "French (Luxembourg)"));
                //			Localization.s_cultureInfo.add("ar-MA", new CultureInfo("ar-MA", "Arabic (Morocco)"));
                //			Localization.s_cultureInfo.add("en-IE", new CultureInfo("en-IE", "English (Ireland)"));
                //			Localization.s_cultureInfo.add("es-PA", new CultureInfo("es-PA", "Spanish (Panama)"));
                //			Localization.s_cultureInfo.add("fr-MC", new CultureInfo("fr-MC", "French (Monaco)"));
                //			Localization.s_cultureInfo.add("ar-TN", new CultureInfo("ar-TN", "Arabic (Tunisia)"));
                //			Localization.s_cultureInfo.add("en-ZA", new CultureInfo("en-ZA", "English (South Africa)"));
                //			Localization.s_cultureInfo.add("es-DO", new CultureInfo("es-DO", "Spanish (Dominican Republic)"));
                //			Localization.s_cultureInfo.add("ar-OM", new CultureInfo("ar-OM", "Arabic (Oman)"));
                //			Localization.s_cultureInfo.add("en-JM", new CultureInfo("en-JM", "English (Jamaica)"));
                //			Localization.s_cultureInfo.add("es-VE", new CultureInfo("es-VE", "Spanish (Bolivarian Republic of Venezuela)"));
                //			Localization.s_cultureInfo.add("ar-YE", new CultureInfo("ar-YE", "Arabic (Yemen)"));
                //			Localization.s_cultureInfo.add("en-029", new CultureInfo("en-029", "English (Caribbean)"));
                //			Localization.s_cultureInfo.add("es-CO", new CultureInfo("es-CO", "Spanish (Colombia)"));
                //			Localization.s_cultureInfo.add("ar-SY", new CultureInfo("ar-SY", "Arabic (Syria)"));
                //			Localization.s_cultureInfo.add("en-BZ", new CultureInfo("en-BZ", "English (Belize)"));
                //			Localization.s_cultureInfo.add("es-PE", new CultureInfo("es-PE", "Spanish (Peru)"));
                //			Localization.s_cultureInfo.add("ar-JO", new CultureInfo("ar-JO", "Arabic (Jordan)"));
                //			Localization.s_cultureInfo.add("en-TT", new CultureInfo("en-TT", "English (Trinidad and Tobago)"));
                //			Localization.s_cultureInfo.add("es-AR", new CultureInfo("es-AR", "Spanish (Argentina)"));
                //			Localization.s_cultureInfo.add("ar-LB", new CultureInfo("ar-LB", "Arabic (Lebanon)"));
                //			Localization.s_cultureInfo.add("en-ZW", new CultureInfo("en-ZW", "English (Zimbabwe)"));
                //			Localization.s_cultureInfo.add("es-EC", new CultureInfo("es-EC", "Spanish (Ecuador)"));
                //			Localization.s_cultureInfo.add("ar-KW", new CultureInfo("ar-KW", "Arabic (Kuwait)"));
                //			Localization.s_cultureInfo.add("en-PH", new CultureInfo("en-PH", "English (Philippines)"));
                //			Localization.s_cultureInfo.add("es-CL", new CultureInfo("es-CL", "Spanish (Chile)"));
                //			Localization.s_cultureInfo.add("ar-AE", new CultureInfo("ar-AE", "Arabic (U.A.E.)"));
                //			Localization.s_cultureInfo.add("es-UY", new CultureInfo("es-UY", "Spanish (Uruguay)"));
                //			Localization.s_cultureInfo.add("ar-BH", new CultureInfo("ar-BH", "Arabic (Bahrain)"));
                //			Localization.s_cultureInfo.add("es-PY", new CultureInfo("es-PY", "Spanish (Paraguay)"));
                //			Localization.s_cultureInfo.add("ar-QA", new CultureInfo("ar-QA", "Arabic (Qatar)"));
                //			Localization.s_cultureInfo.add("es-BO", new CultureInfo("es-BO", "Spanish (Bolivia)"));
                //			Localization.s_cultureInfo.add("es-SV", new CultureInfo("es-SV", "Spanish (El Salvador)"));
                //			Localization.s_cultureInfo.add("es-HN", new CultureInfo("es-HN", "Spanish (Honduras)"));
                //			Localization.s_cultureInfo.add("es-NI", new CultureInfo("es-NI", "Spanish (Nicaragua)"));
                //			Localization.s_cultureInfo.add("es-PR", new CultureInfo("es-PR", "Spanish (Puerto Rico)"));
                //			Localization.s_cultureInfo.add("zh-CHT", new CultureInfo("zh-CHT", "Chinese (Traditional)"));
                //			Localization.s_cultureInfo.add("sr", new CultureInfo("sr", "Serbian"));
                //			Localization.s_cultureInfo.add("am-ET", new CultureInfo("am-ET", "Amharic (Ethiopia)"));
                //			Localization.s_cultureInfo.add("tzm-Latn-DZ", new CultureInfo("tzm-Latn-DZ", "Central Atlas Tamazight (Latin, Algeria)"));
                //			Localization.s_cultureInfo.add("iu-Latn-CA", new CultureInfo("iu-Latn-CA", "Inuktitut (Latin, Canada)"));
                //			Localization.s_cultureInfo.add("sma-NO", new CultureInfo("sma-NO", "Sami, Southern (Norway)"));
                //			Localization.s_cultureInfo.add("mn-Mong-CN", new CultureInfo("mn-Mong-CN", "Mongolian (Traditional Mongolian, China)"));
                //			Localization.s_cultureInfo.add("gd-GB", new CultureInfo("gd-GB", "Scottish Gaelic (United Kingdom)"));
                //			Localization.s_cultureInfo.add("en-MY", new CultureInfo("en-MY", "English (Malaysia)"));
                //			Localization.s_cultureInfo.add("prs-AF", new CultureInfo("prs-AF", "Dari (Afghanistan)"));
                //			Localization.s_cultureInfo.add("bn-BD", new CultureInfo("bn-BD", "Bangla (Bangladesh)"));
                //			Localization.s_cultureInfo.add("wo-SN", new CultureInfo("wo-SN", "Wolof (Senegal)"));
                //			Localization.s_cultureInfo.add("rw-RW", new CultureInfo("rw-RW", "Kinyarwanda (Rwanda)"));
                //			Localization.s_cultureInfo.add("qut-GT", new CultureInfo("qut-GT", "K'iche' (Guatemala)"));
                //			Localization.s_cultureInfo.add("sah-RU", new CultureInfo("sah-RU", "Sakha (Russia)"));
                //			Localization.s_cultureInfo.add("gsw-FR", new CultureInfo("gsw-FR", "Alsatian (France)"));
                //			Localization.s_cultureInfo.add("co-FR", new CultureInfo("co-FR", "Corsican (France)"));
                //			Localization.s_cultureInfo.add("oc-FR", new CultureInfo("oc-FR", "Occitan (France)"));
                //			Localization.s_cultureInfo.add("mi-NZ", new CultureInfo("mi-NZ", "Maori (New Zealand)"));
                //			Localization.s_cultureInfo.add("ga-IE", new CultureInfo("ga-IE", "Irish (Ireland)"));
                //			Localization.s_cultureInfo.add("se-SE", new CultureInfo("se-SE", "Sami, Northern (Sweden)"));
                //			Localization.s_cultureInfo.add("br-FR", new CultureInfo("br-FR", "Breton (France)"));
                //			Localization.s_cultureInfo.add("smn-FI", new CultureInfo("smn-FI", "Sami, Inari (Finland)"));
                //			Localization.s_cultureInfo.add("moh-CA", new CultureInfo("moh-CA", "Mohawk (Mohawk)"));
                //			Localization.s_cultureInfo.add("arn-CL", new CultureInfo("arn-CL", "Mapudungun (Chile)"));
                //			Localization.s_cultureInfo.add("ii-CN", new CultureInfo("ii-CN", "Yi (China)"));
                //			Localization.s_cultureInfo.add("dsb-DE", new CultureInfo("dsb-DE", "Lower Sorbian (Germany)"));
                //			Localization.s_cultureInfo.add("ig-NG", new CultureInfo("ig-NG", "Igbo (Nigeria)"));
                //			Localization.s_cultureInfo.add("kl-GL", new CultureInfo("kl-GL", "Greenlandic (Greenland)"));
                //			Localization.s_cultureInfo.add("lb-LU", new CultureInfo("lb-LU", "Luxembourgish (Luxembourg)"));
                //			Localization.s_cultureInfo.add("ba-RU", new CultureInfo("ba-RU", "Bashkir (Russia)"));
                //			Localization.s_cultureInfo.add("nso-ZA", new CultureInfo("nso-ZA", "Sesotho sa Leboa (South Africa)"));
                //			Localization.s_cultureInfo.add("quz-BO", new CultureInfo("quz-BO", "Quechua (Bolivia)"));
                //			Localization.s_cultureInfo.add("yo-NG", new CultureInfo("yo-NG", "Yoruba (Nigeria)"));
                //			Localization.s_cultureInfo.add("ha-Latn-NG", new CultureInfo("ha-Latn-NG", "Hausa (Latin, Nigeria)"));
                //			Localization.s_cultureInfo.add("fil-PH", new CultureInfo("fil-PH", "Filipino (Philippines)"));
                //			Localization.s_cultureInfo.add("ps-AF", new CultureInfo("ps-AF", "Pashto (Afghanistan)"));
                //			Localization.s_cultureInfo.add("fy-NL", new CultureInfo("fy-NL", "Frisian (Netherlands)"));
                //			Localization.s_cultureInfo.add("ne-NP", new CultureInfo("ne-NP", "Nepali (Nepal)"));
                //			Localization.s_cultureInfo.add("se-NO", new CultureInfo("se-NO", "Sami, Northern (Norway)"));
                //			Localization.s_cultureInfo.add("iu-Cans-CA", new CultureInfo("iu-Cans-CA", "Inuktitut (Syllabics, Canada)"));
                //			Localization.s_cultureInfo.add("sr-Latn-RS", new CultureInfo("sr-Latn-RS", "Serbian (Latin, Serbia)"));
                //			Localization.s_cultureInfo.add("si-LK", new CultureInfo("si-LK", "Sinhala (Sri Lanka)"));
                //			Localization.s_cultureInfo.add("sr-Cyrl-RS", new CultureInfo("sr-Cyrl-RS", "Serbian (Cyrillic, Serbia)"));
                //			Localization.s_cultureInfo.add("lo-LA", new CultureInfo("lo-LA", "Lao (Lao PDR)"));
                //			Localization.s_cultureInfo.add("km-KH", new CultureInfo("km-KH", "Khmer (Cambodia)"));
                //			Localization.s_cultureInfo.add("cy-GB", new CultureInfo("cy-GB", "Welsh (United Kingdom)"));
                //			Localization.s_cultureInfo.add("bo-CN", new CultureInfo("bo-CN", "Tibetan (China)"));
                //			Localization.s_cultureInfo.add("sms-FI", new CultureInfo("sms-FI", "Sami, Skolt (Finland)"));
                //			Localization.s_cultureInfo.add("as-IN", new CultureInfo("as-IN", "Assamese (India)"));
                //			Localization.s_cultureInfo.add("ml-IN", new CultureInfo("ml-IN", "Malayalam (India)"));
                //			Localization.s_cultureInfo.add("en-IN", new CultureInfo("en-IN", "English (India)"));
                //			Localization.s_cultureInfo.add("or-IN", new CultureInfo("or-IN", "Odia (India)"));
                //			Localization.s_cultureInfo.add("bn-IN", new CultureInfo("bn-IN", "Bangla (India)"));
                //			Localization.s_cultureInfo.add("tk-TM", new CultureInfo("tk-TM", "Turkmen (Turkmenistan)"));
                //			Localization.s_cultureInfo.add("bs-Latn-BA", new CultureInfo("bs-Latn-BA", "Bosnian (Latin, Bosnia and Herzegovina)"));
                //			Localization.s_cultureInfo.add("mt-MT", new CultureInfo("mt-MT", "Maltese (Malta)"));
                //			Localization.s_cultureInfo.add("sr-Cyrl-ME", new CultureInfo("sr-Cyrl-ME", "Serbian (Cyrillic, Montenegro)"));
                //			Localization.s_cultureInfo.add("se-FI", new CultureInfo("se-FI", "Sami, Northern (Finland)"));
                //			Localization.s_cultureInfo.add("zu-ZA", new CultureInfo("zu-ZA", "isiZulu (South Africa)"));
                //			Localization.s_cultureInfo.add("xh-ZA", new CultureInfo("xh-ZA", "isiXhosa (South Africa)"));
                //			Localization.s_cultureInfo.add("tn-ZA", new CultureInfo("tn-ZA", "Setswana (South Africa)"));
                //			Localization.s_cultureInfo.add("hsb-DE", new CultureInfo("hsb-DE", "Upper Sorbian (Germany)"));
                //			Localization.s_cultureInfo.add("bs-Cyrl-BA", new CultureInfo("bs-Cyrl-BA", "Bosnian (Cyrillic, Bosnia and Herzegovina)"));
                //			Localization.s_cultureInfo.add("tg-Cyrl-TJ", new CultureInfo("tg-Cyrl-TJ", "Tajik (Cyrillic, Tajikistan)"));
                //			Localization.s_cultureInfo.add("sr-Latn-BA", new CultureInfo("sr-Latn-BA", "Serbian (Latin, Bosnia and Herzegovina)"));
                //			Localization.s_cultureInfo.add("smj-NO", new CultureInfo("smj-NO", "Sami, Lule (Norway)"));
                //			Localization.s_cultureInfo.add("rm-CH", new CultureInfo("rm-CH", "Romansh (Switzerland)"));
                //			Localization.s_cultureInfo.add("smj-SE", new CultureInfo("smj-SE", "Sami, Lule (Sweden)"));
                //			Localization.s_cultureInfo.add("quz-EC", new CultureInfo("quz-EC", "Quichua (Ecuador)"));
                //			Localization.s_cultureInfo.add("quz-PE", new CultureInfo("quz-PE", "Quechua (Peru)"));
                //			Localization.s_cultureInfo.add("hr-BA", new CultureInfo("hr-BA", "Croatian (Latin, Bosnia and Herzegovina)"));
                //			Localization.s_cultureInfo.add("sr-Latn-ME", new CultureInfo("sr-Latn-ME", "Serbian (Latin, Montenegro)"));
                //			Localization.s_cultureInfo.add("sma-SE", new CultureInfo("sma-SE", "Sami, Southern (Sweden)"));
                //			Localization.s_cultureInfo.add("en-SG", new CultureInfo("en-SG", "English (Singapore)"));
                //			Localization.s_cultureInfo.add("ug-CN", new CultureInfo("ug-CN", "Uyghur (China)"));
                //			Localization.s_cultureInfo.add("sr-Cyrl-BA", new CultureInfo("sr-Cyrl-BA", "Serbian (Cyrillic, Bosnia and Herzegovina)"));
                //			Localization.s_cultureInfo.add("es-US", new CultureInfo("es-US", "Spanish (United States)"));
                //		}
                //		return Localization.s_cultureInfo;
                //	}
                //	static setSupportedLanguages(config: string): void {
                //		Localization.s_cultureInfo = new Dictionary<string, CultureInfo>(StringComparer.IgnoreCase);
                //		Localization.s_cultureInfo.add("en-US", new CultureInfo("en-US", "English (United States)"));
                //		if (config) {
                //			var langs = config.split(";");
                //			langs.forEach(lang => {
                //				var langParts = lang.split(":");
                //				if (langParts.length == 2 && langParts[0] !== "en-US") {
                //					Localization.s_cultureInfo.add(langParts[0], new CultureInfo(langParts[0], langParts[1]));
                //				}
                //			}, this);
                //		}
                //	}
                this.stringTable = new Resco.Dictionary();
                //	public getPlural(id: string): string {
                //		return this.get(id + "+s");
                //	}
                //	public format(id: string, ...args: any[]): string {
                //		var fmt = this.get(id);
                //		return this._formatString(fmt, args);
                //	}
                //	public formatParameters(id: string, ...args: string[]): string {
                //		var fmt = this.get(id);
                //		if (args) {
                //			for (var i = 0; i < args.length; i++) {
                //				args[i] = this.get(args[i]);
                //			}
                //		}
                //		return this._formatString(fmt, args);
                //	}
                //	private _formatString(fmt: string, ...params: any[]): string {
                //		if (!params) {
                //			return fmt;
                //		}
                //		for (var i = 0; i < params[0].length; i++) {
                //			fmt = fmt.replace("{" + i + "}", params[0][i] === undefined || params[0][i] === null ? "" : params[0][i]);
                //		}
                //		return fmt;
                //	}
                //	public CSInvokeMap(): Dictionary<string, CSInvokeMapper> {
                //		var result = new Dictionary<string, CSInvokeMapper>();
                //		result.add("get_LoadedLangId", new CSInvokeMapper("LoadedLangId"));
                //		return result;
                //	}
            }
            Object.defineProperty(Localization, "instance", {
                get: function () {
                    if (!Localization.s_instance) {
                        Localization.s_instance = new Localization();
                    }
                    return Localization.s_instance;
                },
                enumerable: true,
                configurable: true
            });
            //	public LangId: string;
            //	static LoadedLangId: string;
            //	static FallbackLanguage: string = "en-US";
            //	static querySupportedLanguages(config: Configuration): string[] {
            //		var lang = new Array<string>();
            //		var configFiles = config.getFiles("Configuration");
            //		configFiles.forEach(f => {
            //			if (f.endsWith(".lang") && f.length > 8) lang.push(f.substr(4, f.length - 9));
            //			if (f.toLowerCase() === "gui.lang") lang.push("en-US");
            //		}, this);
            //		return lang;
            //	}
            Localization.prototype.initialize = function (stringTable) {
                if (stringTable) {
                    this.stringTable = stringTable;
                }
            };
            //	public initialize(config: Configuration) {
            //		this.stringTable = new Dictionary<string, string>();
            //		var langId = this.LangId;
            //		if (!langId) {
            //			langId = Localization.FallbackLanguage;
            //		}
            //		var localizationFile: string = null;
            //		for (var retry = 0; retry < 3; retry++) {
            //			localizationFile = this._makeLanguageFileName(langId);
            //			if (config.configFileExists(localizationFile)) break;
            //			if (retry === 0) {
            //				localizationFile = "gui.lang";
            //				if (config.configFileExists(localizationFile)) break;
            //			}
            //			localizationFile = null;
            //			if (langId != Localization.FallbackLanguage) {
            //				langId = Localization.FallbackLanguage;
            //			} else {
            //				var s = Localization.querySupportedLanguages(config);
            //				if (s.length <= 0) break;
            //				langId = s[0];
            //			}
            //		}
            //		var hasLocalizationFile = true;
            //		if (!localizationFile) hasLocalizationFile = false;
            //		try {
            //			var defaultFile = this._makeLanguageFileName(Localization.FallbackLanguage);
            //			Localization.LoadedLangId = Localization.FallbackLanguage;
            //			this._initialize(config, defaultFile, false, hasLocalizationFile);
            //		} catch (ex) { }
            //		if (hasLocalizationFile) {
            //			Localization.LoadedLangId = langId;
            //			this._initialize(config, localizationFile, true);
            //		}
            //	}
            //	private _makeLanguageFileName(lang: string): string {
            //		return "gui." + lang + ".lang";
            //	}
            //	private _initialize(config: Configuration, file: string, loadExternal: boolean, customOnly: boolean = false) {
            //		var reader = loadExternal ? config.openDataConfig(file) : config.openLocalConfig(file);
            //		if (reader) {
            //			var line: string;
            //			while ((line = reader.readLine()) != null) {
            //				var idx = line.indexOf("=");
            //				if (idx > 0 && line[0] != "#") {
            //					var k = line.substr(0, idx);
            //					var v = line.substring(idx + 1);
            //					if (v.indexOf("\\") >= 0) {
            //						v = v.replace("\\n", "\n");
            //						v = v.replace("\\r", "\r");
            //					}
            //					this.stringTable.set(k, v);
            //				}
            //			}
            //		}
            //	}
            Localization.prototype.getTextOrDefault = function (id, defaultString) {
                var value = this.stringTable.getValue(id);
                return value === undefined ? defaultString : value;
            };
            //	public getComponentLabel(entityName: string, componentType: string, viewName: string) {
            //		var label = this.stringTable.getValue(entityName + "." + componentType + "." + viewName);
            //		if (label === undefined) label = this.stringTable.getValue(componentType + "." + viewName);
            //		return label !== undefined ? label : viewName;
            //	}
            Localization.prototype.get = function (section, id) {
                if (id) {
                    section = section + "." + id;
                }
                return this.getTextOrDefault(section, section);
            };
            return Localization;
        }());
        Data.Localization = Localization;
    })(Data = MobileCrm.Data || (MobileCrm.Data = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=localization.js.map