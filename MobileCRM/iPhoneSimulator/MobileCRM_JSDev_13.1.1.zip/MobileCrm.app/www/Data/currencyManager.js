//import { Currency } from "MobileCrm/Data/currencyManager/currency";
//import { MetaProperty } from "MobileCrm/Data/metaEntity/metaProperty";
//import { IReference } from "MobileCrm/Data/reference/iReference";
//import { IGetFormattingResult } from "MobileCrm/Data/currencyManager/iGetFormattingResult";
//import { formatString } from "Resco/common/formatString";
//import { round10 } from "Resco/common/round10";
//import { DynamicEntity } from "MobileCrm/Data/entityObject/dynamicEntity";
//import { CrmType } from "MobileCrm/Data/metaEntity/crmType";
//import { Reference } from "MobileCrm/Data/reference/reference";
//import { Configuration } from "MobileCrm/configuration/configuration";
//import { Dictionary } from "Resco/common/dictionary";
//import { ICrmService } from "Resco/Data/WebService/ICrmService/ICrmService";
//import { FetchRequestParams } from "Resco/Data/WebService/fetchRequestParams";
//import { LoadRequest } from "MobileCrm/Data/Online/loadRequest/loadRequest";
//import { DynamicRepository } from "MobileCrm/Data/entityObject/dynamicRepository";
//import { Exception } from "Resco/exception/exception";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/// <reference path="../Helpers/common.ts" />
var MobileCrm;
(function (MobileCrm) {
    var Data;
    (function (Data) {
        var CurrencyManager = /** @class */ (function () {
            //		static round(currencyAmount): number {
            //			return round10(currencyAmount, -CurrencyManager.instance.m_precision);
            //		}
            //		static roundMeta(entity: DynamicEntity, propMeta: MetaProperty, currencyAmount: number): number {
            //			var precision = propMeta.precision;
            //			if (precision <= 0 && propMeta.type === CrmType.Money) {
            //				var r = entity.tryGetValue("transactioncurrencyid");
            //				var currencyId = Reference.as(r.value);
            //				if (currencyId) precision = CurrencyManager.getPrecision(currencyId, propMeta).precision;
            //				if (precision < 0) precision = CurrencyManager.instance.m_precision;
            //			}
            //			if (precision > 0) currencyAmount = round10(currencyAmount, -precision);
            //			return currencyAmount;
            //		}
            function CurrencyManager() {
                //			var showSymbol = true;
                this.m_precision = 2;
                //			this.m_decimalFormat = "{0:N" + this.m_precision + "}";
                //			this.m_userDefaultCurrencyId = Configuration.instance.settings.userDefaultCurrency;
                this.m_items = new Resco.Dictionary();
            }
            Object.defineProperty(CurrencyManager, "instance", {
                get: function () {
                    if (!CurrencyManager.s_instance) {
                        CurrencyManager.s_instance = new CurrencyManager();
                    }
                    return CurrencyManager.s_instance;
                },
                enumerable: true,
                configurable: true
            });
            //		static getPrecision(currencyId: IReference, propMeta: MetaProperty): { precision: number; currency: Currency } {
            //			var mgr = CurrencyManager.instance;
            //			var result = { precision: 0, currency: null };
            //			if (currencyId) result.currency = mgr.m_items.getValue(currencyId.id);
            //			var precision = propMeta ? propMeta.precision : CurrencyManager.UseCurrencyPrecision;
            //			if (precision === CurrencyManager.UseCurrencyPrecision && result.currency) precision = result.currency.precision;
            //			else if (precision < 0) precision = mgr.m_precision;
            //			return result;
            //		}
            CurrencyManager.getFormatting = function (currencyId, propMeta) {
                var result = {};
                var mgr = CurrencyManager.instance;
                var currency = null;
                if (currencyId && mgr.m_items.containsKey(currencyId.id)) {
                    currency = mgr.m_items.getValue(currencyId.id);
                }
                var p = propMeta ? propMeta.precision : CurrencyManager.UseCurrencyPrecision;
                if (p == CurrencyManager.UseCurrencyPrecision && currency) {
                    p = currency.precision;
                }
                else if (p < 0) {
                    p = mgr.m_precision;
                }
                result.precision = p;
                result.format = Currency.getFormatting(currency, p);
                return result;
            };
            CurrencyManager.format = function (currencyId, meta, value) {
                if (value === null || value === undefined) {
                    return "";
                }
                var res = CurrencyManager.getFormatting(currencyId, meta);
                return Resco.formatString(res.format, [value]);
            };
            // Loads the enabled currencies into a cache and queries the default organization.
            CurrencyManager.prototype.initialize = function (items) {
                if (items) {
                    this.m_items = items;
                }
            };
            //		static DecimalFormat = "{0:N2}";
            //		static UseDecimalPricingPrecision = -1;
            CurrencyManager.UseCurrencyPrecision = -2;
            return CurrencyManager;
        }());
        Data.CurrencyManager = CurrencyManager;
        var Reference /*implements IReference*/ = /** @class */ (function () {
            function Reference(id, entityName, displayName) {
                this.m_rowGuid = id;
                this.m_entityName = entityName;
                this.m_primaryName = displayName;
            }
            Object.defineProperty(Reference.prototype, "id", {
                get: function () {
                    return this.rowGuid;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Reference.prototype, "rowGuid", {
                get: function () {
                    return this.m_rowGuid;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Reference.prototype, "entityName", {
                get: function () {
                    return this.m_entityName;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Reference.prototype, "primaryName", {
                get: function () {
                    return this.m_primaryName;
                },
                enumerable: true,
                configurable: true
            });
            Reference.prototype.toString = function () {
                return this.primaryName;
            };
            return Reference;
        }());
        Data.Reference = Reference;
        var Currency = /** @class */ (function (_super) {
            __extends(Currency, _super);
            function Currency(id, displayName) {
                var _this = _super.call(this, id, "transactioncurrency", displayName) || this;
                _this.precision = 2;
                _this.currencySymbol = "?";
                _this.ISOCurrencyCode = "?";
                return _this;
            }
            Currency.getFormatting = function (self, precision) {
                var symbol = "";
                if (self) {
                    symbol = self.currencySymbol; // : currency.ISOCurrencyCode
                }
                return symbol + "{0:N" + precision + "}";
            };
            return Currency;
        }(Reference));
        Data.Currency = Currency;
    })(Data = MobileCrm.Data || (MobileCrm.Data = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=currencyManager.js.map