///<reference path="../../../../MobileCrm/www/TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../container.ts" />
///<reference path="baseDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var AutoPlanner;
            (function (AutoPlanner) {
                var StateItem = /** @class */ (function () {
                    function StateItem() {
                        this.emptyGaps = 0;
                        this.workingDuration = 0;
                        this.travelDuration = 0;
                        this.totalDuration = 0;
                    }
                    return StateItem;
                }());
                AutoPlanner.StateItem = StateItem;
                var ResultReview = /** @class */ (function () {
                    function ResultReview() {
                        this.initial = new StateItem();
                        this.final = new StateItem();
                        this.totalWorkingTime = 0;
                        this.totalTasks = 0;
                        this.processedTasks = 0;
                        this.changedTasks = 0;
                    }
                    ResultReview.prototype.workingTimeImprovement = function () {
                        if (this.final.totalDuration <= 0)
                            return 0;
                        else if (this.initial.totalDuration <= 0)
                            return 100;
                        else {
                            var different = this.initial.totalDuration - this.final.totalDuration;
                            //return (100 * different) / this.initial.totalDuration;
                            return different / Scheduler.minuteInMiliseconds;
                        }
                    };
                    ResultReview.prototype.travelImprovement = function () {
                        if (this.final.travelDuration === 0)
                            return 0;
                        else if (this.initial.travelDuration === 0)
                            return 100;
                        else {
                            var different = this.initial.travelDuration - this.final.travelDuration;
                            //return (100 * different) / this.initial.travelDuration;
                            return different / Scheduler.minuteInMiliseconds;
                        }
                    };
                    ResultReview.prototype.workingTimeEfficiency = function () {
                        if (this.final.emptyGaps === 0)
                            return 0;
                        else if (this.initial.emptyGaps === 0)
                            return 100;
                        else {
                            var different = this.initial.emptyGaps - this.final.emptyGaps;
                            //return (100 * different) / this.initial.emptyGaps;
                            return different / Scheduler.minuteInMiliseconds;
                        }
                    };
                    return ResultReview;
                }());
                AutoPlanner.ResultReview = ResultReview;
                var ResultDialog = /** @class */ (function (_super) {
                    __extends(ResultDialog, _super);
                    function ResultDialog(container, stat, onCloseCallback) {
                        var _this = _super.call(this) || this;
                        _this._pages = [];
                        _this._container = container;
                        _this._stat = stat;
                        _this._onCloseCallback = onCloseCallback;
                        _this._wasSaved = false;
                        _this.onShowDialog();
                        return _this;
                    }
                    ResultDialog.show = function (container, stat, onCloseCallback) {
                        if (ResultDialog._dialogInstance)
                            ResultDialog._dialogInstance.destroy();
                        ResultDialog._dialogInstance = new ResultDialog(container, stat, onCloseCallback);
                    };
                    ResultDialog.prototype.onShowDialog = function () {
                        var _this = this;
                        this.dialog = this._createResultDialogElement();
                        this.addPage(new ReportPage(this._container, this._stat));
                        this.addPage(new ChangesPage(this._stat));
                        this.addPage(new ErrorsPage(this._stat));
                        this.initializeTabDialog(this.dialog);
                        this.dialog.find(".saveButton").click(function (e) {
                            _this.onSave();
                            _this.destroy();
                        });
                        Scheduler.StringTable.localizeElements(this.dialog);
                        _super.prototype.create.call(this, this.dialog, 500, 450, function () {
                            if (_this._wasSaved)
                                _this._onCloseCallback("SAVE");
                            else
                                _this._onCloseCallback("DISCARD");
                        });
                    };
                    ResultDialog.prototype.onSave = function () {
                        this._wasSaved = true;
                    };
                    ResultDialog.prototype.destroy = function () {
                        for (var i = 0; i < this._pages.length; i++) {
                            this._pages[i].removeRescoComponents();
                        }
                        ResultDialog._dialogInstance = null;
                        _super.prototype.destroy.call(this);
                    };
                    ResultDialog.prototype.addPage = function (page) {
                        var rescoTabCtrl = this.dialog.find(".rescoTabCtrl");
                        var dialogControlContainer = this.dialog.find(".dialogControlContainer");
                        rescoTabCtrl.append(page.tabElement);
                        dialogControlContainer.before(page.tabContentElement);
                        this._pages.push(page);
                    };
                    ResultDialog.prototype._createResultDialogElement = function () {
                        var element = Scheduler.Utilities.createFromTemplate(ResultDialog._template);
                        element.find("ul.rescoTabCtrl").css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                        return element;
                    };
                    ResultDialog._dialogInstance = null;
                    ResultDialog._template = '\
			<div class="rescoDialog">\
				<ul class="rescoTabCtrl">\
				</ul>\
				<div class="dialogControlContainer">\
				  <button class="closeButton" data-localization="Scheduler.Msg.DiscardChanges">Discard Changes</button>&nbsp;\
				  <button class="saveButton" data-localization="Msg.Save">Save</button>\
				</div>\
			</div>\
		';
                    return ResultDialog;
                }(Scheduler.BaseDlg));
                AutoPlanner.ResultDialog = ResultDialog;
                var ReportPage = /** @class */ (function (_super) {
                    __extends(ReportPage, _super);
                    function ReportPage(container, stat) {
                        var _this = _super.call(this, "REPORT", "Scheduler.Msg.REPORT", "REPORT", "Scheduler.Msg.ReportTitle", "Auto-scheduling report.") || this;
                        _this.template = '\
			<div class="includedTasks">\
				<p>Tasks included to the optimization process.</p>\
				<ul>\
					<li class="newTasksUsed" data-localization="Scheduler.Msg.NewTasks">New tasks</li>\
					<li class="conflictedTasksUsed" data-localization="Scheduler.Msg.TasksWithConflict">Tasks with conflict</li>\
					<li class="scheduledTasksUsed" data-localization="Scheduler.Msg.AlreadyScheduledTasks">Already scheduled tasks</li>\
				</ul>\
			</div>\
			<div>\
				<table class="report" width="100%">\
					<tr class="ratioTitle">\
						<th class="emptyGap"></th>\
						<th class="travel"></th>\
						<th class="endTime"></th>\
					</tr>\
					<tr class="reportInfo">\
						<th data-localization="Scheduler.Msg.EmptyGapImprovement">Empty gap<br>improvement</th>\
						<th data-localization="Scheduler.Msg.TravelImprovement">Optimize travel<br>per day</th>\
						<th data-localization="Scheduler.Msg.EndTimeImprovement">End time<br>improvement</th>\
					</tr>\
					<tr>\
						<th><br></th>\
						<th></th>\
						<th></th>\
					</tr>\
					<tr class="reportSummary">\
						<th class="totalItems"></th>\
						<th class="optimizedItems"></th>\
						<th class="changedItems"></th>\
					</tr>\
					<tr class="reportInfo">\
						<th data-localization="Scheduler.Msg.TotalTasks">Total<br>tasks</th>\
						<th data-localization="Scheduler.Msg.ProcessedTasks">Processed<br>tasks</th>\
						<th data-localization="Scheduler.Msg.ChangedTasks">Changed<br>tasks</th>\
					</tr>\
				</table>\
			</div>\
		';
                        _this.addBodyContent(_this.template);
                        _this.tabContentBodyElement.css("overflow", "visible");
                        _this._initializeResultPage(container, stat);
                        return _this;
                    }
                    ReportPage.prototype._initializeResultPage = function (container, stat) {
                        var travelImprovement = stat ? stat.travelImprovement() : 0;
                        var settings = container.settings.autoPlanner;
                        if (!stat || !stat.processedTasks || container.settings.autoPlanner.autoScheduleMode == Scheduler.eMode.RouteOptimization) {
                            this.writeRatio(this.tabContentBodyElement.find(".emptyGap"), 0);
                            this.writeRatio(this.tabContentBodyElement.find(".endTime"), 0);
                        }
                        else {
                            this.writeRatio(this.tabContentBodyElement.find(".emptyGap"), stat.workingTimeEfficiency());
                            this.writeRatio(this.tabContentBodyElement.find(".endTime"), stat.workingTimeImprovement());
                        }
                        this.writeRatio(this.tabContentBodyElement.find(".travel"), travelImprovement);
                        this.tabContentBodyElement.find(".totalItems").text(stat.totalTasks);
                        this.tabContentBodyElement.find(".changedItems").text(stat.changedTasks);
                        this.tabContentBodyElement.find(".optimizedItems").text(stat.processedTasks);
                        var sourceInput = Scheduler.Container.inputs.unscheduledTasks;
                        if (!sourceInput || !sourceInput.entityName)
                            this.tabContentBodyElement.find(".newTasksUsed").hide();
                        else if (!settings.autoScheduleNewTasks)
                            this.setElementIgnored(this.tabContentBodyElement.find(".newTasksUsed"));
                        if (!settings.autoScheduleConflictedTasks)
                            this.setElementIgnored(this.tabContentBodyElement.find(".conflictedTasksUsed"));
                        if (!settings.autoScheduleTasksYetNotStarted)
                            this.setElementIgnored(this.tabContentBodyElement.find(".scheduledTasksUsed"));
                    };
                    ReportPage.prototype.writeRatio = function (ctrl, value) {
                        value = Math.ceil(value);
                        if (value === 0)
                            ctrl.text("-");
                        else if (value === 100) {
                            ctrl.text("-");
                            //ctrl.text("100%");
                        }
                        else {
                            var h = value / 60;
                            if (Math.abs(h) < 1)
                                ctrl.text(value + "min");
                            else
                                ctrl.text(h.toFixed(1) + "h");
                            if (value < 0)
                                ctrl.css("color", "red");
                            else if (value > 0)
                                ctrl.css("color", "green");
                        }
                    };
                    ReportPage.prototype.setElementIgnored = function (element) {
                        element.css({ "text-decoration": "line-through" });
                        element.css({ "color": "red" });
                    };
                    return ReportPage;
                }(Scheduler.BasePage));
                var ChangesPage = /** @class */ (function (_super) {
                    __extends(ChangesPage, _super);
                    function ChangesPage(stat) {
                        var _this = _super.call(this, "CHANGES", "Scheduler.Msg.CHANGES", "CHANGES", "Scheduler.Msg.ChangesTitle", "Auto-scheduling changes.") || this;
                        _this.template = '\
		';
                        //this.addBodyContent(this.template); // body content is set by "changeLogList" id below
                        _this.tabContentBodyElement.attr("id", "changeLogList");
                        _this.tabContentBodyElement.css("display", "block");
                        _this._initializeChangesPage(stat);
                        return _this;
                    }
                    ChangesPage.prototype._initializeChangesPage = function (stat) {
                        var changes = stat ? stat.changeLogs : undefined;
                        if (changes && changes.length > 0) {
                            var content = "";
                            for (var i = 0; i < changes.length; i++)
                                content += changes[i] + "<p class='textLine'></p><br>";
                            this.tabContentBodyElement.append(content);
                        }
                    };
                    return ChangesPage;
                }(Scheduler.BasePage));
                var ErrorsPage = /** @class */ (function (_super) {
                    __extends(ErrorsPage, _super);
                    function ErrorsPage(stat) {
                        var _this = _super.call(this, "ERRORS", "Scheduler.Msg.ERRORS", "ERRORS", "Scheduler.Msg.ErrorsTitle", "Auto-scheduling error.") || this;
                        _this.template = '\
		';
                        //this.addBodyContent(this.template); // body content is set by "errorList" id below
                        _this.tabContentBodyElement.attr("id", "errorList");
                        _this.tabContentBodyElement.css("display", "block");
                        _this._initializeErrorsPage(stat);
                        return _this;
                    }
                    ErrorsPage.prototype._initializeErrorsPage = function (stat) {
                        var errors = stat ? stat.errors : undefined;
                        if (errors && errors.length > 0) {
                            var content = "";
                            for (var i = 0; i < errors.length; i++)
                                content += errors[i] + "<br><br>";
                            this.tabContentBodyElement.append(content);
                        }
                    };
                    return ErrorsPage;
                }(Scheduler.BasePage));
            })(AutoPlanner = Scheduler.AutoPlanner || (Scheduler.AutoPlanner = {}));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=autoPlannerResultDlg.js.map