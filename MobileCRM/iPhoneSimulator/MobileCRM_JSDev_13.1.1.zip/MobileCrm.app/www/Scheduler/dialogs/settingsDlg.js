///<reference path="../../../../MobileCrm/www/TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../../../MobileCrm/www/Controls/appColors.ts" />
///<reference path="../../../../MobileCrm/www/Controls/listBox.ts" />
///<reference path="../container.ts" />
///<reference path="baseDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var RequiredUpdate;
            (function (RequiredUpdate) {
                RequiredUpdate[RequiredUpdate["None"] = 0] = "None";
                RequiredUpdate[RequiredUpdate["Reload"] = 1] = "Reload";
                RequiredUpdate[RequiredUpdate["Reinitialize"] = 2] = "Reinitialize";
            })(RequiredUpdate = Scheduler.RequiredUpdate || (Scheduler.RequiredUpdate = {}));
            // Class for custom defined settings item
            var FilterListItem = /** @class */ (function () {
                function FilterListItem(id, name) {
                    this.id = id;
                    this.name = name;
                }
                return FilterListItem;
            }());
            Scheduler.FilterListItem = FilterListItem;
            // Class for custom defined filters
            var FilterList = /** @class */ (function () {
                function FilterList(name, contentLocalizationKey, contentName, filteredByLocalizationKey, filteredByName, dataFetch) {
                    this.name = name;
                    this.contentLocalizationKey = contentLocalizationKey;
                    this.contentName = contentName;
                    this.filteredByLocalizationKey = filteredByLocalizationKey;
                    this.filteredByName = filteredByName;
                    this.dataFetch = dataFetch;
                }
                FilterList.initialize = function (filterDataSources) {
                    if (!filterDataSources)
                        return;
                    FilterList.CustomFilters = [];
                    for (var i = 0; i < filterDataSources.length; i++) {
                        var dataSource = filterDataSources[i];
                        FilterList.CustomFilters.push(new FilterList(dataSource.name, dataSource.contentLocalizationKey, dataSource.contentName, dataSource.filteredByLocalizationKey, dataSource.filteredByName, dataSource.fetch));
                    }
                };
                FilterList.prototype.loadItems = function (onLoadCallback) {
                    var name = this.name;
                    var list = FilterList._filterItemCacheDictionary[name];
                    if (list !== undefined)
                        onLoadCallback(list);
                    else {
                        MobileCRM.FetchXml.Fetch.executeFromXML(this.dataFetch, function (result) {
                            var list = result.map(function (i) { return new FilterListItem(i[0], i[1]); });
                            FilterList._filterItemCacheDictionary[name] = list;
                            onLoadCallback(list);
                        }, function (err) {
                            FilterList._filterItemCacheDictionary[name] = null;
                            Scheduler.StringTable.alert((Scheduler.StringTable.get("Err.CantFetchEntity") || "Can't fetch entity") + " " + name + ". " + err);
                            onLoadCallback(null);
                        }, null);
                    }
                };
                FilterList.CustomFilters = [];
                FilterList._filterItemCacheDictionary = {};
                return FilterList;
            }());
            Scheduler.FilterList = FilterList;
            // Settings dialog implementation
            var SettingsDialog = /** @class */ (function (_super) {
                __extends(SettingsDialog, _super);
                function SettingsDialog(container) {
                    var _this = _super.call(this) || this;
                    _this._pages = [];
                    _this.settings = null;
                    _this.container = container;
                    _this.settings = new Scheduler.Settings(container.settings);
                    _this.onShowDialog();
                    return _this;
                }
                SettingsDialog.show = function (container) {
                    if (SettingsDialog._dialogInstance)
                        SettingsDialog._dialogInstance.destroy();
                    SettingsDialog._dialogInstance = new SettingsDialog(container);
                };
                SettingsDialog.prototype.onShowDialog = function () {
                    var _this = this;
                    if (this.container.dataLoadEnabed(true) === false)
                        return;
                    this.dialog = this._createSettingsDialogElement();
                    //let customizationPage = new CustomizationPage(this.settings, this.container);
                    //this.addPage(customizationPage);
                    //this.addPage(new AutoSchedulePage(this.settings));
                    //this.addPage(new ViewsPage(this.settings, this.container));
                    //this.addPage(new ScheduleRulesPage(this.settings, this.container, this.zIndex));
                    for (var i = 0; i < FilterList.CustomFilters.length; i++) {
                        if (FilterList.CustomFilters[i].dataFetch)
                            this.addPage(new CustomFilterPage(this.settings, FilterList.CustomFilters[i], i));
                    }
                    this.initializeTabDialog(this.dialog);
                    this.dialog.find(".saveButton").click(function (e) {
                        _this.onSave();
                        _this.destroy();
                    });
                    Scheduler.StringTable.localizeElements(this.dialog);
                    _super.prototype.create.call(this, this.dialog, 600, 500);
                    //customizationPage.initializeSlider();
                };
                SettingsDialog.prototype.onSave = function () {
                    var oldFilter = this.container.settings;
                    var newFilter = this.settings;
                    var requiredUpdate = newFilter.customFilterSelection ? RequiredUpdate.None : RequiredUpdate.Reload;
                    if (oldFilter.customFilterSelection && newFilter.customFilterSelection) {
                        for (var i = 0; i < FilterList.CustomFilters.length; i++) {
                            var name_1 = FilterList.CustomFilters[i].name;
                            var srcList = oldFilter.customFilterSelection[name_1];
                            var dstList = newFilter.customFilterSelection[name_1];
                            if (!Scheduler.arraysAreEqual(srcList, dstList)) {
                                requiredUpdate = RequiredUpdate.Reload;
                                break;
                            }
                        }
                    }
                    if (newFilter.autoPlanner.calculateTravel && !this.container.travelCalculationIsEnabled)
                        newFilter.autoPlanner.calculateTravel = false;
                    if (oldFilter.resourceView !== newFilter.resourceView) {
                        this.container.setResourceView(newFilter.resourceView);
                        requiredUpdate = (this.container.taskTemplateHeight || (this.container.taskTemplateHeight === 0)) ? RequiredUpdate.Reload : RequiredUpdate.Reinitialize;
                    }
                    if (oldFilter.unscheduledView != newFilter.unscheduledView) {
                        this.container.setHorizontalView(newFilter.unscheduledView);
                        requiredUpdate = RequiredUpdate.Reinitialize;
                    }
                    if (oldFilter.scheduledView != newFilter.scheduledView) {
                        this.container.setTaskView(newFilter.scheduledView);
                        requiredUpdate = RequiredUpdate.Reinitialize;
                    }
                    if (oldFilter.defaultOfficeAddress != newFilter.defaultOfficeAddress) {
                        var office = Scheduler.Container.defaultOffice;
                        if (!office.id) // if office contains id, it means that it has been loaded from CRM
                            office.locationAddress = newFilter.defaultOfficeAddress;
                    }
                    if (oldFilter.autoPlanner.manualScheduleMode != newFilter.autoPlanner.manualScheduleMode)
                        this.container.buttonsBar.updateAutoPlannerIcon();
                    if (requiredUpdate >= RequiredUpdate.Reload) {
                        this.settings.setDirty();
                        this.container.settings = newFilter;
                        if (requiredUpdate === RequiredUpdate.Reinitialize) {
                            this.container.reinitializeComponents(function () {
                            });
                        }
                        else {
                            this.container.reloadAll();
                        }
                    }
                    else if (newFilter.isDirty)
                        this.container.viewCtrl.onFilterChanged(newFilter);
                    this.container.onSettingsDialogSaved();
                };
                SettingsDialog.prototype.destroy = function () {
                    for (var i = 0; i < this._pages.length; i++)
                        this._pages[i].removeRescoComponents();
                    SettingsDialog._dialogInstance = null;
                    _super.prototype.destroy.call(this);
                };
                SettingsDialog.prototype.addPage = function (page) {
                    var rescoTabCtrl = this.dialog.find(".rescoTabCtrl");
                    var dialogControlContainer = this.dialog.find(".dialogControlContainer");
                    rescoTabCtrl.append(page.tabElement);
                    dialogControlContainer.before(page.tabContentElement);
                    this._pages.push(page);
                };
                SettingsDialog.prototype._createSettingsDialogElement = function () {
                    var element = Scheduler.Utilities.createFromTemplate(SettingsDialog._template);
                    element.find("ul.rescoTabCtrl").css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    return element;
                };
                SettingsDialog._dialogInstance = null;
                SettingsDialog._template = '\
			<div class="rescoDialog" >\
				<ul class="rescoTabCtrl">\
				</ul>\
				<div class="dialogControlContainer">\
				  <button class="closeButton" data-localization="Msg.Close">Close</button>&nbsp;\
				  <button class="saveButton" data-localization="Msg.SaveClose">Save & Close</button>\
				</div>\
			</div>\
		';
                return SettingsDialog;
            }(Scheduler.BaseDlg));
            Scheduler.SettingsDialog = SettingsDialog;
            var CustomizationPage = /** @class */ (function (_super) {
                __extends(CustomizationPage, _super);
                function CustomizationPage(settings, container, changeNotifier, isCollapsable) {
                    var _this = _super.call(this, "SETTINGS", "Scheduler.Msg.SETTINGS", "SETTINGS", "Scheduler.Msg.FilterSettings", "Timetable Settings", isCollapsable) || this;
                    _this._settings = null;
                    _this._moveStepOptions = new Scheduler.Dictionary();
                    var template1 = '<p data-localization="Scheduler.Msg.ShowTimeInterval">Working hours you will use on the scheduler view</p>\
				<div>\
					<div class="rescoSlider"></div>\
				</div>';
                    var completedAndCanceledTemplate = '<p>\
					<label class="checkboxLabel">\
						<input type="checkbox" class="showCompletedAndCanceled">\
						<span data-localization="Scheduler.Msg.ShowCompleted">Show completed or canceled tasks</span>\
					</label>\
				</p>';
                    var weekendsTemplate = '<p>\
					<label class="checkboxLabel">\
						<input type="checkbox" class="showWeekends">\
						<span data-localization="Scheduler.Msg.ShowWeekends">Show weekends</span>\
					</label>\
				</p>';
                    var holidaysTemplate = '<p>\
					<label class="checkboxLabel">\
						<input type="checkbox" class="showHolidays">\
						<span data-localization="Scheduler.Msg.ShowHolidays">Show holidays</span>\
					</label>\
				</p>';
                    var statusLegendTemplate = '<p>\
					<label class="checkboxLabel">\
						<input type="checkbox" class="showStatusLegend">\
						<span data-localization="Scheduler.Msg.ShowStatusLegend">Show status legend</span>\
					</label>\
				</p>';
                    var template2 = '<div style="display:flex">\
					<div class="moveStepBlock" style="margin-right:10px">\
						<p data-localization="Scheduler.Msg.RoundMinutes">Rounded Minutes:</p>\
						<select class="roundMinutes" style="width:120px;min-height:27px;">\
							<option value="1" data-localization="Msg.Minute" data-localizationvalues="1">1 Minute</option>\
							<option value="5" data-localization="Msg.Minutes" data-localizationvalues="5" selected="selected">5 Minutes</option>\
							<option value="10" data-localization="Msg.Minutes" data-localizationvalues="10">10 Minutes</option>\
							<option value="15" data-localization="Msg.Minutes" data-localizationvalues="15">15 Minutes</option>\
							<option value="20" data-localization="Msg.Minutes" data-localizationvalues="20">20 Minutes</option>\
							<option value="30" data-localization="Msg.Minutes" data-localizationvalues="30">30 Minutes</option>\
							<option value="60" data-localization="Msg.Minutes" data-localizationvalues="60">60 Minutes</option>\
						</select>\
					</div>\
					<div class="moveStepBlock">\
						<p data-localization="Scheduler.Msg.MoveStep">Manual drag interval:</p>\
						<select class="moveStep" style="width:120px;min-height:27px;">\
						</select>\
					</div>\
				</div>';
                    var template = template1 + (container.completedAndCanceledEnabled ? completedAndCanceledTemplate : "") + weekendsTemplate + statusLegendTemplate + template2; //template1 + (container.holidaysEnabled ? holidaysTemplate : "") + template2; // this is temporary disabled, while grid view does not support arbitrary days count per week.
                    _this.addBodyContent(template);
                    _this._settings = settings;
                    _this._container = container;
                    _this._moveStepOptions.Add("1", '<option value="1" data-localization="Msg.Minute" data-localizationvalues="1">1 Minute</option>');
                    _this._moveStepOptions.Add("5", '<option value="5" data-localization="Msg.Minutes" data-localizationvalues="5">5 Minutes</option>');
                    _this._moveStepOptions.Add("10", '<option value="10" data-localization="Msg.Minutes" data-localizationvalues="10">10 Minutes</option>');
                    _this._moveStepOptions.Add("15", '<option value="15" data-localization="Msg.Minutes" data-localizationvalues="15">15 Minutes</option>');
                    _this._moveStepOptions.Add("20", '<option value="20" data-localization="Msg.Minutes" data-localizationvalues="20">20 Minutes</option>');
                    _this._moveStepOptions.Add("30", '<option value="30" data-localization="Msg.Minutes" data-localizationvalues="30">30 Minutes</option>');
                    _this._moveStepOptions.Add("60", '<option value="60" data-localization="Msg.Minutes" data-localizationvalues="60">60 Minutes</option>');
                    var self = _this;
                    var content = _this.tabContentBodyElement;
                    if (!_this._settings.roundMinutes)
                        _this._settings.roundMinutes = 5;
                    if (!_this._settings.moveStepInMinutes)
                        _this._settings.moveStepInMinutes = 15;
                    _this.disableSettingsItemsUnusedInMonthView(_this._container.viewCtrl.zoom.inMonthsMode());
                    content.find(".showCompletedAndCanceled")
                        .change(function (e) {
                        self._settings.showCompletedAndCanceled = e.target.checked;
                        self._settings.setDirty();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(self._settings.showCompletedAndCanceled, "showCompletedAndCanceled", Scheduler.SettingsChangeRequest.RedrawNeeded);
                    })
                        .prop('checked', _this._settings.showCompletedAndCanceled);
                    content.find(".showWeekends")
                        .change(function (e) {
                        self._settings.showWeekends = e.target.checked;
                        self._settings.setDirty();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(self._settings.showWeekends, "showWeekends", Scheduler.SettingsChangeRequest.RedrawNeeded);
                    })
                        .prop("checked", _this._settings.showWeekends);
                    content.find(".showHolidays")
                        .change(function (e) {
                        self._settings.showHolidays = e.target.checked;
                        self._settings.setDirty();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(self._settings.showHolidays, "showHolidays", Scheduler.SettingsChangeRequest.RedrawNeeded);
                    })
                        .prop("checked", _this._settings.showHolidays);
                    content.find(".showStatusLegend")
                        .change(function (e) {
                        self._settings.showStatusLegend = e.target.checked;
                        self._settings.setDirty();
                        self._container.updateStatusLegendVisibility();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(self._settings.showStatusLegend, "showStatusLegend", Scheduler.SettingsChangeRequest.None);
                    })
                        .prop("checked", _this._settings.showStatusLegend);
                    content.find(".roundMinutes")
                        .val(_this._settings.roundMinutes)
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        var value = +ctrlTarget.options[idx].value;
                        self._settings.roundMinutes = value;
                        self._validateMoveStep();
                        self._settings.setDirty();
                        self._updateMoveStepOptions();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(self._settings.roundMinutes, "roundMinutes", Scheduler.SettingsChangeRequest.None);
                    });
                    content.find(".moveStep")
                        .val(_this._settings.moveStepInMinutes)
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        var value = +ctrlTarget.options[idx].value;
                        self._settings.moveStepInMinutes = value;
                        self._validateMoveStep();
                        self._settings.setDirty();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(self._settings.moveStepInMinutes, "moveStepInMinutes", Scheduler.SettingsChangeRequest.None);
                    });
                    _this._updateMoveStepOptions(_this._settings.moveStepInMinutes.toString());
                    _this._changeNotifier = changeNotifier;
                    return _this;
                }
                CustomizationPage.prototype.updateComponentsDisabledStatus = function () {
                    this.disableSettingsItemsUnusedInMonthView(this._container.viewCtrl.zoom.inMonthsMode());
                    this.initializeSlider();
                };
                CustomizationPage.prototype._validateMoveStep = function () {
                    if (this._settings.moveStepInMinutes < this._settings.roundMinutes) {
                        this._settings.moveStepInMinutes = this._settings.roundMinutes;
                        this.tabContentBodyElement.find(".moveStep").val(this._settings.moveStepInMinutes);
                    }
                };
                CustomizationPage.prototype._updateMoveStepOptions = function (selectedValue) {
                    var moveStepElement = this.tabContentBodyElement.find(".moveStep");
                    if (moveStepElement.length > 0) {
                        var selectElement = moveStepElement[0];
                        var selectedOptionValue_1 = selectedValue ? selectedValue : selectElement.options[selectElement.selectedIndex].value;
                        moveStepElement.empty();
                        var keys = this._moveStepOptions.Keys();
                        for (var i = 0; i < keys.length; i++) {
                            var key = keys[i];
                            if ((+key) >= this._settings.roundMinutes) {
                                moveStepElement.append(this._moveStepOptions.Item(key));
                            }
                        }
                        var selectedIndex_1 = -1;
                        moveStepElement.find("option").each(function (index, elem) {
                            if (elem instanceof HTMLOptionElement) {
                                if (elem.getAttribute("value") === selectedOptionValue_1) {
                                    selectedIndex_1 = index;
                                }
                            }
                        });
                        selectElement.selectedIndex = selectedIndex_1;
                        Scheduler.StringTable.localizeElements(moveStepElement);
                    }
                };
                CustomizationPage.prototype.disableSettingsItemsUnusedInMonthView = function (disable) {
                    var content = this.tabContentBodyElement;
                    if (disable) {
                        content.find(".moveStep").attr("disabled", "disabled");
                        content.find(".showCompletedAndCanceled").attr("disabled", "disabled");
                        content.find(".showWeekends").attr("disabled", "disabled");
                    }
                    else {
                        content.find(".moveStep").removeAttr("disabled");
                        content.find(".showCompletedAndCanceled").removeAttr("disabled");
                        content.find(".showWeekends").removeAttr("disabled");
                    }
                };
                CustomizationPage.prototype.initializeSlider = function () {
                    var _this = this;
                    var content = this.tabContentBodyElement;
                    var rescoSlider = new Resco.Controls.Scheduler.Slider(content.find(".rescoSlider")[0], this._settings.startWorkingHour, this._settings.endWorkingHour, this._container.viewCtrl.zoom.inMonthsMode());
                    rescoSlider.startValueChanged.add(this, function (sender, e) {
                        _this._settings.startWorkingHour = e.value;
                        _this._settings.setDirty();
                        if (_this._changeNotifier)
                            _this._changeNotifier.onChange(_this._settings.startWorkingHour, "startWorkingHour", Scheduler.SettingsChangeRequest.RedrawNeeded);
                    });
                    rescoSlider.endValueChanged.add(this, function (sender, e) {
                        _this._settings.endWorkingHour = e.value;
                        _this._settings.setDirty();
                        if (_this._changeNotifier)
                            _this._changeNotifier.onChange(_this._settings.endWorkingHour, "endWorkingHour", Scheduler.SettingsChangeRequest.RedrawNeeded);
                    });
                };
                return CustomizationPage;
            }(Scheduler.BasePage));
            Scheduler.CustomizationPage = CustomizationPage;
            var CustomFilterPage = /** @class */ (function (_super) {
                __extends(CustomFilterPage, _super);
                function CustomFilterPage(settings, list, index, changeNotifier, isCollapsable) {
                    var _this = _super.call(this, "listOf" + list.name, list.contentLocalizationKey, list.contentName, list.contentLocalizationKey, list.contentName, isCollapsable) || this;
                    _this._allItemData = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";
                    _this._settings = settings;
                    _this._changeNotifier = changeNotifier;
                    list.loadItems(function (items) {
                        _this._initializeListPicker(items, index);
                    });
                    return _this;
                }
                CustomFilterPage.prototype._initializeListPicker = function (list, index) {
                    var _this = this;
                    if (list && list.length > 0) {
                        var filterItem_1 = FilterList.CustomFilters[index];
                        var selectedItems = this._settings.customFilterSelection[filterItem_1.name];
                        var listItems = list.slice();
                        listItems.splice(0, 0, new FilterListItem(this._allItemData, Scheduler.StringTable.get("Msg.All") || "All"));
                        var pickerSettings = {
                            minHeight: 27,
                            arrowImage: Scheduler.Container.imageFolder + "arrow_down.png",
                            arrowWidth: 27,
                            imageContainerSize: { width: 22, height: 22 },
                            appColors: Scheduler.Container.appColors,
                            dataSource: listItems,
                            displayMember: "name",
                            valueMember: "id",
                            separator: "; "
                        };
                        var simpleListMultiPicker = new Controls.SimpleListMultiPicker(pickerSettings);
                        simpleListMultiPicker.suspendUpdate();
                        var somethingIsSelected = false;
                        if (selectedItems) {
                            for (var i = 0; i < simpleListMultiPicker.items.length; i++) {
                                var listItem = simpleListMultiPicker.items[i];
                                if (selectedItems.indexOf(listItem.data) >= 0) {
                                    listItem.isSelected = true;
                                    somethingIsSelected = true;
                                }
                            }
                        }
                        if (!somethingIsSelected && simpleListMultiPicker.items.length > 0)
                            simpleListMultiPicker.items[0].isSelected = true;
                        simpleListMultiPicker.resumeUpdate();
                        simpleListMultiPicker.itemClicked.add(this, (function (sender, e) {
                            if (e.item.data === _this._allItemData && e.item.isSelected) {
                                for (var i = 1; i < sender.items.length; i++)
                                    sender.items[i].isSelected = false;
                            }
                            else {
                                if (e.item.isSelected) {
                                    sender.items[0].isSelected = false;
                                }
                                else {
                                    var isAnyItemSelected = false;
                                    for (var i = 1; i < sender.items.length; i++) {
                                        if (sender.items[i].isSelected) {
                                            isAnyItemSelected = true;
                                            break;
                                        }
                                    }
                                    if (isAnyItemSelected) {
                                        sender.items[0].isSelected = false;
                                    }
                                    else {
                                        sender.items[0].isSelected = true;
                                    }
                                }
                            }
                        }));
                        simpleListMultiPicker.selectionChanged.add(this, function (sender, e) {
                            var selectedItems = e.selectedItems.map(function (item) {
                                return item.data;
                            });
                            selectedItems = selectedItems.filter(function (id) {
                                return id !== _this._allItemData;
                            });
                            _this._settings.customFilterSelection[filterItem_1.name] = selectedItems.length > 0 ? selectedItems : null;
                            _this._settings.setDirty();
                            if (_this._changeNotifier)
                                _this._changeNotifier.onChange(_this._settings.customFilterSelection, "customFilterSelection", Scheduler.SettingsChangeRequest.ReloadNeeded);
                        });
                        this.addBodyContent(simpleListMultiPicker.element);
                    }
                };
                return CustomFilterPage;
            }(Scheduler.BasePage));
            Scheduler.CustomFilterPage = CustomFilterPage;
            var ViewsPage = /** @class */ (function (_super) {
                __extends(ViewsPage, _super);
                function ViewsPage(settings, container, changeNotifier, isCollapsable) {
                    var _this = _super.call(this, "VIEWS", "Scheduler.Msg.VIEWS", "VIEWS", "Scheduler.Msg.ViewTitle", "Define custom views", isCollapsable) || this;
                    _this._settings = settings;
                    var template = "";
                    if (container.useTaskTemplateContent) {
                        template +=
                            '<p class="scheduledViewLabel" data-localization="Scheduler.Msg.ScheduledTaskView">Scheduled Task View</p>\
					<select class="scheduledView" style="width:100%"></select>';
                    }
                    template +=
                        '<p class="unscheduledViewLabel" data-localization="Scheduler.Msg.SourceView">Source (Unscheduled Task) View</p>\
				<select class="unscheduledView" style="width:100%"></select>\
				<p class="resourceViewLabel" data-localization="Scheduler.Msg.ResourceView">Resource View</p>\
				<select class="resourceView" style="width:100%"></select>';
                    var config = Scheduler.Container.inputs;
                    _this.addBodyContent(template);
                    if (container.useTaskTemplateContent) {
                        _this.initializeList(".scheduledView", container.getTaskViews(), "scheduledView", config.scheduledTasks);
                    }
                    _this.initializeList(".unscheduledView", container.getSourceViews(), "unscheduledView", config.unscheduledTasks);
                    _this.initializeList(".resourceView", container.getResourceViews(), "resourceView", config.resources);
                    _this._changeNotifier = changeNotifier;
                    return _this;
                }
                ViewsPage.prototype.initializeList = function (element, views, selectedView, inputs) {
                    var _this = this;
                    var selectCtrl = this.tabContentBodyElement.find(element);
                    if (!inputs || !inputs.isValid) {
                        selectCtrl.hide();
                        this.tabContentBodyElement.find(element + 'Label').hide();
                    }
                    else if (views.length <= 0) {
                        var option = document.createElement('option');
                        option.text = "Default";
                        option.value = "";
                        option.selected = true;
                        selectCtrl.append(option);
                        selectCtrl.attr("disabled", "disabled");
                    }
                    else {
                        for (var i = 0; i < views.length; i++) {
                            var option = document.createElement('option');
                            option.text = views[i];
                            option.value = option.text;
                            if (option.value === this._settings[selectedView])
                                option.selected = true;
                            if (option.text === "@FallbackView") {
                                option.text = "Default";
                                option.value = "";
                            }
                            selectCtrl.append(option);
                        }
                        if (views.length == 1)
                            selectCtrl.attr("disabled", "disabled");
                        else
                            selectCtrl.change(function (e) {
                                var item = e.target;
                                var idx = item.selectedIndex;
                                if (idx >= 0 && item[idx].value !== "") {
                                    _this._settings.setDirty();
                                    _this._settings[selectedView] = item[idx].value;
                                    if (_this._changeNotifier)
                                        _this._changeNotifier.onChange(_this._settings[selectedView], selectedView, Scheduler.SettingsChangeRequest.ReinitializationNeeded);
                                }
                            });
                    }
                };
                return ViewsPage;
            }(Scheduler.BasePage));
            Scheduler.ViewsPage = ViewsPage;
            var AutoSchedulePage = /** @class */ (function (_super) {
                __extends(AutoSchedulePage, _super);
                function AutoSchedulePage(settings, container, changeNotifier, isCollapsable) {
                    var _this = _super.call(this, "SCHEDULE", "Scheduler.Msg.MANUAL_MOVE", "MANUAL MOVE", "Scheduler.Msg.ScheduleTitle", "Drag & drop scheduling", isCollapsable) || this;
                    _this.addBodyContent('<select class="settingsDlgDropBehavior">\
					<option value="0" data-localization="Scheduler.Msg.ManualDrop">Manually select time slot and Resource</option>\
					<option value="1" data-localization="Scheduler.Msg.SemiOptimizedDrop">Optimize time slots for selected Resource</option>\
					<option value="2" data-localization="Scheduler.Msg.OptimizedDrop">Optimize time slots and used Resource (full optimization)</option>\
				</select>\
				</br></br>\
				<p class="title" data-localization="Scheduler.Msg.RescheduleTitle">Auto-schedule Options</p>\
				<p></p>\
				<label class="checkboxLabel">\
					<input type="checkbox" class="autoScheduleNew">\
					<span data-localization="Scheduler.Msg.AutoScheduleNew">Auto-schedule new Tasks</span>\
				</label>\
				<p></p>\
				<label class="checkboxLabel">\
					<input type="checkbox" class="autoScheduleConflicted">\
					<span data-localization="Scheduler.Msg.AutoScheduleConflicted">Reschedule conflicted Tasks</span>\
				</label>\
				<p></p>\
				<label class="checkboxLabel">\
					<input type="checkbox" class="autoScheduleReady">\
					<span data-localization="Scheduler.Msg.AutoScheduleReady">Reschedule already scheduled Tasks</span>\
				</label>\
				</br></br>\
				<p data-localization="Scheduler.Msg.OldUnscheduledTasks">Before start of optimization:</p>\
				<select class="unrealizedTaskStrategy">\
					<option value="0" data-localization="Scheduler.Msg.DoNothing">No action required</option>\
					<option value="1" data-localization="Scheduler.Msg.SetAsCanceled">Set old unrealized tasks as Canceled</option>\
				</select>\
				');
                    _this._container = container;
                    var content = _this.tabContentBodyElement;
                    var autoPlanner = settings.autoPlanner;
                    var self = _this;
                    content.find(".settingsDlgDropBehavior")
                        .val([autoPlanner.manualScheduleMode.toString()])
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        autoPlanner.manualScheduleMode = +ctrlTarget.options[idx].value;
                        settings.setDirty();
                        self._container.buttonsBar.updateAutoPlannerIcon();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(autoPlanner.manualScheduleMode, "autoPlanner.manualScheduleMode", Scheduler.SettingsChangeRequest.None);
                    });
                    var autoScheduleNew = content.find(".autoScheduleNew");
                    var sourceInput = Scheduler.Container.inputs.unscheduledTasks;
                    if (!sourceInput || !sourceInput.entityName)
                        autoScheduleNew.hide();
                    else
                        autoScheduleNew.change(function (e) {
                            autoPlanner.autoScheduleNewTasks = e.target.checked;
                            settings.setDirty();
                            if (self._changeNotifier)
                                self._changeNotifier.onChange(autoPlanner.autoScheduleNewTasks, "autoPlanner.autoScheduleNewTasks", Scheduler.SettingsChangeRequest.None);
                        })
                            .prop('checked', autoPlanner.autoScheduleNewTasks);
                    content.find(".autoScheduleConflicted")
                        .change(function (e) {
                        autoPlanner.autoScheduleConflictedTasks = e.target.checked;
                        settings.setDirty();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(autoPlanner.autoScheduleConflictedTasks, "autoPlanner.autoScheduleConflictedTasks", Scheduler.SettingsChangeRequest.None);
                    })
                        .prop('checked', autoPlanner.autoScheduleConflictedTasks);
                    content.find(".autoScheduleReady")
                        .change(function (e) {
                        autoPlanner.autoScheduleTasksYetNotStarted = e.target.checked;
                        settings.setDirty();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(autoPlanner.autoScheduleTasksYetNotStarted, "autoPlanner.autoScheduleTasksYetNotStarted", Scheduler.SettingsChangeRequest.None);
                    })
                        .prop('checked', autoPlanner.autoScheduleTasksYetNotStarted);
                    content.find(".unrealizedTaskStrategy")
                        .val(autoPlanner.unrealizedTaskStrategy)
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        var value = +ctrlTarget.options[idx].value;
                        autoPlanner.unrealizedTaskStrategy = value;
                        settings.setDirty();
                        if (self._changeNotifier)
                            self._changeNotifier.onChange(autoPlanner.unrealizedTaskStrategy, "autoPlanner.unrealizedTaskStrategy", Scheduler.SettingsChangeRequest.None);
                    });
                    _this._changeNotifier = changeNotifier;
                    return _this;
                }
                return AutoSchedulePage;
            }(Scheduler.BasePage));
            Scheduler.AutoSchedulePage = AutoSchedulePage;
            var ScheduleRulesPage = /** @class */ (function (_super) {
                __extends(ScheduleRulesPage, _super);
                function ScheduleRulesPage(settings, container, changeNotifier, isCollapsable) {
                    var _this = _super.call(this, "RULES", "Scheduler.Msg.RULES", "RULES", "Scheduler.Msg.AutoScheduleRules", "Auto-schedule Rules", isCollapsable) || this;
                    _this.addBodyContent('<p data-localization="Msg.DefaultOfficeAddress">Default Office Address</p>\
				<input type="text" class="defaultOfficeAddr" style="width:100%" rows="4" >\
				</br></br>\
				<div class="travelCalculationCheckBox">\
					<label class="checkboxLabel">\
						<input type="checkbox" class="calculateTravel">\
						<span data-localization="Scheduler.Msg.CalculateTravel">Use google maps to calculate travel duration (Google API Key required)</span>\
					</label>\
					</br></br>\
				</div>\
				<p data-localization="Scheduler.Msg.ShiftBetweenTask">The minimum gap between the scheduled task and current time</p>\
				<div data-timeField="minGapBetweenTaskAndPlanning" class="minGapBetweenTaskAndPlanning"></div>\
				<p data-localization="Scheduler.Msg.PauseBetweenTasks">The minimum gap between tasks</p>\
				<div data-timeField="minGapBetweenTasks" class="minGapBetweenTasks"></div>\
				');
                    var content = _this.tabContentBodyElement;
                    _this._settings = settings;
                    _this._container = container;
                    var defaultAddress = _this.tabContentElement.find(".defaultOfficeAddr");
                    if (defaultAddress && defaultAddress.length > 0) {
                        var address = Scheduler.Container.defaultOffice.locationAddress;
                        if (address && Scheduler.Container.defaultOffice.id)
                            defaultAddress.attr("readOnly", "true");
                        else
                            address = settings.defaultOfficeAddress;
                        defaultAddress
                            .val(address)
                            .change(function (e) {
                            settings.defaultOfficeAddress = e.target.value;
                            settings.setDirty();
                            if (_this._changeNotifier)
                                _this._changeNotifier.onChange(settings.defaultOfficeAddress, "defaultOfficeAddress", Scheduler.SettingsChangeRequest.None);
                        });
                    }
                    if (!_this._container.travelCalculationIsEnabled) {
                        content.find(".travelCalculationCheckBox").hide();
                    }
                    else {
                        content.find(".calculateTravel")
                            .change(function (e) {
                            if (e.target.checked && !_this._container.travelCalculationIsEnabled) {
                                e.target.checked = false;
                            }
                            else {
                                settings.autoPlanner.calculateTravel = e.target.checked;
                                settings.setDirty();
                                if (_this._changeNotifier)
                                    _this._changeNotifier.onChange(settings.autoPlanner.calculateTravel, "autoPlanner.calculateTravel", Scheduler.SettingsChangeRequest.None);
                            }
                        })
                            .prop('checked', settings.autoPlanner.calculateTravel);
                    }
                    _this._initTimeFields();
                    _this._changeNotifier = changeNotifier;
                    return _this;
                }
                ScheduleRulesPage.prototype._initTimeFields = function () {
                    var minRange = this._container.settings.roundMinutes;
                    var element1 = this.tabContentElement.find(".minGapBetweenTaskAndPlanning");
                    if (element1.length === 1) {
                        var time = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(this._settings.autoPlanner.minGapBetweenTaskAndPlanning));
                        this._inputTimePicker1 = this.createRescoInputTimePicker(element1, minRange, time, { width: 100, height: 27, left: 0, top: 0 }, true);
                        this._inputTimePicker1.valueChanged.add(this, this._onMinOffsetFromNowChanged);
                    }
                    var element2 = this.tabContentElement.find(".minGapBetweenTasks");
                    if (element2.length === 1) {
                        var time = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(this._settings.autoPlanner.minGapBetweenTasks));
                        this._inputTimePicker2 = this.createRescoInputTimePicker(element2, minRange, time, { width: 100, height: 27, left: 0, top: 0 }, true);
                        this._inputTimePicker2.valueChanged.add(this, this._onMinOffsetFromOtherTask);
                    }
                };
                ScheduleRulesPage.prototype._onMinOffsetFromNowChanged = function (sender, e) {
                    this._settings.autoPlanner.minGapBetweenTaskAndPlanning = Resco.Controls.RescoTime.convertFromRescoTimeToMilisecond(e.value);
                    this._settings.setDirty();
                    if (this._changeNotifier)
                        this._changeNotifier.onChange(this._settings.autoPlanner.minGapBetweenTaskAndPlanning, "autoPlanner.minGapBetweenTaskAndPlanning", Scheduler.SettingsChangeRequest.None);
                };
                ScheduleRulesPage.prototype._onMinOffsetFromOtherTask = function (sender, e) {
                    this._settings.autoPlanner.minGapBetweenTasks = Resco.Controls.RescoTime.convertFromRescoTimeToMilisecond(e.value);
                    this._settings.setDirty();
                    if (this._changeNotifier)
                        this._changeNotifier.onChange(this._settings.autoPlanner.minGapBetweenTasks, "autoPlanner.minGapBetweenTasks", Scheduler.SettingsChangeRequest.None);
                };
                ScheduleRulesPage.prototype.removeRescoComponents = function () {
                    this.disposeRescoTimeControls(this._inputTimePicker1);
                    this.disposeRescoTimeControls(this._inputTimePicker2);
                };
                return ScheduleRulesPage;
            }(Scheduler.BasePickersPage));
            Scheduler.ScheduleRulesPage = ScheduleRulesPage;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=settingsDlg.js.map