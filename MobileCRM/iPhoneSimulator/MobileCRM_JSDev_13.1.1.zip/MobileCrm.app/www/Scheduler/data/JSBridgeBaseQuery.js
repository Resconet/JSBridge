///<reference path="../../../../MobileCrm/www/TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../../../MobileCrm/www/Data/fetch.ts" />
///<reference path="../../../../MobileCrm/www/Data/dynamicEntity.ts" />
///<reference path="../../../../MobileCrm/www/Data/dataImageCache.ts" />
///<reference path="../../../../MobileCrm/www/Controls/event.ts" />
///<reference path="../../../../MobileCrm/www/Helpers/common.ts" />
///<reference path="../../../../MobileCrm/www/Helpers/exception.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var JSBridgeBaseQuery = /** @class */ (function () {
            function JSBridgeBaseQuery(fetch) {
                var _this = this;
                this.m_dummyCounter = 0;
                this.completed = false;
                this.m_page = 1;
                this.m_data = new Array();
                fetch.count = 1000;
                this.m_fetch = fetch;
                this.m_repository = new MobileCrm.Data.DynamicRepository();
                this.m_pendingRequest = false;
                fetch.entity.attributes.forEach(function (attr) { return _this.m_repository.add(attr.getMetaProperty(fetch.entity)); });
                if (fetch.entity.links) {
                    var _loop_1 = function (i) {
                        var linkedEntity = fetch.entity.links[i];
                        if (linkedEntity.attributes)
                            linkedEntity.attributes.forEach(function (attr) { return _this.m_repository.add(attr.getMetaProperty(linkedEntity)); });
                    };
                    for (var i = 0; i < fetch.entity.links.length; i++) {
                        _loop_1(i);
                    }
                }
                // replace online request from webclient by request to JSBridge
                //this.m_request = new Data.Online.LoadRequest();
            }
            Object.defineProperty(JSBridgeBaseQuery.prototype, "exception", {
                get: function () {
                    return this.m_exception;
                },
                enumerable: true,
                configurable: true
            });
            JSBridgeBaseQuery.prototype._onRequestCompleted = function () {
                this.m_pendingRequest = false;
            };
            JSBridgeBaseQuery.prototype.sendNextRequest = function () {
                var _this = this;
                if (!this.completed && !this.m_pendingRequest) { // && !this.m_request.inProgress) {
                    // request data from JSBridge
                    this.m_pendingRequest = true;
                    this.m_fetch.page = this.m_page++;
                    var xmlFetch = this.m_fetch.serializeXML();
                    MobileCRM.FetchXml.Fetch.executeFromXML(xmlFetch, function (results) {
                        _this._onRequestFinished(results);
                    }, function (error) {
                        _this.m_exception = new Resco.Exception(error);
                        _this._onRequestFinished();
                    }, this);
                }
            };
            JSBridgeBaseQuery.prototype._onRequestFinished = function (results) {
                var _this = this;
                // TODO: paging and detecting last page
                this.completed = (!results || results.length === 0 || (this.exception !== null && this.exception !== undefined));
                if (results && results.length > 0) {
                    results.forEach(function (item) {
                        var entity = new MobileCrm.Data.DynamicEntity(_this.m_fetch.entity.name, _this.m_repository);
                        for (var i = 0; i < item.length; i++) {
                            // Do not use entity.trySetValue(this.m_repository.properties[i].name, item[i]) method because repository.properties names can be the same for different values.
                            // The same names for different values are apparently allowed and handled by WebApp and native App correctly.
                            // They occur when e.g. WorkOrder view contains "name" field and "customerid.account.name" field also. Both values have property name set as "name". No prefix is added in second case.
                            entity.trySetValueByIndex(i, item[i]);
                        }
                        _this.m_data.push(entity);
                    }, this);
                    results.splice(0, results.length);
                }
                this._onRequestCompleted();
            };
            return JSBridgeBaseQuery;
        }());
        UI.JSBridgeBaseQuery = JSBridgeBaseQuery;
        var JSBridgeEntityQuery = /** @class */ (function (_super) {
            __extends(JSBridgeEntityQuery, _super);
            function JSBridgeEntityQuery(fetch) {
                var _this = _super.call(this, fetch) || this;
                _this.moveNextCompleted = new Resco.Event(_this);
                _this.queryCompleted = new Resco.Event(_this);
                _this.m_position = -1;
                _this.m_current = undefined;
                return _this;
            }
            JSBridgeEntityQuery.prototype.getEnumerator = function () {
                return this;
            };
            JSBridgeEntityQuery.prototype.awaitAll = function () {
                this.m_loadAll = true;
                this.sendNextRequest();
            };
            JSBridgeEntityQuery.prototype._onRequestCompleted = function () {
                _super.prototype._onRequestCompleted.call(this);
                this.moveNextCompleted.raise(Resco.EventArgs.Empty, this);
                if (this.completed) {
                    this.queryCompleted.raise(Resco.EventArgs.Empty, this);
                }
                else if (this.m_loadAll) {
                    this.sendNextRequest();
                }
            };
            JSBridgeEntityQuery.prototype._loadItem = function (index) {
                if (!this.completed && index >= this.m_data.length) {
                    // we don't have the data (but there is more), get next chunk of data
                    this.sendNextRequest();
                }
                if (index < this.m_data.length) {
                    return this.m_data[index];
                }
                return undefined;
            };
            Object.defineProperty(JSBridgeEntityQuery.prototype, "current", {
                get: function () {
                    return this.m_current;
                    //if (this.m_position >= 0 && this.m_position < this.m_data.length) {
                    //	return this.m_data[this.m_position];
                    //}
                    //return null;
                },
                enumerable: true,
                configurable: true
            });
            JSBridgeEntityQuery.prototype.moveNext = function () {
                // try to get the item on next position
                this.m_current = this._loadItem(this.m_position + 1);
                // if the data is available, move the pointer
                if (this.m_current !== undefined) {
                    this.m_position++;
                    return true;
                }
                return !this.completed;
            };
            JSBridgeEntityQuery.prototype.reset = function () {
                this.m_position = -1;
                this.m_data.splice(0, this.m_data.length);
            };
            return JSBridgeEntityQuery;
        }(JSBridgeBaseQuery));
        UI.JSBridgeEntityQuery = JSBridgeEntityQuery;
        var JSBridgeImageLoader = /** @class */ (function () {
            function JSBridgeImageLoader(imageQuery) {
                this.m_imageQuery = imageQuery.split(";");
                this.m_imageProperty = this.m_imageQuery[1];
                this.m_entityName = this.m_imageQuery[0];
                this.m_fetch = new MobileCrm.Data.Fetch.Fetch(null, this.m_imageQuery[0]);
                this.m_fetch.entity.addAttribute(this.m_imageProperty, false);
                // TODO: get the primarykeyname of the entity (this works for annotations, but in more specific case this might fail)
                this.m_fetch.entity.addAttribute("id", false);
            }
            JSBridgeImageLoader.prototype.load = function (entity, onLoaded) {
                var _this = this;
                this.m_onLoaded = onLoaded;
                this.m_fetch.entity.filter.clear();
                for (var i = 2; i < this.m_imageQuery.length - 1; i += 2) {
                    var valueName = this.m_imageQuery[i + 1];
                    if (valueName.startsWith("{")) {
                        var r = this._tryGetEntityValue(entity, valueName);
                        if (r.result) {
                            this.m_fetch.entity.filter.where(this.m_imageQuery[i], r.value);
                        }
                    }
                    else {
                        this.m_fetch.entity.filter.where(this.m_imageQuery[i], valueName);
                    }
                }
                // TODO: if loadDocumentBody is not sufficient and returns no results, try to get the data using fetch (imageQuery might have been too complex to get the result by calling loadDocumentBody)
                var xmlFetch = this.m_fetch.serializeXML();
                MobileCRM.FetchXml.Fetch.executeFromXML(xmlFetch, function (results) {
                    if (results && results.length > 0) {
                        if (results[0][0] !== undefined && results[0][0] !== null && results[0][0] !== "UkVTQ082NA==") {
                            onLoaded(results[0][0]);
                        }
                        else {
                            // we need to get the image using the loadDocumentBody method
                            MobileCRM.DynamicEntity.loadDocumentBody(_this.m_entityName, results[0][1], function (data) {
                                onLoaded(data);
                            }, function (error) {
                                //alert(error);
                            }, _this);
                        }
                    }
                }, function (error) {
                    //alert(error);
                }, this);
            };
            JSBridgeImageLoader.prototype._tryGetEntityValue = function (entity, valueName) {
                if (valueName == "{id}") {
                    return { result: true, value: entity.primaryKeyValue };
                }
                else if (valueName.startsWith("{")) {
                    var val = valueName.substring(1, valueName.length - 2);
                    var end = val.indexOf("}");
                    if (end)
                        val = val.substring(0, end);
                    var result = entity.tryGetValue(val);
                    if (result.result) {
                        var value = result.value;
                        // TODO: find out if the property is of reference type and then return id of that reference
                        //if (isReference(value)) {
                        //    value = (<IReference>value).id;
                        //}
                        return { result: true, value: value };
                    }
                    else if (end && end > val.length - 1) {
                        //val = val.substring(end+1, end);
                    }
                }
                return { result: false, value: null };
            };
            return JSBridgeImageLoader;
        }());
        UI.JSBridgeImageLoader = JSBridgeImageLoader;
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=JSBridgeBaseQuery.js.map