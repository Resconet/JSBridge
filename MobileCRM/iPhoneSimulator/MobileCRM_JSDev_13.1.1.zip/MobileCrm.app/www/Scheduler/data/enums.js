///<reference path="../../../../MobileCrm/www/TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="resource.ts" />
///<reference path="../utilities.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var TaskContainerView;
            (function (TaskContainerView) {
                TaskContainerView[TaskContainerView["None"] = 0] = "None";
                TaskContainerView[TaskContainerView["IsInUndefinedTasksContainer"] = 1] = "IsInUndefinedTasksContainer";
                TaskContainerView[TaskContainerView["IsInDraggableContainer"] = 2] = "IsInDraggableContainer";
                TaskContainerView[TaskContainerView["IsInTasksContainer"] = 3] = "IsInTasksContainer";
            })(TaskContainerView = Scheduler.TaskContainerView || (Scheduler.TaskContainerView = {}));
            var TravelMode;
            (function (TravelMode) {
                /// <summary>from office to client than back to office</summary>
                TravelMode[TravelMode["Default"] = 0] = "Default";
                /// <summary>from office to client</summary>
                TravelMode[TravelMode["FromOffice"] = 1] = "FromOffice";
                /// <summary>from previous client to client</summary>
                TravelMode[TravelMode["FromPreviousClient"] = 2] = "FromPreviousClient";
                /// <summary>back to office</summary>
                TravelMode[TravelMode["ToOffice"] = 4] = "ToOffice";
                /// <summary>from client to another client</summary>
                TravelMode[TravelMode["ToNextClient"] = 8] = "ToNextClient";
                /// <summary>from office to client than back to office</summary>
                TravelMode[TravelMode["FromOfficeToOffice"] = 5] = "FromOfficeToOffice";
                /// <summary>from previous client to client than back to office</summary>
                TravelMode[TravelMode["FromPreviousClientToOffice"] = 6] = "FromPreviousClientToOffice";
                /// <summary>from previous client to client than to next client</summary>
                TravelMode[TravelMode["FromPreviousClientToNextClient"] = 10] = "FromPreviousClientToNextClient";
                /// <summary>from office to client than to next client</summary>
                TravelMode[TravelMode["FromOfficeToNextClient"] = 9] = "FromOfficeToNextClient";
            })(TravelMode = Scheduler.TravelMode || (Scheduler.TravelMode = {}));
            var TaskStatusType;
            (function (TaskStatusType) {
                /// <summary>Task has been added and needs to be planned</summary>
                TaskStatusType[TaskStatusType["Unscheduled"] = 0] = "Unscheduled";
                /// <summary>Task has been planned</summary>
                TaskStatusType[TaskStatusType["Scheduled"] = 1] = "Scheduled";
                /// <summary>Task schedule cannot be modify more</summary>
                TaskStatusType[TaskStatusType["Confirmed"] = 2] = "Confirmed";
                /// <summary>Task break</summary>
                TaskStatusType[TaskStatusType["CoffeeBreak"] = 3] = "CoffeeBreak";
                /// <summary>Task represents TimeOff</summary>
                TaskStatusType[TaskStatusType["TimeOff"] = 4] = "TimeOff";
                /// <summary>Task has been completed</summary>
                TaskStatusType[TaskStatusType["Completed"] = 5] = "Completed";
                /// <summary>Task has been canceled</summary>
                TaskStatusType[TaskStatusType["Canceled"] = 6] = "Canceled";
                TaskStatusType[TaskStatusType["ResourceTimeOff"] = 7] = "ResourceTimeOff";
                // Container createCustomization() method need to be updated also if count of types in the TaskStatusType enum is changed.
                TaskStatusType[TaskStatusType["AutoScheduled"] = 8] = "AutoScheduled";
                // <summary>Task automatically scheduled</summary>
                TaskStatusType[TaskStatusType["ScheduledAndLocked"] = 9] = "ScheduledAndLocked";
                // <summary>Task is scheduled and locked for feature change</summary>
                TaskStatusType[TaskStatusType["Last"] = 10] = "Last";
            })(TaskStatusType = Scheduler.TaskStatusType || (Scheduler.TaskStatusType = {}));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=enums.js.map