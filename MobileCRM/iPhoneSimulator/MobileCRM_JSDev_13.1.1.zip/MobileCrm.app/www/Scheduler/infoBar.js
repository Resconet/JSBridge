///<reference path="utilities.ts" />
///<reference path="container.ts" />
///<reference path="task.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var InfoBar = /** @class */ (function () {
                function InfoBar(imagesRootPath) {
                    this._statusInfoControl = new StatusInfoControl();
                    this._kpiControl = new KPIControl(imagesRootPath);
                }
                Object.defineProperty(InfoBar.prototype, "element", {
                    get: function () {
                        if (!this._element)
                            this._element = this._createInfoBarElement();
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InfoBar.prototype, "statusInfoControl", {
                    get: function () {
                        return this._statusInfoControl;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InfoBar.prototype, "kpiControl", {
                    get: function () {
                        return this._kpiControl;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InfoBar.prototype, "enabledLegend", {
                    get: function () {
                        return this.statusInfoControl.enabledLegend;
                    },
                    set: function (value) {
                        this.statusInfoControl.enabledLegend = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                InfoBar.prototype.setStatusInfo = function (text) {
                    this.statusInfoControl.setStatusInfo(text);
                };
                InfoBar.prototype._createInfoBarElement = function () {
                    var infoBar = $("<div>").attr("id", "schedulerInfoBar");
                    infoBar.css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    infoBar.append(this.statusInfoControl.element);
                    infoBar.append(this.kpiControl.element);
                    return infoBar;
                };
                InfoBar.prototype.onResize = function () {
                    this.statusInfoControl.onResize();
                    this.kpiControl.onResize();
                };
                return InfoBar;
            }());
            Scheduler.InfoBar = InfoBar;
            var StatusInfoControl = /** @class */ (function () {
                function StatusInfoControl() {
                    this._isShownText = false;
                    this._enabledLegend = false;
                }
                Object.defineProperty(StatusInfoControl.prototype, "element", {
                    get: function () {
                        if (!this._element)
                            this._element = this._createStatusInfoControlElement();
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(StatusInfoControl.prototype, "statusLegendElement", {
                    get: function () {
                        return this.element.find(".statusLegend");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(StatusInfoControl.prototype, "enabledLegend", {
                    get: function () {
                        return this._enabledLegend;
                    },
                    set: function (value) {
                        this._enabledLegend = value;
                        if (this.enabledLegend) {
                            this._updateLegendVisibility();
                        }
                        else {
                            this.element.removeClass("showLegend");
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                StatusInfoControl.prototype.setStatusInfo = function (text) {
                    if (text) {
                        this._isShownText = true;
                    }
                    else {
                        this._isShownText = false;
                        text = "";
                    }
                    if (this.enabledLegend) {
                        this._updateLegendVisibility();
                    }
                    this.element.find("div.text").text(text);
                };
                StatusInfoControl.prototype._updateLegendVisibility = function () {
                    if (this._isShownText) {
                        this.element.removeClass("showLegend");
                    }
                    else {
                        this.element.addClass("showLegend");
                    }
                };
                StatusInfoControl.prototype._createStatusInfoControlElement = function () {
                    var statusInfoElement = $("<div>").attr("id", "statusInfo");
                    if (this.enabledLegend) {
                        statusInfoElement.addClass("showLegend");
                    }
                    var textElement = $("<div>").addClass("text");
                    var statusLegendElement = this._createStatusLegendElement();
                    statusInfoElement.append(textElement);
                    statusInfoElement.append(statusLegendElement);
                    return statusInfoElement;
                };
                StatusInfoControl.prototype._createStatusLegendElement = function () {
                    var statusLegendElement = $("<div>").addClass("statusLegend");
                    var statusList = Scheduler.Container.statusCodeTable.statusList;
                    for (var i = 0; i < statusList.length; i++) {
                        var legendItem = this._createLegendItem(statusList[i]);
                        statusLegendElement.append(legendItem);
                    }
                    return statusLegendElement;
                };
                StatusInfoControl.prototype._createLegendItem = function (status) {
                    var legendItem = $("<div>").addClass("legendItem");
                    legendItem.text(status.name());
                    status.setElementCSS(legendItem[0], Scheduler.StatusCSS.Default);
                    return legendItem;
                };
                StatusInfoControl.prototype.onResize = function () {
                    this._deactivatePerfectScrollbar();
                    this._activatePerfectScrollbar(); // Perfect scrollbar needs to remove default scrollbar first.
                };
                StatusInfoControl.prototype._activatePerfectScrollbar = function () {
                    var statusLegendElement = this.statusLegendElement;
                    if (statusLegendElement.length > 0) {
                        this._perfectScrollbar = new PerfectScrollbar(statusLegendElement[0], { suppressScrollY: true });
                    }
                };
                StatusInfoControl.prototype._deactivatePerfectScrollbar = function () {
                    if (this._perfectScrollbar) {
                        this._perfectScrollbar.destroy();
                        this._perfectScrollbar = undefined;
                    }
                };
                return StatusInfoControl;
            }());
            var KPIControl = /** @class */ (function () {
                function KPIControl(imagesRootPath) {
                    this._totalScheduledTime = 0;
                    this._averageTravelTime = 0;
                    this._completedTasksCount = 0;
                    this._allScheduledTasksCount = 0; // without TimeOffs
                    this._allUnscheduledTasksCount = 0;
                    this._ruleViolationsCount = 0;
                    this._jeopardyCount = 0;
                    this._imagesRootPath = "";
                    this._template = '\
			<div id="kpiControl">\
				<div id="unscheduledTasksCount" class="kpiControlItem hidden">\
					<div class="kpiImage" style="background-color: yellow;"></div>\
					<span class="kpiText">0</span>\
				</div>\
				<div id="totalScheduledTime" class="kpiControlItem" data-tooltip-label-key="Scheduler.Msg.KPILabelTotalScheduledTime" data-tooltip-label="Total scheduled time indicator" data-tooltip-text-key="Scheduler.Msg.KPITotalScheduledTime" data-tooltip-text="shows total time duration of all tasks displayed in the view">\
					<div class="kpiImage" data-icon="kpiScheduled.png"></div>\
					<span class="kpiText">0h 0m</span>\
				</div>\
				<div id="averageTravelTime" class="kpiControlItem" data-tooltip-label-key="Scheduler.Msg.KPILabelAverageTravelTime" data-tooltip-label="Average travel time indicator" data-tooltip-text-key="Scheduler.Msg.KPIAverageTravelTime" data-tooltip-text="shows average travel time calculated for tasks displayed in the view">\
					<div class="kpiImage" data-icon="kpiTravel.png"></div>\
					<span class="kpiText">0h 0m</span>\
				</div>\
				<div id="completedTasksRate" class="kpiControlItem" data-tooltip-label-key="Scheduler.Msg.KPILabelCompletedToAllTasks" data-tooltip-label="Completed / all tasks indicator" data-tooltip-text-key="Scheduler.Msg.KPICompletedToAllTasks" data-tooltip-text="shows completed task count in relation to scheduled task count that are displayed in the view">\
					<div class="kpiImage" data-icon="kpiCompleted.png"></div>\
					<span class="kpiText">0/0</span>\
				</div>\
				<div id="ruleViolationsCount" class="kpiControlItem" data-tooltip-label-key="Scheduler.Msg.KPILabelRuleViolations" data-tooltip-label="Rule violations indicator" data-tooltip-text-key="Scheduler.Msg.KPIRuleViolations" data-tooltip-text="shows the number of displayed tasks that violate at least one schedule rule">\
					<div class="kpiImage" data-icon="kpiRuleViolations.png"></div>\
					<span class="kpiText">0</span>\
				</div>\
				<div id="jeopardyCount" class="kpiControlItem" data-tooltip-label-key="Scheduler.Msg.KPILabelJeopardy" data-tooltip-label="Jeopardy indicator" data-tooltip-text-key="Scheduler.Msg.KPIJeopardy" data-tooltip-text="shows the number of unscheduled tasks that are in jeopardy(due date for when the task must be scheduled, is approaching)">\
					<div class="kpiImage" data-icon="kpiJeopardy.png"></div>\
					<span class="kpiText">0</span>\
				</div>\
			</div>\
		';
                    if (imagesRootPath)
                        this._imagesRootPath = imagesRootPath;
                }
                Object.defineProperty(KPIControl.prototype, "element", {
                    get: function () {
                        if (!this._element)
                            this._element = this._createKPIControlElement();
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "totalScheduledTime", {
                    get: function () {
                        return this._totalScheduledTime;
                    },
                    set: function (value) {
                        if (this._totalScheduledTime !== value) {
                            this._totalScheduledTime = value;
                            var minutes = Scheduler.milisecondsToMinutes(this._totalScheduledTime);
                            var h = Math.floor(minutes / 60);
                            var m = minutes % 60;
                            var text = Scheduler.StringTable.get("Scheduler.Msg.HoursMinutes", [h.toString(), m.toString()]) || Scheduler.StringTable.replaceBracketsWithArgs("{0}h {1}m", [h.toString(), m.toString()]);
                            this._updateKPIText(this.element.find("#totalScheduledTime"), text);
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "averageTravelTime", {
                    get: function () {
                        return this._averageTravelTime;
                    },
                    set: function (value) {
                        if (this._averageTravelTime !== value) {
                            this._averageTravelTime = value;
                            var minutes = Scheduler.milisecondsToMinutes(this._averageTravelTime);
                            var h = Math.floor(minutes / 60);
                            var m = minutes % 60;
                            var text = Scheduler.StringTable.get("Scheduler.Msg.HoursMinutes", [h.toString(), m.toString()]) || Scheduler.StringTable.replaceBracketsWithArgs("{0}h {1}m", [h.toString(), m.toString()]);
                            this._updateKPIText(this.element.find("#averageTravelTime"), text);
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "completedTasksCount", {
                    get: function () {
                        return this._completedTasksCount;
                    },
                    set: function (value) {
                        if (this._completedTasksCount !== value) {
                            this._completedTasksCount = value;
                            this._updateCompletedTasksRate();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "allScheduledTasksCount", {
                    get: function () {
                        return this._allScheduledTasksCount;
                    },
                    set: function (value) {
                        if (this._allScheduledTasksCount !== value) {
                            this._allScheduledTasksCount = value;
                            this._updateCompletedTasksRate();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "allUnscheduledTasksCount", {
                    get: function () {
                        return this._allUnscheduledTasksCount;
                    },
                    set: function (value) {
                        if (this._allUnscheduledTasksCount !== value) {
                            this._allUnscheduledTasksCount = value;
                            this._updateKPIText(this.element.find("#unscheduledTasksCount"), this._allUnscheduledTasksCount.toString());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "ruleViolationsCount", {
                    get: function () {
                        return this._ruleViolationsCount;
                    },
                    set: function (value) {
                        if (this._ruleViolationsCount !== value) {
                            this._ruleViolationsCount = value;
                            this._updateKPIText(this.element.find("#ruleViolationsCount"), this._ruleViolationsCount.toString());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "jeopardyCount", {
                    get: function () {
                        return this._jeopardyCount;
                    },
                    set: function (value) {
                        if (this._jeopardyCount !== value) {
                            this._jeopardyCount = value;
                            this._updateKPIText(this.element.find("#jeopardyCount"), this._jeopardyCount.toString());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                KPIControl.prototype.onResize = function () {
                };
                KPIControl.prototype._updateCompletedTasksRate = function () {
                    var text = this._completedTasksCount.toString() + "/" + this._allScheduledTasksCount.toString();
                    this._updateKPIText(this.element.find("#completedTasksRate"), text);
                };
                KPIControl.prototype._updateKPIText = function (kpiControlItem, text) {
                    if (text) {
                        kpiControlItem.find("span.kpiText").text(text);
                    }
                };
                KPIControl.prototype._addItemEvents = function (kpiItem, label, text) {
                    var wasTouchClick = false;
                    kpiItem.on("mouseenter", function (e) {
                        wasTouchClick = false;
                        if (!Scheduler.Container.ref.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            KPITooltip.createTooltip(kpiItem, label, text);
                        }
                    });
                    kpiItem.on("mouseleave", function (e) {
                        if (wasTouchClick) {
                            wasTouchClick = false;
                        }
                        else {
                            if (!Scheduler.Container.ref.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                KPITooltip.removeTooltip();
                            }
                        }
                    });
                    kpiItem.on("click", function (e) {
                        wasTouchClick = false;
                        if (Scheduler.BaseTooltip.isTouchEvent(e)) {
                            wasTouchClick = true;
                            if (!Scheduler.Container.ref.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                if (!Scheduler.TaskPropertyDlg.isShown()) {
                                    KPITooltip.createTooltip(kpiItem, label, text);
                                }
                            }
                        }
                    });
                };
                KPIControl.prototype._addItemsEvents = function (kpiControl) {
                    var kpiItems = kpiControl.find(".kpiControlItem");
                    for (var i = 0; i < kpiItems.length; i++) {
                        var kpiItem = kpiItems[i];
                        var attrLabelKey = kpiItem.attributes["data-tooltip-label-key"];
                        var attrLabel = kpiItem.attributes["data-tooltip-label"];
                        var attrTextKey = kpiItem.attributes["data-tooltip-text-key"];
                        var attrText = kpiItem.attributes["data-tooltip-text"];
                        var label = "";
                        var text = "";
                        if (attrLabelKey && attrLabelKey.nodeValue) {
                            label = Scheduler.StringTable.get(attrLabelKey.nodeValue);
                        }
                        if (!label && attrLabel && attrLabel.nodeValue) {
                            label = attrLabel.nodeValue;
                        }
                        if (attrTextKey && attrTextKey.nodeValue) {
                            text = Scheduler.StringTable.get(attrTextKey.nodeValue);
                        }
                        if (!text && attrText && attrText.nodeValue) {
                            text = attrText.nodeValue;
                        }
                        this._addItemEvents($(kpiItem), label, text);
                    }
                };
                KPIControl.prototype._createKPIControlElement = function () {
                    var kpiControl = Scheduler.Utilities.createFromTemplate(this._template);
                    Scheduler.StringTable.localizeElements(kpiControl);
                    var images = kpiControl.find(".kpiImage");
                    for (var i = 0; i < images.length; i++) {
                        var element = images[i];
                        var icon = element.attributes["data-icon"];
                        if (icon && icon.nodeValue)
                            element.style.backgroundImage = "url(" + this._imagesRootPath + icon.nodeValue + ")";
                    }
                    this._addItemsEvents(kpiControl);
                    return kpiControl;
                };
                return KPIControl;
            }());
            Scheduler.KPIControl = KPIControl;
            var KPITooltip = /** @class */ (function (_super) {
                __extends(KPITooltip, _super);
                function KPITooltip() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                /**
                 * Creates tooltip for provided KPI item.
                 * @param map Map where task marker is drawn.
                 * @param marker Marker that represents the task to which tooltip should be created.
                 * @param task Task to which tooltip should be created.
                 */
                KPITooltip.createTooltip = function (kpiControlItem, label, text) {
                    KPITooltip.removeTooltip();
                    if (kpiControlItem && (label || text)) {
                        var kpiTooltip = new KPITooltip();
                        kpiTooltip._createKPITooltip(kpiControlItem, label, text);
                        Scheduler.BaseTooltip._instance = kpiTooltip;
                    }
                };
                KPITooltip.prototype._createKPITooltip = function (kpiControlItem, label, text) {
                    this._element = this._createElement(label, text);
                    Scheduler.Utilities.bringToFront(this._element);
                    $("body").append(this._element);
                    var itemOffset = kpiControlItem.offset();
                    var tooltipHeight = this._element.outerHeight(true);
                    var offset = KPITooltip.keepInsideBody(itemOffset.left, itemOffset.top - tooltipHeight, this._element.outerWidth(true), tooltipHeight);
                    this._element.css("left", offset.left + "px");
                    this._element.css("top", offset.top + "px");
                };
                KPITooltip.prototype._createElement = function (label, text) {
                    var content = "<div class=\"tooltip kpiTooltip\">";
                    if (label) {
                        content += "<h3>" + label + "</h3>";
                    }
                    if (text) {
                        content += "<div>" + text + "</div>";
                    }
                    content += "</div>";
                    return $(content);
                };
                return KPITooltip;
            }(Scheduler.BaseTooltip));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=infoBar.js.map