///<reference path="../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="timeRange.ts" />
///<reference path="statistic.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var Holiday = (function () {
                function Holiday() {
                    this.isWorking = false;
                }
                return Holiday;
            }());
            Scheduler.Holiday = Holiday;
            var Holidays = (function () {
                function Holidays() {
                }
                Holidays.isInitialized = function () {
                    return Holidays._holidays ? true : false;
                };
                Holidays.isHoliday = function (date) {
                    if (Holidays._holidays) {
                        var month = date.getMonth() + 1;
                        var day = date.getDate();
                        for (var i = 0; i < Holidays._holidays.length; i++) {
                            if (Holidays._holidays[i].month === month && Holidays._holidays[i].day === day)
                                return Holidays._holidays[i];
                        }
                    }
                    return undefined;
                };
                Holidays.initialize = function (input, onFinishCallback) {
                    if (Holidays._holidays || !input || !input.entityName)
                        onFinishCallback(undefined);
                    else {
                        MobileCRM.MetaEntity.loadByName(input.entityName, function (me) {
                            if (!me || !me.isEnabled)
                                onFinishCallback(undefined);
                            else
                                Holidays._load(input, me, onFinishCallback);
                        }, function (err) {
                            onFinishCallback(err);
                        });
                    }
                };
                Holidays._load = function (input, me, onFinishCallback) {
                    var entity = new MobileCRM.FetchXml.Entity(input.entityName);
                    var attr;
                    if (!me.getProperty(attr = input.primaryFieldName) ||
                        !me.getProperty(attr = input.attrDay) ||
                        !me.getProperty(attr = input.attrMonth)) {
                        onFinishCallback("Holiday attribute '" + attr + "' is missing.");
                    }
                    else {
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(input.primaryFieldName));
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(input.attrDay));
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(input.attrMonth));
                        if (me.getProperty("statecode"))
                            entity.addFilter().where("statecode", "eq", 0);
                        var fetch = new MobileCRM.FetchXml.Fetch(entity);
                        fetch.execute("Array", function (result) {
                            var arr = [];
                            for (var i = 0; i < result.length; i++) {
                                var entity_1 = result[i];
                                var holiday = new Holiday();
                                holiday.name = entity_1[0];
                                holiday.day = +entity_1[1];
                                holiday.month = +entity_1[2];
                                arr.push(holiday);
                            }
                            Holidays._holidays = arr;
                            onFinishCallback(undefined);
                        }, function (err) {
                            onFinishCallback(Scheduler.StringTable.get("Err.CantFetchEntity") + " " + entity.name + " " + err);
                        }, this);
                    }
                };
                return Holidays;
            }());
            Holidays._entityName = "resco_holiday";
            Scheduler.Holidays = Holidays;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
