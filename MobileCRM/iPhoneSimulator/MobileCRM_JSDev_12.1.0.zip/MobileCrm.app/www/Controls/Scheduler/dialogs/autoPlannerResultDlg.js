///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../container.ts" />
///<reference path="baseDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var AutoPlanner;
            (function (AutoPlanner) {
                var StateItem = (function () {
                    function StateItem() {
                        this.emptyGaps = 0;
                        this.workingDuration = 0;
                        this.travelDuration = 0;
                        this.totalDuration = 0;
                    }
                    return StateItem;
                }());
                AutoPlanner.StateItem = StateItem;
                var ResultReview = (function () {
                    function ResultReview() {
                        this.initial = new StateItem();
                        this.final = new StateItem();
                        this.totalWorkingTime = 0;
                        this.totalTasks = 0;
                        this.processedTasks = 0;
                        this.changedTasks = 0;
                    }
                    ResultReview.prototype.workingTimeImprovement = function () {
                        if (this.final.totalDuration <= 0)
                            return 0;
                        else if (this.initial.totalDuration <= 0)
                            return 100;
                        else {
                            var different = this.initial.totalDuration - this.final.totalDuration;
                            //return (100 * different) / this.initial.totalDuration;
                            return different / Scheduler.minuteInMiliseconds;
                        }
                    };
                    ResultReview.prototype.travelImprovement = function () {
                        if (this.final.travelDuration === 0)
                            return 0;
                        else if (this.initial.travelDuration === 0)
                            return 100;
                        else {
                            var different = this.initial.travelDuration - this.final.travelDuration;
                            //return (100 * different) / this.initial.travelDuration;
                            return different / Scheduler.minuteInMiliseconds;
                        }
                    };
                    ResultReview.prototype.workingTimeEfficiency = function () {
                        if (this.final.emptyGaps === 0)
                            return 0;
                        else if (this.initial.emptyGaps === 0)
                            return 100;
                        else {
                            var different = this.initial.emptyGaps - this.final.emptyGaps;
                            //return (100 * different) / this.initial.emptyGaps;
                            return different / Scheduler.minuteInMiliseconds;
                        }
                    };
                    return ResultReview;
                }());
                AutoPlanner.ResultReview = ResultReview;
                var ResultDialog = (function (_super) {
                    __extends(ResultDialog, _super);
                    function ResultDialog(container, stat, onCloseCallback) {
                        var _this = _super.call(this) || this;
                        _this._container = container;
                        _this._stat = stat;
                        _this._onCloseCallback = onCloseCallback;
                        _this._wasSaved = false;
                        _this.onShowDialog();
                        return _this;
                    }
                    ResultDialog.show = function (container, stat, onCloseCallback) {
                        if (ResultDialog._dialogInstance)
                            ResultDialog._dialogInstance.destroy();
                        ResultDialog._dialogInstance = new ResultDialog(container, stat, onCloseCallback);
                    };
                    ResultDialog.prototype.onShowDialog = function () {
                        var _this = this;
                        this.dialog = this._createResultDialogElement();
                        this.initializeTabDialog(this.dialog);
                        this.initializeResultPage(this.dialog.find("#REPORT"), this._stat);
                        this.initializeChangesPage(this.dialog.find("#CHANGES"), this._stat);
                        this.initializeErrorsPage(this.dialog.find("#ERRORS"), this._stat);
                        Scheduler.StringTable.localizeElements(this.dialog);
                        var saveButton = this.dialog.find("#saveButton");
                        saveButton.click(function (e) {
                            _this.saveAndClose(e);
                        });
                        _super.prototype.create.call(this, this.dialog, 500, 450, function () {
                            if (_this._wasSaved)
                                _this._onCloseCallback("SAVE");
                            else
                                _this._onCloseCallback("DISCARD");
                        });
                    };
                    ResultDialog.prototype.writeRatio = function (ctrl, value) {
                        value = Math.ceil(value);
                        if (value === 0)
                            ctrl.text("-");
                        else if (value === 100) {
                            ctrl.text("-");
                            //ctrl.text("100%");
                        }
                        else {
                            var h = value / 60;
                            if (Math.abs(h) < 1)
                                ctrl.text(value + "min");
                            else
                                ctrl.text(h.toFixed(1) + "h");
                            if (value < 0)
                                ctrl.css("color", "red");
                            else if (value > 0)
                                ctrl.css("color", "green");
                        }
                    };
                    ResultDialog.prototype.initializeResultPage = function (page, stat) {
                        var travelImprovement = stat ? stat.travelImprovement() : 0;
                        var settings = this._container.settings.autoPlanner;
                        if (!stat || !stat.processedTasks || this._container.settings.autoPlanner.autoScheduleMode == Scheduler.eMode.RouteOptimization) {
                            this.writeRatio(page.find(".emptyGap"), 0);
                            this.writeRatio(page.find(".endTime"), 0);
                        }
                        else {
                            this.writeRatio(page.find(".emptyGap"), stat.workingTimeEfficiency());
                            this.writeRatio(page.find(".endTime"), stat.workingTimeImprovement());
                        }
                        this.writeRatio(page.find(".travel"), travelImprovement);
                        page.find(".totalItems").text(stat.totalTasks);
                        page.find(".changedItems").text(stat.changedTasks);
                        page.find(".optimizedItems").text(stat.processedTasks);
                        if (!settings.autoScheduleNewTasks)
                            this.setElementIgnored(page.find(".newTasksUsed"));
                        if (!settings.autoScheduleConflictedTasks)
                            this.setElementIgnored(page.find(".conflictedTasksUsed"));
                        if (!settings.autoScheduleTasksYetNotStarted)
                            this.setElementIgnored(page.find(".scheduledTasksUsed"));
                    };
                    ResultDialog.prototype.setElementIgnored = function (element) {
                        element.css({ "text-decoration": "line-through" });
                        element.css({ "color": "red" });
                    };
                    ResultDialog.prototype.initializeChangesPage = function (page, stat) {
                        var changes = stat ? stat.changeLogs : undefined;
                        var list;
                        if (changes && (list = page.find("#changeLogList"))) {
                            var content = "";
                            for (var i = 0; i < changes.length; i++)
                                content += changes[i] + "<p class='textLine'></p><br>";
                            list.append(content);
                        }
                    };
                    ResultDialog.prototype.initializeErrorsPage = function (page, stat) {
                        var errors = stat ? stat.errors : undefined;
                        if (!errors || errors.length == 0) {
                        }
                        else {
                            var list;
                            if ((list = page.find("#errorList"))) {
                                var content = "";
                                for (var i = 0; i < errors.length; i++)
                                    content += errors[i] + "<br><br>";
                                list.append(content);
                            }
                        }
                    };
                    ResultDialog.prototype.saveAndClose = function (e) {
                        this._wasSaved = true;
                        this.destroy();
                    };
                    ResultDialog.prototype.destroy = function () {
                        ResultDialog._dialogInstance = null;
                        _super.prototype.destroy.call(this);
                    };
                    ResultDialog.prototype._createResultDialogElement = function () {
                        var element = Scheduler.Utilities.createFromTemplate(ResultDialog._template);
                        element.find("ul.rescoTabCtrl").css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                        return element;
                    };
                    return ResultDialog;
                }(Scheduler.BaseDlg));
                ResultDialog._dialogInstance = null;
                ResultDialog._template = '\
			<div class="rescoDialog">\
				<ul class="rescoTabCtrl">\
				  <li><a id="tab_REPORT" href="javascript:void(0)" class="rescoTabButton text" draggable="false" data-localization="Scheduler.Msg.REPORT">REPORT</a></li>\
				  <li><a id="tab_CHANGES" href="javascript:void(0)" class="rescoTabButton text" draggable="false" data-localization="Scheduler.Msg.CHANGES">CHANGES</a></li>\
				  <li><a id="tab_ERRORS" href="javascript:void(0)" class="rescoTabButton text" draggable="false" data-localization="Scheduler.Msg.ERRORS">ERRORS</a></li>\
				</ul>\
				<div id="REPORT" class="rescoTabContent">\
					<p class="title" data-localization="Scheduler.Msg.ReportTitle">Auto-scheduling report.</p>\
					<p></p>\
					<div class="includedTasks">\
					<p>Tasks included to the optimization process.</p>\
					<ul>\
						<li class="newTasksUsed" data-localization="Scheduler.Msg.NewTasks">New tasks</li>\
						<li class="conflictedTasksUsed" data-localization="Scheduler.Msg.TasksWithConflict">Tasks with conflict</li>\
						<li class="scheduledTasksUsed" data-localization="Scheduler.Msg.AlreadyScheduledTasks">Already scheduled tasks</li>\
					</ul>\
					</div>\
					<div>\
						<table class="report" width="100%">\
							<tr class="ratioTitle">\
								<th class="emptyGap"></th>\
								<th class="travel"></th>\
								<th class="endTime"></th>\
							</tr>\
							<tr class="reportInfo">\
								<th data-localization="Scheduler.Msg.EmptyGapImprovement">Empty gap<br>improvement</th>\
								<th data-localization="Scheduler.Msg.TravelImprovement">Optimize travel<br>per day</th>\
								<th data-localization="Scheduler.Msg.EndTimeImprovement">End time<br>improvement</th>\
							</tr>\
							<tr>\
								<th><br><br></th>\
								<th></th>\
								<th></th>\
							</tr>\
							<tr class="reportSummary">\
								<th class="totalItems"></th>\
								<th class="optimizedItems"></th>\
								<th class="changedItems"></th>\
							</tr>\
							<tr class="reportInfo">\
								<th data-localization="Scheduler.Msg.TotalTasks">Total<br>tasks</th>\
								<th data-localization="Scheduler.Msg.ProcessedTasks">Processed<br>tasks</th>\
								<th data-localization="Scheduler.Msg.ChangedTasks">Changed<br>tasks</th>\
							</tr>\
						</table>\
					</div>\
				</div>\
				<div id="CHANGES" class="rescoTabContent">\
					<p class="title" data-localization="Scheduler.Msg.ChangesTitle">Auto-scheduling changes.</p>\
					<p></p>\
					<div id="changeLogList" class="rescoTabBodyContent" style="display:block;"></div>\
				</div>\
				<div id="ERRORS" class="rescoTabContent">\
					<p class="title" data-localization="Scheduler.Msg.ErrorsTitle">Auto-scheduling error.</p>\
					<p></p>\
					<div id="errorList" class="rescoTabBodyContent" style="display:block;" ></div>\
				</div>\
				<div class="dialogControlContainer">\
				  <button class="closeButton" data-localization="Scheduler.Msg.DiscardChanges">Discard Changes</button>&nbsp;\
				  <button id="saveButton" data-localization="Msg.Save">Save</button>\
				</div>\
			</div>\
		';
                AutoPlanner.ResultDialog = ResultDialog;
            })(AutoPlanner = Scheduler.AutoPlanner || (Scheduler.AutoPlanner = {}));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
