///<reference path="../../TypeScriptDefinitions/JSBridge.d.ts" />
/*
module Resco.Controls.Scheduler {

    export function loadScripts() : void {

        var doc = document.getElementsByTagName('head')[0];
        var root = "..";

        linkStyleSheet(root + "/default.css", doc );
        linkStyleSheet(root + "/perfect-scrollbar.css", doc);
        linkStyleSheet(root + "/Controls/Scheduler/platform.css", doc );
        linkStyleSheet(root + "/Controls/Scheduler/controls.css", doc);
        linkStyleSheet(root + "/Controls/Scheduler/scheduler.css", doc);
        linkPrintStyleSheet( root + "/Controls/Scheduler/schedulerPrint.css", doc );
        linkStyleSheet(root + "/Controls/css/controls.css", doc);

        // Libraries
        addScript( root+"/JSBridge.js", doc );
        addScript(root +"/jquery-2.2.4.min.js", doc );
        addScript(root +"/knockout-3.2.0.min.js", doc );
        addScript(root +"/decimal.min.js", doc );
        addScript(root +"/hammer.min.js", doc );
        addScript(root +"/perfect-scrollbar.min.js", doc );

        // standard controls
        addScript(root +"/Controls/event.js", doc );
        addScript(root +"/Controls/appColors.js", doc );
        addScript(root +"/Controls/listBox.js", doc );
        addScript(root +"/Controls/datePicker.js", doc );

        addScript(root +"/Helpers/command.js", doc );
        addScript(root +"/Helpers/common.js", doc );
        addScript(root +"/Helpers/exception.js", doc );

        linkStyleSheet(root + "/Controls/css/controls.css", doc);
        linkStyleSheet(root + "/Controls/css/advancedList-1.0.3.css", doc);
        addScript(root +"/Controls/event.js", doc );
        addScript(root +"/Controls/appColors.js", doc );
        addScript(root +"/Controls/listBox.js", doc );
        addScript(root +"/Controls/filterGroup.js", doc );
        addScript(root +"/Controls/IView.js", doc );
        addScript(root +"/Controls/advancedList-1.0.3.js", doc );

        // Data infrastructure for dynamiclist controller
        addScript(root +"/Helpers/bindingList.js", doc );
        addScript(root +"/Data/dynamicEntity.js", doc );
        addScript(root +"/Data/fetch.js", doc );
        addScript(root +"/Data/metaData.js", doc );
        addScript(root +"/Data/metaEntity.js", doc );
        addScript(root +"/Data/dataImageCache.js", doc );
        addScript(root +"/Data/imageProvider.js", doc );

        // dynamiclist controller
        addScript(root +"/Controllers/controllerFactory.js", doc );
        addScript(root +"/Controllers/listController.js", doc );
        addScript(root +"/Controllers/entityList.js", doc );
        addScript(root +"/Controllers/dynamicEntityList.js", doc );
        addScript(root +"/Controllers/listTemplateManager.js", doc );
        addScript(root +"/Controllers/Workflow/executionContext.js", doc );
        addScript(root +"/Controllers/Workflow/engine.js", doc );
        addScript(root +"/Controllers/Workflow/externalActions.js", doc );
        addScript(root +"/Controllers/Workflow/step.js", doc );
        addScript(root +"/Controllers/Workflow/stepCollection.js", doc );
        addScript(root +"/Controllers/Workflow/branch.js", doc );
        addScript(root +"/Controllers/Workflow/branchCollection.js", doc );
        addScript(root +"/Controllers/Workflow/conditionGroup.js", doc );
        addScript(root +"/Controllers/Workflow/expressionStep.js", doc );
        addScript(root +"/Controllers/Workflow/conditionStep.js", doc );
        addScript(root +"/Controllers/Workflow/assignmentStep.js", doc );
        addScript(root +"/Controllers/Workflow/functionStep.js", doc );
        addScript(root +"/Controllers/Workflow/positionStep.js", doc );
        addScript(root +"/Controllers/Workflow/sayTextStep.js", doc );
        addScript(root +"/Controllers/Workflow/sharedVariables.js", doc );
        addScript(root +"/Controllers/Workflow/variable.js", doc );
        addScript(root +"/Controllers/Workflow/variableDefinitionStep.js", doc );
        addScript(root +"/Controllers/Workflow/workflow.js", doc );
        addScript(root +"/Controllers/Workflow/commandStep.js", doc );

        // Scheduler
        addScript(root +"/Controls/Scheduler/JSBridgeBaseQuery.js", doc);
        addScript(root +"/Controls/Scheduler/buttonsBar.js", doc );
        addScript(root +"/Controls/Scheduler/enums.js", doc );
        addScript(root +"/Controls/Scheduler/timeRange.js", doc );
        addScript(root +"/Controls/Scheduler/infoBar.js", doc );
        addScript(root +"/Controls/Scheduler/interfaces.js", doc );
        addScript(root + "/Controls/Scheduler/geo.js", doc);
        addScript(root + "/Controls/Scheduler/geoFloydWarshall.js", doc);
        addScript(root +"/Controls/Scheduler/stringTable.js", doc );
        addScript(root +"/Controls/Scheduler/utilities.js", doc );
        addScript(root +"/Controls/Scheduler/statistic.js", doc );
        addScript(root +"/Controls/Scheduler/settings.js", doc );
        addScript(root +"/Controls/Scheduler/dialogs/baseDlg.js", doc );
        addScript(root +"/Controls/Scheduler/dialogs/settingsDlg.js", doc );
        addScript(root +"/Controls/Scheduler/resource.js", doc );
        addScript(root +"/Controls/Scheduler/task.js", doc );
        addScript(root +"/Controls/Scheduler/scroller.js", doc );
        addScript(root +"/Controls/Scheduler/gridView.js", doc );
        addScript(root +"/Controls/Scheduler/container.js", doc );
        addScript(root +"/Controls/Scheduler/taskMoveManager.js", doc );
        addScript(root +"/Controls/Scheduler/dialogs/autoPlannerSettingsDlg.js", doc );
        addScript(root +"/Controls/Scheduler/dialogs/autoPlannerResultDlg.js", doc );
        addScript(root +"/Controls/Scheduler/autoPlanner.js", doc);

        if (MobileCRM.bridge.platform == "iOS") {
            MobileCRM.bridge.command("dataDetectorTypes", "None");
            MobileCRM.bridge.command("setScrollBounce", false);
        }
    };

    function addScript(script:string, doc:any) {
        var JSElement = document.createElement('script');
        JSElement.src = script;
        //JSElement.onload = callback;
        doc.appendChild(JSElement);
    }

    function linkStyleSheet(path: string, doc: any) {
        var JSElement = document.createElement('link');
        JSElement.href = path;
        JSElement.rel = "stylesheet";
        JSElement.type = "text/css";
        doc.appendChild(JSElement);
    }

    function linkPrintStyleSheet(path: string, doc: any) {
        var JSElement = document.createElement('link');
        JSElement.href = path;
        JSElement.rel = "stylesheet";
        JSElement.type = "text/css";
        JSElement.media = "print";
        doc.appendChild(JSElement);
    }
}

Resco.Controls.Scheduler.loadScripts();
*/
