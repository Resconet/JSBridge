///<reference path="../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../Controls/advancedList-1.0.3.ts" />
///<reference path="../../Controls/popupMenu.ts"/>
///<reference path="../../Controllers/controllerFactory.ts" />
///<reference path="../../Controllers/dynamicEntityList.ts" />
///<reference path="../../Helpers/common.ts" />
///<reference path="../../Data/metaEntity.ts" />
///<reference path="../../Data/dataImageCache.ts" />
///<reference path="../../Controls/filterGroup.ts" />
///<reference path="../../Controls/gestureManager.ts" />
///<reference path="libs/es6-shim.d.ts"/>
///<reference path="constants.ts" />
///<reference path="settings.ts" />
///<reference path="geo.ts" />
///<reference path="task.ts" />
///<reference path="dialogs/settingsDlg.ts" />
///<reference path="dialogs/taskPropertyDlg.ts" />
///<reference path="dialogs/autoplannerResultDlg.ts" />
///<reference path="gridview.ts" />
///<reference path="JSBridgeBaseQuery.ts" />
///<reference path="buttonsBar.ts" />
///<reference path="infoBar.ts" />
///<reference path="statusCodeTable.ts" />
///<reference path="dataProvider.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var AppSettings = (function () {
                function AppSettings() {
                }
                return AppSettings;
            }());
            var DoubleClickEventArgs = (function (_super) {
                __extends(DoubleClickEventArgs, _super);
                function DoubleClickEventArgs(id) {
                    var _this = _super.call(this) || this;
                    _this._objectID = id;
                    return _this;
                }
                Object.defineProperty(DoubleClickEventArgs.prototype, "objectID", {
                    get: function () {
                        return this._objectID;
                    },
                    enumerable: true,
                    configurable: true
                });
                return DoubleClickEventArgs;
            }(Resco.EventArgs));
            Scheduler.DoubleClickEventArgs = DoubleClickEventArgs;
            var Container = (function () {
                function Container(controlName, imageFolder, inputs, dataProvider) {
                    var _this = this;
                    this.fresh = false; // indicates that gantt was recently (before first redraw) initialized
                    this._defaultOffice = new Scheduler.Office();
                    this._resourceList = [];
                    this._settings = new Scheduler.Settings();
                    this._useTaskTemplateContent = true;
                    this._stringTableRegularExpression = "^Scheduler\\..*|^Err\\..*|^Msg\\..*|^Cmd\\..*";
                    this._canWrite = true;
                    this._sourceDefined = true;
                    this._loadingInProcess = true;
                    this._dataLoadCompleted = false;
                    this._sourceDataLoadCompleted = false;
                    this._lockRedraw = 0;
                    this._isListInitialized = false;
                    this._isHorizontalListInitialized = false;
                    this._isTaskContentInitialized = false;
                    this._asyncCallbackStack = [];
                    this._initialized = false;
                    this._viewToListSync = false;
                    this._listToViewSync = false;
                    this._horizontalListSelectedRowRoot = null;
                    this._holidaysEnabled = false;
                    this._isSaving = false;
                    this._onSelectedIndexChanged = function (sender, e) {
                        // row.$root jQuery element needs to be cached, because it is removed and replaced by new ($root jQuery element) during row template update.
                        if (_this._horizontalListSelectedRowRoot) {
                            var moveManager = _this.draggableContainer.moveManager;
                            moveManager.gestureManager.offDownMoveUpCancel(_this._horizontalListSelectedRowRoot, _this._onSelectedHorizontalListItemDown, moveManager.moveManagement, moveManager.upManagement, moveManager.cancelManagement);
                        }
                        _this._horizontalListSelectedRowRoot = null;
                        if ((0 <= e.index) && (e.index < _this._horizontalListCtrl.rows.length)) {
                            var row = _this._horizontalListCtrl.rows[e.index];
                            if (row && row.$root) {
                                _this._horizontalListSelectedRowRoot = row.$root;
                                var moveManager = _this.draggableContainer.moveManager;
                                moveManager.gestureManager.onDownMoveUpCancel(_this._horizontalListSelectedRowRoot, _this._onSelectedHorizontalListItemDown, moveManager.moveManagement, moveManager.upManagement, moveManager.cancelManagement);
                            }
                        }
                    };
                    this._onSelectedHorizontalListItemDown = function (ge) {
                        ge.cancelDown = true;
                        if (!_this.isLocked() && !_this.viewCtrl.zoom.inMonthsMode() && !_this.viewCtrl.zoom.inMapViewMode()) {
                            ge.cancelDown = false;
                            var item = null;
                            if ((0 <= _this._horizontalListCtrl.selectedIndex) && (_this._horizontalListCtrl.selectedIndex < _this._horizontalListCtrl.rows.length)) {
                                item = _this._horizontalListCtrl.rows[_this._horizontalListCtrl.selectedIndex];
                            }
                            _this.draggableContainer.moveManager.downManagement(ge, item);
                        }
                    };
                    Container._ref = this;
                    Container._imageFolder = imageFolder;
                    this._element = $("#schedulerElement");
                    // Office settings
                    if (!inputs.office || !inputs.office.entityName) {
                        inputs.office = new Scheduler.OfficeDataInput();
                        inputs.office.entityName = "fs_settings";
                        inputs.office.attrLocation = "location_address";
                        inputs.office.attrBreakPerDay = "break_per_day";
                        inputs.office.attrFirstDayOfWeek = "first_day_of_week";
                        inputs.office.attrStartOfDay = "start_of_day";
                        inputs.office.attrWorkingDayDuration = "working_day_duration";
                        inputs.office.attrWorkingWeekends = "working_weekends";
                    }
                    if (inputs.timeOffSchedules) {
                        if (!inputs.timeOffSchedules.color)
                            inputs.timeOffSchedules.color = "rgba(163,164,165,0.8)";
                    }
                    var self = this;
                    this._inputData = inputs;
                    this._constants = new Scheduler.Constants();
                    this._dataProvider = dataProvider;
                    if (inputs.name)
                        this._controlName = inputs.name.replace(" ", "_");
                    else
                        this._controlName = controlName;
                    this._handleLoadingScreen(true);
                    Scheduler.StringTable.load(this._stringTableRegularExpression, function () {
                        Container.validateInputData(inputs, function (err) {
                            if (err) {
                                Scheduler.StringTable.alert(err);
                                return;
                            }
                            if (!inputs.unscheduledTasks || !inputs.unscheduledTasks.entityName)
                                self._sourceDefined = false;
                            if (inputs.scheduledTasks) {
                                if (inputs.scheduledTasks.borderWidth || (inputs.scheduledTasks.borderWidth === 0))
                                    Scheduler.Task.borderWidth = inputs.scheduledTasks.borderWidth;
                                if (inputs.scheduledTasks.borderRadius || (inputs.scheduledTasks.borderRadius === 0))
                                    Scheduler.Task.borderRadius = inputs.scheduledTasks.borderRadius;
                            }
                            _this._listsDelayLoadManager = new ListsDelayLoadManager(_this, function (appendRows) {
                                _this._refreshChanges(appendRows);
                            });
                            self._appColors = new Controls.AppColors();
                            self._statusCodeTable = new Scheduler.StatusCodeTable(inputs);
                            self.onDataLoadCompleted = new Resco.Event(self);
                            self.onSourceDataLoadCompleted = new Resco.Event(self);
                            self.onTaskDoubleClick = new Resco.Event(self);
                            Scheduler.FilterList.initialize(inputs.filterList);
                            MobileCRM.bridge.onGlobalEvent("WorkOrderChanged", self.onWorkOrderEntityChanged, true, self);
                            Scheduler.Holidays.initialize(inputs.holidays, function (err) {
                                self._holidaysEnabled = Scheduler.Holidays.isInitialized();
                                self.loadOfficeSettings(inputs.office, function (officeData) {
                                    self._defaultOffice = officeData;
                                    self._initialize(function (error) {
                                        self._settings.load(self.getSettingsFileName(), function () {
                                            self._initializeMap(function (error) {
                                                self._initContainer(function () {
                                                    Scheduler.Geo.Service.initialize(officeData.location, self._constants.googleApiKey);
                                                    self.onTaskDoubleClick.add(self, self._onShowTask);
                                                    self._initialized = true;
                                                    self.onInitialized(error, officeData);
                                                });
                                            });
                                        });
                                    });
                                });
                            });
                        });
                    });
                }
                Object.defineProperty(Container, "ref", {
                    get: function () {
                        return Container._ref;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container, "imageFolder", {
                    get: function () {
                        return Container._imageFolder;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container, "appColors", {
                    get: function () {
                        return Container._ref._appColors;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container, "statusCodeTable", {
                    get: function () {
                        return Container._ref._statusCodeTable;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container, "constants", {
                    get: function () {
                        return Container._ref._constants;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container, "inputs", {
                    get: function () {
                        return Container._ref._inputData;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container, "defaultOffice", {
                    get: function () {
                        return Container._ref._defaultOffice;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container, "debugMode", {
                    get: function () {
                        return Container._ref._constants.debugMode;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "element", {
                    //get controlName(): string {
                    //	return this._controlName;
                    //}
                    get: function () {
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "buttonsBar", {
                    get: function () {
                        return this._buttonsBar;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "infoBar", {
                    get: function () {
                        return this._infoBar;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "settings", {
                    get: function () {
                        return this._settings;
                    },
                    set: function (f) {
                        if (f.isDirty)
                            f.save(this.getSettingsFileName());
                        this._settings = f;
                    },
                    enumerable: true,
                    configurable: true
                });
                Container.prototype.getSettingsFileName = function () {
                    return this._controlName + ".Settings.json";
                };
                Object.defineProperty(Container.prototype, "draggableContainer", {
                    get: function () {
                        return this._draggableContainer;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "viewCtrl", {
                    get: function () {
                        return this._viewCtrl;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "listCtrl", {
                    get: function () {
                        return this._listCtrl;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "horizontalListCtrl", {
                    get: function () {
                        return this._horizontalListCtrl;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "taskTemplateCtrl", {
                    get: function () {
                        return this._taskTemplateCtrl;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "allDataLoaded", {
                    get: function () {
                        return this._dataLoadCompleted;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "allSourceDataLoaded", {
                    get: function () {
                        return this._sourceDataLoadCompleted;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "loadingInProcess", {
                    get: function () {
                        return this._loadingInProcess;
                    },
                    enumerable: true,
                    configurable: true
                });
                ;
                Object.defineProperty(Container.prototype, "canModifyTasks", {
                    get: function () {
                        return this._canWrite; //can't be here, because auto-scheduling will not work correctly: && !AutoPlanner.Core.isRunning();
                    },
                    enumerable: true,
                    configurable: true
                });
                ;
                Object.defineProperty(Container.prototype, "listRowHeight", {
                    get: function () {
                        return this._constants.listCtrlRowHeight;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "listHeight", {
                    get: function () {
                        return this._resourceList.length * this._constants.listCtrlRowHeight;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "resourceDictionary", {
                    get: function () {
                        return this._resourceDict;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "isDesktop", {
                    get: function () {
                        var check = true;
                        (function (a) { if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4)))
                            check = false; })(navigator.userAgent || navigator.vendor || window.opera);
                        return check;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "dataProvider", {
                    get: function () {
                        return this._dataProvider;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "sourceDefined", {
                    get: function () {
                        return this._sourceDefined;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "taskTemplateHeight", {
                    get: function () {
                        return this._taskTemplateHeight;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "useTaskTemplateContent", {
                    get: function () {
                        return this._useTaskTemplateContent;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "holidaysEnabled", {
                    get: function () {
                        return this._holidaysEnabled;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "isDataReady", {
                    get: function () {
                        return this._listsDelayLoadManager.isListDelayLoadEnded;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Container.prototype, "isSourceDataReady", {
                    get: function () {
                        return this._listsDelayLoadManager.isHorizontalListDelayLoadEnded;
                    },
                    enumerable: true,
                    configurable: true
                });
                Container.onFormClosing = function () {
                    // onFormClosing method need to be defined, because it is expected by C# code.
                    if (Container.ref) {
                        Container.ref.onFormClosing();
                    }
                };
                Container.prototype.onFormClosing = function () {
                    // onFormClosing method need to be defined, because it is expected by C# code.
                };
                Container.prototype.isLocked = function () {
                    return Scheduler.AutoPlanner.Core.isRunning();
                };
                // check if control is not processing current data and they can be changed
                Container.prototype.dataLoadEnabed = function (showAlert) {
                    if (!Scheduler.AutoPlanner.Core.isRunning())
                        return true;
                    if (showAlert)
                        Scheduler.StringTable.alertByKey("Scheduler.Err.AutoPlanningNotFinished");
                    return false;
                };
                // find resource by Id
                Container.prototype.findResource = function (id) {
                    return this._resourceDict.Item(id);
                };
                // return resource located on the specified row
                Container.prototype.getResourceByRowIndex = function (rowIndex) {
                    if (rowIndex >= 0 && rowIndex < this._resourceList.length)
                        return this._resourceList[rowIndex];
                    return null;
                };
                // find task by Id
                Container.prototype.findTask = function (taskId) {
                    return this.searchForTask(function (task) { return task.id === taskId; });
                };
                Container.prototype.onInitialized = function (error, officeData) {
                };
                Container.prototype.onWorkOrderEntityChanged = function (entity) {
                    // this function is calling to often during save 
                    if (this._isSaving || Scheduler.AutoPlanner.Core.isRunning())
                        return;
                    var entityName = entity.entityName;
                    if (entityName === this._inputData.scheduledTasks.entityName) {
                        var task = this.findTask(entity.id);
                        if (task) {
                            var taskWasRemoved = false;
                            var properties = entity.properties;
                            var resId = properties[this._inputData.scheduledTasks.attrResourceRef];
                            var statuscode = properties[this._inputData.scheduledTasks.attrStatus];
                            if (statuscode !== undefined) {
                                if (!Scheduler.Task.isValidStatusValue(statuscode)) {
                                    this.removeTask(task);
                                    taskWasRemoved = true;
                                }
                            }
                            if (!taskWasRemoved) {
                                this._dataProvider.rowToScheduledTask(properties, task);
                                if (task.getStatus().isUnscheduled()) {
                                    if (!task.isUnscheduledNew())
                                        this.setTaskAsUnscheduled(task, false);
                                }
                                else if (resId && resId.id)
                                    this.reassignTask(task, resId.id, false);
                            }
                            this._refreshChanges();
                        }
                        return;
                        //else if(entityName === this._inputData.unscheduledTasks.entityName ||
                        //		entityName === this._inputData.resources.entityName ||
                        //	(this._inputData.timeOffSchedules && entityName === this._inputData.timeOffSchedules.entityName))
                        //	this.reloadAll();
                    }
                    // refresh all in case some associated lookup changed (skills, territory, ...)
                    this.reloadAll();
                };
                // initialize control
                Container.prototype._initialize = function (onInitialized) {
                    var _this = this;
                    if (!Scheduler.Constants.disableJBridge)
                        MobileCRM.CultureInfo.initialize(function (info) {
                            _this._constants.cultureInfo = info;
                            _this.initializeSettings(onInitialized);
                        }, function (error) {
                            _this._constants.cultureInfo = new MobileCRM.CultureInfo();
                            _this.initializeSettings(onInitialized);
                        }, this);
                    else {
                        onInitialized(null);
                    }
                };
                Container.prototype._initializeMap = function (onInitialized) {
                    if (this._constants.enableMapView) {
                        if (this._constants.googleApiKey) {
                            Scheduler.MapView.initialize(this._constants.googleApiKey, onInitialized);
                            return;
                        }
                        else {
                            this._constants.enableMapView = false;
                        }
                    }
                    onInitialized(null);
                };
                Container.prototype.gridViewScrolled = function (scrollTop) {
                    if (this.viewCtrl instanceof Scheduler.View) {
                        this.viewCtrl.cancelLongPress(); // try to cancel long press if scroll occurred
                    }
                    if (!this._listToViewSync) {
                        if (scrollTop !== this._listCtrl.getScrollPosition()) {
                            this._viewToListSync = true;
                            this._listCtrl.setScrollPosition(scrollTop);
                        }
                    }
                    this._listToViewSync = false;
                };
                // Force reload of all data
                Container.prototype.reloadAll = function () {
                    if (!this._initialized)
                        return;
                    this._listCtrl.reset(false);
                    this.resetData();
                    this._viewCtrl.onFilterChanged(this._settings);
                    this._listsDelayLoadManager.delayLoadStart();
                    if (this._controller)
                        this._controller.reload();
                    if (this._horizontalController)
                        this._horizontalController.reload();
                };
                // reload tasks for existing resources
                Container.prototype.reloadTasks = function () {
                    var _this = this;
                    if (this._resourceList && (this._resourceList.length > 0)) {
                        for (var i = 0; i < this._resourceList.length; i++)
                            this._resourceList[i].clearTasks();
                        this.loadAssociatedTasks(this._resourceList, function (appendRows) {
                            _this._refreshChanges(appendRows);
                        });
                    }
                };
                Container.prototype.lockRedraw = function () {
                    this._lockRedraw++;
                };
                Container.prototype.unlockRedraw = function () {
                    this._lockRedraw--;
                    if (this._lockRedraw < 0)
                        this._lockRedraw = 0;
                    return this._lockRedraw === 0;
                };
                // redraw scheduler control and apply all changes
                Container.prototype.redraw = function () {
                    if (this._lockRedraw === 0 && this._initialized) {
                        //this._drawDurations = new Performance();
                        this._viewCtrl.redraw();
                        this._handleLoadingScreen(false);
                        //this._drawDurations.end();
                    }
                };
                Container.prototype.changeView = function (newView) {
                    if (this.viewCtrl && (this.viewCtrl instanceof Scheduler.MapView)) {
                        this.viewCtrl.dispose();
                    }
                    this._viewCtrl = newView;
                    this.draggableContainer.splitterContainer.viewContainer.view = this._viewCtrl;
                };
                // convert y position to list row index
                Container.prototype.position2RowIndex = function (yPos) {
                    var rowIndex = Math.floor(yPos / this._constants.listCtrlRowHeight);
                    return (0 <= rowIndex && rowIndex < this._resourceList.length) ? rowIndex : -1;
                };
                Container.prototype.forEachResource = function (proc) {
                    this.forEachResourceInRange(0, proc);
                };
                Container.prototype.forEachResourceInRange = function (startIndex, proc) {
                    for (var i = startIndex; i < this._resourceList.length; i++)
                        proc(this._resourceList[i]);
                };
                Container.prototype.forEachScheduledTask = function (proc, visibleOnly) {
                    this.forEachScheduledTaskInRange(0, proc, visibleOnly);
                };
                Container.prototype.forEachScheduledTaskInRange = function (startIndex, proc, visibleOnly) {
                    for (var i = startIndex; i < this._resourceList.length; i++) {
                        var resource = this._resourceList[i];
                        var tasks = resource.getTasks();
                        if (tasks) {
                            for (var j = 0; j < tasks.length; j++) {
                                if (!visibleOnly || (visibleOnly && (this._viewCtrl && this._viewCtrl.hasScheduledTaskVisible(tasks[j])))) {
                                    proc(tasks[j], resource);
                                }
                            }
                        }
                    }
                };
                Container.prototype.forEachTask = function (proc) {
                    this.forEachTaskInRange(0, proc);
                };
                Container.prototype.forEachTaskInRange = function (startIndex, proc) {
                    this.forEachScheduledTaskInRange(startIndex, proc);
                    //this._unscheduledTasksBar.forEach((task) => {
                    //	proc(task, undefined);
                    //});
                };
                Container.prototype.forEachStatistic = function (proc) {
                    this.forEachStatisticInRange(0, proc);
                };
                Container.prototype.forEachStatisticInRange = function (startIndex, proc) {
                    for (var i = startIndex; i < this._resourceList.length; i++) {
                        var resource = this._resourceList[i];
                        var statistics = resource.getStatistics();
                        for (var j = 0; j < statistics.length; j++) {
                            proc(statistics[j], resource);
                        }
                    }
                };
                Container.prototype.saveTask = function (task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var oldParent, resources;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    oldParent = task.resource;
                                    if (taskChanges.parentID !== undefined) {
                                        resources = this.resourceDictionary;
                                        task.resource = resources.Item(taskChanges.parentID);
                                    }
                                    this._onSaving(true);
                                    return [4 /*yield*/, this._dataProvider.saveTask(task, taskChanges)];
                                case 1:
                                    _a.sent();
                                    task.resource = oldParent;
                                    task.applyChanges(taskChanges, true);
                                    this._onSaving(false);
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                Container.prototype._onSaving = function (isSaving) {
                    this._isSaving = isSaving;
                    MobileCRM.bridge.onGlobalEvent("WorkOrderChanged", this.onWorkOrderEntityChanged, !isSaving, this);
                };
                Container.prototype.saveTasks = function (changeList, onFinishCallback, redraw) {
                    var _this = this;
                    var length;
                    if (!changeList || !(length = changeList.length)) {
                        onFinishCallback(null);
                        return;
                    }
                    var promises = new Array(length);
                    var oldParents = new Array(length);
                    this._onSaving(true);
                    for (var i = 0; i < length; i++) {
                        var taskChanges = changeList[i];
                        var task = taskChanges["task"];
                        oldParents[i] = task.resource;
                        if (taskChanges.parentID !== undefined) {
                            var resources = this.resourceDictionary;
                            task.resource = resources.Item(taskChanges.parentID);
                        }
                        this._onSaving(true);
                        promises[i] = this._saveTask(task, taskChanges);
                    }
                    Scheduler.PromiseEx.allEx(promises)
                        .then(function (tasks) {
                        for (var i = 0; i < tasks.length; i++) {
                            var task_1 = tasks[i];
                            if (task_1) {
                                var taskChanges = changeList[i];
                                task_1.resource = oldParents[i];
                                task_1.applyChanges(taskChanges, false);
                            }
                        }
                        if (redraw)
                            _this.redraw();
                        _this._onSaving(false);
                        onFinishCallback(null);
                    })
                        .catch(function (errors) {
                        if (redraw)
                            _this.redraw();
                        _this._onSaving(false);
                        var messages = errors.map(function (error) {
                            return (error instanceof Resco.Exception) ? error.message : error.toString();
                        });
                        onFinishCallback(Scheduler.aggregateErrors(messages));
                    });
                };
                Container.prototype._saveTask = function (task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, this._dataProvider.saveTask(task, taskChanges)];
                                case 1:
                                    _a.sent();
                                    return [2 /*return*/, task];
                            }
                        });
                    });
                };
                Container.prototype.reassignTask = function (task, newResourceID, redraw) {
                    var _this = this;
                    if (!task.resource) {
                        if (!newResourceID)
                            return;
                    }
                    else if (task.resource.getID() === newResourceID)
                        return;
                    if (!newResourceID)
                        this.setTaskAsUnscheduled(task, redraw);
                    else {
                        var resource = this.findResource(newResourceID);
                        if (resource) {
                            if (task.getStatus().isUnscheduled()) {
                                var status_1 = Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                if (!status_1)
                                    return;
                                //if (task instanceof Task) {
                                task.appendTaskBoxFromUTCToDC();
                                //}
                                task.setStatus(status_1);
                                task.appendTaskBoxFromDCToTC();
                                resource.addTask(task); // task need to be added to resource before it is removed from unscheduledTasksBar, because unscheduledTasksBar.remove() method can call all tasks redraw, what remove task gantElement from DOM when task does not belong to any resource!
                                resource.resetSort();
                                if (task.group) {
                                    var scrollPosition_1 = this._horizontalListCtrl ? this._horizontalListCtrl.getScrollPosition() : undefined;
                                    this._dataProvider.hideUnscheduledTasksEntities([task.group.id], redraw, function () {
                                        if ((scrollPosition_1 !== undefined) && (scrollPosition_1 !== null) && _this._horizontalListCtrl)
                                            _this._horizontalListCtrl.setScrollPosition(scrollPosition_1);
                                    });
                                }
                                //this._unscheduledTasksBar.remove(task, redraw);
                            }
                            else {
                                resource.addTask(task);
                                resource.resetSort();
                            }
                        }
                    }
                };
                Container.prototype.setTaskAsUnscheduled = function (task, redraw) {
                    var _this = this;
                    if (task.group) {
                        var scrollPosition_2 = this._horizontalListCtrl ? this._horizontalListCtrl.getScrollPosition() : undefined;
                        this.removeTask(task);
                        this._dataProvider.showUnscheduledTasksEntities([task.group.id], redraw, function () {
                            if (redraw)
                                _this.redraw();
                            else {
                                if ((scrollPosition_2 !== undefined) && (scrollPosition_2 !== null) && _this._horizontalListCtrl)
                                    _this._horizontalListCtrl.setScrollPosition(scrollPosition_2);
                            }
                        });
                    }
                    else {
                        if (redraw)
                            this.redraw();
                    }
                    //this._unscheduledTasksBar.add(task, redraw);
                    //if (redraw)
                    //	this.redraw();
                };
                Container.prototype.removeTask = function (task) {
                    task.removeBox();
                    if (task.resource)
                        task.resource.removeTask(task);
                    if (task.getStatus().isUnscheduled() && !task.isUnscheduledNew()) {
                        //this._unscheduledTasksBar.remove(task, true);
                    }
                };
                Container.prototype.updateKPIControl = function (resource) {
                    var kpiControl;
                    if (this.infoBar && (kpiControl = this.infoBar.kpiControl)) {
                        var allUnscheduledTasks = 0;
                        var allScheduledTasks_1 = 0;
                        var completedTasks_1 = 0;
                        var ruleViolations_1 = 0;
                        var travelTime_1 = 0;
                        var scheduledTime_1 = 0;
                        var jeopardy = 0;
                        /*
                        this._unscheduledTasksBar.forEach((task: Task) => {
                            allUnscheduledTasks++;
                            if (task.isInJeopardy()) {
                                task.updateAlert(true);
                                jeopardy++;
                            }
                        });*/
                        this.forEachScheduledTask(function (task, parent) {
                            if (!resource || (resource && resource.getID() === parent.getID())) {
                                if (!task.isTimeOff()) {
                                    allScheduledTasks_1++;
                                    if (task.getStatus().taskStatusType() === Scheduler.TaskStatusType.Completed)
                                        completedTasks_1++;
                                    if (task.ruleViolations.length > 0)
                                        ruleViolations_1++;
                                    scheduledTime_1 += task.getWorkEnd() - task.getWorkStart();
                                    travelTime_1 += task.getTotalTravelTo() + task.getTotalTravelFrom();
                                }
                            }
                        }, true);
                        travelTime_1 = allScheduledTasks_1 > 0 ? Math.floor(travelTime_1 / allScheduledTasks_1) : 0;
                        kpiControl.allUnscheduledTasksCount = allUnscheduledTasks;
                        kpiControl.allScheduledTasksCount = allScheduledTasks_1;
                        kpiControl.completedTasksCount = completedTasks_1;
                        kpiControl.ruleViolationsCount = ruleViolations_1;
                        kpiControl.totalScheduledTime = scheduledTime_1;
                        kpiControl.averageTravelTime = travelTime_1;
                        kpiControl.jeopardyCount = jeopardy;
                    }
                };
                Container.setElementBackgroundImage = function (element, imageName) {
                    if (element)
                        element.style.backgroundImage = "url(" + Container._imageFolder + imageName + ")";
                };
                Container.prototype.setButtonsBarInfo = function (text) {
                    if (this.buttonsBar) {
                        if (!text) {
                            text = "";
                            if (this._viewCtrl) {
                                var dataRange = this._viewCtrl.zoom.getTimeRange();
                                var filter = this._settings;
                                var hasFilter = false;
                                for (var i = 0; i < Scheduler.FilterList.CustomFilters.length; i++) {
                                    var item = Scheduler.FilterList.CustomFilters[i];
                                    if (filter.customFilterSelection[item.name]) {
                                        hasFilter = true;
                                        if (text === "")
                                            text = Scheduler.StringTable.get("Scheduler.Msg.FilteredBy") + " " + Scheduler.StringTable.get(item.filteredByLocalizationKey);
                                        else
                                            text += ", " + Scheduler.StringTable.get(item.filteredByLocalizationKey);
                                    }
                                }
                                text = Scheduler.StringTable.get("Msg.SEASON") + ": " + this._constants.timeToString(new Date(dataRange.start)) + " - " + this._constants.timeToString(new Date(dataRange.end - 1)) + "</br>" + text;
                                this._buttonsBar.onCustomFilterChanged(hasFilter);
                            }
                        }
                        this.buttonsBar.filterStatusElement.html(text);
                        this.buttonsBar.updateAutoPlannerIcon();
                    }
                };
                /**
                 * Shows text given by parameter in the "schedulerInfoBar" at the scheduler bottom.
                 * @param text represents string that is shown. If omitted, empty string is shown.
                 */
                Container.prototype.setStatusInfo = function (text) {
                    if (this.infoBar)
                        this.infoBar.setStatusInfo(text);
                };
                Container.prototype._refreshChanges = function (appendRows) {
                    if (!this._initialized)
                        this._handleLoadingScreen(false);
                    else if (!appendRows)
                        this.redraw(); // redraw all
                    else if (this._lockRedraw === 0) {
                        this._viewCtrl.appendRows(); // refresh only last changes
                        this._handleLoadingScreen(false);
                    }
                };
                Container.prototype.reinitializeComponents = function (onFinishCallback) {
                    this._initContainer(onFinishCallback);
                };
                //<%----------------------------- PRIVATE FUNCTIONS ---------------------------------%>
                Container.prototype._initContainer = function (onFinishCallback) {
                    var _this = this;
                    this.fresh = true;
                    this.element.empty();
                    this.resetData();
                    MobileCrm.Data.DataImageCache.getImageLoader = this._getDataImageCacheLoader;
                    Resco.UI.AdvancedList.SeparatorColor = "silver";
                    if ((this.settings.zoomLevel === "hmap") && (!Container.constants.enableMapView || !Scheduler.MapView.isInitialized)) {
                        this.settings.zoomLevel = "d";
                    }
                    this._listsDelayLoadManager.delayLoadStart();
                    this._isListInitialized = false;
                    this._isHorizontalListInitialized = false;
                    this._isTaskContentInitialized = false;
                    this._initResourceList(function () {
                        _this._isListInitialized = true;
                        _this._onListsAndTaskInitialized(onFinishCallback);
                    });
                    if (this.sourceDefined) {
                        this._initUnscheduledTasksList(function () {
                            _this._isHorizontalListInitialized = true;
                            _this._onListsAndTaskInitialized(onFinishCallback);
                        });
                    }
                    else {
                        this._isHorizontalListInitialized = true;
                        this._onListsAndTaskInitialized(onFinishCallback);
                    }
                    this._initTaskContent(function () {
                        _this._isTaskContentInitialized = true;
                        _this._onListsAndTaskInitialized(onFinishCallback);
                    });
                    window.removeEventListener("resize", function (e) {
                        _this.onResize();
                    });
                    window.addEventListener("resize", function (e) {
                        _this.onResize();
                    });
                };
                Container.prototype._onListsAndTaskInitialized = function (onFinishCallback) {
                    if (this._isListInitialized && this._isHorizontalListInitialized && this._isTaskContentInitialized) {
                        this._createComponents();
                        onFinishCallback();
                    }
                };
                /*
                private setListView(controller: MobileCrm.UI.IDynamicEntityList, viewName:string ) {
                    if (controller && controller.filterGroup && controller.filterGroup.filters.length > 0) {
                        var settings = controller.filterGroup.filters[0];
                        if( viewName )
                            settings.setSelection(viewName, false);
                        else
                            settings.selectedIndex(0);
                    }
                }*/
                Container.prototype._createListView = function (controller) {
                    var _this = this;
                    this._controller = controller;
                    //this.setListView(controller, Container.inputs.resources.viewName);
                    this._listCtrl.filterChanged.raise(new Resco.UI.FilterChangedEventArgs(4 /* GroupChanged */), this);
                    //this.listCtrl.setFilterText("B", true);
                    this._listCtrl.delayLoadCompleted.add(this, this.onResourceDelayLoadCompleted);
                    this._listCtrl.listScroll.add(this, function (sender, e) {
                        if (_this._listCtrl.orientation === Resco.UI.ListOrientation.Vertical) {
                            if (!_this._viewToListSync) {
                                if (_this.viewCtrl instanceof Scheduler.View) {
                                    var bodyTableElement = _this.viewCtrl.viewBody.element;
                                    if (e.scrollPosition !== bodyTableElement.scrollTop()) {
                                        _this._listToViewSync = true;
                                        bodyTableElement.scrollTop(e.scrollPosition);
                                    }
                                }
                            }
                        }
                        _this._viewToListSync = false;
                    });
                    this._listCtrl.rowClick.add(this, function (sender, e) {
                        if (!_this.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            if (!_this.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.WasProcessed)) {
                                _this.draggableContainer.takeFocusFromFocusedTask();
                                _this.setSelectedRow(e.index);
                            }
                        }
                    });
                    this._listCtrl.rowDblClick.add(this, function (sender, e) {
                        if ((0 <= e.index) && (e.index < _this._listCtrl.rows.length)) {
                            var resources = _this.dataProvider.rowToResource(_this._listCtrl.rows, new Resco.UI.DelayLoadEventArgs(true, e.index, e.index + 1));
                            if (resources && resources.length > 0) {
                                var resourceID = resources[0].getID();
                                _this._openResourceForm(resourceID);
                            }
                        }
                    });
                };
                Container.prototype._openResourceForm = function (resourceID) {
                    MobileCRM.UI.FormManager.showEditDialog(this._inputData.resources.entityName, resourceID, null, null);
                };
                Container.prototype._createHorizontalListView = function (horizontalController) {
                    var _this = this;
                    this._horizontalController = horizontalController;
                    //this.setListView(horizontalController, Container.inputs.unscheduledTasks.viewName);
                    this._horizontalListCtrl.filterChanged.raise(new Resco.UI.FilterChangedEventArgs(4 /* GroupChanged */), this);
                    //this._horizontalListCtrl.setFilterText("B", true);
                    this._horizontalListCtrl.delayLoadCompleted.add(this, this.onHorizontalDelayLoadCompleted);
                    this._horizontalListCtrl.rowClick.add(this, function (sender, e) {
                        if (!_this.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            if (!_this.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.WasProcessed)) {
                                _this.draggableContainer.takeFocusFromFocusedTask();
                                _this.setSelectedItem(e.index);
                            }
                        }
                    });
                    this._horizontalListCtrl.selectedIndexChanged.add(this, this._onSelectedIndexChanged);
                };
                Container.prototype.setResourceView = function (viewName) {
                    if (this._controller && viewName) {
                        var controller = this._controller;
                        controller.selectView(viewName);
                    }
                };
                Container.prototype.setHorizontalView = function (viewName) {
                    if (this._horizontalController && viewName) {
                        var controller = this._horizontalController;
                        controller.selectView(viewName);
                    }
                };
                Container.prototype.setTaskView = function (viewName) {
                    if (viewName && this.taskTemplateCtrl.controller) {
                        this.taskTemplateCtrl.controller.selectView(viewName);
                    }
                };
                /**
                 * Returns all allowedViews for resource.
                 */
                Container.prototype.getResourceViews = function () {
                    return this._getControllerViews(this._controller);
                };
                /**
                 * Returns all allowedViews for source.
                 */
                Container.prototype.getSourceViews = function () {
                    return this._getControllerViews(this._horizontalController);
                };
                /**
                 * Returns all allowedViews for task.
                 */
                Container.prototype.getTaskViews = function () {
                    return this._getControllerViews(this.taskTemplateCtrl.controller);
                };
                Container.prototype._getControllerViews = function (controller) {
                    if (controller) {
                        var ctrller = controller;
                        if (ctrller.allowedViews) {
                            return ctrller.allowedViews.getKeys();
                        }
                    }
                    return [];
                };
                Container.prototype._getListTemplateHeight = function (listCtrl) {
                    var height = this._tryGetListTemplateHeight(listCtrl);
                    if (height === undefined) {
                        height = Container.constants.listCtrlRowHeight;
                    }
                    return height;
                };
                Container.prototype._getHorizontalListTemplateHeight = function (horizontalListCtrl) {
                    var height = this._tryGetListTemplateHeight(horizontalListCtrl);
                    if (height === undefined) {
                        height = Container.constants.unscheduledViewHeight;
                    }
                    return height;
                };
                Container.prototype._tryGetTaskTemplateHeight = function () {
                    if (this.taskTemplateCtrl.isInitialized) {
                        var template = this.taskTemplateCtrl.template;
                        if (template) {
                            return template.size.height();
                        }
                    }
                    return undefined;
                };
                Container.prototype._tryGetListTemplateHeight = function (listCtrl) {
                    if (listCtrl) {
                        var template = Container.tryGetTemplate(listCtrl.templates, listCtrl.templateIndex());
                        if (template) {
                            return template.size.height();
                        }
                    }
                    return undefined;
                };
                Container.tryGetTemplate = function (templates, templateIndex) {
                    if (templateIndex || (templateIndex === 0)) {
                        if (templates && (templates.length > 0)) {
                            if (templates.length > templateIndex) {
                                return templates[templateIndex];
                            }
                        }
                    }
                    return undefined;
                };
                Container.prototype._createComponents = function () {
                    var _this = this;
                    this._handleLoadingScreen(true);
                    this._setListsAndTaskHeight();
                    this._buttonsBar = new Scheduler.ButtonsBar();
                    var buttonsBarElement = this.buttonsBar.element;
                    if (!this._constants.enableAutoSchedule) {
                        var autoSchedule = buttonsBarElement.find(".autoPlanner");
                        if (autoSchedule)
                            autoSchedule.hide();
                    }
                    this.element.append(buttonsBarElement);
                    if (this.settings.zoomLevel.charAt(0) === "m")
                        this.buttonsBar.zoomLevelElement.val("m");
                    else
                        this.buttonsBar.zoomLevelElement.val(this.settings.zoomLevel);
                    if (this.viewCtrl && (this.viewCtrl instanceof Scheduler.MapView)) {
                        this.viewCtrl.dispose();
                    }
                    if (this.settings.zoomLevel === "hmap") {
                        this._viewCtrl = new Scheduler.MapView(this);
                        this.buttonsBar.showHideMapViewButtons(true);
                    }
                    else {
                        this._viewCtrl = new Scheduler.View(this);
                        this.buttonsBar.showHideMapViewButtons(false);
                    }
                    var viewContainer = new ViewContainer(this._viewCtrl);
                    var listContainer = new ListContainer(this);
                    this._splitter = new Scheduler.Splitter(listContainer, viewContainer, Container.constants.listCtrlWidth, Container.constants.separatorWidth, function (ge) {
                        var e = ge.jQueryEventObject;
                        if (e.target && !$(e.target).hasClass("icon") && !$(e.target).hasClass("resourceFilterArrow")) {
                            return true;
                        }
                        return false;
                    });
                    var horizontalListContainer = this.sourceDefined ? new HorizontalListContainer(this.horizontalListCtrl) : undefined;
                    this._draggableContainer = new DraggableContainer(this, horizontalListContainer, this._splitter);
                    this._splitter.resizeStarted.add(this, function (sender, e) {
                        if (_this.viewCtrl instanceof Scheduler.View) {
                            _this.viewCtrl.cancelLongPress(); // try to cancel long press if resize started
                            _this.viewCtrl.taskPopupMenu.close(); // close popup menu if it was opened meantime
                        }
                    });
                    this._splitter.resize.add(this, function (sender, e) {
                        _this._constants.listCtrlWidth = _this._splitter.leftPanelWidth;
                    });
                    this.element.append(this._draggableContainer.element);
                    this._infoBar = new Scheduler.InfoBar(Container._imageFolder);
                    this.element.append(this.infoBar.element);
                    if (!this._constants.enableKPIBar)
                        this.infoBar.kpiControl.element.hide();
                    this._draggableContainer.onResize();
                    this._loadImages();
                    this.updateTodayText();
                    this._handleLoadingScreen(false);
                };
                Container.prototype._setListsAndTaskHeight = function () {
                    // (Lists height need to be set before _createComponents() method content is performed!)
                    // set horizontal list row height from current template used for Source list
                    if (this._horizontalListCtrl) {
                        this._constants.unscheduledViewHeight = this._getHorizontalListTemplateHeight(this._horizontalListCtrl);
                        this._horizontalListCtrl.fixedTemplateHeight = this._constants.unscheduledViewHeight;
                        this._horizontalListCtrl.minHeigth = this._constants.unscheduledViewHeight;
                    }
                    var taskTemplateHeight = this._tryGetTaskTemplateHeight();
                    if (taskTemplateHeight || (taskTemplateHeight === 0)) {
                        // set list row height from current task template
                        this._taskTemplateHeight = taskTemplateHeight;
                        this._constants.listCtrlRowHeight = taskTemplateHeight + (2 * Container.constants.taskVerticalMargin) + (2 * Scheduler.Task.borderWidth);
                        this._listCtrl.fixedTemplateHeight = this._constants.listCtrlRowHeight;
                    }
                    else {
                        // set list row height from current template used for Resource list
                        this._taskTemplateHeight = undefined;
                        this._constants.listCtrlRowHeight = this._getListTemplateHeight(this._listCtrl);
                        this._listCtrl.fixedTemplateHeight = this._constants.listCtrlRowHeight;
                    }
                };
                Container.prototype._getDataImageCacheLoader = function (imageQuery) {
                    return new MobileCrm.UI.JSBridgeImageLoader(imageQuery);
                };
                Container.prototype._initResourceList = function (onFinishCallback) {
                    var _this = this;
                    this._listCtrl = new Resco.UI.AdvancedList(); //new GridList(this); //
                    this._listCtrl.useExternalScrollbar = this.isDesktop;
                    this._listCtrl.delayLoad = true;
                    this._listCtrl.delayLoadBuffer = 40;
                    this._listCtrl.isSearchBoxVisible = false;
                    this._listCtrl.autoSelect = false;
                    // as the gantt chart is not ready to change the height of its rows, we need to maintain the same height for every template that is defined in woodford (overriding its height)
                    // TODO: allow gantt chart to set its rows height dynamically
                    this._listCtrl.create();
                    this._listCtrl.onResize(new Resco.Size(0, 0, false));
                    this._dataProvider.createResourceController(this._listCtrl, function (controller) {
                        _this._createListView(controller);
                        onFinishCallback();
                    });
                };
                Container.prototype._initUnscheduledTasksList = function (onFinishCallback) {
                    var _this = this;
                    this._horizontalListCtrl = new Resco.UI.AdvancedList();
                    this._horizontalListCtrl.useExternalScrollbar = this.isDesktop;
                    this._horizontalListCtrl.delayLoad = true;
                    this._horizontalListCtrl.delayLoadBuffer = 20;
                    this._horizontalListCtrl.isSearchBoxVisible = false;
                    this._horizontalListCtrl.autoSelect = false;
                    this._horizontalListCtrl.orientation = Resco.UI.ListOrientation.Horizontal;
                    // as the gantt chart is not ready to change the height of its rows, we need to maintain the same height for every template that is defined in woodford (overriding its height)
                    // TODO: allow gantt chart to set its rows height dynamically
                    this._horizontalListCtrl.create();
                    this._horizontalListCtrl.onResize(new Resco.Size(0, 0, false));
                    this._dataProvider.createUnscheduledTasksController(this._horizontalListCtrl, function (controller) {
                        _this._createHorizontalListView(controller);
                        onFinishCallback();
                    });
                };
                Container.prototype._initTaskContent = function (onFinishCallback) {
                    var _this = this;
                    this._taskTemplateCtrl = new Scheduler.TaskTemplateControl();
                    if (this.useTaskTemplateContent) {
                        this._dataProvider.createTaskController(function (controller) {
                            _this.taskTemplateCtrl.initialize(controller);
                            onFinishCallback();
                        });
                    }
                    else {
                        onFinishCallback();
                    }
                };
                Container.prototype.onHorizontalListItemDragStart = function (point, item) {
                    var task = this.dataProvider.rowToUnscheduledTask(item);
                    task.setWorkStart(this.viewCtrl.zoom.getVisibleTimeRange().start);
                    task.drawBox(this.draggableContainer.element[0]);
                    if (task.ganttElement) {
                        var taskBounds = task.getTaskBoxDimensions();
                        var itemBounds = Scheduler.AdvancedListEx.getItemBounds(this._horizontalListCtrl, item);
                        var x = point.x - (taskBounds.width / 2);
                        var y = itemBounds.y; //point.y - (taskBounds.height / 2);
                        task.ganttElement.css({ left: x, top: y });
                        this.draggableContainer.setFocusToTask(task, true); // bind task to moveManager// if task.ganttElement is not created, do not set task to focusedTask property!
                        this._cachedHorizontalListSelectedIndex = this._horizontalListCtrl.selectedIndex; // cache selected item index
                        this.setSelectedItem(-1);
                        //this.draggableContainer.moveManager.onTargetElementWasRemoved(); //@JC it is not needed to call this method explicitly, because DragDropManager caches event target element automatically.
                        //if (task.group) { // Temporary disabled due to low performance of hiding items on horizontal list. Method that supports it needs to be added to HTML advanced list.
                        //	let scrollPosition = this._horizontalListCtrl.getScrollPosition();
                        //	this.dataProvider.hideUnscheduledTasksEntities([task.group.id], true, () => {
                        //		if ((scrollPosition !== undefined) && (scrollPosition !== null))
                        //			this._horizontalListCtrl.setScrollPosition(scrollPosition);
                        //	});
                        //}
                    }
                };
                Container.prototype.getTasksFromHorizontalListItems = function () {
                    var _this = this;
                    return Scheduler.AdvancedListEx.getTObjectFromLoadedRows(this._horizontalListCtrl, function (row) {
                        return _this.dataProvider.rowToUnscheduledTask(row);
                    });
                };
                Container.prototype._handleLoadingScreen = function (visible) {
                    var loadingScreen = $("#loadingScreen");
                    if (visible) {
                        if (loadingScreen && loadingScreen.length && loadingScreen.length > 0)
                            return;
                        var template = "<div id='loadingScreen'>\
						<div class='loadingScreenIndicator'><div class='loader'></div></div>\
					</div>";
                        document.body.insertAdjacentHTML("beforeend", template);
                    }
                    else {
                        loadingScreen.remove(); //loadingScreen.fadeOut(200, function () { $(this).remove(); }); // When fadeOut was used, loadingScreen stayed almost transparent for a while because of busy CPU, so user can thing that loading is already finished.
                    }
                };
                Container.prototype.onResourceDelayLoadCompleted = function (sender, e) {
                    var _this = this;
                    // Ensures that code below in the onResourceDelayLoadCompleted() method will not be called twice due to bug in the AdvancedList.
                    if ((e.startIndex > 0) && (e.startIndex >= e.endIndex)) {
                        return;
                    }
                    if (e.endIndex === 0) {
                        if (e.startIndex === 0) {
                            if (e.completed) {
                                this._dataLoadCompleted = true;
                                this.onDataLoadCompleted.raise(Resco.EventArgs.Empty);
                            }
                        }
                    }
                    else if (e.endIndex > 0) {
                        var resources = this._dataProvider.rowToResource(this.listCtrl.rows, e);
                        if (resources && resources.length > 0) {
                            this.loadAssociatedTasks(resources, function (appendRows) {
                                if (e.completed) {
                                    _this._dataLoadCompleted = true;
                                    _this.onDataLoadCompleted.raise(Resco.EventArgs.Empty);
                                }
                                _this._listsDelayLoadManager.listDelayLoadEnded(appendRows);
                            });
                            return;
                        }
                    }
                    this._listsDelayLoadManager.listDelayLoadEnded();
                };
                Container.prototype.onHorizontalDelayLoadCompleted = function (sender, e) {
                    // Ensures that code below in the onHorizontalDelayLoadCompleted() method will not be called twice due to bug in the AdvancedList.
                    if ((e.startIndex > 0) && (e.startIndex >= e.endIndex)) {
                        return;
                    }
                    // !!!Event delayLoadCompleted is raised only once although reload() method (on controller) was called multiple times. This occurs if advanced list have not enough time to complete data load (delayLoadCompleted event was not raised yet) and reload() method is called again.
                    if (e.completed) {
                        this._sourceDataLoadCompleted = true;
                        this.onSourceDataLoadCompleted.raise(Resco.EventArgs.Empty);
                    }
                    this._listsDelayLoadManager.horizontalListDelayLoadEnded();
                    // function from this._asyncCallbackStack must be called and removed even if horizontal list is empty.
                    while (this._asyncCallbackStack.length > 0) {
                        this._asyncCallbackStack[0]();
                        this._asyncCallbackStack.splice(0, 1);
                    }
                };
                Container.prototype.loadAssociatedTasks = function (resources, onDataLoaded) {
                    var _this = this;
                    var unscheduledTasksLoaded = false;
                    var tasksLoaded = false;
                    var loadedUnscheduledTasks = [];
                    var loadedResources = [];
                    var onPartialDataLoaded = function () {
                        if (unscheduledTasksLoaded && tasksLoaded) {
                            unscheduledTasksLoaded = false;
                            tasksLoaded = false;
                            var appendRows = _this.addLoadedResources(loadedResources, true);
                            _this._loadingInProcess = false;
                            if (onDataLoaded)
                                onDataLoaded(appendRows > 0);
                        }
                    };
                    var timeRange;
                    this._loadingInProcess = true;
                    this._handleLoadingScreen(true);
                    if (this.viewCtrl)
                        timeRange = this.viewCtrl.zoom.getTimeRange();
                    else {
                        var start = this._settings.selectedDate.valueOf();
                        timeRange = new Scheduler.TimeRange(start, start + 7 * Scheduler.dayInMiliseconds);
                    }
                    /*
                    if (this._constants.unscheduledTasksEnabled && this._unscheduledTasksBar.isEmpty) {
                        this._dataProvider.loadUnscheduledTasks(resources, (outUnscheduledTasks: Task[]) => {
                            loadedUnscheduledTasks = outUnscheduledTasks;
                            unscheduledTasksLoaded = true;
                            onPartialDataLoaded();
                        }, Container.constants.unscheduledViewMaxTasksInRow);
                    }
                    else*/
                    unscheduledTasksLoaded = true;
                    if (!this._inputData || !resources || !(resources.length > 0)) {
                        tasksLoaded = true;
                        onPartialDataLoaded();
                    }
                    else {
                        for (var i = 0; i < resources.length; i++)
                            resources[i].clearTasks();
                        var timeOffs = undefined;
                        //this.addLoadedResources(resources, false);
                        if (this._inputData.timeOffSchedules && this._inputData.timeOffSchedules.entityName && this._inputData.timeOffSchedules.attrResourceRef)
                            timeOffs = this._inputData.timeOffSchedules;
                        this._dataProvider.loadTasks(this._inputData.scheduledTasks, timeOffs, resources, timeRange, this._settings, function () {
                            loadedResources = resources;
                            tasksLoaded = true;
                            onPartialDataLoaded();
                            //if (this._constants.debugMode)
                            //	console.log("Performance: load processing " + delayLoadStartTime.end() + "ms " + "(Drawing " + Math.round((100 * this._drawDurations) / delayLoadStartTime) + "%, Fetches " + Math.round((100 * data.m_loadingDuration) / delayLoadStartTime) + "%)");
                        });
                    }
                };
                Container.prototype.initializeSettings = function (onInitialized) {
                    var self = this;
                    if (this._constants.cultureInfo && this._defaultOffice.firstDayOfWeek < 0)
                        this._defaultOffice.firstDayOfWeek = this._constants.cultureInfo.dateTimeFormat.firstDayOfWeek;
                    var reader = MobileCRM.Configuration.requestObject(function (config) {
                        var appSettings = new AppSettings();
                        var settings = config.settings;
                        appSettings.debugMode = false;
                        appSettings.googleApiKey = settings.googleApiKey;
                        if (appSettings.googleApiKey)
                            self.onAppSettingsLoaded(appSettings, onInitialized);
                        else {
                            // in case config do not contain googleApiKey, application can provide Resco internal ApiKey
                            MobileCRM.bridge.command("getAppSettings", null, function (appSettings) {
                                self.onAppSettingsLoaded(appSettings, onInitialized);
                            }, function (error) {
                                Scheduler.StringTable.alert(error);
                                onInitialized(null);
                            }, self);
                        }
                    }, function (error) {
                        Scheduler.StringTable.alert(error);
                        onInitialized(null);
                    }, null);
                    //var reader = (<any>MobileCRM.bridge).exposeObjectAsync("MobileCrm.Data:MobileCrm.Configuration.Instance.OpenUIConfig", [path]);
                };
                Container.prototype.onAppSettingsLoaded = function (appSettings, onInitialized) {
                    if (appSettings) {
                        this._constants.googleApiKey = appSettings.googleApiKey;
                        this._constants.debugMode = appSettings.debugMode;
                    }
                    onInitialized(null);
                };
                /**
                 * a project contains tasks, resources, roles, and info about permissions
                 * @param project
                 */
                Container.prototype.addLoadedResources = function (resources, canWrite) {
                    if (resources && resources.length) {
                        var _self = this;
                        this._canWrite = canWrite;
                        this._resourceDict.add(resources);
                        this._resourceList = this._resourceDict.Values();
                        this._resourceList.sort(function (a, b) {
                            return a.rowIndex - b.rowIndex;
                        });
                        this.forEachTask(function (task, parent) {
                            task.resource = parent;
                        });
                        return resources[0].rowIndex;
                    }
                    else {
                        this._canWrite = false;
                        this._resourceList = [];
                        return 0;
                    }
                };
                Container.prototype.searchForTask = function (proc) {
                    for (var i = 0; i < this._resourceList.length; i++) {
                        var tasks = this._resourceList[i].getTasks();
                        if (tasks) {
                            for (var j = 0; j < tasks.length; j++)
                                if (proc(tasks[j]))
                                    return tasks[j];
                        }
                    }
                    return undefined; // this._unscheduledTasksBar.search(proc);
                };
                Container.prototype.resetData = function () {
                    Scheduler.LocationCache = new Scheduler.Dictionary();
                    this._canWrite = false;
                    this._resourceList = [];
                    //this._unscheduledTasksBar = new UnscheduledTasksBar(this);
                    this._resourceDict = new Scheduler.ResourceDictionary();
                    this._dataLoadCompleted = false;
                    this._sourceDataLoadCompleted = false;
                };
                Container.prototype.saveGantt = function (forTransaction) {
                    var saved = [];
                    for (var i = 0; i < this._resourceList.length; i++)
                        saved.push(this._resourceList[i].clone());
                    var ret = { tasks: saved };
                    if (this.draggableContainer.focusedTask) {
                        ret.selectedRow = this.draggableContainer.focusedTask.getRowIndex();
                    }
                    //ret.deletedTaskIds = this.deletedTaskIds;  //this must be consistent with transactions and undo
                    return ret;
                };
                Container.prototype.onResize = function () {
                    this.draggableContainer.onResize();
                };
                Container.prototype._loadImages = function () {
                    var imageFactory = Scheduler.ImageFactory.getInstance();
                    imageFactory.addImageToElementBackground("Activity.appointment.png", "", this.buttonsBar.calendarPreviewIconElement[0]);
                    imageFactory.addImageToElementBackground("Controls.arrow_left.png", "", this.buttonsBar.leftArrowElement[0]);
                    imageFactory.addImageToElementBackground("Controls.arrow_right.png", "", this.buttonsBar.rightArrowElement[0]);
                    imageFactory.addImageToElementBackground("Controls.arrow_down.png", "", this.buttonsBar.calendarPreviewArrowElement[0]);
                    //if (this.draggableContainer.splitterContainer.listContainer.isViewFilterEnabled)
                    //	imageFactory.addImageToElementBackground("Controls.arrow_down.png", "", $(".rescoComboBox .icon")[0]);
                    imageFactory.addImageToElementBackground("Controls.SearchBarIcon.png", "", $(".resourceFilterIcon")[0]);
                    imageFactory.addImageToElementBackground("Controls.arrow_down.png", "", $(".resourceFilterArrow")[0]);
                    imageFactory.addImage("Controls.arrow_up.png", "");
                    imageFactory.addImage("Controls.PlusMark.png", "");
                    if (Container.inputs.resources.imagePlaceholder)
                        imageFactory.addImage(Container.inputs.resources.imagePlaceholder, "");
                    Container.setElementBackgroundImage(this.buttonsBar.filterElement[0], "settings.png");
                };
                Container.prototype.setSelectedRow = function (index) {
                    if (Container.constants.enableRowSelection) {
                        if (this.viewCtrl instanceof Scheduler.View) {
                            this.viewCtrl.selectedRowIndex = index;
                        }
                        this._listCtrl.selectedIndex = index;
                    }
                    if (index >= 0 && this._horizontalListCtrl)
                        this._horizontalListCtrl.selectedIndex = -1;
                };
                Container.prototype.setSelectedItem = function (index) {
                    if (this.viewCtrl instanceof Scheduler.View) {
                        this.viewCtrl.selectedRowIndex = -1;
                    }
                    this._listCtrl.selectedIndex = -1;
                    if (this._horizontalListCtrl)
                        this._horizontalListCtrl.selectedIndex = index;
                };
                Container.prototype.revertSelectedItem = function () {
                    if (this._cachedHorizontalListSelectedIndex >= -1) {
                        this.setSelectedItem(this._cachedHorizontalListSelectedIndex);
                        this._cachedHorizontalListSelectedIndex = undefined;
                    }
                };
                Container.prototype.loadOfficeSettings = function (officeSettings, onFinishCallback) {
                    var office = new Scheduler.Office();
                    office.firstDayOfWeek = -1;
                    if (!officeSettings || !officeSettings.entityName) {
                        onFinishCallback(office);
                        return;
                    }
                    var entity = new MobileCRM.FetchXml.Entity(officeSettings.entityName);
                    var attrMap = [-1, -1, -1, -1, -1, -1];
                    var cnt = 0;
                    if (officeSettings.attrLocation) {
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(officeSettings.attrLocation));
                        attrMap[0] = cnt++;
                    }
                    if (officeSettings.attrBreakPerDay) {
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(officeSettings.attrBreakPerDay));
                        attrMap[1] = cnt++;
                    }
                    if (officeSettings.attrFirstDayOfWeek) {
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(officeSettings.attrFirstDayOfWeek));
                        attrMap[2] = cnt++;
                    }
                    if (officeSettings.attrStartOfDay) {
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(officeSettings.attrStartOfDay));
                        attrMap[3] = cnt++;
                    }
                    if (officeSettings.attrWorkingDayDuration) {
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(officeSettings.attrWorkingDayDuration));
                        attrMap[4] = cnt++;
                    }
                    if (officeSettings.attrWorkingWeekends) {
                        entity.attributes.push(new MobileCRM.FetchXml.Attribute(officeSettings.attrWorkingWeekends));
                        attrMap[5] = cnt++;
                    }
                    if (entity.attributes.length == 0) {
                        onFinishCallback(office);
                        return;
                    }
                    var fetch = new MobileCRM.FetchXml.Fetch(entity);
                    fetch.execute("Array", function (result) {
                        if (result.length > 0) {
                            var entity = result[0];
                            if (officeSettings.attrLocation) {
                                office.locationAddress = entity[attrMap[0]];
                                office.location = new Scheduler.Location(office.locationAddress);
                            }
                            var invalidOffice = [];
                            if (officeSettings.attrBreakPerDay) {
                                var breakPerDay = +entity[attrMap[1]];
                                office.breakPerDay = breakPerDay;
                                if (office.breakPerDay !== breakPerDay)
                                    invalidOffice.push("breakPerDay");
                            }
                            if (officeSettings.attrFirstDayOfWeek) {
                                var firstDayOfWeek = +entity[attrMap[2]];
                                office.firstDayOfWeek = firstDayOfWeek;
                                if (office.firstDayOfWeek !== firstDayOfWeek)
                                    invalidOffice.push("firstDayOfWeek");
                            }
                            if (officeSettings.attrStartOfDay) {
                                var startWorkingTime = +entity[attrMap[3]];
                                office.startWorkingTime = startWorkingTime;
                                if (office.startWorkingTime !== startWorkingTime)
                                    invalidOffice.push("startWorkingTime");
                            }
                            if (officeSettings.attrWorkingDayDuration) {
                                var workingDayDuration = +entity[attrMap[4]];
                                office.workingDayDuration = workingDayDuration;
                                if (office.workingDayDuration !== workingDayDuration)
                                    invalidOffice.push("workingDayDuration");
                            }
                            if (officeSettings.attrWorkingWeekends) {
                                var workingWeekends = entity[attrMap[5]];
                                office.workingWeekends = workingWeekends && (workingWeekends == 'True' || workingWeekends == 'true' || workingWeekends == '1') ? true : false;
                            }
                            office.location.isOffice = true;
                            if (invalidOffice.length > 0) {
                                var error = " (";
                                for (var i = 0; i < invalidOffice.length; i++) {
                                    if (i > 0) {
                                        error += ", ";
                                    }
                                    error += invalidOffice[i];
                                }
                                error += ")";
                                Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.NotValidOfficeSettings", [error]));
                            }
                        }
                        onFinishCallback(office);
                        return office;
                    }, function (err) {
                        Scheduler.StringTable.alert(Scheduler.StringTable.get("Err.CantFetchEntity") + " " + officeSettings.entityName + " " + err);
                        onFinishCallback(office);
                    }, this);
                };
                Container.prototype._onShowTask = function (sender, e) {
                    var task = this.findTask(e.objectID);
                    if (task) {
                        Scheduler.TaskTooltip.removeTooltip();
                        Resco.Controls.Scheduler.TaskPropertyDlg.show(this, task);
                    }
                };
                Container._validateEntity = function (entity, name, onInitialize) {
                    if (!entity) {
                        onInitialize(undefined, "Input structure '" + name + "' is empty.");
                        return;
                    }
                    if (!entity.entityName) {
                        onInitialize(undefined, "Input '" + name + "' hasn't entity name.");
                        return;
                    }
                    MobileCRM.MetaEntity.loadByName(entity.entityName, function (me) {
                        if (me) {
                            var canWrite = me.canWrite();
                            if (!canWrite || entity.canWrite === undefined)
                                entity.canWrite = canWrite;
                            entity.primaryKeyName = me.primaryKeyName;
                            entity.primaryFieldName = me.primaryFieldName;
                            //if (!entity.attrStatecode)
                            //	entity.attrStatecode = "statecode";
                            //if (entity.attrStatecode && !me.getProperty(entity.attrStatecode))
                            //	entity.attrStatecode = undefined;
                            if (!me.isEnabled)
                                onInitialize(undefined, "Entity '" + entity.entityName + "' is disabled.");
                            else
                                onInitialize(me, undefined);
                        }
                        else
                            onInitialize(undefined, "Entity '" + entity.entityName + "' was not found.");
                    }, function (err) {
                        onInitialize(undefined, err);
                    });
                };
                Container.validateInputData = function (inputs, onInitialize) {
                    if (!inputs) {
                        onInitialize("Input data does not exist.");
                        return;
                    }
                    if (!inputs.statusList || inputs.statusList.length == 0) {
                        onInitialize("Input data does not contain list of statuses.");
                        return;
                    }
                    if (!inputs.scheduledTasks) {
                        onInitialize("Input data does not contain required activity.");
                        return;
                    }
                    if (inputs.unscheduledTasks) {
                        if (inputs.unscheduledTasks.color === undefined)
                            inputs.unscheduledTasks.color = "#ffdc4c";
                    }
                    if (inputs.scheduledTasks.focusedColor === undefined)
                        inputs.scheduledTasks.focusedColor = "#4286ff";
                    if (inputs.scheduledTasks.deniedColor === undefined)
                        inputs.scheduledTasks.deniedColor = "#ff0000";
                    if (inputs.office === undefined)
                        inputs.office = new Scheduler.OfficeDataInput();
                    Container._validateEntity(inputs.resources, "Resources", function (me, err) {
                        if (err)
                            onInitialize(err);
                        else {
                            var taskInputs_1 = inputs.scheduledTasks;
                            Container._validateEntity(taskInputs_1, "Activity", function (me, err) {
                                if (err)
                                    onInitialize(err);
                                else {
                                    if (me) {
                                        if (!me.getProperty(taskInputs_1.attrScheduledStart) ||
                                            !me.getProperty(taskInputs_1.attrScheduledEnd) ||
                                            !me.getProperty(taskInputs_1.attrResourceRef)) {
                                            onInitialize("Input entity do not contain all required fields.");
                                            return;
                                        }
                                        if (taskInputs_1.attrWindowStart && !me.getProperty(taskInputs_1.attrWindowStart)) {
                                            taskInputs_1.attrWindowStart = undefined;
                                            taskInputs_1.attrWindowEnd = undefined;
                                        }
                                        if (taskInputs_1.attrWorkduration && !me.getProperty(taskInputs_1.attrWorkduration))
                                            taskInputs_1.attrWorkduration = undefined;
                                        if (taskInputs_1.attrTravelFrom && !me.getProperty(taskInputs_1.attrTravelFrom)) {
                                            taskInputs_1.attrTravelFrom = undefined;
                                            taskInputs_1.attrTravelTo = undefined;
                                            taskInputs_1.attrTravelMode = undefined;
                                        }
                                        else if (taskInputs_1.attrTravelMode && !me.getProperty(taskInputs_1.attrTravelMode))
                                            taskInputs_1.attrTravelMode = undefined;
                                    }
                                    var uTaskInputs_1 = inputs.unscheduledTasks;
                                    if (!uTaskInputs_1 || !uTaskInputs_1.entityName)
                                        onInitialize(undefined);
                                    else {
                                        Container._validateEntity(uTaskInputs_1, "Source", function (me, err) {
                                            if (!err) {
                                                if (uTaskInputs_1.attrEstimatedDuration && !me.getProperty(uTaskInputs_1.attrEstimatedDuration))
                                                    uTaskInputs_1.attrEstimatedDuration = undefined;
                                                if (uTaskInputs_1.attrLocationRef && !me.getProperty(uTaskInputs_1.attrLocationRef))
                                                    uTaskInputs_1.attrLocationRef = undefined;
                                                if (uTaskInputs_1.attrTerritoryRef && !me.getProperty(uTaskInputs_1.attrTerritoryRef))
                                                    uTaskInputs_1.attrTerritoryRef = undefined;
                                            }
                                            Container._validateEntity(inputs.office, "Office", function (me, err) {
                                                if (err)
                                                    inputs.office = undefined;
                                                else {
                                                    if (inputs.office.attrWorkingWeekends && !me.getProperty(inputs.office.attrWorkingWeekends))
                                                        inputs.office.attrWorkingWeekends = undefined;
                                                }
                                                onInitialize(undefined);
                                            });
                                        });
                                    }
                                }
                            });
                        }
                    });
                };
                Container.prototype.updateHorizontalListController = function (reloadNow, onFinishCallback) {
                    if (!this.sourceDefined) {
                        if (onFinishCallback)
                            onFinishCallback();
                        return;
                    }
                    if (onFinishCallback)
                        this._asyncCallbackStack.push(onFinishCallback);
                    if (reloadNow)
                        this._horizontalController.reload();
                };
                Container.prototype.loadCustomerAddresses = function (tasks, onFinish) {
                    var _this = this;
                    if (tasks && (tasks.length > 0)) {
                        this.setStatusInfo(Scheduler.StringTable.get("Scheduler.Msg.AddressesLoading") + "...");
                        var _tasks_1 = [];
                        _tasks_1.push.apply(_tasks_1, tasks);
                        this.dataProvider.loadLocations(_tasks_1, function (error) {
                            _this.setStatusInfo("");
                            onFinish(_tasks_1.length);
                        });
                    }
                    else {
                        onFinish(0);
                    }
                };
                Container.roundTimeToMoveStep = function (time) {
                    if (!time)
                        return time === 0 ? 0 : null;
                    var moveStep = Container.ref.settings.moveStepInMinutes * Scheduler.minuteInMiliseconds;
                    return Math.round(time / moveStep) * moveStep;
                };
                Container.roundTime = function (time) {
                    if (!time)
                        return time === 0 ? 0 : null;
                    var moveStep = Container.ref.settings.roundMinutes * Scheduler.minuteInMiliseconds;
                    return Math.round(time / moveStep) * moveStep;
                };
                Container.prototype.updateTodayText = function () {
                    if (this.buttonsBar && this.viewCtrl && this.viewCtrl.zoom) {
                        if (this.viewCtrl.zoom.inHoursMode()) {
                            this.buttonsBar.todayButtonElement.text(Scheduler.StringTable.get("Msg.TODAY") || "Today");
                        }
                        else if (this.viewCtrl.zoom.inDaysMode()) {
                            this.buttonsBar.todayButtonElement.text(Scheduler.StringTable.get("Msg.THISWEEK") || "THIS WEEK");
                        }
                        else {
                            // keep text as it is
                        }
                    }
                };
                return Container;
            }());
            Scheduler.Container = Container;
            var DraggableContainer = (function () {
                function DraggableContainer(container, horizontalListContainer, splitterContainer) {
                    this.horizontalListContainer = horizontalListContainer; // !!!Can be undefined (if unscheduledViewHeight is 0 or less)!!!
                    this.splitterContainer = splitterContainer;
                    this.element = this._createDraggableContainerElement();
                    this.moveManager = new Scheduler.TaskMoveManager(container, this.element);
                    this.bindEvents();
                }
                DraggableContainer.prototype._createDraggableContainerElement = function () {
                    var element = $("<div>").attr("id", "draggableContainer");
                    if (this.horizontalListContainer) {
                        element.append(this.horizontalListContainer.element);
                    }
                    if (this.splitterContainer) {
                        element.append(this.splitterContainer.element);
                    }
                    return element;
                };
                Object.defineProperty(DraggableContainer.prototype, "focusedTask", {
                    get: function () {
                        return this._focusedTask;
                    },
                    enumerable: true,
                    configurable: true
                });
                DraggableContainer.prototype.isFocusedTask = function (task) {
                    return this.focusedTask && this.focusedTask.id === task.id;
                };
                DraggableContainer.prototype.setFocusToTask = function (task, force) {
                    if (force || !this.isFocusedTask(task)) {
                        this.takeFocusFromFocusedTask();
                        this._focusedTask = task; //set current task
                        if (task.ganttElement) {
                            task.setFocus();
                            this.moveManager.bindToFocusedTask(); // @JC bind mousedown/touchstart event to task (enable task touch move)
                            //if (!task.isUnscheduled()) {
                            //	//this.m_hScroll.scrollToFitTask(parseFloat(taskBox.attr("x")), parseFloat(taskBox.attr("width")), this.container.constants.ganttAutoHScrollMinEdgeSpace);
                            //	this.vScroll.scrollToFitTask(parseFloat(taskBox.attr("y")), parseFloat(taskBox.attr("height")), this.container.constants.ganttAutoVScrollMinEdgeSpace);
                            //}
                        }
                    }
                };
                DraggableContainer.prototype.takeFocusFromFocusedTask = function () {
                    this.moveManager.unbindFromFocusedTask(); // unbind mousedown/touchstart event from focused Task (disable task touch move)
                    if (this.focusedTask) {
                        this.focusedTask.takeFocus();
                        this._focusedTask = undefined; //reset current task
                    }
                };
                DraggableContainer.prototype.bindEvents = function () {
                    var _this = this;
                    var eventNameStart = Controls.GestureManager.DOWN + ".focused";
                    this.element.off(eventNameStart).on(eventNameStart, null, function (e) {
                        _this.moveManager.resetStateFlags();
                    });
                    var eventNameEnd = Controls.GestureManager.UP + ".focused";
                    this.element.off(eventNameEnd).on(eventNameEnd, null, function (e) {
                        // if click event was performed on an editable task, do not un-select the task, because it was just selected now
                        var focusedTaskWasClicked = Scheduler.Task.isElementOfFocusedTask(e.target);
                        if (!focusedTaskWasClicked) {
                            if (!_this.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                if (!_this.moveManager.hasStateFlags(Scheduler.DragDropActions.WasProcessed)) {
                                    _this.takeFocusFromFocusedTask(); // task lost focus
                                }
                            }
                        }
                    });
                };
                DraggableContainer.prototype.onResize = function () {
                    if (this.horizontalListContainer) {
                        this.horizontalListContainer.onResize();
                    }
                    if (this.splitterContainer) {
                        this.splitterContainer.onResize();
                    }
                };
                return DraggableContainer;
            }());
            Scheduler.DraggableContainer = DraggableContainer;
            var HorizontalListContainer = (function () {
                function HorizontalListContainer(horizontalListCtrl) {
                    this.horizontalListCtrl = horizontalListCtrl;
                    this.element = this._createHorizontalListContainerElement();
                }
                HorizontalListContainer.prototype._createHorizontalListContainerElement = function () {
                    var element = $("<div>").attr("id", "horizontalListContainer");
                    element.css("background-color", Container.constants.componentsBackgroundColor);
                    element.height(Container.constants.unscheduledViewHeight);
                    if (this.horizontalListCtrl) {
                        element.append(this.horizontalListCtrl.htmlRoot);
                    }
                    return element;
                };
                HorizontalListContainer.prototype.onResize = function () {
                    if (this.horizontalListCtrl) {
                        this.horizontalListCtrl.onResize(new Resco.Size(this.element.width(), this.element.height(), false));
                    }
                };
                return HorizontalListContainer;
            }());
            Scheduler.HorizontalListContainer = HorizontalListContainer;
            var ListContainer = (function () {
                function ListContainer(container) {
                    this._searchBy = SearchBy.Resource;
                    this._lastFilterValue = "";
                    this._searchPopup = undefined;
                    this._constants = Container.constants;
                    this._container = container;
                    this.listCtrl = container.listCtrl;
                    this.element = this._createListContainerElement();
                }
                ListContainer.prototype._createListContainerElement = function () {
                    var element = $("<div id='listContainer'></div>");
                    element.css("background-color", Container.constants.componentsBackgroundColor);
                    element.append(this._createSearchElement());
                    if (this.listCtrl)
                        element.append(this.listCtrl.htmlRoot);
                    return element;
                };
                ListContainer.prototype._createSearchElement = function () {
                    var _this = this;
                    var self = this;
                    var lastFilterValue = "";
                    var viewFilter = document.createElement("div");
                    this._searchForResource = Scheduler.StringTable.get("Scheduler.Msg.SearchForResource") || "Search For Resource";
                    this._searchForSource = Scheduler.StringTable.get("Scheduler.Msg.SearchForSource") || "Search For Source";
                    viewFilter.classList.add("listViewFilter");
                    viewFilter.classList.add("tableHeader");
                    viewFilter.classList.add("flex");
                    viewFilter.style.height = this._constants.viewHeaderHeight + "px";
                    viewFilter.style.position = "relative";
                    var resourceFilter = document.createElement("div");
                    resourceFilter.classList.add("flex");
                    resourceFilter.classList.add("resourceFilter");
                    resourceFilter.style.backgroundColor = Container.constants.componentsBackgroundColor;
                    var resourceFilterInput = document.createElement("input");
                    resourceFilterInput.classList.add("resourceFilterInput");
                    resourceFilterInput.style.width = "10px"; //@DM: Android hack because there was ignored flex property without width. //@JC: Input element needs to have set width, to enable shrink it, to be less wide than its content.
                    resourceFilterInput.setAttribute("type", "text");
                    resourceFilterInput.setAttribute("placeholder", this._searchForResource);
                    resourceFilterInput.addEventListener("keyup", function (e) {
                        var code = e.which || e.keyCode;
                        var value = e.target.value;
                        if (code === 13 || value === "")
                            self.onSearch(value, _this._searchBy);
                    });
                    var resourceFilterIcon = document.createElement("div");
                    resourceFilterIcon.classList.add("resourceFilterIcon");
                    var resourceFilterArrow = document.createElement("div");
                    resourceFilterArrow.classList.add("resourceFilterArrow");
                    var resourceFilterPreview = document.createElement("div");
                    resourceFilterPreview.classList.add("resourceFilterPreview");
                    resourceFilterPreview.style.height = this._constants.viewHeaderHeight + "px";
                    resourceFilterPreview.addEventListener("click", function (e) {
                        self.onSearchClick(resourceFilterInput.value);
                    });
                    resourceFilterPreview.appendChild(resourceFilterIcon);
                    resourceFilterPreview.appendChild(resourceFilterArrow);
                    resourceFilter.appendChild(resourceFilterInput);
                    resourceFilter.appendChild(resourceFilterPreview);
                    viewFilter.appendChild(resourceFilter);
                    return $(viewFilter);
                };
                ListContainer.prototype.onSearchClick = function (value) {
                    var self = this;
                    if (!this._searchPopup) {
                        this._searchPopup = new Controls.PopupMenu();
                        this._searchPopup.width = 200;
                        this._searchPopup.menuColor = Container.constants.componentsBackgroundColor;
                        this._searchPopup.borderColor = "#aaaaaa";
                        this._searchPopup.useBorder = true;
                    }
                    this._searchPopup.items = [];
                    this._searchPopup.items.push(new Controls.PopupMenuItem(this._searchForResource, undefined, function (e) {
                        self.onSearch(value, SearchBy.Resource);
                    }));
                    this._searchPopup.items.push(new Controls.PopupMenuItem(this._searchForSource, undefined, function (e) {
                        self.onSearch(value, SearchBy.Source);
                    }));
                    var button = this.element.find(".resourceFilterPreview");
                    var offset = button.offset();
                    this._searchPopup.x = offset.left;
                    this._searchPopup.y = offset.top + button.outerHeight(true);
                    this._searchPopup.open();
                };
                ListContainer.prototype.onSearch = function (value, searchBy) {
                    if (this._lastFilterValue != value || this._searchBy != searchBy) {
                        this._lastFilterValue = value;
                        if (this._searchBy != searchBy) {
                            var resourceFilterInput = this.element.find(".resourceFilterInput");
                            this._searchBy = searchBy;
                            if (this._searchBy == SearchBy.Resource)
                                resourceFilterInput.attr("placeholder", this._searchForResource);
                            else
                                resourceFilterInput.attr("placeholder", this._searchForSource);
                        }
                        if (value == "") {
                            if (this.listCtrl)
                                this.listCtrl.setFilterText(value, true);
                            var horizontalListCtrl = this._container.horizontalListCtrl;
                            if (horizontalListCtrl)
                                horizontalListCtrl.setFilterText(value, true);
                        }
                        else {
                            if (this._searchBy == SearchBy.Resource) {
                                if (this.listCtrl)
                                    this.listCtrl.setFilterText(value, true);
                            }
                            else if (this._searchBy == SearchBy.Source) {
                                var horizontalListCtrl = this._container.horizontalListCtrl;
                                if (horizontalListCtrl)
                                    horizontalListCtrl.setFilterText(value, true);
                            }
                        }
                        this._container.setSelectedRow(-1);
                        this._container.setSelectedItem(-1);
                    }
                };
                ListContainer.prototype.onResize = function () {
                    if (this.listCtrl) {
                        this.listCtrl.onResize(new Resco.Size(this.element.width(), this.element.height() - this._constants.viewHeaderHeight, false));
                    }
                };
                return ListContainer;
            }());
            Scheduler.ListContainer = ListContainer;
            var ViewContainer = (function () {
                function ViewContainer(view) {
                    this._view = view;
                    this.element = this._createViewContainerElement();
                }
                ViewContainer.prototype._createViewContainerElement = function () {
                    var element = $("<div>").attr("id", "viewContainer");
                    element.css("background-color", Container.constants.componentsBackgroundColor);
                    if (this.view) {
                        element.append(this.view.element);
                    }
                    return element;
                };
                Object.defineProperty(ViewContainer.prototype, "view", {
                    get: function () {
                        return this._view;
                    },
                    set: function (value) {
                        this._view = value;
                        if (this.element) {
                            this.element.empty();
                            if (this.view) {
                                this.element.append(this.view.element);
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                ViewContainer.prototype.onResize = function () {
                    if (this.view) {
                        this.view.onResize();
                    }
                };
                return ViewContainer;
            }());
            Scheduler.ViewContainer = ViewContainer;
            var UnscheduledTasksBar = (function () {
                function UnscheduledTasksBar(container) {
                    this._tasks = [];
                    this._container = container;
                }
                Object.defineProperty(UnscheduledTasksBar.prototype, "tasks", {
                    get: function () {
                        return this._tasks;
                    },
                    enumerable: true,
                    configurable: true
                });
                UnscheduledTasksBar.prototype.forEach = function (proc) {
                    if (this._tasks) {
                        for (var j = 0; j < this._tasks.length; j++)
                            proc(this._tasks[j]);
                    }
                };
                Object.defineProperty(UnscheduledTasksBar.prototype, "isEmpty", {
                    get: function () {
                        return !this._tasks || this._tasks.length == 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(UnscheduledTasksBar.prototype, "count", {
                    get: function () {
                        return this._tasks ? this._tasks.length : 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                UnscheduledTasksBar.prototype.add = function (task, redraw) {
                    if (Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Unscheduled)) {
                        task.setStatus(Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Unscheduled]);
                        if (redraw && task instanceof Scheduler.Task)
                            task.appendTaskBoxFromDCOrTCToUTC();
                        if (task.resource)
                            task.resource.removeTask(task);
                        if (!this._tasks)
                            this._tasks = [];
                        this._tasks.push(task);
                    }
                };
                UnscheduledTasksBar.prototype.remove = function (unscheduledTask, redraw) {
                    if (this._tasks) {
                        for (var i = 0; i < this._tasks.length; i++) {
                            var task = this._tasks[i];
                            if (unscheduledTask.id === task.id) {
                                this._tasks.splice(i, 1);
                                if (redraw)
                                    this.fillTaskBuffer(redraw);
                                return;
                            }
                        }
                    }
                };
                UnscheduledTasksBar.prototype.append = function (tasks) {
                    if (!tasks || !tasks.length)
                        return 0;
                    if (!this._tasks)
                        this._tasks = tasks;
                    else {
                        var len = this._tasks.length, j, i;
                        for (i = 0; i < tasks.length; i++) {
                            var id = tasks[i].id;
                            for (j = 0; j < len; j++) {
                                if (this._tasks[j].id === id)
                                    break;
                            }
                            if (j === len)
                                this._tasks.push(tasks[i]);
                        }
                        if (len === this._tasks.length)
                            return 0;
                    }
                    return tasks.length;
                };
                UnscheduledTasksBar.prototype.search = function (proc) {
                    if (this._tasks) {
                        for (var i = 0; i < this._tasks.length; i++) {
                            if (proc(this._tasks[i]))
                                return this._tasks[i];
                        }
                    }
                    return null;
                };
                UnscheduledTasksBar.prototype.fillTaskBuffer = function (redraw) {
                    var _this = this;
                    var viewCtrl = this._container.viewCtrl;
                    var children = $("#undefinedTasks").children();
                    viewCtrl.xOffsetUT = 0;
                    children.each(function (i, el) {
                        var taskBox = $(el);
                        taskBox.css("left", viewCtrl.xOffsetUT + Container.constants.unscheduledViewTaskSpacing);
                        viewCtrl.xOffsetUT += Container.constants.unscheduledViewTaskWidth + Container.constants.unscheduledViewTaskSpacing;
                    });
                    //this.updateLabel();
                    if (children.length === 0) {
                        if (!this.isEmpty) {
                            if (redraw)
                                this._container.redraw();
                        }
                        else if (Container.constants.unscheduledTasksEnabled) {
                            this._container.dataProvider.loadUnscheduledTasks(this._container.resourceDictionary.Values(), function (tasks) {
                                if (_this.append(tasks) > 0) {
                                    if (redraw)
                                        _this._container.redraw();
                                }
                            }, Container.constants.unscheduledViewMaxTasksInRow);
                        }
                    }
                };
                return UnscheduledTasksBar;
            }());
            Scheduler.UnscheduledTasksBar = UnscheduledTasksBar;
            var ListsDelayLoadManager = (function () {
                function ListsDelayLoadManager(container, onEnded) {
                    this._isListDelayLoadEnded = true;
                    this._isHorizontalListDelayLoadEnded = true;
                    this._appendRows = true;
                    this._container = container;
                    this._onEnded = onEnded;
                }
                Object.defineProperty(ListsDelayLoadManager.prototype, "isListDelayLoadEnded", {
                    get: function () {
                        return this._isListDelayLoadEnded;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ListsDelayLoadManager.prototype, "isHorizontalListDelayLoadEnded", {
                    get: function () {
                        return this._isHorizontalListDelayLoadEnded;
                    },
                    enumerable: true,
                    configurable: true
                });
                ListsDelayLoadManager.prototype.delayLoadStart = function () {
                    this._isListDelayLoadEnded = false;
                    this._isHorizontalListDelayLoadEnded = this._container.sourceDefined ? false : true;
                    this._appendRows = true;
                };
                ListsDelayLoadManager.prototype.listDelayLoadEnded = function (appendRows) {
                    this._appendRows = this._appendRows && appendRows;
                    this._isListDelayLoadEnded = true;
                    this._onListsDelayLoadEnded();
                };
                ListsDelayLoadManager.prototype.horizontalListDelayLoadEnded = function () {
                    if (this._container.sourceDefined) {
                        this._appendRows = false;
                    }
                    this._isHorizontalListDelayLoadEnded = true;
                    this._onListsDelayLoadEnded();
                };
                ListsDelayLoadManager.prototype._onListsDelayLoadEnded = function () {
                    if (this._isListDelayLoadEnded && this._isHorizontalListDelayLoadEnded) {
                        this._onEnded(this._appendRows);
                        this._appendRows = true;
                    }
                };
                return ListsDelayLoadManager;
            }());
            var SearchBy;
            (function (SearchBy) {
                SearchBy[SearchBy["Resource"] = 0] = "Resource";
                SearchBy[SearchBy["Source"] = 1] = "Source";
            })(SearchBy || (SearchBy = {}));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
