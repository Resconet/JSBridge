﻿/// Hardcoded Javascript for Diagnostics tool.

function createInputEditor() {
    var h3 = document.createElement("h3");
    h3.innerText = "Please write or paste your script.";

    var editableDiv = document.createElement("div");
    editableDiv.contentEditable = true;
    editableDiv.style.border = "1px solid black";
    editableDiv.style.borderRadius = "5px";
    editableDiv.style.minWidth = "100px"
    editableDiv.style.minHeight = "200px"
    editableDiv.style.padding = "5px";
    editableDiv.id = "editableDiv";

    /// save command
    var saveBtn = document.createElement("button");
    saveBtn.innerText = "Create";
    saveBtn.addEventListener("click", onSaveBtn, true);

    var cancelBtn = document.createElement("button");
    cancelBtn.innerText = "Cancel";
    cancelBtn.addEventListener("click", function () {
        document.location.reload();
    }, true);

    var fileNameInput = document.createElement("input");
    fileNameInput.type = "text";
    fileNameInput.style.minWidth = "30px";
    fileNameInput.id = "fileNameInp";
    fileNameInput.placeholder = "Script Name";

    /// add elements to html body.
    appendElement(h3);
    appendElement(editableDiv);
    appendElement(fileNameInput, true);
    appendElement(saveBtn, true);
    appendElement(cancelBtn);
}

function appendElement(element, createDiv) {
    if (element) {
        if (createDiv) {
            var div = document.createElement("div");
            div.appendChild(element);
            document.body.appendChild(div);
        }
        else
            document.body.appendChild(element);
    }
}

try {
    createInputEditor();
} catch (ex) {
    MobileCRM.bridge.alert(ex);
}
function onSaveBtn(e) {
    var txtInput = document.getElementById("editableDiv");
    var file = document.getElementById("fileNameInp");
    if (!file.value.length > 0) {
        MobileCRM.bridge.alert("Please write name of file.");
    }
    else {
        if (txtInput) {
            var data = { script: txtInput.innerText, fileName: file.value };
            if (Diagnostics) {
                var conf = Diagnostics.configuration;
                var path = config.storageDirectory + "/WWW/Diagnostics/" + data.fileName;
                MobileCRM.Application.writeFile(path, data.script, false, function (res) {
                    document.location.reload(true);
                }, MobileCRM.bridge.alert, null);
            }
        }
    }
}