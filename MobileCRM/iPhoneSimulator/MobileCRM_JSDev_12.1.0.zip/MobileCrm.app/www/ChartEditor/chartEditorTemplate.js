﻿///<reference path="../TypeScriptDefinitions/knockout.d.ts" />

function writeTemplates() {
    var addTemplate = function (templateName, templateMarkup) {
        document.write("<script type='text/html' id='" + templateName + "'>" + templateMarkup + "<" + "/script>");
    };

    addTemplate("chartEditorMain",
    "<div class='chartEditor' data-bind='style: { height: editorSizeMonitor.height() + \"px\", backgroundColor: formBackgroundColor  }' >\
        <div class='header' data-bind='style: { backgroundColor: titleBackgroundColor, color: titleForegroundColor }' >\
            <div class='backButton backArrow' data-bind='click: backArrowClick, style: { backgroundImage: backArrowImg }'></div>\
            <div class='designerName'><span data-bind='text: isEntityListShow() ? localization()[\"SelectEntityLabel\"] : localization()[\"EditorMainLabel\"]'></span></div>\
            <!-- ko if: selectedChart() == null && !isEntityListShow() -->\
                <div class='addChartButton' data-bind='click: showEntityList, style: { backgroundImage: addButtonImg }'></div>\
            <!-- /ko -->\
            <!-- ko if: selectedChart() !== null  -->\
                <div class='addChartButton' data-bind='click: savePrivateChart, style: { backgroundImage: saveButtonImg }'></div>\
            <!-- /ko -->\
        </div>\
        <!-- ko if: isEntityListShow() -->\
            <!-- ko component: { name: \"selectionListComponent\", params: { items: $root.entities, sizeMonitor: $root.editorSizeMonitor, callback: updateSelectedEntity }} -->\<!-- /ko -->\
        <!-- /ko -->\
        <!-- ko ifnot: isEntityListShow() -->\
            <div id='content' class='content' data-bind='style: { height: editorSizeMonitor.contentHeight() + \"px\"}, event: { onresize: editorSizeMonitor.changeSize() }' >\
                <!-- ko if: charts().length === 0 -->\
                    <div class='emptyEditor'><span data-bind='text: localization()[\"NoData\"]'></span></div>\
                <!-- /ko -->\
                <!-- ko if: selectedChart() !== null -->\
                    <!-- ko template: { name: \"chartProperties\", data: selectedChart } --><!-- /ko -->\
                <!-- /ko -->\
                <!-- ko if: selectedChart() == null  && charts().length > 0 -->\
                    <!-- ko foreach: charts -->\
                        <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
                        <div class='chartItem' data-bind='style: { backgroundColor: $parent.formItemBackgroundColor }'>\
                            <div class='name' data-bind='text: $data.name, click: function(data, event){ $root.openSelectedChart(data, event) }, style: { color: $root.formItemLabelForegroundColor }'></div>\
                            <div class='removeButton' data-bind='click: function(data, event) { $root.removeChart(data, event)}, style: { backgroundImage: $root.removeButtonImg }'></div>\
                        </div>\
                    <!-- /ko-->\
                <!-- /ko -->\
            </div>\
        <!-- /ko -->\
    </div>\
	");

    addTemplate("chartProperties",
    "<div class='chartProperties'>\
        <div class='partSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
        <div class='chartPropertyPart row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor }' >\
            <div class='label'><span data-bind='text: $root.localization()[\"ChartNameLabel\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
            <div class='oneValueCell'><input class='text inputElement ' data-bind='value: name'></div>\
        </div>\
        <div class='partSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
        <div class='chartPropertyPart' data-bind='style: { backgroundColor: $root.formItemBackgroundColor }' >\
            <!-- ko component: { name: \"imageBar\", params: { items: kinds, sizeMonitor: $root.editorSizeMonitor, callback: updateKindsSelection  }} -->\<!-- /ko -->\
        </div>\
        <div class='legendPart'>\
            <div class='partLabelParent'>\
                <div class='partLabel'><span data-bind='style: { color: $root.formItemLabelForegroundColor }, text: isGauge() ? $root.localization()[\"GaugePropertiesValue\"] : $root.localization()[\"ChartSeries\"]'></span></div>\
                <!-- ko if: canAddSeries() -->\
                    <div class='addSeries' data-bind='click: addNewSeries, style: { backgroundImage: $root.addSeriesButtonImg }'></div>\
                <!-- /ko -->\
            </div>\
            <!-- ko foreach: series() -->\
                <div class='series'>\
                    <div class='properties'>\
                        <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                            <div class='label'><span data-bind='text:$root.localization()[\"ChartSeriesLabel\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                            <div class='oneValueCell'>\
                                <!-- ko component: { name: \"tree-view\", params:\
                                    {\
                                        dataSource: $parent.rootEntities,\
                                        displayMember: 'label',\
                                        childrenMember: 'childrenMember',\
                                        childrenFlagMember: 'target',\
                                        valueMember: 'id',\
                                        selectedItemsPath: [seriesField !== undefined ? seriesField.split(\".\") : ''],\
                                        dimension: { width: 200, height: 200  },\
                                        windowMonitor: $root.editorSizeMonitor, \
                                        selectionItemsChanged: updateSeriesField,\
                                        isEnabledInitSelection: true,\
                                    }} -->\
                                <!-- /ko -->\
                            </div>\
                        </div>\
                        <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
                        <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                            <div class='label'><span data-bind='text: $root.localization()[\"ChartSeriesAggregation\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                            <div class='oneValueCell'>\
                                <!-- ko component: { name: \"combo-box\", params:\
                                    {\
                                        width: 200, \
                                        height: 200,\
                                        windowMonitor: $root.editorSizeMonitor,\
                                        displayMember: \"label\",\
                                        valueMember: \"id\",\
                                        dataSource: isNumeric() ? allAggregators() : countAggregators(),\
                                        selectedItem: aggregation(),\
                                        selectionChanged: updateAggregation \
                                    }} -->\
                                <!-- /ko -->\
                            </div>\
                        </div>\
                        <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
                        <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                            <div class='label'><span data-bind='text: $root.localization()[\"ChartSeriesLimit\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                            <div class='oneValueCell'>\
                                <div>\
                                <!-- ko component: { name: \"combo-box\", params:\
                                    {\
                                        width: 200, \
                                        height: 200,\
                                        windowMonitor: $root.editorSizeMonitor,\
                                        dataSource: limits,\
                                        displayMember: \"label\",\
                                        valueMember: \"label\",\
                                        selectedItem: { label: ChartEditor.ChartLimit[limitValue()] },\
                                        selectionChanged: $parent.updateSeriesLimits \
                                    }} -->\
                                <!-- /ko -->\
                                </div>\
                            </div>\
                        </div>\
                        <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }, visible: limitCountEnabled'></div>\
                        <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor }, visible: limitCountEnabled' >\
                            <div class='label'><span data-bind='text: $root.localization()[\"ChartSeriesLimitValue\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                            <div class='oneValueCell'>\
                                <div><input class='inputElement' type='number' data-bind='value: $parent.limitCount'/></div>\
                            </div>\
                        </div>\
                        <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
                        <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                            <div class='label'><span data-bind='text: $root.localization()[\"ChartSeriesColor\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                            <div class='oneValueCell'>\
                                <!-- ko component: { name: \"colorPicker\", params: { color: seriesColor, width: 250, height: 200, sizeMonitor: $root.editorSizeMonitor }} -->\<!-- /ko -->\
                            </div>\
                        </div>\
                        <!-- ko if: $parent.series().length > 1 -->\
                            <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
                            <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                               <div class='label'></div>\
                               <div class='oneValueCell'>\
                                    <div class='removeSeriesButton' data-bind='click: function(data, event) { $parent.removeSeries(data, event)} , style: { color: $root.formItemLinkColor }'><span data-bind='text: $root.localization()[\"ChartSeriesDeleteCmd\"]'></span></div>\
                                </div>\
                            </div>\
                        <!--  /ko -->\
                    </div>\
                </div>\
            <!-- /ko -->\
        </div>\
        <!-- ko ifnot: isGauge() -->\
            <div class='legendPart'>\
                <div class='partLabelParent'>\
                    <div class='partLabel'><span data-bind='style: { color: $root.formItemLabelForegroundColor }, text:$root.localization()[\"ChartHorizontalAxis\"]'></span></div>\
                </div>\
                <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                    <div class='label'><span data-bind='text: $root.localization()[\"ChartHorizontalAxisLabel\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                    <div class='oneValueCell'>\
                        <!-- ko component: { name: \"tree-view\", params:\
                            {\
                                dataSource: rootEntities,\
                                displayMember: 'label',\
                                childrenMember: 'childrenMember',\
                                childrenFlagMember: 'target',\
                                valueMember: 'id',\
                                selectedItemsPath: [axisField.logicalName !== undefined ? axisField.logicalName.split(\".\"): ''],\
                                dimension: { width: 200, height: 200  },\
                                windowMonitor: $root.editorSizeMonitor, \
                                selectionItemsChanged: updateAxisField,\
                                isEnabledInitSelection: true,\
                            }} -->\
                        <!-- /ko -->\
                    </div>\
                </div>\
                <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
                <!-- ko if: axisField.fieldType() == Resco.Controls.CrmType['DateTime']  -->\
                    <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                        <div class='label'><span data-bind='text: $root.localization()[\"ChartHorizontalAxisGroupBy\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                        <div class='oneValueCell'>\
                            <!-- ko component: { name: \"combo-box\", params:\
                                {\
                                    width: 200, \
                                    height: 200,\
                                    windowMonitor: $root.editorSizeMonitor,\
                                    displayMember: \"label\",\
                                    valueMember: \"id\",\
                                    dataSource: dateGroupItems,\
                                    selectedItem: dateGroupItem,\
                                    selectionChanged: updateDateGroupItems \
                                }} -->\
                            <!-- /ko -->\
                        </div>\
                    </div>\
                <!-- /ko -->\
            </div>\
            <div class='legendPart'>\
                <div class='partLabelParent'>\
                    <div class='partLabel'><span data-bind='style: { color: $root.formItemLabelForegroundColor }, text: $root.localization()[\"ChartDrillDown\"]'></span></div>\
                </div>\
                <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                    <div class='label'><span data-bind='text: $root.localization()[\"ChartDrillDownLabel\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                    <div class='oneValueCell'>\
                    <!-- ko component: { name: \"tree-view\", params:\
                            {\
                                dataSource: drillDownAvailableItems,\
                                displayMember: 'label',\
                                valueMember: 'id',\
                                selectedItemsPath: [drillDownFields],\
                                dimension: { width: 200, height: 200  },\
                                windowMonitor: $root.editorSizeMonitor, \
                                selectionItemsChanged: updateDrillDownField ,\
                                isEnabledInitSelection: false,\
                                isMultiselect: true, \
                            }} -->\
                        <!-- /ko -->\
                    </div>\
                </div>\
            </div>\
            <!-- ko if: visibleStyle() -->\
                <div class='legendPart'>\
                    <div class='partLabelParent'>\
                        <div class='partLabel'><span data-bind='style: { color: $root.formItemLabelForegroundColor }, text: $root.localization()[\"ChartSettings\"]'></span></div>\
                    </div>\
                    <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                        <div class='label'><span data-bind='text: $root.localization()[\"ChartSettingsChartStyle\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                        <div class='oneValueCell'>\
                            <!-- ko component: { name: \"combo-box\", params:\
                                {\
                                    width: 200, \
                                    height: 200,\
                                    windowMonitor: $root.editorSizeMonitor,\
                                    displayMember: \"label\",\
                                    valueMember: \"id\",\
                                    dataSource: chartStyle(),\
                                    selectedItem: chartStyleSelected(),\
                                    selectionChanged: updateChartStyle \
                                }} -->\
                            <!-- /ko -->\
                        </div>\
                    </div>\
                    <!-- ko if: chartDonutRatioEnabled() -->\
                        <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
                        <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                            <div class='label'><span data-bind='text: $root.localization()[\"ChartSettingsDonutRatio\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                            <div class='oneValueCell'>\
                                <div><input class='inputElement shortInput' type='number' max='100' min='1' data-bind='value: chartDonutRatio'/><span>%</span></div>\
                            </div>\
                        </div>\
                    <!-- /ko -->\
                </div>\
            <!-- /ko -->\
        <!-- /ko -->\
        <!-- ko if: isGauge() -->\
            <div class='legendPart'>\
                <div class='partLabelParent'>\
                    <div class='partLabel'><span data-bind='style: { color: $root.formItemLabelForegroundColor }, text: $root.localization()[\"GaugePropertiesTargetValue\"]'></span></div>\
                </div>\
                <!-- ko template: { name: \"gaugeProperties\", data: gaugeTargetValue } --><!-- /ko -->\
            </div>\
            <div class='legendPart'>\
                <div class='row'>\
                    <div class='partLabel'><span data-bind='style: { color: $root.formItemLabelForegroundColor }, text: $root.localization()[\"GaugePropertiesMinimalValue\"]'></span></div>\
                </div>\
                 <!-- ko template: { name: \"gaugeProperties\", data: gaugeMinimalValue } --><!-- /ko -->\
            </div>\
            <div class='legendPart'>\
                <div class='row'>\
                    <div class='partLabel'><span data-bind='style: { color: $root.formItemLabelForegroundColor }, text: $root.localization()[\"GaugePropertiesMaximalValue\"]'></span></div>\
                </div>\
                 <!-- ko template: { name: \"gaugeProperties\", data: gaugeMaximalValue } --><!-- /ko -->\
            </div>\
        <!-- /ko -->\
     </div>\
    ");

    addTemplate("gaugeProperties",
   "<div class='properties'>\
        <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
            <div class='label'><span data-bind='text: $root.localization()[\"GaugePropertiesLables\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
            <div class='oneValueCell'>\
               <!-- ko component: { name: \"combo-box\", params:\
                    {\
                        width: 200, \
                        height: 200,\
                        windowMonitor: $root.editorSizeMonitor,\
                        dataSource: type,\
                        selectedItem: selectedType(),\
                        selectionChanged: updateType \
                    }} -->\
               <!-- /ko -->\
            </div>\
        </div>\
        <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
        <!-- ko if: $data.isConstant -->\
            <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                <div class='label'><span data-bind='text: $root.localization()[\"GaugePropertiesValue\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                <div class='oneValueCell'>\
                    <input class='text inputElement' data-bind='value: constantValue'>\
                </div>\
            </div>\
        <!-- /ko -->\
        <!-- ko ifnot: $data.isConstant -->\
            <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                <div class='label'><span data-bind='text: $root.localization()[\"GaugePropertiesField\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                <div class='oneValueCell'>\
                    <!-- ko component: { name: \"tree-view\", params:\
                        {\
                            dataSource: $parent.rootEntities,\
                            displayMember: 'label',\
                            childrenMember: 'childrenMember',\
                            childrenFlagMember: 'target',\
                            valueMember: 'id',\
                            selectedItemsPath: [targetValue !== undefined ? targetValue.split(\".\"): ''],\
                            dimension: { width: 200, height: 200  },\
                            windowMonitor: $root.editorSizeMonitor, \
                            selectionItemsChanged: updateTargetValue,\
                            isEnabledInitSelection: true,\
                        }} -->\
                    <!-- /ko -->\
                </div>\
            </div>\
            <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
            <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                <div class='label'><span data-bind='text: $root.localization()[\"ChartSeriesAggregation\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                <div class='oneValueCell'>\
                    <!-- ko component: { name: \"combo-box\", params:\
                        {\
                            width: 200, \
                            height: 200,\
                            windowMonitor: $root.editorSizeMonitor,\
                            displayMember: \"label\",\
                            valueMember: \"id\",\
                            dataSource: isNumeric() ? allAggregators() : countAggregators(),\
                            selectedItem: aggregation(),\
                            selectionChanged: updateAggregation \
                        }} -->\
                    <!-- /ko -->\
                </div>\
            </div>\
        <!-- /ko -->\
        <!-- ko if: $data.hasColor -->\
            <div class='rowSeparator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
            <div class='row' data-bind='style: { backgroundColor: $root.formItemBackgroundColor } ' >\
                <div class='label'><span data-bind='text: $root.localization()[\"ChartSeriesColor\"], style: { color: $root.formItemLabelForegroundColor }'></span></div>\
                <div class='oneValueCell'>\
                    <!-- ko component: { name: \"colorPicker\", params: { color: $data.targetColor, width: 250, height: 200, sizeMonitor: $root.editorSizeMonitor }} -->\<!-- /ko -->\
                </div>\
            </div>\
        <!-- /ko -->\
    </div>");
}




/**Main function that loads templates*/
(function () {
    writeTemplates();

    var templateEngine = ko.nativeTemplateEngine.instance;

    registerComboBox();
    registerTreeView();
    registerSelectionListComponent();
    registerColorPickerComponent();
    registerImageBar();

    ko.bindingHandlers.row = {
        update: function (element, valueAccessor) {
            ko.renderTemplate("chartEditorMain", valueAccessor(), { templateEngine: ko.nativeTemplateEngine.instance }, element, "replaceNode");
        }
    };
}());