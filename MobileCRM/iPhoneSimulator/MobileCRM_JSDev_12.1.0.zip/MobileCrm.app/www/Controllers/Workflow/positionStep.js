/// <reference path="functionStep.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var PositionStep = (function (_super) {
                __extends(PositionStep, _super);
                function PositionStep() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                PositionStep.prototype._getName = function () {
                    return "PositionStep";
                };
                return PositionStep;
            }(Workflow.FunctionStep));
            Workflow.PositionStep = PositionStep;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
