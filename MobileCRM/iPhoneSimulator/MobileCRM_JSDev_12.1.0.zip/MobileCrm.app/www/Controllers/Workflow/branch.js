/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="step.ts" />
/// <reference path="executionContext.ts" />
/// <reference path="conditionGroup.ts" />
/// <reference path="stepCollection.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var JumpStep = (function (_super) {
                __extends(JumpStep, _super);
                function JumpStep() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                JumpStep.prototype._getName = function () {
                    return "JumpStep";
                };
                JumpStep.deserializeXML = function ($step) {
                    var s = new JumpStep();
                    s._deserializeXML($step);
                    return s;
                };
                JumpStep.prototype.execute = function (context) {
                    context.instructionPointer += this.offset;
                    return null;
                };
                JumpStep.prototype.fixupOffset = function (ip) {
                    this.offset = ip - this.offset - 1;
                };
                return JumpStep;
            }(Workflow.Step));
            Workflow.JumpStep = JumpStep;
            var Branch = (function (_super) {
                __extends(Branch, _super);
                function Branch() {
                    var _this = _super.call(this) || this;
                    _this.conditions = new Workflow.ConditionGroup();
                    _this.action = new Workflow.StepCollection();
                    return _this;
                }
                Branch.prototype._getName = function () {
                    return "Branch";
                };
                Branch.prototype.decode = function (steps) {
                    this.offset = steps.length;
                    steps.push(this);
                    this.action.decode(steps);
                    this.jumpEnd = new JumpStep();
                    this.jumpEnd.offset = steps.length;
                    steps.push(this.jumpEnd);
                    this.fixupOffset(steps.length);
                };
                Branch.deserializeXML = function ($step) {
                    var s = new Branch();
                    s._deserializeXML($step);
                    return s;
                };
                Branch.prototype._deserializeXML = function ($step) {
                    this.conditions._deserializeXML($step.children("conditions"));
                    this.action._deserializeXML($step.children("action"));
                    _super.prototype._deserializeXML.call(this, $step);
                };
                Branch.prototype.execute = function (context) {
                    var r = this.conditions.execute(context);
                    if (!r) {
                        _super.prototype.execute.call(this, context);
                    }
                    return null;
                };
                return Branch;
            }(JumpStep));
            Workflow.Branch = Branch;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
