/// <reference path="../Controls/advancedList-1.0.3.ts" />
/// <reference path="../Helpers/command.ts" />
/// <reference path="../Data/dataImageCache.ts" />
/// <reference path="../Data/imageProvider.ts" />
/// <reference path="listTemplateManager.ts" />
/// <reference path="controllerFactory.ts" />
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var ListController = (function () {
            function ListController() {
                this.hasButtons = false;
            }
            Object.defineProperty(ListController.prototype, "isLoaded", {
                get: function () {
                    return this.m_listView && this.m_listView.dataSource != null;
                },
                set: function (value) {
                    this._setLoaded(value);
                },
                enumerable: true,
                configurable: true
            });
            // this is how we can override setter isLoaded() in BaseEntityList
            ListController.prototype._setLoaded = function (value) {
                if (value) {
                    this.reload();
                }
                else if (this.m_listView) {
                    this.m_listView.dataSource = null;
                }
            };
            Object.defineProperty(ListController.prototype, "isVisible", {
                get: function () {
                    return this.m_listView.isVisible();
                },
                set: function (value) {
                    this.m_listView.isVisible(value);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListController.prototype, "listView", {
                get: function () {
                    return this.m_listView;
                },
                set: function (value) {
                    this._setListView(true, value);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListController.prototype, "handleRowClick", {
                get: function () {
                    return !this.hasButtons;
                },
                enumerable: true,
                configurable: true
            });
            ListController.prototype.setupView = function (lv, bRegisterEvents, buttons) {
                if (bRegisterEvents === null || bRegisterEvents === undefined) {
                    bRegisterEvents = true;
                }
                this._setListView(bRegisterEvents, lv);
                if (lv != null) {
                    if (!this.rowTemplates) {
                        this._loadTemplates();
                    }
                    this.setupTemplates(lv, buttons);
                }
            };
            ListController.prototype._setListView = function (bRegisterEvents, lv) {
                if (this.m_listView) {
                    this.m_listView.rowClick.remove(this, this._onRowClick);
                    this.m_listView.buttonClick.remove(this, this._onButtonClick);
                    this.m_listView.filterChanged.remove(this, this._onFilterChanged);
                    if (this.m_listView.getEmptyListText == this._getEmptyListText) {
                        this.m_listView.getEmptyListText = null;
                        this.m_listView.getEmptyListTextOwner = null;
                    }
                }
                this.m_listView = lv;
                if (this.m_listView) {
                    this.m_listView.emptyFilterText("Search..."); // TODO Localize: MobileCrm.Localization.instance.format("FmtSearch", this.caption));
                    this.m_listView.getEmptyListText = this._getEmptyListText;
                    this.m_listView.getEmptyListTextOwner = this;
                    if (bRegisterEvents) {
                        this.m_listView.rowClick.add(this, this._onRowClick);
                        this.m_listView.buttonClick.add(this, this._onButtonClick);
                        this.m_listView.cellClick.add(this, this._onCellClick);
                        this.m_listView.filterChanged.add(this, this._onFilterChanged);
                    }
                }
            };
            ListController.prototype._loadTemplates = function () {
            };
            ListController.prototype.setupTemplates = function (lv, buttons) {
                if (!this.hasButtons && (buttons == null || buttons.length == 0 || (buttons.every(function (b) { return ListController.IgnoredButtons.indexOf(b) >= 0; })))) {
                    buttons = null;
                }
                if (this.rowTemplates) {
                    var skip = false;
                    this.rowTemplates.forEach(function (row, index) {
                        MobileCrm.UI.ListTemplateManager.setTemplate(lv, MobileCrm.ControllerFactory.instance.listStyles, row, buttons, skip);
                        skip = true;
                    }, this);
                }
            };
            ListController.prototype._onRowClick = function (sender, args) {
            };
            ListController.prototype._onButtonClick = function (sender, args) {
            };
            ListController.prototype._onCellClick = function (sender, args) {
            };
            ListController.prototype._onFilterChanged = function (sender, args) {
                this.reload();
            };
            ListController.prototype.reload = function () {
                this.m_listView.dataSource = this._loadDataSource();
            };
            ListController.prototype._loadDataSource = function () {
                return new Resco.UI.AdvancedListEnumerator([]);
            };
            ListController.prototype.clear = function () {
                this.listView.dataSource = null;
            };
            ListController.prototype._getEmptyListText = function (sender) {
                var view = sender;
                if (view.filterText.length == 0) {
                    return "No items";
                }
                return "No items match your search";
            };
            ListController.prototype.clearFilterText = function (reload) {
                if (this.listView.filterText) {
                    this.listView.setFilterText("", false);
                    if (reload) {
                        this.reload();
                    }
                }
            };
            ListController.prototype.sayText = function (localize, text) {
                //if (localize) {
                //    text = MobileCrm.Localization.instance.get(text);
                //}
                //this.listView.form.sayText(text);
                alert(text);
            };
            ListController.prototype.sayError = function (ex) {
                //this.listView.form.sayError(ex);
                alert(ex.message);
            };
            ListController.loadCellImage = function (row, imageData, isImageQuery, cellElement, placeHolder) {
                if (isImageQuery) {
                    var loaderResult = MobileCrm.Data.DataImageCache.loadImage(row.data, imageData, 100, 100, null, cellElement);
                    if (!loaderResult.isLocal) {
                        return loaderResult.data;
                    }
                    imageData = loaderResult.data;
                }
                // TODO: Platform
                var unselCol = "black"; //Platform.instance.appStyle.listForeground ? Platform.instance.appStyle.listForeground : Platform.instance.appStyle.appColorStart;
                //if (!unselCol) {
                //    unselCol = "black";
                //}
                var selCol = "#0066CC"; //Platform.instance.appStyle.listSelForeground ? Platform.instance.appStyle.listSelForeground : "white";
                // replace '.' with '\\' (except the last dot that separates the extension
                if (imageData) {
                    //imageData = imageData.makePathFromDottedNotation();
                }
                else {
                    imageData = placeHolder;
                }
                if (imageData !== null && imageData !== undefined) {
                    return MobileCrm.ImageProvider.instance.getImage(imageData, (row.selected() ? selCol : unselCol), null, cellElement, true, placeHolder);
                }
                return "";
            };
            return ListController;
        }());
        ListController.IgnoredButtons = ["Call", "Email", "More", "Regarding", "Select"];
        UI.ListController = ListController;
        var ViewMode;
        (function (ViewMode) {
            ViewMode[ViewMode["Default"] = 0] = "Default";
            ViewMode[ViewMode["Relationship"] = 1] = "Relationship";
            ViewMode[ViewMode["Lookup"] = 2] = "Lookup";
            ViewMode[ViewMode["Dashboard"] = 3] = "Dashboard";
            ViewMode[ViewMode["Map"] = 4] = "Map";
        })(ViewMode = UI.ViewMode || (UI.ViewMode = {}));
        var ViewOptions;
        (function (ViewOptions) {
            ViewOptions[ViewOptions["None"] = 0] = "None";
            ViewOptions[ViewOptions["IsHidden"] = 4096] = "IsHidden";
            ViewOptions[ViewOptions["OnlineOnly"] = 8192] = "OnlineOnly";
            ViewOptions[ViewOptions["OfflineOnly"] = 16384] = "OfflineOnly";
            ViewOptions[ViewOptions["UseSyncFilter"] = 32768] = "UseSyncFilter";
            ViewOptions[ViewOptions["HasGPS"] = 65536] = "HasGPS";
        })(ViewOptions = UI.ViewOptions || (UI.ViewOptions = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
