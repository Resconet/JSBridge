/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
var AuditAnalyzer;
(function (AuditAnalyzer) {
    var Configuration = (function () {
        function Configuration(data) {
            this.active = data.active;
            this.dateOperator = data.dateOperator;
            this.since = SetupPage.dateToInputString(data.since);
            this.to = SetupPage.dateToInputString(data.to);
            this.precision = data.precision;
            this.nVisitsLimit = data.nVisitsLimit;
        }
        return Configuration;
    }());
    var ConfigFile = "AuditAnalyzer.json";
    var SetupPage = (function () {
        function SetupPage(config) {
            this.config = new Configuration(config);
            $("#precisionInput").val(this.config.precision);
            $("#dateOperatorSelect").val(this.config.dateOperator);
            $("#daySince").val(this.config.since);
            $("#dayTo").val(this.config.to);
            $("#nVisitsLimitInput").val(this.config.nVisitsLimit);
            var hideFreqVisitedVal = (new Number(this.config.nVisitsLimit) > 0);
            document.getElementById("hideFreqVisited")["checked"] = hideFreqVisitedVal;
            if (!hideFreqVisitedVal)
                this.hideFreqVisited(false, false);
            this.setOperator(this.config.dateOperator, false);
        }
        SetupPage.Init = function (config) {
            SetupPage.instance = new SetupPage(config);
            window["setupPage"] = SetupPage.instance;
        };
        SetupPage.prototype.onOperatorChanged = function (newVal) {
            this.setOperator(newVal, true);
        };
        SetupPage.prototype.setOperator = function (newVal, animate) {
            if (newVal == "custom") {
                $("#dateInterval").show(animate ? 200 : 0);
            }
            else {
                $("#dateInterval").hide(animate ? 200 : 0);
            }
        };
        SetupPage.prototype.hideFreqVisited = function (hide, animate) {
            if (hide) {
                $("#maxVisibleVisits").show(animate ? 200 : 0);
            }
            else {
                $("#maxVisibleVisits").hide(animate ? 200 : 0);
            }
        };
        SetupPage.prototype.serialize = function () {
            var c = this.config;
            c.precision = SetupPage.validatePositiveNumber($("#precisionInput").val());
            c.dateOperator = $("#dateOperatorSelect").val();
            var since = $("#daySince").val();
            if (since)
                c.since = since;
            var to = $("#dayTo").val();
            if (to)
                c.to = to;
            if (!document.getElementById("hideFreqVisited")["checked"])
                c.nVisitsLimit = "0";
            else
                c.nVisitsLimit = SetupPage.validatePositiveNumber($("#nVisitsLimitInput").val());
            return c;
        };
        SetupPage.prototype.onDeactivate = function () {
            this.config.active = false;
            this.apply();
        };
        SetupPage.prototype.onApply = function () {
            this.config.active = true;
            this.apply();
        };
        SetupPage.prototype.apply = function () {
            MobileCRM.bridge.command("applyChanges", JSON.stringify(this.serialize()));
        };
        SetupPage.dateToInputString = function (date) {
            /// <param name="date" type="Date"/>
            var m = date.getMonth() + 1;
            var d = date.getDate();
            return date.getFullYear().toString() + '-' + (m < 10 ? '0' : '') + m + '-' + (d < 10 ? '0' : '') + d;
        };
        SetupPage.validatePositiveNumber = function (s) {
            var n = new Number(s);
            return n <= 0 ? "0" : n.toString();
        };
        return SetupPage;
    }());
    AuditAnalyzer.SetupPage = SetupPage;
})(AuditAnalyzer || (AuditAnalyzer = {}));
