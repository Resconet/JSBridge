/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="advancedList-1.0.3.ts" />
/// <reference path="event.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var UI;
    (function (UI) {
        function isIListBindingItem(obj) {
            // unable to check if object is instance of interface in typescript
            // hack. check if obj has function getTextValue ( -> assume it is IListBindingItem)
            if ((typeof obj.getTextValue === "function") && (typeof obj.getImageValue === "function")) {
                return true;
            }
            return false;
        }
        UI.isIListBindingItem = isIListBindingItem;
        var CellClickEventArgs = (function (_super) {
            __extends(CellClickEventArgs, _super);
            function CellClickEventArgs(row, cellIndex, rowIndex, binding) {
                var _this = _super.call(this) || this;
                _this.row = row;
                _this.cellIndex = cellIndex;
                _this.rowIndex = rowIndex;
                _this.binding = binding;
                _this.cancelRowSelect = false;
                return _this;
            }
            return CellClickEventArgs;
        }(Resco.EventArgs));
        UI.CellClickEventArgs = CellClickEventArgs;
        var ListOrientation;
        (function (ListOrientation) {
            ListOrientation[ListOrientation["Vertical"] = 0] = "Vertical";
            ListOrientation[ListOrientation["Horizontal"] = 1] = "Horizontal";
        })(ListOrientation = UI.ListOrientation || (UI.ListOrientation = {}));
        var ViewType;
        (function (ViewType) {
            ViewType[ViewType["FilterList"] = 0] = "FilterList";
            ViewType[ViewType["Detail"] = 1] = "Detail";
            ViewType[ViewType["GridView"] = 2] = "GridView";
            ViewType[ViewType["Map"] = 3] = "Map";
            ViewType[ViewType["Chart"] = 4] = "Chart";
            ViewType[ViewType["Flip"] = 5] = "Flip";
            ViewType[ViewType["Document"] = 6] = "Document";
            ViewType[ViewType["Calendar"] = 7] = "Calendar";
            ViewType[ViewType["Custom"] = 8] = "Custom";
            ViewType[ViewType["Email"] = 9] = "Email";
        })(ViewType = UI.ViewType || (UI.ViewType = {}));
        UI.ViewTemplateNames = ["tmplAdvancedList", "tmplDetailView", "tmplGridView", "tmplMapView", "tmplChartView", "tmplFlipView", "tmplDocumentView", "tmplCalendarView", "tmplCustomView", "tmplEmailView"];
        function isFilterView(obj) {
            return ((obj instanceof UI.AdvancedList)); // || (obj instanceof ChartView) || (obj instanceof MapView) || (obj instanceof Calendar));
        }
        UI.isFilterView = isFilterView;
        function asFilterView(obj) {
            return isFilterView(obj) ? obj : null;
        }
        UI.asFilterView = asFilterView;
        var FilterChangedEventArgs = (function (_super) {
            __extends(FilterChangedEventArgs, _super);
            function FilterChangedEventArgs(kind) {
                var _this = _super.call(this) || this;
                _this.kind = kind;
                return _this;
            }
            return FilterChangedEventArgs;
        }(Resco.EventArgs));
        FilterChangedEventArgs.All = new FilterChangedEventArgs(2 /* TextChanged */ | 4 /* GroupChanged */);
        UI.FilterChangedEventArgs = FilterChangedEventArgs;
        var InnerRowClickEventArgs = (function (_super) {
            __extends(InnerRowClickEventArgs, _super);
            function InnerRowClickEventArgs() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            return InnerRowClickEventArgs;
        }(Resco.EventArgs));
        UI.InnerRowClickEventArgs = InnerRowClickEventArgs;
        //export interface IChartView extends IView, IFilterView {
        //    chartType: ChartType;
        //    title: string;
        //    valueAxisTitle: string;
        //    labelAxisTitle: string;
        //    noDataText: string;
        //    dataSource: Array<any>;
        //    bindings: string[];
        //    seriesColors: string[];
        //    seriesTitles: string[];
        //    seriesClick: Resco.Event<ChartViewClickEvent>;
        //    currency: string;
        //    currencySymbol: string;
        //    valuePrecision: number;
        //    show: () => void;
        //    unload: () => void;
        //}
        //export class ChartViewClickEvent extends Resco.EventArgs {
        //	/// <summary>Gets the clicked series index.</summary>
        //	public seriesIndex: number;
        //	/// <summary>Gets the clicked data point.</summary>
        //	public dataPointIndex: number;
        //	constructor(seriesIndex: number, dataIndex: number) {
        //		super();
        //		this.seriesIndex = seriesIndex;
        //		this.dataPointIndex = dataIndex;
        //	}
        //   }
        var FlexiViewLayout = (function () {
            function FlexiViewLayout(view, layoutConfig) {
                this.view = view;
                this.isHeaderVisible = true;
                this.height = 2;
                if (layoutConfig) {
                    this.parse(layoutConfig);
                }
            }
            FlexiViewLayout.prototype.parse = function (config) {
                if (config) {
                    this.isHeaderVisible = config[1] == "1";
                    this.isVertical = config[2] == "1";
                    this.width = config[3] == "1" ? 1 : 0;
                    this.maxLines = parseInt(config[4]);
                    if (this.maxLines == 0) {
                        this.maxLines = 1;
                    }
                    var pp = config.split(";");
                    if (pp.length > 1) {
                        this.height = Resco.strictParseInt(pp[1]);
                    }
                }
            };
            return FlexiViewLayout;
        }());
        UI.FlexiViewLayout = FlexiViewLayout;
        var AppointmentProperty;
        (function (AppointmentProperty) {
            /// <summary>Start date (DateTime).</summary>
            AppointmentProperty[AppointmentProperty["StartDate"] = 0] = "StartDate";
            /// <summary>End date (DateTime).</summary>
            AppointmentProperty[AppointmentProperty["EndDate"] = 1] = "EndDate";
            /// <summary>Title, subject (string).</summary>
            AppointmentProperty[AppointmentProperty["Title"] = 2] = "Title";
            /// <summary>Undertitle (string).</summary>
            AppointmentProperty[AppointmentProperty["SubTitle"] = 3] = "SubTitle";
            /// <summary>Identifier of the appointment group (Guid).</summary>
            AppointmentProperty[AppointmentProperty["GroupId"] = 4] = "GroupId";
            /// <summary>Image identifier (string).</summary>
            AppointmentProperty[AppointmentProperty["Icon"] = 5] = "Icon";
            /// <summary>Calendar item color.</summary>
            AppointmentProperty[AppointmentProperty["Color"] = 6] = "Color";
            /// <sumary>
            AppointmentProperty[AppointmentProperty["Activitypecode"] = 7] = "Activitypecode";
            /// <sumary>
            AppointmentProperty[AppointmentProperty["ActualDurationMinutes"] = 8] = "ActualDurationMinutes";
            /// <sumary>
            AppointmentProperty[AppointmentProperty["IsReadOnly"] = 9] = "IsReadOnly";
        })(AppointmentProperty = UI.AppointmentProperty || (UI.AppointmentProperty = {}));
    })(UI = Resco.UI || (Resco.UI = {}));
})(Resco || (Resco = {}));
