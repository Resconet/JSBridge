/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="controls.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        /**
         * The ViewModel of the ColorPicker control.
         */
        var ColorPicker = (function () {
            /**
             * Constructor of the ColorPicker component. Makes initialization of all properties based on input parameters.
             * @param params Initialization parameters for colorPicker properties.
             */
            function ColorPicker(params) {
                var _this = this;
                this.defaultColors = ["#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF", "#FF9933"];
                this.width = 150;
                this.height = 150;
                this.colorElementWidth = 50;
                this.colorElementHeight = 50;
                this.topPosition = ko.observable();
                this.leftPosition = ko.observable();
                this.selectedColor = ko.observable();
                this.isOpened = ko.observable();
                if (params.color() !== undefined && params.color() !== "") {
                    this.selectedColor = params.color;
                    if (this.selectedColor().length === 9) {
                        var newColor = "#" + this.selectedColor().substr(3);
                        this.selectedColor(newColor);
                    }
                    var vselectedColor = this.defaultColors.filter(function (c) { return c === _this.selectedColor(); });
                    if (vselectedColor && vselectedColor.length === 0) {
                        this.defaultColors.pop();
                        this.defaultColors.push(this.selectedColor());
                    }
                }
                else {
                    if (params.color() === "")
                        this.selectedColor = params.color; //@DM empty color means that exist knockout value from caller object and we need this connection
                    this.selectedColor(this.defaultColors[0]);
                }
                if (params.width && params.height) {
                    this.width = params.width;
                    this.height = params.height;
                }
                this.sizeMonitor = params.sizeMonitor;
                this._calculateDimension(this.defaultColors.length);
            }
            /**
             * Handles click on closed colorPicker and opens it.
             * @param sender sender
             * @param e event which call method and from this event is target.
             */
            ColorPicker.prototype.openColorPicker = function (sender, e) {
                var target = e.currentTarget;
                this._setPosition(target);
                this.isOpened(true);
            };
            /**
             * Handles all clicks to colorPicker during open status.If it was clicked to color it sets new selected color.
             * @param x Number value for column where was clicked.
             * @param y Number value for row where was clicked.
             * @param sender sender
             * @param e event.
             */
            ColorPicker.prototype.closeColorPicker = function (x, y, sender, e) {
                if (x !== -1 && y !== -1) {
                    var selColor = this.getColor(x, y);
                    this.selectedColor(selColor);
                }
                this.isOpened(false);
                this.topPosition(0);
                this.leftPosition(0);
            };
            /**
             * Gets color which will be displayed on the position x,y in the colorPicker grid
             * @param x column where will by displayed color.
             * @param y row where will be displayed color.
             */
            ColorPicker.prototype.getColor = function (x, y) {
                var index = this._inverseToLinearIndex(x, y);
                return this.defaultColors[index];
            };
            ColorPicker.prototype._inverseToLinearIndex = function (x, y) {
                var a = 1;
                var b = this.columnsCount;
                return (a * x) + (b * y);
            };
            ColorPicker.prototype._setPosition = function (div) {
                this._updateDimensionProperties();
                var leftParentPosition = div.offsetLeft;
                var topParentPosition = div.offsetTop;
                if (topParentPosition + this.height > this.sizeMonitor.height()) {
                    topParentPosition = topParentPosition - this.height + div.clientHeight;
                }
                this.topPosition(topParentPosition);
                this.leftPosition(leftParentPosition);
            };
            ColorPicker.prototype._calculateDimension = function (dataCount) {
                this.columnsCount = Math.ceil(Math.sqrt(dataCount));
                this.rowsCount = Math.ceil(dataCount / this.columnsCount);
                this.rows = new Array();
                for (var i = 0; i < this.rowsCount; i++) {
                    this.rows.push(i);
                }
                this.columns = new Array();
                for (var j = 0; j < this.columnsCount; j++) {
                    this.columns.push(j);
                }
                this._updateDimensionProperties();
            };
            ColorPicker.prototype._updateDimensionProperties = function () {
                this.sizeMonitor.contentClientHeight(document.getElementById("content").scrollHeight);
                this.sizeMonitor.contentClientWidth(document.getElementById("content").clientWidth);
                if (this.width > (this.sizeMonitor.contentClientWidth() * 0.55)) {
                    this.width = (this.sizeMonitor.contentClientWidth() * 0.55);
                }
                this.colorElementHeight = Math.ceil(this.height / this.rowsCount);
                this.colorElementWidth = Math.ceil(this.width / this.columnsCount);
            };
            return ColorPicker;
        }());
        Controls.ColorPicker = ColorPicker;
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
