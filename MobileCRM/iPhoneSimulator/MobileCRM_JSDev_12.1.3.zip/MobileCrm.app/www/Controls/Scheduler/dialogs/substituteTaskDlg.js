///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../../Controls/Scheduler/container.ts" />
///<reference path="../../../Controls/appColors.ts" />
///<reference path="../../../Controls/listBox.ts" />
///<reference path="baseDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var SubstituteTaskDlg = (function (_super) {
                __extends(SubstituteTaskDlg, _super);
                function SubstituteTaskDlg(container, task, onSubstituteCallback) {
                    var _this = _super.call(this) || this;
                    _this._type = Scheduler.AutoPlanner.TypeOfSubstitution.DoNotChangeSchedule;
                    _this._isEmpty = true;
                    _this._task = task;
                    _this._resource = task.resource;
                    _this._container = container;
                    _this._onSubstituteCallback = onSubstituteCallback;
                    _this.onShowDialog();
                    return _this;
                }
                SubstituteTaskDlg.show = function (container, task, onSubstituteCallback) {
                    if (SubstituteTaskDlg._dialogInstance)
                        SubstituteTaskDlg._dialogInstance.destroy();
                    SubstituteTaskDlg._dialogInstance = new SubstituteTaskDlg(container, task, onSubstituteCallback);
                };
                SubstituteTaskDlg.prototype.onShowDialog = function () {
                    var _this = this;
                    if (this._container.dataLoadEnabed(true) === false)
                        return;
                    this.dialog = this._createSubstituteTaskDlgElement();
                    this._tabContentElement = this.dialog.find(".rescoTabContent");
                    this._tabContentElement.find(".resourceName").css({ "font-family": "font-family:'Times New Roman',Courier" });
                    this._type = Scheduler.AutoPlanner.TypeOfSubstitution.DoNotChangeSchedule;
                    if (this._task.getStart() < Date.now()) {
                        this._type = Scheduler.AutoPlanner.TypeOfSubstitution.AsSoonAsPossible;
                        this._tabContentElement.find(".substitutionMode > option[value=0]").remove();
                    }
                    this._tabContentElement.find(".substitutionMode").change(function (e) {
                        var item = e.target;
                        if (item.selectedIndex >= 0) {
                            _this._type = parseInt(item[item.selectedIndex].value);
                            _this._onTypeChanged();
                        }
                    }).val(this._type); // this._onTypeChanged() method needs to be called explicitly below, because "change" event is not fired yet, because element is not added to DOM tree yet!
                    this._onTypeChanged();
                    this.initializeTabDialog(this.dialog);
                    Scheduler.StringTable.localizeElements(this.dialog);
                    this.dialog.find("#substituteButton").click(function (e) {
                        _this.onSubstitute();
                    });
                    _super.prototype.create.call(this, this.dialog, 400, 500);
                };
                SubstituteTaskDlg.prototype.onSubstitute = function () {
                    if (this._onSubstituteCallback(this._selectedResource, this._selectedStartTime)) {
                        this.destroy();
                    }
                };
                SubstituteTaskDlg.prototype.destroy = function () {
                    SubstituteTaskDlg._dialogInstance = null;
                    _super.prototype.destroy.call(this);
                };
                SubstituteTaskDlg.prototype._onTypeChanged = function () {
                    var _this = this;
                    Scheduler.AutoPlanner.Core.findSubstituteResults(this._type, this._task, function (resourceStartPairs) {
                        _this._initListCtrl(resourceStartPairs);
                    });
                };
                SubstituteTaskDlg.prototype._initListCtrl = function (resourceStartPairs) {
                    var _this = this;
                    var resourceListElement = this._tabContentElement.find(".resourceName");
                    resourceListElement.find('option').remove();
                    if (resourceStartPairs) {
                        this._resources = resourceStartPairs.map(function (rsp) { return rsp.resource; });
                        this._startTimes = resourceStartPairs.map(function (rsp) { return rsp.startTime; });
                    }
                    else {
                        this._resources = undefined;
                        this._startTimes = undefined;
                    }
                    if (this._resources && this._resources.length > 0 && this._startTimes && this._startTimes.length > 0) {
                        var smallestTimeIdx = 0;
                        var smallestTime = this._startTimes[0];
                        var maxChars = this._resources[0].getName().length;
                        var startTime = this._task.getStart();
                        // find the best time for substitution
                        for (var i_1 = 1; i_1 < this._startTimes.length; i_1++) {
                            if (this._startTimes[i_1] < smallestTime) {
                                smallestTimeIdx = i_1;
                                smallestTime = this._startTimes[i_1];
                            }
                            var len = this._resources[i_1].getName().length;
                            if (maxChars < len)
                                maxChars = len;
                        }
                        this._isEmpty = false;
                        this._selectedResource = this._resources[smallestTimeIdx];
                        this._selectedStartTime = this._startTimes[smallestTimeIdx];
                        this._updateResourceImage();
                        for (var i = 0; i < this._resources.length; i++) {
                            var resource = this._resources[i];
                            var option = document.createElement('option');
                            var name = resource.getName();
                            var time = this._startTimes[i];
                            if ((time - startTime) > 0) {
                                var l1 = (maxChars - name.length) + 5;
                                var timeStr = new Date(time);
                                for (var j = 0; j < l1; j++)
                                    name += '\u00a0';
                                name += timeStr.toLocaleString();
                            }
                            option.text = name;
                            option.value = i.toString();
                            if (i === smallestTimeIdx)
                                option.selected = true;
                            resourceListElement.append(option);
                        }
                        resourceListElement.change(function (e) {
                            var item = e.target;
                            _this._selectedResource = undefined;
                            _this._selectedStartTime = 0;
                            if (!_this._isEmpty && item.selectedIndex >= 0) {
                                var idx = item[item.selectedIndex].value;
                                _this._selectedResource = _this._resources[idx];
                                _this._selectedStartTime = _this._startTimes[idx];
                                _this._updateResourceImage();
                            }
                        });
                    }
                    else {
                        var option = document.createElement('option');
                        option.text = Scheduler.StringTable.get("Scheduler.Msg.NoSuitableResource") || "No suitable resource has been found.";
                        option.value = "-1";
                        this._isEmpty = true;
                        this._selectedResource = undefined;
                        this._selectedStartTime = 0;
                        resourceListElement.append(option);
                        this._updateResourceImage();
                    }
                };
                SubstituteTaskDlg.prototype._updateResourceImage = function () {
                    var imageElement = this._tabContentElement.find(".resourceImage");
                    if (imageElement !== undefined && imageElement.length > 0) {
                        if (!this._selectedResource)
                            imageElement.attr("src", "");
                        else {
                            imageElement.attr("src", Scheduler.Resource.getDefaultImage());
                            this._selectedResource.getImage(function (image) {
                                if (image)
                                    imageElement.attr("src", image);
                            });
                        }
                    }
                };
                SubstituteTaskDlg.prototype._createSubstituteTaskDlgElement = function () {
                    var element = Scheduler.Utilities.createFromTemplate(SubstituteTaskDlg._template);
                    element.find("ul.rescoTabCtrl").css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    return element;
                };
                return SubstituteTaskDlg;
            }(Scheduler.BaseDlg));
            SubstituteTaskDlg._dialogInstance = null;
            SubstituteTaskDlg._template = '\
			<div class="rescoDialog">\
				<ul class="rescoTabCtrl">\
					<li><a id="tab_SUBSTITUTE" href="javascript:void(0)" class="rescoTabButton" draggable="false" data-localization="Scheduler.Msg.SUBSTITUTE">RESOURCE SUBSTITUTE</a></li>\
				</ul>\
				<div id="SUBSTITUTE" class="rescoTabContent">\
					<p class="title" data-localization="Scheduler.Msg.SUBSTITUTETitle">Select resource personnel for substitution.</p>\
					<p></p>\
					<image class="resourceImage" width="64" height="64" draggable="false" style="horizontal-align: center;"/>\
					<p></p>\
					<p data-localization="Scheduler.Msg.SubstitutionMode">Substitute to be completed by:</p>\
					<select class="substitutionMode" style="width:100%">\
						<option value="0" data-localization="Scheduler.Msg.DoNotChangeSchedule">Do not change planned schedule</option>\
						<option value="1" data-localization="Scheduler.Msg.AsSoonAsPossible">As soon as possible</option>\
						<option value="2" data-localization="Scheduler.Msg.TheSameDay">Find free slots in the same day</option>\
						<option value="3" data-localization="Scheduler.Msg.TheSameMonth">Find free slots in the same month</option>\
					</select>\
					<p data-localization="Scheduler.Msg.AvailableResource">Available resource:</p>\
					<select class="resourceName" style="width:100%"></select>\
					<p></p>\
				</div>\
				<div class="dialogControlContainer">\
				  <button class="closeButton" data-localization="Msg.Cancel">Cancel</button>&nbsp;\
				  <button id="substituteButton" data-localization="Msg.Substitute">Substitute</button>&nbsp;\
				</div>\
			</div>\
		';
            Scheduler.SubstituteTaskDlg = SubstituteTaskDlg;
            var ResourceStartPair = (function () {
                function ResourceStartPair(resource, startTime) {
                    this.resource = resource;
                    this.startTime = startTime;
                }
                return ResourceStartPair;
            }());
            Scheduler.ResourceStartPair = ResourceStartPair;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
