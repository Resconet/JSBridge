///<reference path="utilities.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var ButtonsBar = (function () {
                function ButtonsBar() {
                    this._showHideAllSources = true;
                    this._showHideAllScheduledTasks = true;
                    this.autoPlannerPopupMenu = undefined;
                    this._tmpPart1 = '\
			<div id="schedulerButtonsBar">\
				<div class="toolbarButton" onclick="Resco.Controls.Scheduler.SettingsDialog.show(_scheduler);">\
					<div id="settingsIcon" class="imageButton" style="background-image: url(\'settings.png\');"></div>\
					<div id="showSettingsDialog" class="textButton" data-localization="Scheduler.Msg.SETTINGS">SETTINGS</div>\
				</div>\
				<div class="toolbarButton" onclick="_scheduler.buttonsBar.onAutoPlannerClick();">\
					<div id="autoPlannerIcon" class="imageButton" style="background-image: url(\'settingsM.png\');"></div>\
					<div id="runReschedule" class="textButton" data-localization="Scheduler.Msg.RUNAUTOSCHEDULE">RUN AUTO-SCHEDULE</div>\
				</div>\
				<div class="toolbarButton mapButton hidden" onclick="_scheduler.buttonsBar.onShowHideAllSchedules()">\
					<div id="showHideScheduledIcon" class="imageButton" style="background-image: url(\'scheduledShownAll.png\');"></div>\
					<div id="showHideScheduledText" class="textButton" data-localization="Scheduler.Msg.HIDEALL">SHOW ALL</div>\
				</div>\
				<div class="toolbarButton mapButton hidden" onclick="_scheduler.buttonsBar.onShowHideAllSources()">\
					<div id="showHideSourcesIcon" class="imageButton" style="background-image: url(\'sourcesShownAll.png\');"></div>\
					<div id="showHideSourcesText" class="textButton" data-localization="Scheduler.Msg.HIDEALL">HIDE ALL</div>\
				</div>\
				<div class="labelBar">\
					<label id="filterStatus"></label>\
				</div>\
				<div class="zoomControl">\
					<div id="leftArrow" onclick="_scheduler.viewCtrl.doPageScroll(-1);"></div>\
					<div id="todayButton" class="textButton" onclick="_scheduler.viewCtrl.showDate(null);" data-localization="Msg.TODAY">TODAY</div>\
					<div id="rightArrow" onclick="_scheduler.viewCtrl.doPageScroll(+1);"></div>\
					<div id="calendarPreview" onclick="_scheduler.viewCtrl.openCalendarPreview();">\
						<div class="calendarPreviewIcon"></div>\
						<div class="calendarPreviewArrow"></div>\
					</div>\
					<select id="zoomLevel" onChange="_scheduler.viewCtrl.setZoomLevel();">\
						<option value="h" data-localization="Msg.Day">Day</option>\
						<option value="h2" data-localization="Msg.Days" data-localizationvalues="2">2 Days</option>\
						<option value="h3" data-localization="Msg.Days" data-localizationvalues="3">3 Days</option>\
						<option value="d" data-localization="Msg.Week">Week</option>\
						<option value="d2" data-localization="Msg.Weeks" data-localizationvalues="2">2 Weeks</option>\
						<option value="d4" data-localization="Msg.Weeks" data-localizationvalues="4">4 Weeks</option>\
						<option value="d6" data-localization="Msg.Weeks" data-localizationvalues="6">6 Weeks</option>\
						<option value="m" data-localization="Msg.MonthOverview">Month overview</option>\
		';
                    this._tmpPart2 = '\
					</select>\
				</div>\
			</div>\
		';
                    this._tmpMapView = '<option value="hmap" data-localization="Msg.MapView">Map view</option>';
                    this._template = this._tmpPart1 + (Scheduler.Container.constants.enableMapView ? this._tmpMapView : "") + this._tmpPart2;
                    this.showHideSourcesIconElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "sourcesShownAll.png" + ")" });
                    this.showHideScheduledIconElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "scheduledShownAll.png" + ")" });
                }
                Object.defineProperty(ButtonsBar.prototype, "element", {
                    get: function () {
                        if (!this._element)
                            this._element = this._createButtonsBarElement();
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "filterElement", {
                    get: function () {
                        return this.element.find("#settingsIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "autoPlannerElement", {
                    get: function () {
                        return this.element.find("#autoPlannerIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "filterStatusElement", {
                    get: function () {
                        return this.element.find("#filterStatus");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideScheduledIconElement", {
                    get: function () {
                        return this.element.find("#showHideScheduledIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideScheduledTextElement", {
                    get: function () {
                        return this.element.find("#showHideScheduledText");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideSourcesIconElement", {
                    get: function () {
                        return this.element.find("#showHideSourcesIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideSourcesTextElement", {
                    get: function () {
                        return this.element.find("#showHideSourcesText");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "leftArrowElement", {
                    get: function () {
                        return this.element.find("#leftArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "todayButtonElement", {
                    get: function () {
                        return this.element.find("#todayButton");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "rightArrowElement", {
                    get: function () {
                        return this.element.find("#rightArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewElement", {
                    get: function () {
                        return this.element.find("#calendarPreview");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewIconElement", {
                    get: function () {
                        return this.calendarPreviewElement.find(".calendarPreviewIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewArrowElement", {
                    get: function () {
                        return this.calendarPreviewElement.find(".calendarPreviewArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "zoomLevelElement", {
                    get: function () {
                        return this.element.find("#zoomLevel");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideAllSources", {
                    get: function () {
                        return this._showHideAllSources;
                    },
                    set: function (value) {
                        if (value !== this.showHideAllSources) {
                            this._showHideAllSources = value;
                            if (this.showHideAllSources) {
                                this.showHideSourcesIconElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "sourcesShownAll.png" + ")" });
                                this.showHideSourcesTextElement.text(Scheduler.StringTable.get("Scheduler.Msg.HIDEALL"));
                            }
                            else {
                                this.showHideSourcesIconElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "sourcesHiddenAll.png" + ")" });
                                this.showHideSourcesTextElement.text(Scheduler.StringTable.get("Scheduler.Msg.SHOWALL"));
                            }
                            var view = Scheduler.Container.ref.viewCtrl;
                            if (view && (view instanceof Scheduler.MapView)) {
                                view.showHideAllSources = this.showHideAllSources;
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideAllScheduledTasks", {
                    get: function () {
                        return this._showHideAllScheduledTasks;
                    },
                    set: function (value) {
                        if (value !== this.showHideAllScheduledTasks) {
                            this._showHideAllScheduledTasks = value;
                            if (this.showHideAllScheduledTasks) {
                                this.showHideScheduledIconElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "scheduledShownAll.png" + ")" });
                                this.showHideScheduledTextElement.text(Scheduler.StringTable.get("Scheduler.Msg.HIDEALL"));
                            }
                            else {
                                this.showHideScheduledIconElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "scheduledHiddenAll.png" + ")" });
                                this.showHideScheduledTextElement.text(Scheduler.StringTable.get("Scheduler.Msg.SHOWALL"));
                            }
                            var view = Scheduler.Container.ref.viewCtrl;
                            if (view && (view instanceof Scheduler.MapView)) {
                                view.showHideAllScheduledTasks = this.showHideAllScheduledTasks;
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                ButtonsBar.prototype.updateAutoPlannerIcon = function () {
                    var mode = Scheduler.Container.ref.settings.autoPlanner.manualScheduleMode;
                    var element = this.autoPlannerElement[0];
                    if (mode == Scheduler.eMode.Manual)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsM.png");
                    else if (mode == Scheduler.eMode.SemiOptimized)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsS.png");
                    else if (mode == Scheduler.eMode.RouteOptimization)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsT.png");
                    else
                        Scheduler.Container.setElementBackgroundImage(element, "settingsA.png");
                };
                ButtonsBar.prototype.onCustomFilterChanged = function (hasFilter) {
                    var icon = this.filterElement;
                    if (icon) {
                        var image = Scheduler.Container.imageFolder + (hasFilter ? "settingsFiltered.png" : "settings.png");
                        icon.css({ "background-image": "url(" + image + ")" });
                    }
                };
                ;
                ButtonsBar.prototype.onAutoPlannerStateChanged = function (started) {
                    var buttonCtrl = this.element.find("#runReschedule");
                    if (buttonCtrl) {
                        if (started)
                            buttonCtrl.text(Scheduler.StringTable.get("Scheduler.Msg.STOPAUTOSCHEDULE"));
                        else
                            buttonCtrl.text(Scheduler.StringTable.get("Scheduler.Msg.RUNAUTOSCHEDULE"));
                    }
                    if (started) {
                        var element = this.autoPlannerElement[0];
                        Scheduler.Container.setElementBackgroundImage(element, "stop.png");
                    }
                    else
                        this.updateAutoPlannerIcon();
                };
                ButtonsBar.prototype.onAutoPlannerClick = function () {
                    if (!this.autoPlannerPopupMenu) {
                        this.autoPlannerPopupMenu = new Controls.PopupMenu();
                        this.autoPlannerPopupMenu.width = 350;
                        this.autoPlannerPopupMenu.iconSize = 22;
                        this.autoPlannerPopupMenu.menuColor = Scheduler.Container.constants.componentsBackgroundColor;
                        this.autoPlannerPopupMenu.borderColor = "#aaaaaa";
                        this.autoPlannerPopupMenu.useBorder = true;
                    }
                    this.autoPlannerPopupMenu.items = [];
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.SemiOptimization") || "Optimize schedules per Resource", "url(" + Scheduler.Container.imageFolder + "settingsS.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.SemiOptimized);
                    }));
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.RouteOptimization") || "Optimization Route (per day)", "url(" + Scheduler.Container.imageFolder + "settingsT.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.RouteOptimization);
                    }));
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.FullOptimization") || "Do Full Optimization", "url(" + Scheduler.Container.imageFolder + "settingsA.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.Optimized);
                    }));
                    var offset = this.autoPlannerElement.offset();
                    this.autoPlannerPopupMenu.x = offset.left;
                    this.autoPlannerPopupMenu.y = this.element.outerHeight(true);
                    this.autoPlannerPopupMenu.open();
                };
                ButtonsBar.prototype.showHideMapViewButtons = function (show) {
                    var mapButtons = this.element.find(".mapButton");
                    if (show) {
                        mapButtons.removeClass("hidden");
                        var view = Scheduler.Container.ref.viewCtrl;
                        if (view && (view instanceof Scheduler.MapView)) {
                            this.showHideAllSources = view.showHideAllSources;
                            this.showHideAllScheduledTasks = view.showHideAllScheduledTasks;
                        }
                    }
                    else {
                        mapButtons.addClass("hidden");
                    }
                };
                ButtonsBar.prototype.onShowHideAllSources = function () {
                    this.showHideAllSources = !this.showHideAllSources;
                };
                ButtonsBar.prototype.onShowHideAllSchedules = function () {
                    this.showHideAllScheduledTasks = !this.showHideAllScheduledTasks;
                };
                ButtonsBar.prototype._createButtonsBarElement = function () {
                    var element = Scheduler.Utilities.createFromTemplate(this._template);
                    element.css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    Scheduler.StringTable.localizeElements(element);
                    return element;
                };
                return ButtonsBar;
            }());
            Scheduler.ButtonsBar = ButtonsBar;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
