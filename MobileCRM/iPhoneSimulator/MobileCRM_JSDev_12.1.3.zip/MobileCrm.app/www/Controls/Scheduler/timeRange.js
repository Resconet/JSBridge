var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var TimeRange = (function () {
                function TimeRange(start, end) {
                    this.start = start;
                    this.end = end;
                }
                TimeRange.prototype.clone = function () {
                    return new TimeRange(this.start, this.end);
                };
                TimeRange.cloneArray = function (arr) {
                    var dst = new Array(arr.length);
                    for (var i = 0; i < arr.length; i++) {
                        var src = arr[i];
                        dst[i] = new TimeRange(src.start, src.end);
                    }
                    return dst;
                };
                TimeRange.prototype.isValid = function () {
                    return this.end >= this.start;
                };
                TimeRange.dayOffsetInMinutes = function (time) {
                    var d = new Date(time);
                    return (time - new Date(d.getFullYear(), d.getMonth(), d.getDate()).valueOf()) / Scheduler.minuteInMiliseconds;
                };
                TimeRange.prototype.isInside = function (boundedRange) {
                    return this.start >= boundedRange.start && this.end <= boundedRange.end;
                };
                TimeRange.prototype.contain = function (range) {
                    return range.end > this.start && range.start < this.end;
                };
                TimeRange.prototype.timeIsInside = function (time) {
                    return this.start <= time && time < this.end;
                };
                TimeRange.prototype.expand = function (range) {
                    if (this.start > range.start)
                        this.start = range.start;
                    if (this.end < range.end)
                        this.end = range.end;
                };
                TimeRange.prototype.restrict = function (range) {
                    if (this.start < range.start)
                        this.start = range.start;
                    if (this.end > range.end)
                        this.end = range.end;
                };
                TimeRange.prototype.days = function () {
                    return Math.round((this.end - this.start) / Scheduler.dayInMiliseconds);
                };
                TimeRange.prototype.duration = function () {
                    return this.end - this.start;
                };
                TimeRange.prototype.durationToString = function () {
                    return TimeRange.convertDurationToString(this.duration());
                };
                TimeRange.convertDurationToString = function (value) {
                    var d = 0, h = 0, m = 0;
                    var ret = "";
                    if (value > Scheduler.dayInMiliseconds) {
                        d = Math.round(value / Scheduler.dayInMiliseconds);
                        value -= d * Scheduler.dayInMiliseconds;
                        ret = d + " " + Scheduler.StringTable.get("Scheduler.Msg.Days") + " ";
                    }
                    if (value > Scheduler.hourInMiliseconds) {
                        h = Math.round(value / Scheduler.hourInMiliseconds);
                        value -= h * Scheduler.hourInMiliseconds;
                        if (h > 0)
                            ret += h + " " + Scheduler.StringTable.get("Scheduler.Msg.Hours") + " ";
                    }
                    if (value > Scheduler.minuteInMiliseconds) {
                        m = Math.round(value / Scheduler.minuteInMiliseconds);
                        if (m > 0)
                            ret += m + " " + Scheduler.StringTable.get("Scheduler.Msg.Minutes");
                    }
                    return ret;
                };
                return TimeRange;
            }());
            Scheduler.TimeRange = TimeRange;
            Scheduler.minuteInMiliseconds = 60 * 1000;
            Scheduler.hourInMiliseconds = 60 * Scheduler.minuteInMiliseconds;
            Scheduler.dayInMiliseconds = 24 * Scheduler.hourInMiliseconds;
            Scheduler.weekInMiliseconds = 7 * Scheduler.dayInMiliseconds;
            function minutesToMiliseconds(minutes) {
                return minutes * Scheduler.minuteInMiliseconds;
            }
            Scheduler.minutesToMiliseconds = minutesToMiliseconds;
            function milisecondsToMinutes(milisecond) {
                return Math.floor(milisecond / Scheduler.minuteInMiliseconds); // stripping the rest is better approach then round it, because in other code parts seconds are stripped also or are not taken in to account
            }
            Scheduler.milisecondsToMinutes = milisecondsToMinutes;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
