///<reference path="../../Controls/Scheduler/container.ts" />
///<reference path="workOrderData.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var WorkOrderDataProvider = (function (_super) {
                __extends(WorkOrderDataProvider, _super);
                function WorkOrderDataProvider(dataSource) {
                    return _super.call(this, dataSource) || this;
                }
                WorkOrderDataProvider.prototype.rowToResource = function (listRows, e) {
                    if (e.startIndex === 0)
                        AllowedResources.workOrders = new Scheduler.Dictionary();
                    return _super.prototype.rowToResource.call(this, listRows, e);
                };
                WorkOrderDataProvider.prototype.loadTasks = function (inputs, timeoffs, resources, timeRange, filter, onFinishCallback) {
                    var self = this;
                    Scheduler.WorkOrderScheduleEntity.load(inputs, resources, timeRange, filter, function () {
                        if (!timeoffs)
                            onFinishCallback();
                        else
                            Scheduler.TimeOffData.load(timeoffs, resources, timeRange, function () {
                                onFinishCallback();
                            });
                    });
                };
                WorkOrderDataProvider.prototype.loadLocations = function (tasks, onLoad) {
                    for (var i = tasks.length - 1; i >= 0; i--) {
                        var task = tasks[i];
                        if (task.group && task.group.locationRef && task.group.locationRef.id) {
                            var location = Scheduler.LocationCache.Item(task.group.locationRef.id);
                            if (location !== undefined) {
                                task.setLocation(location);
                                tasks.splice(i, 1);
                            }
                        }
                    }
                    if (tasks.length > 0)
                        Scheduler.WorkOrderEntity.loadCustomerAddress(tasks, onLoad);
                    else if (onLoad)
                        onLoad(null);
                };
                WorkOrderDataProvider.prototype.loadQualifiedResources = function (tasks, onFinishCallback) {
                    AllowedResources.load(tasks, onFinishCallback);
                };
                WorkOrderDataProvider.prototype.getUnscheduledTasksEnumerator = function (fetch) {
                    if (!this._inputData.unscheduledTasks.entityViews)
                        fetch.entity.filter.where("statuscode", "4", "eq"); ///WorkOrderStatus=4 - is ready to schedule
                    return _super.prototype.getUnscheduledTasksEnumerator.call(this, fetch);
                };
                WorkOrderDataProvider.prototype.saveTask = function (task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var start, end, totalWork, taskSplitEnabled, status_1;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!(this._inputData.createRule && task.isUnscheduledNew())) return [3 /*break*/, 2];
                                    return [4 /*yield*/, _super.prototype.saveTask.call(this, task, taskChanges)];
                                case 1: return [2 /*return*/, _a.sent()];
                                case 2:
                                    start = +taskChanges.start;
                                    end = +taskChanges.end;
                                    totalWork = +taskChanges.totalWork;
                                    taskSplitEnabled = Scheduler.Container.inputs.scheduledTasks.attrWorkduration && Scheduler.Container.constants.viewSplitOvertimeTasks;
                                    if (task.getStatus().isUnscheduled() && taskChanges.statuscode === undefined) {
                                        status_1 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                        if (!status_1)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity"));
                                        taskChanges.statuscode = status_1.value();
                                    }
                                    taskChanges["workorderid"] = task.group.id;
                                    if (start && !end) {
                                        if (taskSplitEnabled) {
                                            if (!totalWork)
                                                totalWork = task.getTotalWorkTime();
                                            end = start + totalWork;
                                        }
                                        else {
                                            end = start + (totalWork || task.getTotalWorkTime());
                                            totalWork = undefined;
                                        }
                                    }
                                    if (!task.isUnscheduledNew()) return [3 /*break*/, 4];
                                    return [4 /*yield*/, Scheduler.WorkOrderScheduleEntity.saveNew(task, taskChanges, start, end, totalWork, taskSplitEnabled)];
                                case 3:
                                    _a.sent();
                                    return [3 /*break*/, 6];
                                case 4: return [4 /*yield*/, Scheduler.WorkOrderScheduleEntity.save(task, taskChanges, start, end, totalWork)];
                                case 5:
                                    _a.sent();
                                    _a.label = 6;
                                case 6: return [4 /*yield*/, task.reloadTemplateData()];
                                case 7:
                                    _a.sent();
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                WorkOrderDataProvider.prototype.onTaskDlgInitialized = function (dialog) {
                    for (var i = 0; i < dialog.pages.length; i++) {
                        var page = dialog.pages[i];
                        if (page instanceof Scheduler.InfoPage)
                            page.onStatusChanged = this._onStatusChanged.bind(this, dialog, page);
                    }
                };
                WorkOrderDataProvider.prototype._onStatusChanged = function (dialog, page, status) {
                    if (status.isFinished()) {
                        if (page.tabContentElement.find("#taskInfoStatusCheckboxDiv").length === 0) {
                            var statusCheckBox = $("<input>");
                            statusCheckBox.attr("type", "checkbox");
                            statusCheckBox.prop("checked", false);
                            statusCheckBox.change(function (e) {
                                dialog.onChange("applyStatusforWorkOrder", e.target.checked);
                            });
                            var localizationSpan = $("<span>");
                            localizationSpan.attr("data-localization", "Scheduler.Msg.ApplyStatus");
                            localizationSpan.text("Apply status to whole WorkOrder");
                            var checkBoxDiv = $("<div>");
                            checkBoxDiv.attr("id", "taskInfoStatusCheckboxDiv");
                            checkBoxDiv.append($("<p>"));
                            checkBoxDiv.append(statusCheckBox);
                            checkBoxDiv.append(localizationSpan);
                            Scheduler.StringTable.localizeElements(checkBoxDiv);
                            page.tabContentElement.find("#taskInfoStatusDiv").after(checkBoxDiv);
                        }
                    }
                    else {
                        page.tabContentElement.find("#taskInfoStatusCheckboxDiv").remove();
                    }
                };
                return WorkOrderDataProvider;
            }(Scheduler.DataProvider));
            Scheduler.WorkOrderDataProvider = WorkOrderDataProvider;
            var AllowedResources = (function (_super) {
                __extends(AllowedResources, _super);
                function AllowedResources() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                AllowedResources.load = function (tasks, onFinishCallback) {
                    if (!tasks || tasks.length == 0)
                        onFinishCallback(null);
                    else {
                        var territoryDependentTasks = new WorkOrdersPerTerritotyDict(tasks);
                        var territories = territoryDependentTasks.Territories;
                        if (territories.length > 0)
                            territoryDependentTasks.load(territories, 0, onFinishCallback);
                        else
                            onFinishCallback(null);
                    }
                };
                return AllowedResources;
            }(Array));
            AllowedResources.workOrders = new Scheduler.Dictionary();
            var WorkOrdersPerTerritotyDict = (function () {
                function WorkOrdersPerTerritotyDict(tasks) {
                    this._items = {};
                    this._tasks = tasks;
                    for (var i = tasks.length - 1; i >= 0; i--) {
                        var task = tasks[i];
                        if (!task.getLinkedResources() && task.group) {
                            var workorderid = task.group.id;
                            var resources = AllowedResources.workOrders.Item(workorderid);
                            if (resources === undefined) {
                                var territoryId = task.group && task.group.territory ? task.group.territory.id : "";
                                var workOrderIds = this._items[territoryId];
                                if (!workOrderIds) {
                                    workOrderIds = {};
                                    this._items[territoryId] = workOrderIds;
                                }
                                workOrderIds[workorderid] = workorderid;
                            }
                            else
                                task.setLinkedResources(resources);
                        }
                    }
                }
                Object.defineProperty(WorkOrdersPerTerritotyDict.prototype, "Territories", {
                    get: function () {
                        var keySet = [];
                        for (var prop in this._items) {
                            if (this._items.hasOwnProperty(prop))
                                keySet.push(prop);
                        }
                        return keySet;
                    },
                    enumerable: true,
                    configurable: true
                });
                WorkOrdersPerTerritotyDict.prototype._workOrderIds = function (territoryId) {
                    var values = [];
                    var workOrderIds = this._items[territoryId];
                    for (var prop in workOrderIds) {
                        if (workOrderIds.hasOwnProperty(prop))
                            values.push(workOrderIds[prop]);
                    }
                    return values;
                };
                WorkOrdersPerTerritotyDict.prototype._setLinkedResources = function () {
                    for (var i = this._tasks.length - 1; i >= 0; i--) {
                        var task = this._tasks[i];
                        if (task.getLinkedResources() == undefined && task.group) {
                            var resources = AllowedResources.workOrders.Item(task.group.id);
                            task.setLinkedResources(resources ? resources : null);
                        }
                    }
                };
                WorkOrdersPerTerritotyDict.prototype.load = function (territories, index, onFinishCallback) {
                    var promises = new Array();
                    var self = this;
                    for (var i = 0; i < territories.length; i++) {
                        var territoryId = territories[i];
                        var orderIds = this._workOrderIds(territoryId);
                        promises.push(this._loadPerTerritory(orderIds, territoryId, AllowedResources.workOrders));
                    }
                    Scheduler.PromiseEx.allEx(promises)
                        .then(function (tasks) {
                        self._setLinkedResources();
                        onFinishCallback(null);
                    })
                        .catch(function (errors) {
                        var messages = errors.map(function (error) {
                            return (error instanceof Resco.Exception) ? error.message : error.toString();
                        });
                        onFinishCallback(Scheduler.aggregateErrors(messages));
                    });
                };
                WorkOrdersPerTerritotyDict.prototype._loadPerTerritory = function (workOrdersIds, territoryid, workOrders) {
                    return __awaiter(this, void 0, void 0, function () {
                        var entity, woSkillsLink, resSkillsLink, territoryLink, fetch, entityResult, lastWorkOrderId, idDic, woCount, i, row, workOrderId, resourceId, i;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    entity = new MobileCRM.FetchXml.Entity("fs_workorder");
                                    entity.addAttribute("id");
                                    if (workOrdersIds && (workOrdersIds.length > 0))
                                        entity.addFilter().isIn("id", workOrdersIds);
                                    woSkillsLink = entity.addLink("fs_workorderskill", "workorderid", "id", "inner");
                                    woSkillsLink.alias = "woSkills";
                                    resSkillsLink = woSkillsLink.addLink("fs_resourceskill", "skillid", "skillid", "inner");
                                    resSkillsLink.alias = "resSkills";
                                    resSkillsLink.addAttribute("resourceid");
                                    if (territoryid) {
                                        territoryLink = resSkillsLink.addLink("fs_resourceterritory", "resourceid", "resourceid", "outer");
                                        territoryLink.alias = "resTerritory";
                                        territoryLink.addFilter().where("territoryid", "eq", territoryid);
                                    }
                                    entity.orderBy("id", true);
                                    fetch = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch.executeAsync("Array")];
                                case 1:
                                    entityResult = _a.sent();
                                    if (entityResult.length > 0) {
                                        lastWorkOrderId = entityResult[0][0];
                                        idDic = new Scheduler.Dictionary();
                                        woCount = 0;
                                        for (i = 0; i < entityResult.length; i++) {
                                            row = entityResult[i];
                                            workOrderId = row[0];
                                            if (lastWorkOrderId != workOrderId) {
                                                woCount++;
                                                workOrders.Add(lastWorkOrderId, idDic.Keys());
                                                idDic = new Scheduler.Dictionary();
                                                lastWorkOrderId = workOrderId;
                                            }
                                            resourceId = row[1].id;
                                            idDic.Add(resourceId, resourceId);
                                        }
                                        if (lastWorkOrderId) {
                                            woCount++;
                                            workOrders.Add(lastWorkOrderId, idDic.Keys());
                                        }
                                        if (woCount < workOrdersIds.length) {
                                            for (i = 0; i < workOrdersIds.length; i++) {
                                                if (workOrders.Item(workOrdersIds[i]) === undefined)
                                                    workOrders.Add(workOrdersIds[i], null);
                                            }
                                        }
                                    }
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                return WorkOrdersPerTerritotyDict;
            }());
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
