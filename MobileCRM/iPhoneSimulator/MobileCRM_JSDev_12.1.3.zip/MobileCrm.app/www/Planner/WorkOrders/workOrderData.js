///<reference path="../../Controls//Scheduler/enums.ts" />
///<reference path="../../Controls//Scheduler/settings.ts" />
///<reference path="../../Controls//Scheduler/container.ts" />
///<reference path="../../Controls//Scheduler/resource.ts" />
///<reference path="../../Controls//Scheduler/task.ts" />
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var workOrderStatus;
            (function (workOrderStatus) {
                /// <summary>WorkOrder is created</summary>
                workOrderStatus[workOrderStatus["Draft"] = 1] = "Draft";
                /// <summary>WorkOrder has been completed</summary>
                workOrderStatus[workOrderStatus["Completed"] = 2] = "Completed";
                /// <summary>WorkOrder has been canceled</summary>
                workOrderStatus[workOrderStatus["Canceled"] = 3] = "Canceled";
                /// <summary>WorkOrder is ready to schedule</summary>
                workOrderStatus[workOrderStatus["Ready"] = 4] = "Ready";
                /// <summary>WorkOrder is scheduled</summary>
                workOrderStatus[workOrderStatus["Scheduled"] = 5] = "Scheduled";
            })(workOrderStatus = Scheduler.workOrderStatus || (Scheduler.workOrderStatus = {}));
            var ResourceEntity = (function () {
                function ResourceEntity() {
                }
                ResourceEntity.findResource = function (resources, id) {
                    for (var i = 0; i < resources.length; i++) {
                        if (resources[i].getID() === id)
                            return resources[i];
                    }
                    return null;
                };
                return ResourceEntity;
            }());
            Scheduler.ResourceEntity = ResourceEntity;
            var WorkOrderEntity = (function () {
                function WorkOrderEntity() {
                }
                WorkOrderEntity._groupTasksByCustomer = function (tasks, outDic) {
                    var customerId;
                    var location;
                    // try to find locations from cache or group rest of tasks by customers 
                    for (var i = 0; i < tasks.length; i++) {
                        var r = tasks[i];
                        if (r.getLocation() !== undefined || !r.group || !r.group.locationRef)
                            continue;
                        else if (!(customerId = r.group.locationRef.id))
                            r.location = null;
                        else if ((location = Scheduler.LocationCache.Item(customerId)))
                            r.location = location;
                        else {
                            var taskGroup = outDic.Item(customerId);
                            if (!taskGroup)
                                outDic.Add(customerId, taskGroup = []);
                            taskGroup.push(r);
                        }
                    }
                };
                WorkOrderEntity.loadCustomerAddress = function (tasks, onFinishCallback) {
                    var location;
                    var group;
                    if (tasks.length === 1 && (group = tasks[0].group) && group.locationRef && (location = Scheduler.LocationCache.Item(group.locationRef.id)) !== undefined) {
                        tasks[0].location = location;
                        onFinishCallback(null);
                    }
                    else {
                        var entity = new MobileCRM.FetchXml.Entity("account");
                        var orderDic_1 = new Scheduler.Dictionary();
                        // try to find locations from cache or group rest of tasks by customers 
                        WorkOrderEntity._groupTasksByCustomer(tasks, orderDic_1);
                        var customerIds = orderDic_1.Keys();
                        if (customerIds.length == 0) {
                            onFinishCallback(null);
                            return;
                        }
                        entity.attributes = WorkOrderEntity._accountAddressAttributes.slice(); // !!!It is necessary to set a new copy (instance) here, because in other case "entity.addAttribute("id");" below will accumulate "id" attribute, by adding it to the same instance every call of this code!!!
                        entity.addAttribute("id");
                        if (customerIds && (customerIds.length > 0)) {
                            entity.addFilter().isIn("id", customerIds);
                        }
                        var fetch_1 = new MobileCRM.FetchXml.Fetch(entity);
                        //fetch.count = 1;
                        fetch_1.execute("DynamicEntities", function (entityResult) {
                            for (var i = 0; i < entityResult.length; i++) {
                                var prop = entityResult[i].properties;
                                var latitude = undefined;
                                var longitude = undefined;
                                var address = "";
                                if (prop['address1_country'] !== undefined)
                                    address += prop['address1_country'] + ",";
                                if (prop['address1_stateorprovince'] !== undefined)
                                    address += prop['address1_stateorprovince'] + ",";
                                if (prop['address1_city'] !== undefined) {
                                    if (prop['address1_postalcode'] !== undefined)
                                        address += prop['address1_postalcode'] + " " + prop['address1_city'] + ",";
                                    else
                                        address += prop['address1_city'] + ",";
                                }
                                if (prop['address1_line1'] !== undefined)
                                    address += prop['address1_line1'] + ",";
                                if (prop['address1_line2'] !== undefined)
                                    address += prop['address1_line2'] + ",";
                                if (prop['address1_line3'] !== undefined)
                                    address += prop['address1_line3'] + ",";
                                if (prop['address1_longitude'] !== undefined && prop['address1_latitude'] !== undefined) {
                                    latitude = prop['address1_latitude'];
                                    longitude = prop['address1_longitude'];
                                }
                                Scheduler.LocationCache.Add(prop.id, location = new Scheduler.Location(address, latitude, longitude));
                                var taskGroup = orderDic_1.Item(prop.id);
                                for (var j = 0; j < taskGroup.length; j++)
                                    taskGroup[j].location = location;
                            }
                            onFinishCallback(null);
                        }, function (err) {
                            onFinishCallback(err);
                        }, this);
                    }
                };
                // change WorkOrder statuscode => Scheduled
                WorkOrderEntity.updateEntity = function (taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var entity, errorMsg, workorderid, inputs, fetch, result, item, progress, bSave;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    entity = new MobileCRM.FetchXml.Entity(Scheduler.Container.inputs.unscheduledTasks.entityName);
                                    errorMsg = Scheduler.StringTable.get("Scheduler.Err.TaskUpdate");
                                    workorderid = taskChanges["workorderid"];
                                    inputs = Scheduler.Container.inputs.unscheduledTasks;
                                    entity.addAttribute(inputs.primaryKeyName);
                                    entity.addAttribute("statuscode");
                                    entity.addAttribute("completionpercent");
                                    entity.addFilter().where(inputs.primaryKeyName, "eq", workorderid);
                                    fetch = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch.executeAsync("DynamicEntities")];
                                case 1:
                                    result = _a.sent();
                                    item = result[0];
                                    progress = taskChanges["progress"];
                                    bSave = true;
                                    if (taskChanges.applyStatusforWorkOrder)
                                        item.properties.statuscode = taskChanges.applyStatusforWorkOrder;
                                    else if (item.properties.statuscode !== workOrderStatus.Scheduled)
                                        item.properties.statuscode = workOrderStatus.Scheduled;
                                    else
                                        bSave = false;
                                    if (progress !== undefined && progress !== item.properties.completionpercent && progress >= 0 && progress <= 100) {
                                        item.properties.completionpercent = progress;
                                        bSave = true;
                                    }
                                    if (!bSave) return [3 /*break*/, 3];
                                    return [4 /*yield*/, item.saveAsync()];
                                case 2:
                                    _a.sent();
                                    _a.label = 3;
                                case 3: return [2 /*return*/];
                            }
                        });
                    });
                };
                return WorkOrderEntity;
            }());
            WorkOrderEntity._accountAddressAttributes = [
                new MobileCRM.FetchXml.Attribute("address1_latitude"),
                new MobileCRM.FetchXml.Attribute("address1_longitude"),
                new MobileCRM.FetchXml.Attribute("address1_country"),
                new MobileCRM.FetchXml.Attribute("address1_stateorprovince"),
                new MobileCRM.FetchXml.Attribute("address1_city"),
                new MobileCRM.FetchXml.Attribute("address1_postalcode"),
                new MobileCRM.FetchXml.Attribute("address1_line1"),
                new MobileCRM.FetchXml.Attribute("address1_line2"),
                new MobileCRM.FetchXml.Attribute("address1_line3")
            ];
            Scheduler.WorkOrderEntity = WorkOrderEntity;
            var WorkOrderScheduleEntity = (function () {
                function WorkOrderScheduleEntity() {
                }
                WorkOrderScheduleEntity.load = function (inputData, resources, timeRange, filter, onFinishCallback) {
                    var entity = new MobileCRM.FetchXml.Entity(inputData.entityName);
                    var filters = [];
                    var startPeriod = undefined;
                    var endPeriod = undefined;
                    var resourceCount;
                    if (!resources || !(resourceCount = resources.length)) {
                        onFinishCallback();
                        return;
                    }
                    for (var i = 0; i < resourceCount; i++)
                        resources[i].clearTasks();
                    if (!inputData.attrWorkduration)
                        entity.attributes = WorkOrderScheduleEntity._attributes.slice(); // !!!It is necessary to set a new copy (instance) here, because in other case calling "entity.addAttribute()" method below (in taskTemplateController.addAttributesAndLinks()) will accumulate attributes, by adding them to the same instance every call of that code!!!
                    else
                        entity.attributes = WorkOrderScheduleEntity._attributes_v2.slice(); // !!!It is necessary to set a new copy (instance) here, because in other case calling "entity.addAttribute()" method below (in taskTemplateController.addAttributesAndLinks()) will accumulate attributes, by adding them to the same instance every call of that code!!!
                    var resourceIds = resources.map(function (i) { return i.getID(); });
                    if (resourceIds && (resourceIds.length > 0)) {
                        var resourceFilter = new MobileCRM.FetchXml.Filter();
                        resourceFilter.isIn(inputData.attrResourceRef, resourceIds);
                        filters.push(resourceFilter);
                    }
                    var statusCodeTable = Scheduler.Container.statusCodeTable;
                    var statusArray = statusCodeTable.getSupportedStatusesValues();
                    if (statusArray && (statusArray.length > 0)) {
                        var statusFilter = new MobileCRM.FetchXml.Filter();
                        statusFilter.isIn(inputData.attrStatus, statusArray);
                        filters.push(statusFilter);
                    }
                    if ((statusArray = statusCodeTable.getUnscheduledStatusesValues()) && (statusArray.length > 0)) {
                        var unscheduledFilter = new MobileCRM.FetchXml.Filter();
                        unscheduledFilter.notIn(inputData.attrStatus, statusArray);
                        filters.push(unscheduledFilter);
                    }
                    if (!filter.showCompletedAndCanceled && !filter.monthOverviewMode() && (statusArray = statusCodeTable.getFinishedStatusesValues()) && (statusArray.length > 0)) {
                        var finishedFilter = new MobileCRM.FetchXml.Filter();
                        finishedFilter.notIn(inputData.attrStatus, statusArray);
                        filters.push(finishedFilter);
                    }
                    if (timeRange.start > 0) {
                        startPeriod = new Date(timeRange.start);
                    }
                    if (timeRange.end > timeRange.start) {
                        endPeriod = new Date(timeRange.end);
                    }
                    if (startPeriod || endPeriod) {
                        var timeFilter = new MobileCRM.FetchXml.Filter();
                        // add tasks > as Schedules, when date is in range
                        var f1 = new MobileCRM.FetchXml.Filter();
                        var f2 = new MobileCRM.FetchXml.Filter();
                        var f3 = new MobileCRM.FetchXml.Filter();
                        if (startPeriod) {
                            f1.where("endedon", "not-null", null);
                            f1.where("endedon", "ge", startPeriod);
                            f2.where("arrivedon", "not-null", null);
                            f2.where("arrivedon", "ge", startPeriod);
                            f3.where("scheduledend", "ge", startPeriod);
                        }
                        if (endPeriod) {
                            f1.where("startedon", "not-null", null);
                            f1.where("startedon", "lt", endPeriod);
                            f2.where("arrivedon", "not-null", null);
                            f2.where("arrivedon", "lt", endPeriod);
                            f3.where("scheduledstart", "lt", endPeriod);
                        }
                        timeFilter.type = "or";
                        timeFilter.filters = [f1, f2, f3];
                        filters.push(timeFilter);
                    }
                    entity.addFilter().filters = filters;
                    var linkEntity = entity.addLink("fs_workorder", "id", "workorderid", "inner");
                    linkEntity.addAttribute("completionpercent", "completionpercent", null);
                    linkEntity.addAttribute("customerid", "customerid", null);
                    linkEntity.addAttribute("territoryid", "territoryid", null);
                    entity.orderBy("resourceid", false);
                    if (Scheduler.Container.ref.taskTemplateCtrl.isInitialized) {
                        Scheduler.Container.ref.taskTemplateCtrl.addAttributesAndLinks(entity);
                    }
                    var fetch = new Scheduler.MultipageFetch();
                    fetch.execute(entity, function (entityResult) {
                        var lastResurce = undefined;
                        for (var i = 0; i < entityResult.length; i++) {
                            var prop = entityResult[i].properties;
                            if (!prop.scheduledstart || !prop.scheduledend)
                                continue;
                            if (!lastResurce || (lastResurce.getID() !== prop.resourceid.id)) {
                                var resource = ResourceEntity.findResource(resources, prop.resourceid.id);
                                if (!resource)
                                    continue;
                                lastResurce = resource;
                            }
                            var task = WorkOrderScheduleEntity._entityToTask(inputData, prop);
                            if (task && timeRange.contain(new Scheduler.TimeRange(task.getWorkStart(), task.getWorkStart() + task.getTotalWorkTime())))
                                lastResurce.addTask(task);
                        }
                        onFinishCallback();
                    });
                };
                WorkOrderScheduleEntity._entityToTask = function (inputData, prop) {
                    if (!prop.scheduledstart || !prop.scheduledend)
                        return null;
                    var startDate = new Date(prop.scheduledstart);
                    var endDate = new Date(prop.scheduledend);
                    var travel;
                    var task = new Scheduler.Task(inputData, prop.id, prop.name, 0, 0);
                    if (Scheduler.Container.ref.taskTemplateCtrl.isInitialized) {
                        task.templateData = Scheduler.Container.ref.taskTemplateCtrl.toTemplateData(inputData.entityName, prop);
                    }
                    task.progress = prop.completionpercent || 0;
                    task.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(prop.statuscode));
                    task.group = new Scheduler.Group(prop.workorderid.id, prop.workorderid.primaryName, prop.customerid, prop.territoryid);
                    travel = task.getTravel();
                    travel.to = (prop.scheduledtravelto || 0) * Scheduler.minuteInMiliseconds;
                    travel.from = (prop.scheduledtravelfrom || 0) * Scheduler.minuteInMiliseconds;
                    travel.mode = prop.travelmode || 0;
                    if (prop.windowstart && prop.windowstart < prop.windowend)
                        task.requiredWindow = new Scheduler.TimeRange(prop.windowstart, prop.windowend);
                    else
                        task.requiredWindow = undefined;
                    if (!task.isEditable()) {
                        if (task.getStatus().isFinished())
                            task.progress = 100;
                        if (startDate && endDate) {
                            var scheduledDuration = endDate.valueOf() - startDate.valueOf();
                            if (prop.startedon) {
                                startDate = new Date(prop.startedon);
                                endDate = prop.endedon ? new Date(prop.endedon) : new Date(startDate.valueOf() + scheduledDuration);
                            }
                            else if (prop.arrivedon) {
                                startDate = new Date(prop.arrivedon);
                                endDate = new Date(startDate.valueOf() + scheduledDuration);
                            }
                        }
                    }
                    var start = startDate.valueOf();
                    task.setWorkStart(start);
                    task.hasScheduledStart = true;
                    if (prop.workduration !== undefined)
                        task.setTotalWorkTime(Scheduler.minutesToMiliseconds(prop.workduration));
                    else {
                        var end = endDate.valueOf();
                        if (end < start)
                            end = start;
                        task.setTotalWorkTime(end - start);
                    }
                    return task;
                };
                WorkOrderScheduleEntity.updateTaskFromEntityProperties = function (task, prop) {
                    if (prop.id !== undefined && prop.id === task.id) {
                        var startDate = prop.scheduledstart ? new Date(prop.scheduledstart) : undefined;
                        var endDate = prop.scheduledend ? new Date(prop.scheduledend) : undefined;
                        var travel = task.getTravel();
                        if (prop.name !== undefined)
                            task.name = prop.name;
                        if (prop.scheduledtravelfrom !== undefined)
                            travel.from = Scheduler.minutesToMiliseconds(+prop.scheduledtravelfrom);
                        if (prop.scheduledtravelto !== undefined)
                            travel.to = Scheduler.minutesToMiliseconds(+prop.scheduledtravelto);
                        if (prop.travelmode !== undefined)
                            travel.mode = prop.travelmode;
                        if (prop.workduration !== undefined)
                            task.setTotalWorkTime(Scheduler.minutesToMiliseconds(prop.workduration));
                        //if (prop.scheduledbreak !== undefined) // scheduledBreak is not used now
                        //	task.scheduledBreak = minutesToMiliseconds(+prop.scheduledbreak);
                        if (prop.windowstart !== undefined || prop.windowend !== undefined) {
                            if (prop.windowstart && prop.windowstart < prop.windowend)
                                task.requiredWindow = new Scheduler.TimeRange(prop.windowstart, prop.windowend);
                            else
                                task.requiredWindow = undefined;
                        }
                        if (prop.statuscode !== undefined) {
                            task.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(prop.statuscode));
                            if (!task.isEditable()) {
                                if (startDate && endDate) {
                                    var scheduledDuration = endDate.valueOf() - startDate.valueOf();
                                    if (prop.startedon) {
                                        startDate = new Date(prop.startedon);
                                        endDate = prop.endedon ? new Date(prop.endedon) : new Date(startDate.valueOf() + scheduledDuration);
                                    }
                                    else if (prop.arrivedon) {
                                        startDate = new Date(prop.arrivedon);
                                        endDate = new Date(startDate.valueOf() + scheduledDuration);
                                    }
                                }
                            }
                        }
                        if (startDate) {
                            task.setWorkStart(startDate.valueOf());
                            task.hasScheduledStart = true;
                        }
                        if (endDate) {
                            var start = task.getWorkStart();
                            var end = endDate.valueOf();
                            if (end < start)
                                end = start;
                            task.setTotalWorkTime(end - start);
                        }
                    }
                };
                WorkOrderScheduleEntity.saveNew = function (task, taskChanges, start, end, totalWork, taskSplitEnabled) {
                    return __awaiter(this, void 0, void 0, function () {
                        var resource, entity, props, travel, status;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    resource = task.resource;
                                    entity = MobileCRM.DynamicEntity.createNew(Scheduler.Container.inputs.scheduledTasks.entityName);
                                    props = entity.properties;
                                    travel = task.getTravel();
                                    props.scheduledstart = new Date(start || task.getWorkStart());
                                    props.scheduledend = new Date(end || task.getWorkEnd());
                                    if (taskSplitEnabled) {
                                        props.workduration = Scheduler.milisecondsToMinutes(totalWork || task.getTotalWorkTime());
                                        props.travelmode = task.getTravel().mode;
                                    }
                                    status = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                    if (!status)
                                        throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity"));
                                    taskChanges.statuscode = status.value();
                                    props.statuscode = taskChanges.statuscode;
                                    props.workorderid = new MobileCRM.Reference(Scheduler.Container.inputs.unscheduledTasks.entityName, task.group.id, task.group.name);
                                    if (resource) {
                                        props.resourceid = new MobileCRM.Reference(Scheduler.Container.inputs.resources.entityName, resource.getID(), resource.getName());
                                        props.targetid = resource.target;
                                        props.name = props.resourceid.primaryName + " - " + task.group.name;
                                    }
                                    else {
                                        if (!taskChanges.parentID)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoResourceIdForNewTask"));
                                        props.resourceid = new MobileCRM.Reference(Scheduler.Container.inputs.resources.entityName, taskChanges.parentID, null);
                                        props.targetid = null;
                                        props.name = task.group.name;
                                    }
                                    taskChanges.name = props.name;
                                    if (travel.from != 0)
                                        props.scheduledtravelfrom = travel.fromInMinutes;
                                    if (travel.to != 0)
                                        props.scheduledtravelto = travel.toInMinutes;
                                    //if (task.scheduledBreak != 0) // scheduledBreak is not used now
                                    //	props.scheduledbreak = milisecondsToMinutes(task.scheduledBreak);
                                    return [4 /*yield*/, WorkOrderScheduleEntity._saveEntity(entity, task, taskChanges)];
                                case 1:
                                    //if (task.scheduledBreak != 0) // scheduledBreak is not used now
                                    //	props.scheduledbreak = milisecondsToMinutes(task.scheduledBreak);
                                    _a.sent();
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                WorkOrderScheduleEntity.save = function (task, taskChanges, start, end, totalWork) {
                    return __awaiter(this, void 0, void 0, function () {
                        var resource, entity, fetch, result, item, prop, oldStatuscode, changes, newValue, status_1, propStatusType;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    resource = task.resource;
                                    entity = new MobileCRM.FetchXml.Entity(Scheduler.Container.inputs.scheduledTasks.entityName);
                                    if (!Scheduler.Container.inputs.scheduledTasks.attrWorkduration)
                                        entity.attributes = WorkOrderScheduleEntity._attributes;
                                    else
                                        entity.attributes = WorkOrderScheduleEntity._attributes_v2;
                                    entity.addFilter().where("id", "eq", task.id);
                                    fetch = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch.executeAsync("DynamicEntities")];
                                case 1:
                                    result = _a.sent();
                                    if (!(result.length === 0)) return [3 /*break*/, 2];
                                    throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoTasks"));
                                case 2:
                                    item = result[0];
                                    prop = item.properties;
                                    oldStatuscode = prop.statuscode;
                                    changes = 0;
                                    newValue = void 0;
                                    if (!Scheduler.Container.statusCodeTable.getStatusByValue(prop.statuscode).isEditable())
                                        throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity") + " " + Scheduler.Container.inputs.scheduledTasks.entityName + ".");
                                    if (taskChanges.travelFrom !== undefined) {
                                        newValue = Scheduler.milisecondsToMinutes(+taskChanges.travelFrom);
                                        if (prop.scheduledtravelfrom === undefined || prop.scheduledtravelfrom !== newValue) {
                                            prop.scheduledtravelfrom = newValue;
                                            changes++;
                                        }
                                    }
                                    if (taskChanges.travelTo !== undefined) {
                                        newValue = Scheduler.milisecondsToMinutes(+taskChanges.travelTo);
                                        if (prop.scheduledtravelto === undefined || prop.scheduledtravelto !== newValue) {
                                            prop.scheduledtravelto = newValue;
                                            changes++;
                                        }
                                    }
                                    if (start && !Scheduler.Utilities.equalDates(start, prop.scheduledstart)) {
                                        prop.scheduledstart = new Date(start);
                                        changes++;
                                    }
                                    if (taskChanges.statuscode !== undefined && taskChanges.statuscode !== prop.statuscode && Scheduler.Task.isValidStatusValue(taskChanges.statuscode)) {
                                        prop.statuscode = taskChanges.statuscode;
                                        changes++;
                                    }
                                    if (Scheduler.Container.inputs.scheduledTasks.attrTravelMode && taskChanges.travelmode && prop.travelmode !== taskChanges.travelmode) {
                                        prop.travelmode = taskChanges.travelmode;
                                        changes++;
                                    }
                                    if (Scheduler.Container.inputs.scheduledTasks.attrWorkduration && totalWork && prop.workduration !== (totalWork = Scheduler.milisecondsToMinutes(totalWork))) {
                                        prop.workduration = totalWork;
                                        changes++;
                                    }
                                    if (end && !Scheduler.Utilities.equalDates(end, prop.scheduledend)) {
                                        prop.scheduledend = new Date(end);
                                        changes++;
                                    }
                                    if (taskChanges.name !== undefined) {
                                        prop.name = taskChanges.name;
                                        changes++;
                                    }
                                    if (Scheduler.Container.statusCodeTable.getStatusByValue(oldStatuscode).isUnscheduled()) {
                                        if (!resource)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoResourceIdForNewTask"));
                                        status_1 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                        if (!status_1)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity"));
                                        prop.statuscode = status_1.value();
                                        prop.resourceid = resource.reference();
                                        prop.targetid = resource.target;
                                        changes++;
                                    }
                                    else if (resource) {
                                        if (!prop.resourceid || prop.resourceid.id !== resource.getID()) {
                                            prop.resourceid = resource.reference();
                                            prop.targetid = resource.target;
                                            changes++;
                                        }
                                    }
                                    if (taskChanges.progress !== undefined)
                                        changes++;
                                    if (!(changes > 0)) return [3 /*break*/, 4];
                                    /*
                                    if (start) {
                                        console.log('Start:' + new Date(start) + ' End:' + new Date(end) + '( ' + (prop.workduration ? prop.workduration / 60 : '?') + ')');
                                        if (end < start)
                                            end = start;
                                    }*/
                                    if (taskChanges.applyStatusforWorkOrder) {
                                        propStatusType = Scheduler.Container.statusCodeTable.getStatusByValue(prop.statuscode).taskStatusType();
                                        if (propStatusType === Scheduler.TaskStatusType.Completed) {
                                            taskChanges.progress = 100;
                                            taskChanges.applyStatusforWorkOrder = workOrderStatus.Completed;
                                        }
                                        else if (propStatusType === Scheduler.TaskStatusType.Canceled)
                                            taskChanges.applyStatusforWorkOrder = workOrderStatus.Canceled;
                                        else
                                            taskChanges.applyStatusforWorkOrder = undefined;
                                    }
                                    return [4 /*yield*/, WorkOrderScheduleEntity._saveEntity(item, task, taskChanges)];
                                case 3:
                                    _a.sent();
                                    _a.label = 4;
                                case 4: return [2 /*return*/];
                            }
                        });
                    });
                };
                WorkOrderScheduleEntity._saveEntity = function (entity, task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var result;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4 /*yield*/, entity.saveAsync()];
                                case 1:
                                    result = _a.sent();
                                    if (!task.isUnscheduledNew()) return [3 /*break*/, 3];
                                    task.id = result.id;
                                    task.entityInput.entityName = Scheduler.Container.inputs.scheduledTasks.entityName;
                                    return [4 /*yield*/, WorkOrderEntity.updateEntity(taskChanges)];
                                case 2:
                                    _a.sent(); // We need to await WorkOrder entity to be updated/saved also in the case that task template contains also reference to the WorkOrder entity.
                                    return [3 /*break*/, 5];
                                case 3:
                                    if (!(taskChanges["progress"] !== undefined || taskChanges.applyStatusforWorkOrder)) return [3 /*break*/, 5];
                                    return [4 /*yield*/, WorkOrderEntity.updateEntity(taskChanges)];
                                case 4:
                                    _a.sent(); // We need to await WorkOrder entity to be updated/saved also in the case that task template contains also reference to the WorkOrder entity.
                                    _a.label = 5;
                                case 5: return [2 /*return*/];
                            }
                        });
                    });
                };
                return WorkOrderScheduleEntity;
            }());
            WorkOrderScheduleEntity._attributes = [
                new MobileCRM.FetchXml.Attribute("id"),
                new MobileCRM.FetchXml.Attribute("name"),
                new MobileCRM.FetchXml.Attribute("statuscode"),
                new MobileCRM.FetchXml.Attribute("scheduledstart"),
                new MobileCRM.FetchXml.Attribute("scheduledend"),
                new MobileCRM.FetchXml.Attribute("arrivedon"),
                new MobileCRM.FetchXml.Attribute("startedon"),
                new MobileCRM.FetchXml.Attribute("endedon"),
                new MobileCRM.FetchXml.Attribute("scheduledtravelfrom"),
                new MobileCRM.FetchXml.Attribute("scheduledtravelto"),
                //new MobileCRM.FetchXml.Attribute("scheduledbreak"),  // scheduledBreak is not used now
                new MobileCRM.FetchXml.Attribute("workorderid"),
                new MobileCRM.FetchXml.Attribute("resourceid")
            ];
            WorkOrderScheduleEntity._attributes_v2 = [
                new MobileCRM.FetchXml.Attribute("id"),
                new MobileCRM.FetchXml.Attribute("name"),
                new MobileCRM.FetchXml.Attribute("statuscode"),
                new MobileCRM.FetchXml.Attribute("scheduledstart"),
                new MobileCRM.FetchXml.Attribute("scheduledend"),
                new MobileCRM.FetchXml.Attribute("workduration"),
                new MobileCRM.FetchXml.Attribute("arrivedon"),
                new MobileCRM.FetchXml.Attribute("startedon"),
                new MobileCRM.FetchXml.Attribute("endedon"),
                new MobileCRM.FetchXml.Attribute("scheduledtravelfrom"),
                new MobileCRM.FetchXml.Attribute("scheduledtravelto"),
                new MobileCRM.FetchXml.Attribute("travelmode"),
                //new MobileCRM.FetchXml.Attribute("scheduledbreak"),  // scheduledBreak is not used now
                new MobileCRM.FetchXml.Attribute("workorderid"),
                new MobileCRM.FetchXml.Attribute("resourceid")
            ];
            Scheduler.WorkOrderScheduleEntity = WorkOrderScheduleEntity;
            var TimeOffData = (function () {
                function TimeOffData() {
                }
                TimeOffData.reasonTypeToReason = function (reasonValue) {
                    if (reasonValue === 1)
                        return Scheduler.StringTable.get("Msg.PersonalVacation");
                    else if (reasonValue === 2)
                        return Scheduler.StringTable.get("Msg.SickLeave");
                    else if (reasonValue === 3)
                        return Scheduler.StringTable.get("Msg.MaternityPaternityLeave");
                    else if (reasonValue === 4)
                        return Scheduler.StringTable.get("Msg.CompassionateLeave");
                    else
                        return Scheduler.StringTable.get("Msg.Unknown");
                };
                TimeOffData.load = function (input, resources, timeRange, onFinishCallback) {
                    if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.TimeOff) && (resources.length > 0)) {
                        //let startTime: Performance = new Performance();
                        var entity = new MobileCRM.FetchXml.Entity(input.entityName);
                        entity.attributes = TimeOffData._attributes;
                        var filters = [];
                        var resourceIds = resources.map(function (i) { return i.getID(); });
                        if (resourceIds && (resourceIds.length > 0)) {
                            var resourceFilter = new MobileCRM.FetchXml.Filter();
                            resourceFilter.isIn(input.attrResourceRef, resourceIds);
                            filters.push(resourceFilter);
                        }
                        var startDate = new Date(timeRange.start);
                        var endDate = new Date(timeRange.end);
                        var timeFilter = new MobileCRM.FetchXml.Filter();
                        timeFilter.where(input.attrScheduledEnd, "ge", startDate);
                        timeFilter.where(input.attrScheduledStart, "lt", endDate);
                        filters.push(timeFilter);
                        entity.addFilter().filters = filters;
                        entity.orderBy(input.attrResourceRef, false);
                        var fetch_2 = new Scheduler.MultipageFetch();
                        fetch_2.execute(entity, function (entityResult) {
                            var lastResurce = undefined;
                            for (var i = 0; i < entityResult.length; i++) {
                                var prop = entityResult[i].properties;
                                if (!prop.from || !prop.to)
                                    continue;
                                if (!lastResurce || (lastResurce.getID() !== prop.resourceid.id)) {
                                    var resource = ResourceEntity.findResource(resources, prop.resourceid.id);
                                    if (!resource)
                                        continue;
                                    lastResurce = resource;
                                }
                                var task = TimeOffData._entityToTask(input, prop);
                                if (task && timeRange.contain(new Scheduler.TimeRange(task.getWorkStart(), task.getWorkStart() + task.getTotalWorkTime())))
                                    lastResurce.addTask(task);
                            }
                            onFinishCallback();
                        });
                    }
                    else
                        onFinishCallback();
                };
                TimeOffData._entityToTask = function (inputData, prop) {
                    if (!prop.from || !prop.to)
                        return null;
                    var reason = prop.name; // TimeOffData.reasonTypeToReason(+prop.type);
                    var task = new Scheduler.Task(inputData, prop.id, reason, new Date(prop.from).valueOf(), new Date(prop.to).valueOf());
                    task.setStatus(Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.TimeOff]);
                    return task;
                };
                return TimeOffData;
            }());
            TimeOffData._attributes = [
                new MobileCRM.FetchXml.Attribute("resourceid"),
                new MobileCRM.FetchXml.Attribute("id"),
                new MobileCRM.FetchXml.Attribute("name"),
                new MobileCRM.FetchXml.Attribute("from"),
                new MobileCRM.FetchXml.Attribute("to"),
                new MobileCRM.FetchXml.Attribute("type") //4
            ];
            Scheduler.TimeOffData = TimeOffData;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
