/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="User.ts" />
/// <reference path="Chatter.ts" />
var Chatter;
(function (Chatter) {
    var ChannelNavBar = /** @class */ (function () {
        function ChannelNavBar() {
            var _this = this;
            this.channels = ko.observableArray();
            this.users = ko.observableArray();
            this.visible = ko.observable();
            this.otherChannels = [];
            this.visibleChannels = ko.computed(function () { return ko.utils.arrayFilter(_this.channels(), function (channel) { return channel.visible(); }); });
            this.visibleUsers = ko.computed(function () { return ko.utils.arrayFilter(_this.users(), function (user) { return user.visible(); }); });
        }
        ChannelNavBar.prototype.applyConfig = function (config) {
            if (config) {
                this.showChannels = config.channels !== null;
                if (config.channels)
                    this.channels(config.channels.map(Channel.fromConfig));
                if (config.users)
                    this.users(config.users.map(Channel.fromConfig));
                if (config.otherChannels)
                    this.otherChannels = config.otherChannels.map(Channel.fromConfig);
                this.visible(true);
            }
        };
        ChannelNavBar.getSortIndex = function (channels, name, regardingEntity) {
            name = Chatter.Localization.toLower(name);
            regardingEntity = Chatter.Localization.toLower(regardingEntity);
            var i = 0;
            // Sort on regarding entity first ...
            while (i < channels.length && Chatter.Localization.toLower(channels[i].regardingEntity) < regardingEntity)
                i++;
            // ... then by the channel name.
            while (i < channels.length && Chatter.Localization.toLower(channels[i].regardingEntity) == regardingEntity && Chatter.Localization.toLower(channels[i].name()) <= name)
                i++;
            return i;
        };
        ChannelNavBar.prototype.addNewChannel = function (newChannel) {
            var index = ChannelNavBar.getSortIndex(this.channels(), newChannel.name, newChannel.regardingEntity);
            this.channels.splice(index, 0, Channel.fromConfig(newChannel, -1, null));
        };
        /**
         * Appends users coming from initial asynchronous loading.
         * @param users	New bunch of asynchronously loaded users
         */
        ChannelNavBar.prototype.appendUsers = function (users) {
            var _a;
            var newUsers = users.map(function (config, index, configs) { return Channel.fromConfig(config); });
            (_a = this.users).splice.apply(_a, [this.users().length, 0].concat(newUsers));
        };
        ChannelNavBar.prototype.appendChannel = function (id) {
            // Find channel in otherChannels and move it to channels
            for (var i = 0; i < this.otherChannels.length; i++) {
                var c = this.otherChannels[i];
                if (c.id == id) {
                    this.otherChannels.splice(i, 1);
                    var index = ChannelNavBar.getSortIndex(this.channels(), c.name(), c.regardingEntity);
                    this.channels.splice(index, 0, c);
                    return;
                }
            }
        };
        ChannelNavBar.prototype.removeChannel = function (id) {
            var channels = this.channels();
            for (var i = 0; i < channels.length; i++) {
                var c = channels[i];
                if (c.id == id) {
                    var channelToSelect = c.selected() ? (i < channels.length - 1 ? channels[i + 1] : channels[i - 1]) : null;
                    // Remove channel from channels...
                    this.channels.splice(i, 1);
                    // ... and move it to otherChannels (to be available in the list of all channels)
                    var index = ChannelNavBar.getSortIndex(this.otherChannels, c.name(), c.regardingEntity);
                    this.otherChannels.splice(index, 0, c);
                    if (channelToSelect)
                        channelToSelect.handleClick();
                    return;
                }
            }
        };
        ChannelNavBar.prototype.updateUnreadMessages = function (channelList) {
            this.channels().forEach(function (channel) {
                var newUnread = channelList[channel.id];
                channel.unread((newUnread || "").toString());
            });
            this.users().forEach(function (channel) {
                var newUnread = channelList[channel.id];
                channel.unread((newUnread || "").toString());
            });
        };
        ChannelNavBar.prototype.updateSelectedState = function (id) {
            this.channels().forEach(function (channel) {
                channel.selected(channel.id == id);
            });
            this.users().forEach(function (channel) {
                channel.selected(channel.id == id);
            });
        };
        return ChannelNavBar;
    }());
    Chatter.ChannelNavBar = ChannelNavBar;
    var Channel = /** @class */ (function () {
        function Channel(entity, id, name, unread, selected, visitedRecently, regardingEntity, icon) {
            var _this = this;
            this.name = ko.observable(name);
            this.unread = ko.observable(unread);
            this.entity = entity;
            this.id = id;
            this.selected = ko.observable(selected);
            this.visitedRecently = ko.observable(visitedRecently);
            this.visible = ko.computed(function () { return _this.visitedRecently() || _this.unread() > 0 || _this.selected(); }, this);
            this.regardingEntity = regardingEntity;
            this.icon = icon ? icon : ("Home." + regardingEntity + ".png");
        }
        Channel.fromConfig = function (cc, index, wholeConfig) {
            return new Channel(cc.entity, cc.id, cc.name, cc.unread, cc.selected, cc.visitedRecently, cc.regardingEntity, cc.icon);
        };
        Channel.prototype.handleClick = function () {
            if (!this.visitedRecently())
                this.visitedRecently(true);
            Chatter.Topic.instance.setChannel(this.entity, this.id);
            return true;
        };
        return Channel;
    }());
    Chatter.Channel = Channel;
    var NavBarConfig = /** @class */ (function () {
        function NavBarConfig() {
        }
        return NavBarConfig;
    }());
    Chatter.NavBarConfig = NavBarConfig;
    var ChannelConfig = /** @class */ (function () {
        function ChannelConfig() {
        }
        return ChannelConfig;
    }());
    Chatter.ChannelConfig = ChannelConfig;
})(Chatter || (Chatter = {}));
//# sourceMappingURL=NavBar.js.map