/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="Localization.ts" />
var Chatter;
(function (Chatter) {
    var MEditor = /** @class */ (function () {
        function MEditor(element, emoticonsMenu, isEmpty) {
            this.escapeRegex = function (str) {
                return (str + '').replace(/([.?*+^$[\]\\(){}|-])/g, '\\$1');
            };
            this.element = element;
            this.emoticonsMenu = emoticonsMenu;
            this.lastSelRange = null;
            this.isEmpty = isEmpty;
            this.isEnabled = true;
            function _getTextRecursive(root, parser) {
                var text = '';
                var nodes = root.childNodes;
                for (var i = 0; i < nodes.length; i++) {
                    var node = nodes[i];
                    if (parser) {
                        var t = parser(node);
                        if (t) {
                            text += t;
                            continue;
                        }
                    }
                    var nodeName = node.nodeName;
                    if (nodeName == 'P' || nodeName == 'DIV') {
                        var nodeText = _getTextRecursive(node, parser);
                        if (i > 0)
                            text += '<br/>';
                        else if (nodeText.length >= 2 && nodeText.substr(0, 2) == '\n\t')
                            nodeText = nodeText.substr(2);
                        text += nodeText;
                    }
                    else if (nodeName == 'BR')
                        text += '<br/>';
                    else if (nodeName == 'IMG')
                        text += node.alt;
                    else if (nodeName == "A") {
                        var href = node.href;
                        if (href && (href.indexOf("http://") === 0 || href.indexOf("https://") === 0))
                            text += href;
                    }
                    else if (node.nodeValue)
                        text += node.nodeValue;
                }
                return text;
            }
            var _this = this;
            /*var placeHolderText = element.attr("placeholder");
            if (placeHolderText) {
                var placeHolder = $("<span class=\"meditor-placeholder\">" + placeHolderText + "</span>");
                element.append(placeHolder);

                var hidePlaceHolder = function () {
                    var placeHolder = $("span.meditor-placeholder", element);
                    if (placeHolder.length > 0) {
                        placeHolder.remove();

                        // Create empty text node and select it (forces keyboard to open on Android)
                        var node = element[0].appendChild(document.createTextNode(""));
                        var sel = window.getSelection();
                        if (sel) {
                            var range = document.createRange();
                            range.selectNode(node);
                            sel.addRange(range);
                        }
                        if (isEmpty)
                            isEmpty(false);
                    }
                };
                var showPlaceHolderIfEmpty = function () {
                    if ((!element.text() || element.text() == "") && !self.isFocused()) {
                        if (isEmpty)
                            isEmpty(true);
                        element.empty();
                        element.append(placeHolder);
                    }
                };

                element.click(function () {
                    hidePlaceHolder;
                });
                element.focus(hidePlaceHolder);
                element.blur(showPlaceHolderIfEmpty);
                this.getText = function (parser: (node: any) => string) {
                    hidePlaceHolder();
                    var result = _getTextRecursive(element[0], parser);
                    showPlaceHolderIfEmpty();
                    return result;
                }
            }
            else*/
            this.getText = function (parser) {
                return _getTextRecursive(element[0], parser).replace(/[\x00-\x1F\x85\u2028\u2029]/g, ""); // Remove ASCII chars below space and "bad" Unicode chars (Next Line, Line Separator, Paragraph Separator)
            };
            // Create emoticons dropdown
            this.LoadEmoticonsMenu();
            this.emoticonsMenu.on('click', 'div', function (e) {
                var emoji = $('.label', $(this)).text();
                window.setTimeout(function () {
                    _this.insertEmoticon.call(_this, emoji);
                }, 0);
            });
            if (!MEditor._selectionChangedHandler) {
                MEditor._selectionChangedHandler = function (eventObject) {
                    var selObj = window.getSelection();
                    if (selObj.anchorNode && selObj.getRangeAt) {
                        var selRange = selObj.getRangeAt(0);
                        var selMeditor = MEditor.fromNode(selRange.startContainer);
                        if (selMeditor && selMeditor == MEditor.fromNode(selRange.endContainer))
                            selMeditor.lastSelRange = selRange;
                    }
                };
                $(document).bind('selectionchange', MEditor._selectionChangedHandler);
            }
            element.addClass(MEditor.MEditorTargetClass);
            element.data('MEditor', this);
        }
        MEditor.fromNode = function (node) {
            var body = document.body;
            while (node && node != body) {
                var $node = $(node);
                if ($node.hasClass(MEditor.MEditorTargetClass)) {
                    return $node.data('MEditor');
                }
                node = node.parentNode;
            }
            return null;
        };
        MEditor.prototype.disable = function () {
            this.isEnabled = false;
        };
        MEditor.prototype.enable = function () {
            this.isEnabled = true;
        };
        MEditor.prototype.focus = function () {
            this.element[0].focus();
        };
        MEditor.prototype.restoreLastSelection = function () {
            var selRange = this.lastSelRange;
            if (selRange) {
                var selObj = window.getSelection();
                selObj.removeAllRanges();
                selObj.addRange(selRange);
            }
        };
        MEditor.prototype.clearText = function () {
            this.element.html(null);
            var divElement = this.element[0];
            // Fire "blur" event to show the placeholder
            // Find another way, because the code below will hide the keyboard.
            //divElement.focus();
            //divElement.blur();
        };
        MEditor.prototype.replaceSelection = function (htmlText) {
            var $element = $(htmlText);
            var editorDiv = this.element[0];
            var domElement = $element[0];
            var selRange = this.lastSelRange;
            var selObj = window.getSelection();
            $("span.meditor-placeholder", editorDiv).remove();
            if (this.isEmpty)
                this.isEmpty(false);
            if (selRange) {
                selRange.deleteContents();
                selRange.insertNode(domElement);
                selObj.removeAllRanges();
                var nbsp = document.createTextNode("\u00A0");
                var nbspNode = domElement.parentNode.insertBefore(nbsp, domElement.nextSibling);
                var newRange = document.createRange();
                newRange.setStartAfter(nbspNode);
                newRange.setEndAfter(nbspNode);
                selObj.addRange(newRange);
                return;
            }
            // Selection out of the editorDiv - append html to its end
            editorDiv.appendChild(domElement);
            var selNode = editorDiv.appendChild(document.createTextNode("\u00A0"));
            selObj.removeAllRanges();
            var newRange = document.createRange();
            newRange.setStartAfter(selNode);
            newRange.setEndAfter(selNode);
            selObj.addRange(newRange);
        };
        MEditor.prototype.LoadEmoticonsMenu = function () {
            var emojisElements = [];
            for (var key in EMOJI_ICONS) {
                emojisElements.push('<div class="emoticons_dropdown_item" onclick="javascript:void(0)" title="' + this.emojiEntities(key) + '">' + this.createIcon(key) + '<span class="label" hidden>' + this.emojiEntities(key) + '</span></div>');
            }
            this.emoticonsMenu.html(emojisElements.join(''));
        };
        MEditor.prototype.emojiEntities = function (str) {
            return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        };
        MEditor.prototype.createIcon = function (emoji) {
            var filename = EMOJI_ICONS[emoji];
            return '<img src="' + EMOJI_PATH + filename + '" alt="' + this.emojiEntities(emoji) + '">';
        };
        MEditor.prototype.insertEmoticon = function (emoji) {
            this.replaceSelection(this.createIcon(emoji));
        };
        MEditor.prototype.EmoticonsToIcons = function (text) {
            if (text) {
                for (var key in EMOJI_ICONS) {
                    text = text.replace(new RegExp(key, 'g'), this.createIcon(key));
                }
                return text;
            }
            else
                return "";
        };
        MEditor.MEditorTargetClass = "MEditorTarget";
        return MEditor;
    }());
    Chatter.MEditor = MEditor;
    var EMOJI_PATH = 'images/emojis/';
    var EMOJI_ICONS = {
        ':smile:': 'smile.png',
        ':angry:': 'angry.png',
        ':flushed:': 'flushed.png',
        ':neckbeard:': 'neckbeard.png',
        ':laughing:': 'laughing.png',
        ':sunglasses:': 'sunglasses.png'
    };
})(Chatter || (Chatter = {}));
//# sourceMappingURL=MEditor.js.map