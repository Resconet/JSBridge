var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var CanvasCropper = /** @class */ (function (_super) {
            __extends(CanvasCropper, _super);
            function CanvasCropper(canvas, drawingImage, backgroundImage, canvasProperties, x, y, w, h, cropRatio) {
                return _super.call(this, canvas, drawingImage, backgroundImage, canvasProperties, x, y, w, h, cropRatio) || this;
            }
            // return size and position of the selected area
            CanvasCropper.prototype.GetCroppedImageCanvas = function () {
                var temp_canvas = document.createElement('canvas');
                var temp_ctx = temp_canvas.getContext('2d');
                var dstX = Math.round(this.x * this.canvasProperties.ImageRatio);
                var dstY = Math.round(this.y * this.canvasProperties.ImageRatio);
                var dstW = Math.round(this.w * this.canvasProperties.ImageRatio);
                var dstH = Math.round(this.h * this.canvasProperties.ImageRatio);
                temp_ctx.canvas.width = dstW;
                temp_ctx.canvas.height = dstH;
                temp_ctx.drawImage(this.backgroundImage, dstX, dstY, dstW, dstH, 0, 0, dstW, dstH);
                temp_ctx.drawImage(this.drawingImage, dstX, dstY, dstW, dstH, 0, 0, dstW, dstH);
                this.dispose();
                return temp_canvas;
            };
            CanvasCropper.prototype.afterSelectionDrawn = function () { };
            CanvasCropper.calcSelectionSize = function (canvasProperties) {
                var w = canvasProperties.ImageWidth;
                var h = canvasProperties.ImageHeight;
                var maxW = canvasProperties.MaxImageWidth;
                var maxH = canvasProperties.MaxImageHeight;
                if (maxW > 0 && maxW < w)
                    w = maxW;
                if (maxH > 0 && maxH < h)
                    h = maxH;
                var cropRatio = Math.abs(canvasProperties.CropRatio);
                if (cropRatio) {
                    var currentRatio = w / h;
                    if (currentRatio > cropRatio)
                        w = h * cropRatio;
                    else
                        h = w / cropRatio;
                }
                var imageRatio = canvasProperties.ImageRatio;
                return [w / imageRatio, h / imageRatio];
            };
            return CanvasCropper;
        }(ImageEditor.CanvasSelector));
        ImageEditor.CanvasCropper = CanvasCropper;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=CanvasCropper.js.map