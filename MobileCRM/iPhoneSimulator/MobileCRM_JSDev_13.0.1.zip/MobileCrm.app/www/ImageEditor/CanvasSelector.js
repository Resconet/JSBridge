var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var CanvasSelector = /** @class */ (function () {
            function CanvasSelector(canvas, drawingImage, backgroundImage, canvasProperties, x, y, w, h, selRatio) {
                this.canvas = canvas;
                this.drawingImage = drawingImage;
                this.backgroundImage = backgroundImage;
                this.canvasProperties = canvasProperties;
                this.x = x;
                this.y = y;
                this.w = w;
                this.h = h;
                this.selRatio = selRatio;
                /*private onKeyPress(e: KeyboardEvent) {
                    if (this.allowSelRatioSwap && e.keyCode == 9) {
                        this.swapSelection();
                        e.stopPropagation();
                    }
                }*/
                this.onMouseMoveBound = this.onMouseMove.bind(this);
                this.onTouchMoveBound = this.onTouchMove.bind(this);
                this.onMouseDownBound = this.onMouseDown.bind(this);
                this.onTouchStartBound = this.onTouchStart.bind(this);
                this.onMouseUpBound = this.onMouseUp.bind(this);
                this.onTouchEndBound = this.onTouchEnd.bind(this);
                this.onMouseLeaveBound = this.onMouseLeave.bind(this);
                if (canvas === null || canvas === undefined || !(canvas instanceof HTMLCanvasElement))
                    throw "Image is missing or it is not a valid HTML DOM element!";
                this.ctx = canvas.getContext("2d");
                if (backgroundImage === null || backgroundImage === undefined || !(backgroundImage instanceof HTMLImageElement || backgroundImage instanceof HTMLCanvasElement))
                    throw "Image canvas is missing or it is not a valid HTML DOM element!";
                if (drawingImage === null || drawingImage === undefined || !(drawingImage instanceof HTMLCanvasElement))
                    throw "Drawing image is missing or it is not a valid HTML DOM element!";
                if (canvasProperties === null || canvasProperties === undefined || !(canvasProperties instanceof ImageEditor.CanvasImageProperties))
                    throw "Image details are missing!";
                this.csize = 6; // resize cubes size
                this.csizeh = 10; // resize cubes size (on hover)
                this.bHow = [false, false, false, false]; // hover statuses
                this.iCSize = [this.csize, this.csize, this.csize, this.csize]; // resize cubes sizes
                this.bDrag = [false, false, false, false]; // drag statuses
                this.bDragAll = false; // drag whole selection
                this.selectorCubesEl = [null, null, null, null];
                if (this.selRatio && this.selRatio < 0) {
                    this.allowSelRatioSwap = true;
                    this.selRatio = -this.selRatio;
                }
                // initialize sizes
                if (h === undefined || h === null)
                    if (this.canvasProperties.DimensionsFlipped)
                        this.h = backgroundImage.width / 2 / this.canvasProperties.ImageRatio;
                    else
                        this.h = backgroundImage.height / 2 / this.canvasProperties.ImageRatio;
                else
                    this.h = h;
                if (w === undefined || w === null)
                    if (this.canvasProperties.DimensionsFlipped)
                        this.w = backgroundImage.height / 2 / this.canvasProperties.ImageRatio;
                    else
                        this.w = backgroundImage.width / 2 / this.canvasProperties.ImageRatio;
                else
                    this.w = w;
                // initialize positions
                if (x === undefined || x === null) {
                    this.x = (this.canvas.width - this.w) / 2;
                }
                else {
                    this.x = x;
                }
                if (y === undefined || y === null) {
                    this.y = (this.canvas.height - this.h) / 2;
                }
                else {
                    this.y = x;
                }
                // extra variables to dragging calculations
                this.px = x;
                this.py = y;
                if (canvasProperties.DimensionsFlipped) {
                    this.x += this.y;
                    this.y = this.x - this.y;
                    this.x = this.x - this.y;
                    this.w += this.h;
                    this.h = this.w - this.h;
                    this.w = this.w - this.h;
                    this.px += this.py;
                    this.py = this.px - this.py;
                    this.px = this.px - this.py;
                }
                this.selectorWindowEl = document.createElement('div');
                this.selectorWindowEl.style.position = 'fixed';
                this.selectorWindowEl.style.display = 'none';
                for (var i = 0; i < 4; i++) {
                    this.selectorCubesEl[i] = document.createElement('div');
                    this.selectorCubesEl[i].style.position = 'fixed';
                    this.selectorCubesEl[i].style.background = '#FFF';
                    this.selectorWindowEl.appendChild(this.selectorCubesEl[i]);
                }
                document.getElementsByTagName('body')[0].appendChild(this.selectorWindowEl);
                this.drawScene();
                this.activateGestureHandling();
            }
            // define helper functions
            // define Selection draw method
            CanvasSelector.prototype.drawSelection = function () {
                var canvasOffset = this.getOffset(this.canvas);
                this.selectorWindowEl.style.top = canvasOffset.top + 'px';
                this.selectorWindowEl.style.left = canvasOffset.left + 'px';
                if (this.canvasProperties.DimensionsFlipped) {
                    this.selectorWindowEl.style.width = this.h + 'px';
                    this.selectorWindowEl.style.height = this.w + 'px';
                }
                else {
                    this.selectorWindowEl.style.width = this.w + 'px';
                    this.selectorWindowEl.style.height = this.h + 'px';
                }
                var top, left, width, height;
                if (this.canvasProperties.DimensionsFlipped) {
                    width = this.h;
                    height = this.w;
                }
                else {
                    width = this.w;
                    height = this.h;
                }
                if (this.canvasProperties.Rotation === 90) {
                    top = this.x;
                    left = this.canvas.clientWidth - this.y - this.h;
                    this.selectorWindowEl.style.borderTop = this.x + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderRight = this.y + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderBottom = (this.canvas.clientHeight - this.x - this.w) + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderLeft = (this.canvas.clientWidth - this.y - this.h) + 'px solid rgba(0,0,0,0.25)';
                }
                else if (this.canvasProperties.Rotation === 180) {
                    top = this.canvas.clientHeight - this.y - this.h;
                    left = this.canvas.clientWidth - this.x - this.w;
                    this.selectorWindowEl.style.borderBottom = this.y + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderRight = this.x + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderTop = (this.canvas.clientHeight - this.y - this.h) + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderLeft = (this.canvas.clientWidth - this.x - this.w) + 'px solid rgba(0,0,0,0.25)';
                }
                else if (this.canvasProperties.Rotation === 270) {
                    top = this.canvas.clientHeight - this.x - this.w;
                    left = this.y;
                    this.selectorWindowEl.style.borderBottom = this.x + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderLeft = this.y + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderTop = (this.canvas.clientHeight - this.x - this.w) + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderRight = (this.canvas.clientWidth - this.y - this.h) + 'px solid rgba(0,0,0,0.25)';
                }
                else {
                    top = this.y;
                    left = this.x;
                    this.selectorWindowEl.style.borderTop = this.y + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderLeft = this.x + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderBottom = (this.canvas.clientHeight - this.y - this.h) + 'px solid rgba(0,0,0,0.25)';
                    this.selectorWindowEl.style.borderRight = (this.canvas.clientWidth - this.x - this.w) + 'px solid rgba(0,0,0,0.25)';
                }
                this.selectorWindowEl.style.display = '';
                top += canvasOffset.top;
                left += canvasOffset.left;
                var movedBy = (this.canvasProperties.Rotation % 360) / 90;
                // draw resize cubes
                for (var i = 0; i < 4; i++) {
                    var j = (movedBy + i) % 4;
                    this.selectorCubesEl[j].style.width = this.iCSize[i] * 2 + 'px';
                    this.selectorCubesEl[j].style.height = this.iCSize[i] * 2 + 'px';
                    var topi = top - this.iCSize[i];
                    var lefti = left - this.iCSize[i];
                    if (j >= 2)
                        topi += height;
                    if (j === 1 || j === 2)
                        lefti += width;
                    this.selectorCubesEl[j].style.top = topi + 'px';
                    this.selectorCubesEl[j].style.left = lefti + 'px';
                }
                this.afterSelectionDrawn();
            };
            // main drawScene function
            CanvasSelector.prototype.drawScene = function () {
                this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height); // clear canvas
                // calculate the ratio between the canvas and the image
                this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
                this.ctx.save();
                this.ctx.setTransform(1, 0, 0, 1, 0, 0);
                this.ctx.translate(this.ctx.canvas.width / 2, this.ctx.canvas.height / 2);
                this.ctx.rotate(this.canvasProperties.Rotation * Math.PI / 180);
                if (this.canvasProperties.DimensionsFlipped)
                    this.ctx.translate(-this.ctx.canvas.height / 2, -this.ctx.canvas.width / 2);
                else
                    this.ctx.translate(-this.ctx.canvas.width / 2, -this.ctx.canvas.height / 2);
                // draw source image and make it darker
                // this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
                if (this.canvasProperties.DimensionsFlipped) {
                    this.ctx.drawImage(this.backgroundImage, 0, 0, this.canvas.height, this.canvas.width);
                    this.ctx.drawImage(this.drawingImage, 0, 0, this.canvas.height, this.canvas.width);
                    // this.ctx.fillRect(0, 0, this.ctx.canvas.height, this.ctx.canvas.width);
                }
                else {
                    this.ctx.drawImage(this.backgroundImage, 0, 0, this.canvas.width, this.canvas.height);
                    this.ctx.drawImage(this.drawingImage, 0, 0, this.canvas.width, this.canvas.height);
                    // this.ctx.fillRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
                }
                // draw selection
                this.drawSelection();
            };
            CanvasSelector.prototype.restrictPos = function (curPos, curDim, MinPos, MaxPos) {
                if (curPos > MinPos && curPos + curDim < MaxPos)
                    return curPos;
                else if (curPos < MinPos)
                    return MinPos;
                else
                    return MaxPos - curDim;
            };
            CanvasSelector.prototype.absolutePosition = function (el) {
                var x = 0;
                var y = 0;
                while (el !== null) {
                    x += el.offsetLeft;
                    y += el.offsetTop;
                    el = el.offsetParent;
                }
                return { x: x, y: y };
            };
            ;
            CanvasSelector.prototype.getOffset = function (e) {
                var pos = this.absolutePosition(e);
                // We need to account for the scroll position
                var scrollLeft = window.pageXOffset ? window.pageXOffset : document.body.scrollLeft;
                var scrollTop = window.pageYOffset ? window.pageYOffset : document.body.scrollTop;
                scrollLeft = Math.abs(scrollLeft) > 1 ? scrollLeft : 0;
                scrollTop = Math.abs(scrollTop) > 1 ? scrollTop : 0;
                return { left: scrollLeft + pos.x, top: scrollTop + pos.y };
            };
            CanvasSelector.prototype.activateGestureHandling = function () {
                this.selectorWindowEl.addEventListener('mousemove', this.onMouseMoveBound);
                this.selectorWindowEl.addEventListener('mousedown', this.onMouseDownBound);
                this.selectorWindowEl.addEventListener('mouseup', this.onMouseUpBound);
                this.selectorWindowEl.addEventListener('mouseleave', this.onMouseLeaveBound);
                this.selectorWindowEl.addEventListener('touchmove', this.onTouchMoveBound);
                this.selectorWindowEl.addEventListener('touchstart', this.onTouchStartBound);
                this.selectorWindowEl.addEventListener('touchend', this.onTouchEndBound);
                //this.selectorWindowEl.addEventListener("keypress", this.onKeyPress);
            };
            CanvasSelector.prototype.disableGestureHandling = function () {
                this.selectorWindowEl.removeEventListener('mousemove', this.onMouseMoveBound);
                this.selectorWindowEl.removeEventListener('mousedown', this.onMouseDownBound);
                this.selectorWindowEl.removeEventListener('mouseup', this.onMouseUpBound);
                this.selectorWindowEl.removeEventListener('mouseleave', this.onMouseLeaveBound);
                this.selectorWindowEl.removeEventListener('touchmove', this.onTouchMoveBound);
                this.selectorWindowEl.removeEventListener('touchstart', this.onTouchStartBound);
                this.selectorWindowEl.removeEventListener('touchend', this.onTouchEndBound);
                //this.selectorWindowEl.removeEventListener("keypress", this.onKeyPress);
            };
            CanvasSelector.prototype.rotateCoordinates = function (e, width, height) {
                if (width === void 0) { width = this.ctx.canvas.width; }
                if (height === void 0) { height = this.ctx.canvas.height; }
                var tmp;
                switch (this.canvasProperties.Rotation) {
                    case 90:
                        tmp = e.x;
                        e.x = e.y;
                        e.y = width - tmp;
                        break;
                    case 180:
                        e.x = width - e.x;
                        e.y = height - e.y;
                        break;
                    case 270:
                        tmp = e.y;
                        e.y = e.x;
                        e.x = height - tmp;
                        break;
                    default:
                        break;
                }
                return e;
            };
            // binding mousemove event
            CanvasSelector.prototype.OnMouseMove = function (e) { };
            CanvasSelector.prototype.onMouseMove = function (e) {
                e.stopImmediatePropagation();
                e.stopPropagation();
                e.preventDefault();
                var canvasOffset = this.getOffset(this.canvas);
                var iMouseX = Math.floor(e.clientX - canvasOffset.left);
                var iMouseY = Math.floor(e.clientY - canvasOffset.top);
                var rotated = this.rotateCoordinates({ x: iMouseX, y: iMouseY });
                iMouseX = rotated.x;
                iMouseY = rotated.y;
                // in case of drag of whole selector
                if (this.bDragAll) {
                    this.x = this.restrictPos(iMouseX - this.px, this.w, 0, this.backgroundImage.width / this.canvasProperties.ImageRatio);
                    this.y = this.restrictPos(iMouseY - this.py, this.h, 0, this.backgroundImage.height / this.canvasProperties.ImageRatio);
                }
                for (var i = 0; i < 4; i++) {
                    this.bHow[i] = false;
                    this.iCSize[i] = this.csize;
                }
                // hovering over resize cubes
                if (iMouseX > this.x - this.csizeh && iMouseX < this.x + this.csizeh &&
                    iMouseY > this.y - this.csizeh && iMouseY < this.y + this.csizeh) {
                    this.bHow[0] = true;
                    this.iCSize[0] = this.csizeh;
                }
                if (iMouseX > this.x + this.w - this.csizeh && iMouseX < this.x + this.w + this.csizeh &&
                    iMouseY > this.y - this.csizeh && iMouseY < this.y + this.csizeh) {
                    this.bHow[1] = true;
                    this.iCSize[1] = this.csizeh;
                }
                if (iMouseX > this.x + this.w - this.csizeh && iMouseX < this.x + this.w + this.csizeh &&
                    iMouseY > this.y + this.h - this.csizeh && iMouseY < this.y + this.h + this.csizeh) {
                    this.bHow[2] = true;
                    this.iCSize[2] = this.csizeh;
                }
                if (iMouseX > this.x - this.csizeh && iMouseX < this.x + this.csizeh &&
                    iMouseY > this.y + this.h - this.csizeh && iMouseY < this.y + this.h + this.csizeh) {
                    this.bHow[3] = true;
                    this.iCSize[3] = this.csizeh;
                }
                // in case of dragging of resize cubes
                var iFW, iFH, iFX, iFY;
                if (this.bDrag[0]) { // Dragging upper-left corner
                    iFX = iMouseX - this.px;
                    iFY = iMouseY - this.py;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFY < 0)
                        iFY = 0;
                    iFW = this.w + this.x - iFX;
                    iFH = this.h + this.y - iFY;
                }
                if (this.bDrag[1]) { // Dragging upper-right corner
                    iFX = this.x;
                    iFY = iMouseY - this.py;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFY < 0)
                        iFY = 0;
                    iFW = iMouseX - this.px - iFX;
                    iFH = this.h + this.y - iFY;
                }
                if (this.bDrag[2]) { // Dragging lower-right corner
                    iFX = this.x;
                    iFY = this.y;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFY < 0)
                        iFY = 0;
                    iFW = iMouseX - this.px - iFX;
                    iFH = iMouseY - this.py - iFY;
                }
                if (this.bDrag[3]) { // Dragging lower-left corner
                    iFX = iMouseX - this.px;
                    iFY = this.y;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFY < 0)
                        iFY = 0;
                    iFW = this.w + this.x - iFX;
                    iFH = iMouseY - this.py - iFY;
                }
                if (iFW > this.csizeh * 2 && iFH > this.csizeh * 2) {
                    var canvasW = void 0, canvasH = void 0;
                    if (this.canvasProperties.DimensionsFlipped) {
                        canvasW = this.canvas.height;
                        canvasH = this.canvas.width;
                    }
                    else {
                        canvasW = this.canvas.width;
                        canvasH = this.canvas.height;
                    }
                    this.w = this.restrictPos(iFW, 0, 0, canvasW - iFX);
                    this.h = this.restrictPos(iFH, 0, 0, canvasH - iFY);
                    this.maintainSelRatio(iFX, iFY);
                }
                this.drawScene();
                this.OnMouseMove(e);
            };
            CanvasSelector.prototype.swapSelection = function () {
                if (this.allowSelRatioSwap) {
                    this.selRatio = 1 / this.selRatio;
                    var canvasW = void 0, canvasH = void 0;
                    if (this.canvasProperties.DimensionsFlipped) {
                        canvasW = this.canvas.height;
                        canvasH = this.canvas.width;
                    }
                    else {
                        canvasW = this.canvas.width;
                        canvasH = this.canvas.height;
                    }
                    var w = this.w;
                    this.w = Math.min(this.h, canvasW);
                    this.h = Math.min(w, canvasH);
                    var iFX = this.restrictPos(this.x, this.w, 0, canvasW);
                    var iFY = this.restrictPos(this.y, this.h, 0, canvasH);
                    this.maintainSelRatio(iFX, iFY);
                    this.drawScene();
                }
            };
            CanvasSelector.prototype.maintainSelRatio = function (iFX, iFY) {
                var selRatio = this.selRatio;
                if (selRatio) {
                    var ratio = this.w / this.h;
                    if (ratio > selRatio) {
                        var iFW = this.h * selRatio;
                        if (this.bDrag[3] || this.bDrag[0])
                            iFX += this.w - iFW;
                        this.w = iFW;
                    }
                    else {
                        var iFH = this.w / selRatio;
                        if (this.bDrag[1] || this.bDrag[0])
                            iFY += this.h - iFH;
                        this.h = iFH;
                    }
                }
                this.x = iFX;
                this.y = iFY;
            };
            CanvasSelector.prototype.onTouchMove = function (e) {
                var touch = e.touches[0];
                var mouseEvent = new MouseEvent('mousemove', touch);
                this.selectorWindowEl.dispatchEvent(mouseEvent);
            };
            // binding mousedown event
            CanvasSelector.prototype.OnMouseDown = function (e) { };
            CanvasSelector.prototype.onMouseDown = function (e) {
                var canvasOffset = this.getOffset(this.canvas);
                var iMouseX = Math.floor(e.clientX - canvasOffset.left);
                var iMouseY = Math.floor(e.clientY - canvasOffset.top);
                var rotated = this.rotateCoordinates({ x: iMouseX, y: iMouseY });
                iMouseX = rotated.x;
                iMouseY = rotated.y;
                this.px = iMouseX - this.x;
                this.py = iMouseY - this.y;
                for (var i = 0; i < 4; i++) {
                    if (!this.bHow[i])
                        continue;
                    this.px = iMouseX - this.x;
                    this.py = iMouseY - this.y;
                    if (i >= 2)
                        this.py -= this.h;
                    if (i === 1 || i === 2)
                        this.px -= this.w;
                }
                if (iMouseX > this.x + this.csizeh && iMouseX < this.x + this.w - this.csizeh &&
                    iMouseY > this.y + this.csizeh && iMouseY < this.y + this.h - this.csizeh) {
                    this.bDragAll = true;
                }
                for (var i = 0; i < 4; i++) {
                    if (this.bHow[i]) {
                        this.bDrag[i] = true;
                    }
                }
                this.OnMouseDown(e);
            };
            CanvasSelector.prototype.onTouchStart = function (e) {
                var touch = e.touches[0];
                var mouseEvent = new MouseEvent('mousemove', touch);
                this.selectorWindowEl.dispatchEvent(mouseEvent);
                mouseEvent = new MouseEvent('mousedown', touch);
                this.selectorWindowEl.dispatchEvent(mouseEvent);
            };
            // binding mouseup event
            CanvasSelector.prototype.OnMouseUp = function (e) { };
            CanvasSelector.prototype.onMouseUp = function (e) {
                this.bDragAll = false;
                for (var i = 0; i < 4; i++) {
                    this.bDrag[i] = false;
                }
                this.px = 0;
                this.py = 0;
                this.drawScene();
                this.OnMouseUp(e);
            };
            CanvasSelector.prototype.onTouchEnd = function (e) {
                var touch = e.touches[0];
                var mouseEvent = new MouseEvent('mouseup', touch);
                this.selectorWindowEl.dispatchEvent(mouseEvent);
            };
            CanvasSelector.prototype.onMouseLeave = function (e) {
                var canvasOffset = this.getOffset(this.canvas);
                var iMouseX = Math.floor(e.clientX - canvasOffset.left);
                var iMouseY = Math.floor(e.clientY - canvasOffset.top);
                var rotated = this.rotateCoordinates({ x: iMouseX, y: iMouseY });
                iMouseX = rotated.x;
                iMouseY = rotated.y;
                if (this.bDragAll) {
                    this.x = this.restrictPos(iMouseX - this.px, this.w, 0, this.backgroundImage.width / this.canvasProperties.ImageRatio);
                    this.y = this.restrictPos(iMouseY - this.py, this.h, 0, this.backgroundImage.height / this.canvasProperties.ImageRatio);
                }
                // in case of dragging of resize cubes
                var iFW, iFH, iFX, iFY;
                if (this.bDrag[0]) {
                    iFX = iMouseX - this.px;
                    iFY = iMouseY - this.py;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFX < 0)
                        iFY = 0;
                    iFW = this.w + this.x - iFX;
                    iFH = this.h + this.y - iFY;
                }
                if (this.bDrag[1]) {
                    iFX = this.x;
                    iFY = iMouseY - this.py;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFX < 0)
                        iFY = 0;
                    iFW = iMouseX - this.px - iFX;
                    iFH = this.h + this.y - iFY;
                }
                if (this.bDrag[2]) {
                    iFX = this.x;
                    iFY = this.y;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFX < 0)
                        iFY = 0;
                    iFW = iMouseX - this.px - iFX;
                    iFH = iMouseY - this.py - iFY;
                }
                if (this.bDrag[3]) {
                    iFX = iMouseX - this.px;
                    iFY = this.y;
                    if (iFX < 0)
                        iFX = 0;
                    if (iFX < 0)
                        iFY = 0;
                    iFW = this.w + this.x - iFX;
                    iFH = iMouseY - this.py - iFY;
                }
                if (iFW > this.csizeh * 2 && iFH > this.csizeh * 2) {
                    var canvasW = void 0, canvasH = void 0;
                    if (this.canvasProperties.DimensionsFlipped) {
                        canvasW = this.canvas.height;
                        canvasH = this.canvas.width;
                    }
                    else {
                        canvasW = this.canvas.width;
                        canvasH = this.canvas.height;
                    }
                    this.w = this.restrictPos(iFW, 0, 0, canvasW - iFX);
                    this.h = this.restrictPos(iFH, 0, 0, canvasH - iFY);
                    this.maintainSelRatio(this.x, this.y);
                }
                this.bDragAll = false;
                for (var i = 0; i < 4; i++) {
                    this.bDrag[i] = false;
                }
                this.px = 0;
                this.py = 0;
                this.drawScene();
            };
            // return size and position of the selected area
            CanvasSelector.prototype.getCoordinates = function () {
                return {
                    x: this.x * this.canvasProperties.ImageRatio,
                    y: this.y * this.canvasProperties.ImageRatio,
                    w: this.w * this.canvasProperties.ImageRatio,
                    h: this.h * this.canvasProperties.ImageRatio
                };
            };
            CanvasSelector.prototype.AfterDispose = function () { };
            CanvasSelector.prototype.dispose = function () {
                this.disableGestureHandling();
                this.selectorWindowEl.parentElement.removeChild(this.selectorWindowEl);
                return this.AfterDispose();
            };
            return CanvasSelector;
        }());
        ImageEditor.CanvasSelector = CanvasSelector;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=CanvasSelector.js.map