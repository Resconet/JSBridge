/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../../Helpers/exception.ts" />
/// <reference path="stepCollection.ts" />
/// <reference path="executionContext.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var ConditionGroup = /** @class */ (function (_super) {
                __extends(ConditionGroup, _super);
                function ConditionGroup() {
                    var _this = _super.call(this) || this;
                    _this.logicalOperator = LogicalOperator.And;
                    return _this;
                }
                ConditionGroup.prototype._getName = function () {
                    return "ConditionGroup";
                };
                ConditionGroup.deserializeXML = function ($step) {
                    var s = new ConditionGroup();
                    s._deserializeXML($step);
                    return s;
                };
                ConditionGroup.prototype._deserializeXML = function ($step) {
                    var op = $step.attr("op");
                    if (op && op == "Or") {
                        this.logicalOperator = LogicalOperator.Or;
                    }
                    _super.prototype._deserializeXML.call(this, $step);
                };
                ConditionGroup.prototype.execute = function (context) {
                    context.callStack.push(this);
                    var result = (this.logicalOperator == LogicalOperator.And);
                    for (var i = 0; i < this.steps.length; i++) {
                        var step = this.steps[i];
                        var stepResult = step.execute(context);
                        if (stepResult === null) {
                            throw new Resco.Exception("Invalid null result of step: " + step.fullName);
                        }
                        if (this.logicalOperator == LogicalOperator.And) {
                            result = result && stepResult;
                            if (!result) {
                                break;
                            }
                        }
                        else {
                            result = result || stepResult;
                            if (result) {
                                break;
                            }
                        }
                    }
                    context.callStack.pop();
                    return result;
                };
                return ConditionGroup;
            }(Workflow.StepCollection));
            Workflow.ConditionGroup = ConditionGroup;
            var LogicalOperator;
            (function (LogicalOperator) {
                /// <summary>The conditions should be evaluated as logical And.</summary>
                LogicalOperator[LogicalOperator["And"] = 0] = "And";
                /// <summary>The conditions should be evaluated as logical Or.</summary>
                LogicalOperator[LogicalOperator["Or"] = 1] = "Or";
            })(LogicalOperator = Workflow.LogicalOperator || (Workflow.LogicalOperator = {}));
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=conditionGroup.js.map