/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="expressionStep.ts" />
/// <reference path="executionContext.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var AssignmentStep = /** @class */ (function (_super) {
                __extends(AssignmentStep, _super);
                function AssignmentStep() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                AssignmentStep.prototype._getName = function () {
                    return "AssignmentStep";
                };
                AssignmentStep.deserializeXML = function ($step) {
                    var s = new AssignmentStep();
                    s._deserializeXML($step);
                    return s;
                };
                AssignmentStep.prototype.execute = function (context) {
                    context.callStack.push(this);
                    var v = this.getArgumentValue(context, 0);
                    context.setVariable(this.serializedVariable, v);
                    context.callStack.pop();
                    return null;
                };
                return AssignmentStep;
            }(Workflow.ExpressionStep));
            Workflow.AssignmentStep = AssignmentStep;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=assignmentStep.js.map