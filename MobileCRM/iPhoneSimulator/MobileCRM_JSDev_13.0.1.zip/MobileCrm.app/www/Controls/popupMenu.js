///<reference path="../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="event.ts" />
///<reference path="gestureManager.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var PopupMenu = /** @class */ (function () {
            function PopupMenu() {
                var _this = this;
                this._isOpened = false;
                this._items = [];
                this._innerItems = [];
                this._selectedIndex = -1;
                this._useBorder = false;
                this._gestureManager = new Controls.GestureManager();
                this.showIcons = true;
                this.zIndex = 110;
                this.x = 0;
                this.y = 0;
                this.width = 200;
                this.itemHeight = 40;
                this.separatorHeight = 1;
                this.iconSize = 32;
                this.backgroundColor = "transparent";
                this.menuColor = "lightgray";
                this.borderColor = "gray";
                this.lineColor = "gray";
                this.selectedColor = "deepskyblue";
                this.readOnlyColor = "gray";
                this.separatorColor = "gray";
                this.borderWidth = 1;
                this.onClose = new Resco.Event(this);
                this._onPointerDown = function (e) {
                    _this._manageSelection({ x: e.pageX, y: e.pageY });
                };
                this._onPointerMove = function (e) {
                    _this._manageSelection({ x: e.pageX, y: e.pageY });
                };
                this._onPointerUp = function (e) {
                    if ((_this._selectedIndex >= 0) && (_this._selectedIndex < _this._innerItems.length)) {
                        var selectedItem = _this._innerItems[_this._selectedIndex];
                        if (selectedItem.onClick) {
                            selectedItem.onClick(e.jQueryEventObject);
                        }
                        _this._unselectSelectedItem();
                        if (selectedItem.isReadOnly || selectedItem.isSeparator) {
                            return;
                        }
                    }
                    _this.close();
                };
            }
            Object.defineProperty(PopupMenu.prototype, "element", {
                get: function () {
                    if (!this._element)
                        this._element = this._createPopupMenuElement();
                    return this._element;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenu.prototype, "contentElement", {
                get: function () {
                    return this.element.children(".content");
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenu.prototype, "items", {
                get: function () {
                    return this._items;
                },
                set: function (value) {
                    this._items = value || [];
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenu.prototype, "useBorder", {
                get: function () {
                    return this._useBorder;
                },
                set: function (value) {
                    this._useBorder = value;
                    if (this.useBorder) {
                        this.contentElement.addClass("hasBorder");
                    }
                    else {
                        this.contentElement.removeClass("hasBorder");
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenu.prototype, "isOpened", {
                get: function () {
                    return this._isOpened;
                },
                enumerable: true,
                configurable: true
            });
            PopupMenu.prototype._createPopupMenuElement = function () {
                var template = '\
				<div class="popupMenu">\
					<div class="content">\
					</div>\
				</div>\
			';
                return $(template);
            };
            PopupMenu.prototype.open = function () {
                this.close();
                this._isOpened = true;
                this._selectedIndex = -1;
                this._addEvents();
                this._updateElement();
                $("body").append(this.element);
            };
            PopupMenu.prototype.close = function () {
                if (this._isOpened) {
                    this._removeEvents();
                    this.element.remove();
                    this.onClose.raise(Resco.EventArgs.Empty);
                    this._isOpened = false;
                }
            };
            PopupMenu.prototype._addEvents = function () {
                this._gestureManager.onDownMoveUpCancel(this.element, this._onPointerDown, this._onPointerMove, this._onPointerUp, this._onPointerUp);
            };
            PopupMenu.prototype._removeEvents = function () {
                this._gestureManager.offDownMoveUpCancel(this.element, this._onPointerDown, this._onPointerMove, this._onPointerUp, this._onPointerUp);
            };
            PopupMenu.prototype._updateElement = function () {
                this.contentElement.empty();
                this.element.css({ zIndex: this.zIndex });
                this.element.css({ "background-color": this.backgroundColor });
                this.contentElement.css({ "background-color": this.menuColor });
                this.contentElement.css({ "border-color": this.borderColor });
                this.contentElement.css({ "border-width": this.borderWidth });
                this._innerItems = [];
                var hasIcons = false;
                for (var i = 0; i < this.items.length; i++)
                    if (this.items[i].image) {
                        hasIcons = true;
                        break;
                    }
                if (!hasIcons)
                    this.showIcons = false;
                for (var i = 0; i < this.items.length; i++) {
                    var itemWrapper = new PopupMenuItemWrapper(this, this.items[i]);
                    this.contentElement.append(itemWrapper.element);
                    this._innerItems.push(itemWrapper);
                }
                var width = this.width + 2 * this.borderWidth;
                var height = this._getItemsHeight() + 2 * this.borderWidth;
                var insideOffset = this._getOffsetInsideRectangle(width, height);
                this.contentElement.css({ left: insideOffset.x, top: insideOffset.y, width: width, height: height });
            };
            PopupMenu.prototype._getItemsHeight = function () {
                var height = 0;
                for (var i = 0; i < this._innerItems.length; i++) {
                    if (this._innerItems[i].isSeparator) {
                        height += this.separatorHeight;
                    }
                    else {
                        height += this.itemHeight;
                    }
                }
                return height;
            };
            PopupMenu.prototype._getOffsetInsideRectangle = function (width, height) {
                var x = this.x;
                var y = this.y;
                if (this.insideRectangle) {
                    if (x < this.insideRectangle.x)
                        x = this.insideRectangle.x;
                    if (y < this.insideRectangle.y)
                        y = this.insideRectangle.y;
                    if ((x + width) > (this.insideRectangle.x + this.insideRectangle.width))
                        x = (this.insideRectangle.x + this.insideRectangle.width) - width;
                    if ((y + height) > (this.insideRectangle.y + this.insideRectangle.height))
                        y = (this.insideRectangle.y + this.insideRectangle.height) - height;
                }
                return { x: x, y: y };
            };
            /// Returns -1 if touch point is outside popup menu content.
            PopupMenu.prototype._getItemIndex = function (point) {
                var contentOffset = this.contentElement.offset();
                var contentBounds = { x: contentOffset.left, y: contentOffset.top, width: this.contentElement.width(), height: this.contentElement.height() };
                if ((point.x >= contentBounds.x) && (point.x < (contentBounds.x + contentBounds.width))) {
                    if ((point.y >= contentBounds.y) && (point.y < (contentBounds.y + contentBounds.height))) {
                        var vPosition = (point.y - contentBounds.y) + this.contentElement.scrollTop();
                        var index = this._getItemIndexFromVPosition(vPosition);
                        if ((index >= 0) && (index < this._innerItems.length))
                            return index;
                    }
                }
                return -1;
            };
            PopupMenu.prototype._getItemIndexFromVPosition = function (vPosition) {
                if (vPosition >= 0) {
                    for (var i = 0; i < this._innerItems.length; i++) {
                        if (this._innerItems[i].isSeparator) {
                            vPosition -= this.separatorHeight;
                        }
                        else {
                            vPosition -= this.itemHeight;
                        }
                        if (vPosition < 0) {
                            return i;
                        }
                    }
                }
                return -1;
            };
            PopupMenu.prototype._manageSelection = function (point) {
                var index = this._getItemIndex(point);
                if (index != this._selectedIndex) {
                    this._unselectSelectedItem();
                    this._selectedIndex = index;
                    this._selectSelectedItem();
                }
            };
            PopupMenu.prototype._selectSelectedItem = function () {
                if ((this._selectedIndex >= 0) && (this._selectedIndex < this._innerItems.length)) {
                    this._innerItems[this._selectedIndex].setSelection(true);
                }
            };
            PopupMenu.prototype._unselectSelectedItem = function () {
                if ((this._selectedIndex >= 0) && (this._selectedIndex < this._innerItems.length)) {
                    this._innerItems[this._selectedIndex].setSelection(false);
                    this._selectedIndex = -1;
                }
            };
            return PopupMenu;
        }());
        Controls.PopupMenu = PopupMenu;
        var PopupMenuItem = /** @class */ (function () {
            function PopupMenuItem(text, image, onClick) {
                this.text = text;
                this.image = image;
                this.onClick = onClick;
            }
            return PopupMenuItem;
        }());
        Controls.PopupMenuItem = PopupMenuItem;
        var PopupMenuReadOnlyItem = /** @class */ (function (_super) {
            __extends(PopupMenuReadOnlyItem, _super);
            function PopupMenuReadOnlyItem(text, image) {
                return _super.call(this, text, image) || this;
            }
            return PopupMenuReadOnlyItem;
        }(PopupMenuItem));
        Controls.PopupMenuReadOnlyItem = PopupMenuReadOnlyItem;
        var PopupMenuSeparatorItem = /** @class */ (function (_super) {
            __extends(PopupMenuSeparatorItem, _super);
            function PopupMenuSeparatorItem() {
                return _super.call(this, "") || this;
            }
            return PopupMenuSeparatorItem;
        }(PopupMenuItem));
        Controls.PopupMenuSeparatorItem = PopupMenuSeparatorItem;
        var PopupMenuItemWrapper = /** @class */ (function () {
            function PopupMenuItemWrapper(popupMenu, popupMenuItem) {
                this._popupMenu = popupMenu;
                this._popupMenuItem = popupMenuItem;
            }
            Object.defineProperty(PopupMenuItemWrapper.prototype, "element", {
                get: function () {
                    if (!this._element)
                        this._element = this._createElement();
                    return this._element;
                },
                enumerable: true,
                configurable: true
            });
            PopupMenuItemWrapper.prototype._createElement = function () {
                var itemElement = $("<div>").addClass("item");
                if (this.isSeparator) {
                    itemElement.addClass("separator");
                    itemElement.height(this._popupMenu.separatorHeight);
                    itemElement.css({ "background-color": this._popupMenu.separatorColor });
                }
                else {
                    var textElement = $("<div>").addClass("text");
                    itemElement.height(this._popupMenu.itemHeight);
                    if (this._popupMenu.showIcons) {
                        textElement.css({ "border-left-color": this._popupMenu.lineColor });
                        var imageBoxElement = $("<div>").addClass("imageBox");
                        imageBoxElement.width(this._popupMenu.itemHeight);
                        imageBoxElement.height(this._popupMenu.itemHeight);
                        if (this.image) {
                            var iconSize = this._popupMenu.iconSize ? this._popupMenu.iconSize : this._popupMenu.itemHeight;
                            var imageElement = $("<div>").addClass("image");
                            imageElement.width(iconSize);
                            imageElement.height(iconSize);
                            imageElement.css({ "background-image": this.image });
                            imageBoxElement.append(imageElement);
                        }
                        itemElement.append(imageBoxElement);
                    }
                    else {
                        textElement.css({ "border-left-style": "hidden" });
                    }
                    if (this.isReadOnly) {
                        itemElement.addClass("readonly");
                        textElement.css({ "color": this._popupMenu.readOnlyColor });
                    }
                    textElement.text(this.text);
                    itemElement.append(textElement);
                }
                return itemElement;
            };
            PopupMenuItemWrapper.prototype.setSelection = function (selected) {
                if (selected)
                    this.element.addClass("selected");
                else
                    this.element.removeClass("selected");
                if (!this.isReadOnly && !this.isSeparator) {
                    this.element.css({ "background-color": selected ? this._popupMenu.selectedColor : "" });
                }
            };
            Object.defineProperty(PopupMenuItemWrapper.prototype, "isReadOnly", {
                get: function () {
                    return (this._popupMenuItem instanceof PopupMenuReadOnlyItem) ? true : false;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenuItemWrapper.prototype, "isSeparator", {
                get: function () {
                    return (this._popupMenuItem instanceof PopupMenuSeparatorItem) ? true : false;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenuItemWrapper.prototype, "text", {
                get: function () {
                    return this._popupMenuItem.text;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenuItemWrapper.prototype, "image", {
                get: function () {
                    return this._popupMenuItem.image;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(PopupMenuItemWrapper.prototype, "onClick", {
                get: function () {
                    return this._popupMenuItem.onClick;
                },
                enumerable: true,
                configurable: true
            });
            return PopupMenuItemWrapper;
        }());
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=popupMenu.js.map