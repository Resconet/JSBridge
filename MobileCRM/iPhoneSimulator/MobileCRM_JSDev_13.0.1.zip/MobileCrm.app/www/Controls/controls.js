/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        "use strict";
        /**
         * Set of the main properties of the window size and content element size.
         * @DM: to-do: move to separate file
         * @DM: singleton? now is sent as parameter to all components
         */
        var WindowSizeMonitor = /** @class */ (function () {
            function WindowSizeMonitor() {
                var _this = this;
                this.m_headerSpace = 50; // @DM: default height of header.
                this.width = ko.observable(0);
                this.height = ko.observable(0);
                this.contentHeight = ko.computed(function () {
                    return _this.height() - _this.m_headerSpace;
                }, this);
                this.contentScrollTop = ko.observable(0);
                this.contentClientHeight = ko.observable(0);
                this.contentClientWidth = ko.observable(0);
                this.changeSize();
                window.addEventListener("resize", function () {
                    _this.changeSize();
                });
            }
            /**
             * Method to set new values for width and height.
             */
            WindowSizeMonitor.prototype.changeSize = function () {
                this.width(window.innerWidth);
                this.height(window.innerHeight);
            };
            return WindowSizeMonitor;
        }());
        Controls.WindowSizeMonitor = WindowSizeMonitor;
        /**
         * One item of the Selection list component
         * @DM: to-do: move to separate file
         */
        var SelectionListItem = /** @class */ (function () {
            function SelectionListItem(logicalName, displayName) {
                this.logicalName = logicalName;
                this.displayName = displayName || this.logicalName;
            }
            return SelectionListItem;
        }());
        Controls.SelectionListItem = SelectionListItem;
        /**
         * ViewModel for component that displays list of items. Every item is clickable and after click it sends information
         * about selected item to the ViewModel where is callback defined.
         * using: knockout.js is required.
         * 1. register component with registerSelectionListComponent() from controlsTemplate.js
         * 2. initialize component: params are set by 'SelectionListParameters'
         * <!-- ko component: { name: \"selectionListComponent\", params: { items: ..., sizeMonitor: ...., callback: ... }} -->\<!-- /ko -->\
         * @DM: to-do: move to separate file
         */
        var SelectionList = /** @class */ (function () {
            function SelectionList(params) {
                this.items = new Array();
                this.items = this._sortItems(params.items);
                this.sizeMonitor = params.sizeMonitor;
                this.callback = params.callback;
            }
            /**
             * Method called after click on the item in the list of entities.
             * @param index index of item where was clicked
             * @param sender sender
             * @param e event
             */
            SelectionList.prototype.confirmSelectedEntity = function (index, sender, e) {
                if (typeof index === "number") {
                    this.callback(this.items[index]);
                }
            };
            SelectionList.prototype._sortItems = function (items) {
                var sortedItems = new Array();
                sortedItems = items.sort(function (i1, i2) {
                    var displayName1 = i1.displayName.toLowerCase();
                    var displayName2 = i2.displayName.toLowerCase();
                    if (displayName1 < displayName2)
                        return -1;
                    if (displayName1 > displayName2)
                        return 1;
                    return 0;
                });
                return sortedItems;
            };
            return SelectionList;
        }());
        Controls.SelectionList = SelectionList;
        /**
         * Class represents image button in the ImageBar ViewModel
         */
        var ImageBarItem = /** @class */ (function () {
            function ImageBarItem() {
                this.enabled = ko.observable();
                this.selected = ko.observable();
                this.width = ko.observable();
                this.height = ko.observable();
                this.name = "";
                this.path = "";
            }
            return ImageBarItem;
        }());
        Controls.ImageBarItem = ImageBarItem;
        /**
         * ViewModel represents HTML component of Image-bar. It's viewModel for component imageBar. Every ImageBarItem is clickable.
         * Using: knockout.js is required.
         * 1. register Image-Bar component with calls function registerImageBar().
         * 2. initialize component: params are set by 'ImageBarParams'
         * <!-- ko component: { name: \"imageBar\", params: { items: ..., sizeMonitor: ...., callback: ... }} -->\<!-- /ko -->\
         */
        var ImageBar = /** @class */ (function () {
            function ImageBar(params) {
                this.images = params.items;
                this._sizeMonitor = params.sizeMonitor;
                this.callback = params.callback;
                this._updateItemsSize();
            }
            ImageBar.prototype._updateItemsSize = function () {
                if (this._sizeMonitor) {
                    var imageSize_1 = this._sizeMonitor.width() / this.images.length;
                    imageSize_1 -= 4; // @DM: 4 is margin from both sides of the image;
                    this.images.forEach(function (i) { i.width(imageSize_1); i.height(imageSize_1); });
                }
            };
            /**
             * Calls after click on one of the Icon in the bar.
             * @param sender object which calls method.
             * @param e event
             */
            ImageBar.prototype.clickOnItem = function (sender, e) {
                var icon = sender;
                this._disableSelection();
                this.callback(icon);
            };
            ImageBar.prototype._disableSelection = function () {
                var originalSelection = this.images.filter(function (i) { return i.selected(); });
                if (originalSelection && originalSelection.length > 0) {
                    originalSelection.forEach(function (i) { i.selected(false); });
                }
            };
            return ImageBar;
        }());
        Controls.ImageBar = ImageBar;
        /**
         * The possible crm type used in axis or series.
         * @DM: to-do: move to separate file
         */
        var CrmType;
        (function (CrmType) {
            /// <summary>Boolean property; <see cref="bool"/>.</summary>
            CrmType[CrmType["Boolean"] = 0] = "Boolean";
            /// <summary>Customer, special kind of <i>Lookup</i> property, only for <i>Accounts</i> and <i>Contacts</i>; <see cref="Guid"/>.</summary>
            CrmType[CrmType["Customer"] = 1] = "Customer";
            /// <summary>Date property; <see cref="DateTime"/>.</summary>
            CrmType[CrmType["DateTime"] = 2] = "DateTime";
            /// <summary>Decimal property; <see cref="decimal"/>.</summary>
            CrmType[CrmType["Decimal"] = 3] = "Decimal";
            /// <summary>Float property; <see cref="float"/>.</summary>
            CrmType[CrmType["Float"] = 4] = "Float";
            /// <summary>Integer property; <see cref="int"/>.</summary>
            CrmType[CrmType["Integer"] = 5] = "Integer";
            /// <summary>Internal property.</summary>
            CrmType[CrmType["Internal"] = 6] = "Internal";
            /// <summary>Lookup property, generally used for foreign keys; <see cref="Guid"/>.</summary>
            CrmType[CrmType["Lookup"] = 7] = "Lookup";
            /// <summary>Memo property, large string; <see cref="string"/>.</summary>
            CrmType[CrmType["Memo"] = 8] = "Memo";
            /// <summary>Money property; <see cref="decimal"/>.</summary>
            CrmType[CrmType["Money"] = 9] = "Money";
            /// <summary>Owner property.</summary>
            CrmType[CrmType["Owner"] = 10] = "Owner";
            /// <summary>PartyList property.</summary>
            CrmType[CrmType["PartyList"] = 11] = "PartyList";
            /// <summary>Pick-list property, allows to pick a value from a list; <see cref="int"/>.</summary>
            CrmType[CrmType["Picklist"] = 12] = "Picklist";
            /// <summary>Primary key property; <see cref="Guid"/>.</summary>
            CrmType[CrmType["PrimaryKey"] = 13] = "PrimaryKey";
            /// <summary>State property; Must not be used.</summary>
            CrmType[CrmType["State"] = 14] = "State";
            /// <summary>Status property, special kind of Pick-list; <see cref="int"/>.</summary>
            CrmType[CrmType["Status"] = 15] = "Status";
            /// <summary>String property; <see cref="string"/>.</summary>
            CrmType[CrmType["String"] = 16] = "String";
            /// <summary>Unique identifier; <see cref="Guid"/>.</summary>
            CrmType[CrmType["UniqueIdentifier"] = 17] = "UniqueIdentifier";
            /// <summary>Virtual property.</summary>
            CrmType[CrmType["Virtual"] = 18] = "Virtual";
            /// <summary>CalendarRules property.</summary>
            CrmType[CrmType["CalendarRules"] = 19] = "CalendarRules";
            /// <summary>EntityName property; Must not be used.</summary>
            CrmType[CrmType["EntityName"] = 20] = "EntityName";
            /// <summary>BigInt property; CRM2011 specific. Used for version number instead of String in CRM4</summary>
            CrmType[CrmType["BigInt"] = 21] = "BigInt";
            /// <summary>Double property; CRM2011 specific. Specifies a double attribute.</summary>
            CrmType[CrmType["Double"] = 22] = "Double";
            /// <summary>Double ManagedProperty; CRM2011 specific. Specifies a managed property attribute.</summary>
            CrmType[CrmType["ManagedProperty"] = 23] = "ManagedProperty";
            /// <summary>Special type used in RescoXRM.</summary>
            CrmType[CrmType["RowVersion"] = 524288] = "RowVersion";
            /// <summary>Special type used in RescoXRM.</summary>
            CrmType[CrmType["Binary"] = 524289] = "Binary";
            CrmType[CrmType["PicklistArray"] = 524290] = "PicklistArray";
            /// <summary>Special type used in Rules.</summary>
            CrmType[CrmType["StringList"] = 524291] = "StringList";
            /// <summary>Special type used in Rules.</summary>
            CrmType[CrmType["Entity"] = 524292] = "Entity";
        })(CrmType = Controls.CrmType || (Controls.CrmType = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=controls.js.map