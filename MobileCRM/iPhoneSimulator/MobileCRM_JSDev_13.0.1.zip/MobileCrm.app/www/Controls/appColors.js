/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="event.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        /**
         *  AppColors object that loads and holds colors used in application.
         */
        var AppColors = /** @class */ (function () {
            function AppColors() {
                this.propertyChanged = new Resco.Event(this);
            }
            AppColors.prototype.clone = function () {
                var appColors = new AppColors();
                appColors._formBackgroundColor = this.formBackgroundColor;
                appColors._titleBackgroundColor = this.titleBackgroundColor;
                appColors._titleForegroundColor = this.titleForegroundColor;
                appColors._formItemBackgroundColor = this.formItemBackgroundColor;
                appColors._formItemLabelForegroundColor = this.formItemLabelForegroundColor;
                appColors._formItemLinkColor = this.formItemLinkColor;
                appColors._listBackgroundColor = this.listBackgroundColor;
                appColors._listForegroundColor = this.listForegroundColor;
                appColors._listSelBackgroundColor = this.listSelBackgroundColor;
                appColors._listSelForegroundColor = this.listSelForegroundColor;
                appColors._listSeparatorColor = this.listSeparatorColor;
                return appColors;
            };
            Object.defineProperty(AppColors.prototype, "formBackgroundColor", {
                get: function () {
                    return this._formBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.formBackgroundColor) {
                        this._formBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "titleBackgroundColor", {
                get: function () {
                    return this._titleBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.titleBackgroundColor) {
                        this._titleBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("titleBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "titleForegroundColor", {
                get: function () {
                    return this._titleForegroundColor;
                },
                set: function (value) {
                    if (value !== this.titleForegroundColor) {
                        this._titleForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("titleForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "formItemBackgroundColor", {
                get: function () {
                    return this._formItemBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.formItemBackgroundColor) {
                        this._formItemBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formItemBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "formItemLabelForegroundColor", {
                get: function () {
                    return this._formItemLabelForegroundColor;
                },
                set: function (value) {
                    if (value !== this.formItemLabelForegroundColor) {
                        this._formItemLabelForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formItemLabelForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "formItemLinkColor", {
                get: function () {
                    return this._formItemLinkColor;
                },
                set: function (value) {
                    if (value !== this.formItemLinkColor) {
                        this._formItemLinkColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formItemLinkColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listBackgroundColor", {
                get: function () {
                    return this._listBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.listBackgroundColor) {
                        this._listBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listForegroundColor", {
                get: function () {
                    return this._listForegroundColor;
                },
                set: function (value) {
                    if (value !== this.listForegroundColor) {
                        this._listForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listSelBackgroundColor", {
                get: function () {
                    return this._listSelBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.listSelBackgroundColor) {
                        this._listSelBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listSelBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listSelForegroundColor", {
                get: function () {
                    return this._listSelForegroundColor;
                },
                set: function (value) {
                    if (value !== this.listSelForegroundColor) {
                        this._listSelForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listSelForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listSeparatorColor", {
                get: function () {
                    return this._listSeparatorColor;
                },
                set: function (value) {
                    if (value !== this.listSeparatorColor) {
                        this._listSeparatorColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listSeparatorColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            AppColors.prototype._loadColors = function (onFinishCallback) {
                var _this = this;
                var promises = [];
                promises.push(this._loadColor("FormBackground").then(function (value) {
                    _this.formBackgroundColor = value;
                }));
                promises.push(this._loadColor("TitleBackground").then(function (value) {
                    _this.titleBackgroundColor = value;
                }));
                promises.push(this._loadColor("TitleForeground").then(function (value) {
                    _this.titleForegroundColor = value;
                }));
                promises.push(this._loadColor("FormItemBackground").then(function (value) {
                    _this.formItemBackgroundColor = value;
                }));
                promises.push(this._loadColor("FormItemLabelForeground").then(function (value) {
                    _this.formItemLabelForegroundColor = value;
                }));
                promises.push(this._loadColor("FormItemLink").then(function (value) {
                    _this.formItemLinkColor = value;
                }));
                promises.push(this._loadColor("ListBackground").then(function (value) {
                    _this.listBackgroundColor = value;
                }));
                promises.push(this._loadColor("ListForeground").then(function (value) {
                    _this.listForegroundColor = value;
                }));
                promises.push(this._loadColor("ListSelBackground").then(function (value) {
                    _this.listSelBackgroundColor = value;
                }));
                promises.push(this._loadColor("ListSelForeground").then(function (value) {
                    _this.listSelForegroundColor = value;
                }));
                promises.push(this._loadColor("ListSeparator").then(function (value) {
                    _this.listSeparatorColor = value;
                }));
                Promise.all(promises).then(function () {
                    onFinishCallback();
                });
            };
            AppColors.prototype._loadColor = function (colorName) {
                return new Promise(function (resolve, reject) {
                    MobileCRM.Application.getAppColor(colorName, function (result) {
                        resolve(result);
                    }, function (err) {
                        resolve(undefined);
                    });
                });
            };
            AppColors.initialize = function (onFinishCallback) {
                var appColors = new AppColors();
                appColors._loadColors(function () {
                    onFinishCallback(appColors);
                });
            };
            return AppColors;
        }());
        Controls.AppColors = AppColors;
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=appColors.js.map