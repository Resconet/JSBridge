///<reference path="utilities.ts" />
///<reference path="container.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var ReductionType;
            (function (ReductionType) {
                ReductionType[ReductionType["None"] = 0] = "None";
                ReductionType[ReductionType["ButtonsTexts"] = 1] = "ButtonsTexts";
                ReductionType[ReductionType["ButtonsTextsAndFilterStatus"] = 2] = "ButtonsTextsAndFilterStatus";
                ReductionType[ReductionType["All"] = 3] = "All"; // Buttons texts are hidden and whole filter status is hidden
            })(ReductionType || (ReductionType = {}));
            var FilterStatus = /** @class */ (function () {
                function FilterStatus() {
                    this.rangeLabel = "";
                    this.rangeText = "";
                    this.filtersLabel = "";
                    this.filtersText = "";
                }
                return FilterStatus;
            }());
            Scheduler.FilterStatus = FilterStatus;
            var ButtonsBar = /** @class */ (function () {
                /**
                 * Update minWidth in this._updateReducedWidth() method also if any button/item is added or removed from ButtonsBar.
                 */
                function ButtonsBar() {
                    this._reductionType = ReductionType.None;
                    this._filterStatus = new FilterStatus();
                    this._tmpPart0 = '<div id="schedulerButtonsBar">';
                    this._tmpSettings = '\
				<div class="toolbarButton" onclick="Resco.Controls.Scheduler.SettingsDialog.show(Resco.Controls.Scheduler.Container.ref);">\
					<div id="settingsIcon" class="imageButton" style="background-image: url(\'settings.png\');"></div>\
					<div id="showSettingsDialog" class="textButton" data-localization="Scheduler.Msg.SETTINGS">SETTINGS</div>\
				</div>';
                    this._tmpPart1 = '\
				<div class="toolbarButton" onclick="Resco.Controls.Scheduler.Container.ref.buttonsBar.onAutoPlannerClick();">\
					<div id="autoPlannerIcon" class="imageButton" style="background-image: url(\'settingsM.png\');"></div>\
					<div id="runReschedule" class="textButton" data-localization="Scheduler.Msg.RUNAUTOSCHEDULE">RUN AUTO-SCHEDULE</div>\
				</div>';
                    this._tmpShowHideMarkers = '\
				<div class="toolbarButton hidden" onclick="Resco.Controls.Scheduler.Container.ref.buttonsBar.onShowHideMarkers();">\
					<div id="showHideMarkersIcon" class="imageButton" style="background-image: url(\'resourceShown.png\');"></div>\
					<div id="showHideMarkersText" class="textButton" data-localization="Scheduler.Msg.SHOWHIDE">SHOW/HIDE</div>\
				</div>';
                    this._tmpPart2 = '\
				<div class="labelBar">\
					<div id="filterStatus"></div>\
				</div>';
                    this._tmpViewSwitch = '\
				<div class="toolbarButton" onclick="Resco.Controls.Scheduler.Container.ref.onViewChanged();">\
					<div id="viewTypeIcon" class="imageButton"></div>\
				</div>';
                    this._tmpPart3 = '\
					<div class="zoomControl">\
					<div id="leftArrow" onclick="Resco.Controls.Scheduler.Container.ref.viewCtrl.doPageScroll(-1);"></div>\
					<div id="todayButton" class="textButton" onclick="Resco.Controls.Scheduler.Container.ref.viewCtrl.showDate(null);" data-localization="Msg.TODAY">TODAY</div>\
					<div id="rightArrow" onclick="Resco.Controls.Scheduler.Container.ref.viewCtrl.doPageScroll(+1);"></div>\
					<div id="calendarPreview" onclick="Resco.Controls.Scheduler.Container.ref.viewCtrl.openCalendarPreview();">\
						<div class="calendarPreviewIcon"></div>\
						<div class="calendarPreviewArrow"></div>\
					</div>\
					<select id="zoomLevel" onChange="Resco.Controls.Scheduler.Container.ref.viewCtrl.setZoomLevel();">\
						<option value="h" data-localization="Msg.Day">Day</option>\
						<option value="h2" data-localization="Msg.Days" data-localizationvalues="2">2 Days</option>\
						<option value="h3" data-localization="Msg.Days" data-localizationvalues="3">3 Days</option>\
						<option value="d" data-localization="Msg.Week">Week</option>\
						<option value="d2" data-localization="Msg.Weeks" data-localizationvalues="2">2 Weeks</option>\
						<option value="d4" data-localization="Msg.Weeks" data-localizationvalues="4">4 Weeks</option>\
						<option value="d6" data-localization="Msg.Weeks" data-localizationvalues="6">6 Weeks</option>\
						<option value="m" data-localization="Msg.MonthOverview">Month overview</option>\
					</select>\
				</div>\
				<div class="toolbarButton toolbarRightButton" onclick="Resco.Controls.Scheduler.Container.ref.buttonsBar.onShowHideQuickMenu();">\
					<div id="quickMenuIcon" class="imageButton" style="background-image: url(\'settings.png\');"></div>\
				</div>\
			</div>\
		';
                    this._template = this._tmpPart0 + this._tmpPart1 + (Scheduler.Container.constants.enableMapView ? (this._tmpShowHideMarkers + this._tmpPart2 + this._tmpViewSwitch) : this._tmpPart2) + this._tmpPart3;
                    this.showHideMarkersIconElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "resourceShown.png" + ")" });
                }
                Object.defineProperty(ButtonsBar.prototype, "element", {
                    get: function () {
                        if (!this._element)
                            this._element = this._createButtonsBarElement();
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "autoPlannerElement", {
                    //get filterElement(): JQuery {
                    //	return this.element.find("#settingsIcon");
                    //}
                    get: function () {
                        return this.element.find("#autoPlannerIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "filterStatusElement", {
                    get: function () {
                        return this.element.find("#filterStatus");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideMarkersIconElement", {
                    get: function () {
                        return this.element.find("#showHideMarkersIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideMarkersTextElement", {
                    get: function () {
                        return this.element.find("#showHideMarkersText");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "leftArrowElement", {
                    get: function () {
                        return this.element.find("#leftArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "todayButtonElement", {
                    get: function () {
                        return this.element.find("#todayButton");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "rightArrowElement", {
                    get: function () {
                        return this.element.find("#rightArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewElement", {
                    get: function () {
                        return this.element.find("#calendarPreview");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewIconElement", {
                    get: function () {
                        return this.calendarPreviewElement.find(".calendarPreviewIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewArrowElement", {
                    get: function () {
                        return this.calendarPreviewElement.find(".calendarPreviewArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "zoomLevelElement", {
                    get: function () {
                        return this.element.find("#zoomLevel");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "quickMenuElement", {
                    get: function () {
                        return this.element.find("#quickMenuIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "viewTypeElement", {
                    get: function () {
                        return this.element.find("#viewTypeIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showHideAllSources", {
                    get: function () {
                        var view = Scheduler.Container.ref.viewCtrl;
                        if (view && (view instanceof Scheduler.MapView)) {
                            return view.showHideAllSources;
                        }
                        return false;
                    },
                    set: function (value) {
                        var view = Scheduler.Container.ref.viewCtrl;
                        if (view && (view instanceof Scheduler.MapView)) {
                            view.showHideAllSources = value;
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "showTasksOfAllResources", {
                    get: function () {
                        var view = Scheduler.Container.ref.viewCtrl;
                        if (view && (view instanceof Scheduler.MapView)) {
                            return view.showTasksOfAllResources;
                        }
                        return false;
                    },
                    set: function (value) {
                        var view = Scheduler.Container.ref.viewCtrl;
                        if (view && (view instanceof Scheduler.MapView)) {
                            view.showTasksOfAllResources = value;
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "hideTasksOfAllResources", {
                    get: function () {
                        var view = Scheduler.Container.ref.viewCtrl;
                        if (view && (view instanceof Scheduler.MapView)) {
                            return view.hideTasksOfAllResources;
                        }
                        return false;
                    },
                    set: function (value) {
                        var view = Scheduler.Container.ref.viewCtrl;
                        if (view && (view instanceof Scheduler.MapView)) {
                            view.hideTasksOfAllResources = value;
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                ButtonsBar.prototype.updateAutoPlannerIcon = function () {
                    var mode = Scheduler.Container.ref.settings.autoPlanner.manualScheduleMode;
                    var element = this.autoPlannerElement[0];
                    if (mode == Scheduler.eMode.Manual)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsM.png");
                    else if (mode == Scheduler.eMode.SemiOptimized)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsS.png");
                    else if (mode == Scheduler.eMode.RouteOptimization)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsT.png");
                    else
                        Scheduler.Container.setElementBackgroundImage(element, "settingsA.png");
                };
                //public onCustomFilterChanged(hasFilter: boolean): void {
                //	let icon = this.filterElement;
                //	if (icon) {
                //		let image = Container.imageFolder + (hasFilter ? "settingsFiltered.png" : "settings.png");
                //		icon.css({ "background-image": "url("+image+")" });
                //	}
                //};
                ButtonsBar.prototype.onAutoPlannerStateChanged = function (started) {
                    var buttonCtrl = this.element.find("#runReschedule");
                    if (buttonCtrl) {
                        if (started)
                            buttonCtrl.text(Scheduler.StringTable.get("Scheduler.Msg.STOPAUTOSCHEDULE") || "STOP AUTO-SCHEDULE");
                        else
                            buttonCtrl.text(Scheduler.StringTable.get("Scheduler.Msg.RUNAUTOSCHEDULE") || "RUN AUTO-SCHEDULE");
                    }
                    if (started) {
                        var element = this.autoPlannerElement[0];
                        Scheduler.Container.setElementBackgroundImage(element, "stop.png");
                    }
                    else
                        this.updateAutoPlannerIcon();
                };
                ButtonsBar.prototype.onAutoPlannerClick = function () {
                    if (!this.autoPlannerPopupMenu) {
                        this.autoPlannerPopupMenu = new Controls.PopupMenu();
                        this.autoPlannerPopupMenu.width = 350;
                        this.autoPlannerPopupMenu.iconSize = 22;
                        this.autoPlannerPopupMenu.menuColor = Scheduler.Container.constants.componentsBackgroundColor;
                        this.autoPlannerPopupMenu.borderColor = Scheduler.Container.constants.componentsBorderColor;
                        this.autoPlannerPopupMenu.useBorder = true;
                    }
                    this.autoPlannerPopupMenu.items = [];
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.SemiOptimization") || "Optimize schedules per Resource", "url(" + Scheduler.Container.imageFolder + "settingsS.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.SemiOptimized);
                    }));
                    if (Scheduler.Container.ref.travelCalculationIsEnabled) {
                        this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.RouteOptimization") || "Optimized Route (per day)", "url(" + Scheduler.Container.imageFolder + "settingsT.png)", function (e) {
                            Scheduler.AutoPlanner.Core.run(Scheduler.eMode.RouteOptimization);
                        }));
                    }
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.FullOptimization") || "Complete Optimization", "url(" + Scheduler.Container.imageFolder + "settingsA.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.Optimized);
                    }));
                    var offset = this.autoPlannerElement.offset();
                    this.autoPlannerPopupMenu.x = offset.left;
                    this.autoPlannerPopupMenu.y = this.element.outerHeight(true);
                    this.autoPlannerPopupMenu.open();
                };
                ButtonsBar.prototype.showHideMapViewButtons = function (show) {
                    var showHideMarkersButton = this.showHideMarkersIconElement.parent();
                    if (showHideMarkersButton.length > 0) {
                        if (show) {
                            showHideMarkersButton.removeClass("hidden");
                        }
                        else {
                            showHideMarkersButton.addClass("hidden");
                        }
                        this._updateReducedWidth();
                    }
                };
                ButtonsBar.prototype.onShowHideMarkers = function () {
                    var _this = this;
                    if (!this.showHideMarkersPopupMenu) {
                        this.showHideMarkersPopupMenu = new Controls.PopupMenu();
                        this.showHideMarkersPopupMenu.width = 300;
                        this.showHideMarkersPopupMenu.iconSize = 22;
                        this.showHideMarkersPopupMenu.menuColor = Scheduler.Container.constants.componentsBackgroundColor;
                        this.showHideMarkersPopupMenu.borderColor = Scheduler.Container.constants.componentsBorderColor;
                        this.showHideMarkersPopupMenu.useBorder = true;
                    }
                    this.showHideMarkersPopupMenu.items = [];
                    if (this.showHideAllSources) {
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuReadOnlyItem(Scheduler.StringTable.get("Scheduler.Msg.ShowSourcesMarkers") || "Show all sources on map"));
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.HideSourcesMarkers") || "Hide all sources on map", null, function (e) {
                            _this.showHideAllSources = false;
                        }));
                    }
                    else {
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.ShowSourcesMarkers") || "Show all sources on map", null, function (e) {
                            _this.showHideAllSources = true;
                        }));
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuReadOnlyItem(Scheduler.StringTable.get("Scheduler.Msg.HideSourcesMarkers") || "Hide all sources on map"));
                    }
                    this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuSeparatorItem());
                    if (this.showTasksOfAllResources) {
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuReadOnlyItem(Scheduler.StringTable.get("Scheduler.Msg.ShowScheduledMarkers") || "Show tasks of all resources on map"));
                    }
                    else {
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.ShowScheduledMarkers") || "Show tasks of all resources on map", null, function (e) {
                            _this.showTasksOfAllResources = true;
                        }));
                    }
                    if (this.hideTasksOfAllResources) {
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuReadOnlyItem(Scheduler.StringTable.get("Scheduler.Msg.HideScheduledMarkers") || "Hide tasks of all resources on map"));
                    }
                    else {
                        this.showHideMarkersPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.HideScheduledMarkers") || "Hide tasks of all resources on map", null, function (e) {
                            _this.hideTasksOfAllResources = true;
                        }));
                    }
                    var offset = this.showHideMarkersIconElement.offset();
                    this.showHideMarkersPopupMenu.x = offset.left;
                    this.showHideMarkersPopupMenu.y = this.element.outerHeight(true);
                    this.showHideMarkersPopupMenu.open();
                };
                ButtonsBar.prototype.setFilterStatus = function (filterStatus) {
                    this._filterStatus = filterStatus;
                    this._updateFilterStatus();
                    this._updateReducedWidth();
                };
                ButtonsBar.prototype.changeViewTypeImage = function (isMapView) {
                    if (isMapView) {
                        this.viewTypeElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "timeView.png" + ")" });
                    }
                    else {
                        this.viewTypeElement.css({ "background-image": "url(" + Scheduler.Container.imageFolder + "mapView.png" + ")" });
                    }
                };
                ButtonsBar.prototype.onShowHideQuickMenu = function () {
                    Scheduler.Container.ref.showQuickMenu = !Scheduler.Container.ref.showQuickMenu;
                };
                ButtonsBar.prototype.onResize = function () {
                    this._updateReducedWidth();
                };
                ButtonsBar.prototype._createButtonsBarElement = function () {
                    var element = Scheduler.Utilities.createFromTemplate(this._template);
                    element.css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    Scheduler.StringTable.localizeElements(element);
                    return element;
                };
                ButtonsBar.prototype._updateReducedWidth = function () {
                    var filterStatusElement = this.filterStatusElement;
                    var filterStatusElementParent = filterStatusElement.parent();
                    this._setReductionType(ReductionType.None);
                    var filterStatusWidth = filterStatusElement.outerWidth(true) || 0;
                    var labelBarWidth = filterStatusElementParent.width() || 0;
                    if (filterStatusWidth > labelBarWidth) {
                        this._setReductionType(ReductionType.ButtonsTexts);
                        filterStatusWidth = filterStatusElement.outerWidth(true) || 0;
                        labelBarWidth = filterStatusElementParent.width() || 0;
                        if (filterStatusWidth > labelBarWidth) {
                            this._setReductionType(ReductionType.ButtonsTextsAndFilterStatus);
                            filterStatusWidth = filterStatusElement.outerWidth(true) || 0;
                            labelBarWidth = filterStatusElementParent.width() || 0;
                            if (filterStatusWidth > labelBarWidth) {
                                this._setReductionType(ReductionType.All);
                            }
                        }
                    }
                };
                ButtonsBar.prototype._setReductionType = function (value) {
                    if (value != this._reductionType) {
                        this._reductionType = value;
                        if (this._reductionType === ReductionType.None) {
                            // full size
                            $("#schedulerButtonsBar .toolbarButton .textButton").css("display", "");
                            $("#filterStatus").css("display", "");
                            $("#zoomLevel").css("width", "");
                        }
                        else if (this._reductionType === ReductionType.ButtonsTexts) {
                            // buttons texts hidden
                            $("#schedulerButtonsBar .toolbarButton .textButton").css("display", "none");
                            $("#filterStatus").css("display", "");
                            $("#zoomLevel").css("width", "");
                        }
                        else if (this._reductionType === ReductionType.ButtonsTextsAndFilterStatus) {
                            // buttons texts hidden and filter status reduced
                            $("#schedulerButtonsBar .toolbarButton .textButton").css("display", "none");
                            $("#filterStatus").css("display", "");
                            $("#zoomLevel").css("width", "60px");
                        }
                        else {
                            // buttons texts and filter status hidden
                            $("#schedulerButtonsBar .toolbarButton .textButton").css("display", "none");
                            $("#filterStatus").css("display", "none");
                            $("#zoomLevel").css("width", "60px");
                        }
                        this._updateFilterStatus();
                    }
                };
                ButtonsBar.prototype._updateFilterStatus = function () {
                    var text = "";
                    if (this._reductionType === ReductionType.ButtonsTextsAndFilterStatus) {
                        text = this._filterStatus.rangeText;
                        if (this._filterStatus.filtersText) {
                            text += "</br>" + this._filterStatus.filtersText;
                        }
                    }
                    else {
                        text = this._filterStatus.rangeLabel + this._filterStatus.rangeText;
                        if (this._filterStatus.filtersLabel || this._filterStatus.filtersText) {
                            text += "</br>" + this._filterStatus.filtersLabel + this._filterStatus.filtersText;
                        }
                    }
                    this.filterStatusElement.html(text);
                };
                return ButtonsBar;
            }());
            Scheduler.ButtonsBar = ButtonsBar;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=buttonsBar.js.map