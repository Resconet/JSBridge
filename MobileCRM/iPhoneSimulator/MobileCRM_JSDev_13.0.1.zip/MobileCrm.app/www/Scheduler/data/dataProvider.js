///<reference path="../../../../MobileCrm/www/Controllers/entityList.ts" />
///<reference path="../../../../MobileCrm/www/Controllers/Workflow/workflow.ts" />
///<reference path="../container.ts" />
///<reference path="../task.ts" />
///<reference path="source.ts" />
///<reference path="JSBridgeBaseQuery.ts" />
///<reference path="inputs.ts" />
///<reference path="statusCodeTable.ts" />
///<reference path="rules.ts" />
///<reference path="skillTerritoryFilter.ts" />
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var AsyncInitState;
            (function (AsyncInitState) {
                AsyncInitState[AsyncInitState["NotRequested"] = 0] = "NotRequested";
                AsyncInitState[AsyncInitState["Requested"] = 1] = "Requested";
                AsyncInitState[AsyncInitState["Initialized"] = 2] = "Initialized";
            })(AsyncInitState || (AsyncInitState = {}));
            var DataProvider = /** @class */ (function () {
                function DataProvider(inputData) {
                    this._isListConfigInitialized = false;
                    this._isHorizontalListConfigInitialized = false;
                    this._isTaskConfigInitialized = false;
                    this._isStylesConfigInitialized = AsyncInitState.NotRequested;
                    this._isMetaDataInitialized = AsyncInitState.NotRequested;
                    this._stylesCallbacks = [];
                    this._metaDataCallbacks = [];
                    this._hiddenHorizontalListEntitiesIds = [];
                    this._unscheduledItemAttributeMap = {}; // Do not cache and use the same attribute map for whole dataProvider instance life, because attrbutes provided by list view can be different, when another view is chosen.
                    this.resourceIdIndex = -1;
                    this.resourceNameIndex = -1;
                    this.resourceOwnerIdIndex = -1;
                    this._inputData = inputData;
                }
                DataProvider.prototype.getSettings = function () {
                    return Scheduler.Container.ref.settings;
                };
                DataProvider.prototype.setupAllowedViews = function (controller, config, selectedViewKey) {
                    if (!config || !config.entityName)
                        return;
                    var configViews = config ? config.entityViews : null;
                    var hasView = (configViews && configViews.length > 0) ? true : false;
                    if (!hasView || configViews.indexOf(config.entityName + ".*") >= 0) {
                        var viewFilter = controller.viewFilter;
                        if (viewFilter && viewFilter.values) {
                            var viewNames = "";
                            for (var i = 0; i < viewFilter.values.length; i++) {
                                if (viewNames !== "")
                                    viewNames += ":";
                                viewNames += config.entityName + "." + viewFilter.values[i].value;
                            }
                            if (hasView) {
                                var tmp = config.entityName + ".@";
                                var startIdx = configViews.indexOf(tmp);
                                if (startIdx >= 0) {
                                    var endIdx = configViews.indexOf(':', startIdx);
                                    var initialConfig = endIdx < 0 ? configViews.substring(startIdx) : configViews.substring(startIdx, endIdx);
                                    var initialName = config.entityName + "." + initialConfig.substring(tmp.length);
                                    viewNames = viewNames.replace(initialName, initialConfig);
                                }
                            }
                            else {
                                hasView = (viewNames && viewNames.length > 0) ? true : false;
                            }
                            config.entityViews = viewNames;
                        }
                    }
                    if (hasView)
                        controller.setupAllowedViews(config.entityViews);
                    if (controller.allowedViews) {
                        var settings = Scheduler.Container.ref.settings;
                        var selectedView = settings[selectedViewKey];
                        if (selectedView && controller.allowedViews.containsKey(selectedView)) {
                            controller.selectView(selectedView);
                        }
                        else {
                            var keys = controller.allowedViews.getKeys();
                            if (keys.length > 0) {
                                selectedView = controller.initialView ? controller.initialView : keys[0];
                                controller.selectView(selectedView);
                            }
                            else {
                                selectedView = undefined;
                            }
                            if (selectedView !== settings[selectedViewKey]) {
                                settings[selectedViewKey] = selectedView;
                                settings.setDirty();
                                Scheduler.Container.ref.settings = settings; // force settings to be saved
                            }
                        }
                    }
                };
                DataProvider.prototype.createResourceController = function (listCtrl, onFinishCallback) {
                    var _this = this;
                    var config = Scheduler.Container.inputs.resources;
                    this._initListController(config.entityName, function (viewConfig) {
                        var _controller = MobileCrm.ControllerFactory.instance.getListController(config.entityName);
                        // list configuration and datasource getter
                        _controller.getUIConfig = function (uiPath) { return viewConfig; };
                        _controller.getUIConfigScope = _this;
                        _controller.getDataSourceEnumerator = function (fetch) { return _this.getResourceEnumerator(fetch); };
                        _controller.setView(listCtrl, MobileCrm.UI.ViewMode.Default);
                        _this.setupAllowedViews(_controller, config, "resourceView");
                        onFinishCallback(_controller);
                    });
                };
                DataProvider.prototype.createUnscheduledTasksController = function (horizontalListCtrl, onFinishCallback) {
                    var _this = this;
                    var config = Scheduler.Container.inputs.unscheduledTasks;
                    this._initHorizontalListController(config.entityName, function (viewConfig) {
                        var _controller = MobileCrm.ControllerFactory.instance.getListController(config.entityName);
                        // list configuration and datasource getter
                        _controller.getUIConfig = function (uiPath) { return viewConfig; };
                        _controller.getUIConfigScope = _this;
                        _controller.getDataSourceEnumerator = function (fetch) { return _this.getUnscheduledTasksEnumerator(fetch); };
                        _controller.setView(horizontalListCtrl, MobileCrm.UI.ViewMode.Default);
                        _this.setupAllowedViews(_controller, config, "unscheduledView");
                        onFinishCallback(_controller);
                    });
                };
                DataProvider.prototype.createTaskController = function (onFinishCallback) {
                    var _this = this;
                    var config = Scheduler.Container.inputs.scheduledTasks;
                    this._initTaskController(config.entityName, function (viewConfig) {
                        var _controller = MobileCrm.ControllerFactory.instance.getListController(config.entityName, Scheduler.TaskDynamicEntityList);
                        _controller.getUIConfig = function (uiPath) { return viewConfig; };
                        _controller.getUIConfigScope = _this;
                        _controller.loadConfiguration(MobileCrm.UI.ViewMode.Default); //_controller.setView(undefined, MobileCrm.UI.ViewMode.Default);
                        _this.setupAllowedViews(_controller, config, "scheduledView");
                        onFinishCallback(_controller);
                    });
                };
                DataProvider.prototype._toValue = function (name, item) {
                    var idx;
                    return (name && (idx = this._unscheduledItemAttributeMap[name]) !== undefined) ? item[idx] : undefined;
                };
                DataProvider.prototype.rowToUnscheduledTask = function (row) {
                    var _this = this;
                    var inputData = this._inputData.unscheduledTasks;
                    var item = row.data.m_data;
                    var entityProperties = row.data.repository.properties;
                    var epLength = entityProperties.length;
                    this._unscheduledItemAttributeMap = {};
                    for (var i = epLength - 1; i >= 0; i--) { // The oposite iteration ensures that the attribute value under lower index will be used, in the case when two attributes have the same name. (Result row.data array contains values only for attributes with lower index in the case of duplicity.)
                        this._unscheduledItemAttributeMap[entityProperties[i].name] = i;
                    }
                    var estimatedduration;
                    var now = Date.now();
                    var id = this._toValue(inputData.primaryKeyName, item);
                    var name = this._toValue(inputData.primaryFieldName, item);
                    var task = new Scheduler.Task(this._inputData.scheduledTasks, "New_" + id, name, 0, 0);
                    if (!inputData.attrEstimatedDuration || !(estimatedduration = +this._toValue(inputData.attrEstimatedDuration, item)))
                        estimatedduration = inputData.defaultDuration;
                    if ((estimatedduration === undefined) || (estimatedduration === null) || estimatedduration < 0)
                        estimatedduration = Scheduler.Container.constants.defaultTaskDuration;
                    if (this._inputData.sourceToOwnerRelationship && inputData.attrOwnerId) {
                        var ownerId = this._toValue(inputData.attrOwnerId, item);
                        if (ownerId) {
                            if (ownerId.id)
                                this.setOwningResources(task, ownerId.id);
                            else
                                this.setOwningResources(task, ownerId);
                        }
                    }
                    estimatedduration = Scheduler.minutesToMiliseconds(estimatedduration);
                    if (id) {
                        if (!(task.group = Scheduler.Source.find(id))) {
                            var locationRef = inputData.linkAddress ? (inputData.linkAddress.linkToAttr ? this._toValue(inputData.linkAddress.linkToAttr, item) : (new MobileCRM.Reference(inputData.entityName, id, name))) : undefined;
                            var territoryRef = inputData.attrTerritoryRef ? this._toValue(inputData.attrTerritoryRef, item) : undefined;
                            var skillRef = inputData.attrSkillRef ? this._toValue(inputData.attrSkillRef, item) : undefined;
                            task.group = Scheduler.Source.create(task, id, name, locationRef, territoryRef, skillRef, row.data.m_data);
                            if (task.group.locationRef && inputData.linkAddress) {
                                task.location = this.resultToAddress(inputData.linkAddress, item, function (n, p) { return _this._toValue(n, p); });
                                if (task.location)
                                    Scheduler.LocationCache.Add(task.group.locationRef.id, task.location);
                            }
                        }
                    }
                    task.progress = inputData.attrProgress ? this._toValue(inputData.attrProgress, item) || 0 : 0;
                    task.setWorkStart(now);
                    task.hasScheduledStart = false;
                    task.setTotalWorkTime(estimatedduration);
                    var status = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                    task.setStatus(new Scheduler.Status(undefined, "NewSourceTask", "", Scheduler.TaskStatusType.Unscheduled, status ? status.color() : inputData.color));
                    //			if ((task.location = WorkOrderEntity._getAddress(resultObject.customerAddress)) !== undefined && task.group)
                    //				LocationCache.Add(task.group.locationRef.id, task.location);
                    //task.setTravelFrom(this.ctrl.geo.duration(task.customerAddress));
                    //task.setTravelTo(task.getTravelFrom());
                    return task;
                };
                DataProvider.prototype.resultToAddress = function (inputData, prop, toValue) {
                    var latitude = undefined;
                    var longitude = undefined;
                    if (inputData.attrLatitude) {
                        latitude = toValue(inputData.attrLatitude, prop);
                        longitude = toValue(inputData.attrLongitude, prop);
                    }
                    var address = "";
                    var s;
                    var len;
                    if ((s = toValue(inputData.attrCountry, prop)))
                        address += s + ",";
                    if ((s = toValue(inputData.attrStateorprovince, prop)))
                        address += s + ",";
                    if ((s = toValue(inputData.attrCity, prop))) {
                        var p = toValue(inputData.attrPostalcode, prop);
                        if (p)
                            address += p + " " + s + ",";
                        else
                            address += s + ",";
                    }
                    if ((s = toValue(inputData.attrStreet1, prop)))
                        address += s + ",";
                    if ((s = toValue(inputData.attrStreet2, prop)))
                        address += s + ",";
                    if ((len = address.length) > 0)
                        address = address.substring(0, --len); // remove last ','
                    if (len > 0 || (latitude && longitude))
                        return new Scheduler.Location(address, latitude, longitude);
                    return undefined;
                };
                DataProvider.prototype.loadUnscheduledTasks = function (resources, onFinishCallback, maxCount) {
                    if (onFinishCallback)
                        onFinishCallback(null);
                };
                /// Default implementation initialize location during load (in case address attribute is defined in UnscheduledDataInput)
                DataProvider.prototype.loadLocations = function (tasks, onLoad) {
                    if (!tasks || tasks.length === 0) {
                        if (onLoad)
                            onLoad(null);
                    }
                    else {
                        if (Scheduler.LocationCache.Item.length > 0) {
                            for (var i = tasks.length - 1; i >= 0; i--) {
                                var task = tasks[i];
                                var group = task.group;
                                if (group && group.locationRef && group.locationRef.id) {
                                    var location_1 = Scheduler.LocationCache.Item(group.locationRef.id);
                                    if (location_1 !== undefined) {
                                        task.setLocation(location_1);
                                        tasks.splice(i, 1);
                                    }
                                }
                            }
                        }
                        if (tasks.length > 0)
                            this.loadCustomerAddress(tasks, onLoad);
                        else if (onLoad)
                            onLoad(null);
                    }
                };
                /// Default implementation set all resources as qualified  
                DataProvider.prototype.loadQualifiedResources = function (tasks, onFinishCallback) {
                    Scheduler.AllowedResources.Load(tasks, onFinishCallback);
                    /*
                    if (tasks && tasks.length > 0) {
                        if (this._inputData.sourceToOwnerRelationship) {
                            if (this._inputData.unscheduledTasks.attrOwnerId) {
                                for (let i = 0; i < tasks.length; i++) {
                                    let task = tasks[i];
                                    if (task.getLinkedResources() === undefined) {
                                        //task.setLinkedResources(null);
                                    }
                                }
                            }
                        }
                        else {
                            for (let i = 0; i < tasks.length; i++) {
                                let task = tasks[i];
                                if (task.getLinkedResources() === undefined)
                                    task.setLinkedResources(null);
                            }
                        }
                    }
                    onFinishCallback(null);
                    */
                };
                DataProvider.prototype.loadCustomerAddress = function (tasks, onFinishCallback) {
                    var _this = this;
                    var location;
                    var group;
                    var unscheduledTasks = this._inputData.unscheduledTasks;
                    if (tasks.length === 1 && (group = tasks[0].group) && group.locationRef && (location = Scheduler.LocationCache.Item(group.locationRef.id)) !== undefined) {
                        tasks[0].location = location;
                        if (onFinishCallback)
                            onFinishCallback(null);
                    }
                    else {
                        var entityName = null;
                        var inputs_1;
                        if (unscheduledTasks && (inputs_1 = unscheduledTasks.linkAddress)) {
                            if (!(entityName = inputs_1.entityName))
                                entityName = unscheduledTasks.entityName;
                        }
                        if (!entityName) {
                            if (onFinishCallback)
                                onFinishCallback(null);
                            return;
                        }
                        //if (entityName)
                        var entity = new MobileCRM.FetchXml.Entity(entityName);
                        var orderDic_1 = new Scheduler.Dictionary();
                        // try to find locations from cache or group rest of tasks by customers 
                        this.groupTasksByCustomer(tasks, orderDic_1);
                        var customerIds = orderDic_1.Keys();
                        if (customerIds.length == 0) {
                            if (onFinishCallback)
                                onFinishCallback(null);
                            return;
                        }
                        entity.attributes = Scheduler.Entity.CreateFetchXmlAttributeList(inputs_1);
                        if (customerIds.length > 0)
                            entity.addFilter().isIn(inputs_1.primaryKeyName, customerIds);
                        var fetch_1 = new MobileCRM.FetchXml.Fetch(entity);
                        fetch_1.execute("DynamicEntities", function (entityResult) {
                            for (var i = 0; i < entityResult.length; i++) {
                                var prop = entityResult[i].properties;
                                var location_2 = _this.resultToAddress(inputs_1, prop, function (name, property) {
                                    return name ? property[name] : undefined;
                                });
                                Scheduler.LocationCache.Add(prop.id, location_2);
                                var taskGroup = orderDic_1.Item(prop.id);
                                if (taskGroup) {
                                    for (var j = 0; j < taskGroup.length; j++)
                                        taskGroup[j].location = location_2;
                                }
                            }
                            if (onFinishCallback)
                                onFinishCallback(null);
                        }, function (err) {
                            if (onFinishCallback)
                                onFinishCallback(err);
                        }, this);
                    }
                };
                DataProvider.prototype.groupTasksByCustomer = function (tasks, outDic) {
                    var customerId;
                    var location;
                    // try to find locations from cache or group rest of tasks by customers 
                    for (var i = 0; i < tasks.length; i++) {
                        var r = tasks[i];
                        if (r.getLocation() !== undefined || !r.group || !r.group.locationRef)
                            continue;
                        else if (!(customerId = r.group.locationRef.id))
                            r.location = null;
                        else if ((location = Scheduler.LocationCache.Item(customerId)))
                            r.location = location;
                        else {
                            var taskGroup = outDic.Item(customerId);
                            if (!taskGroup)
                                outDic.Add(customerId, taskGroup = []);
                            taskGroup.push(r);
                        }
                    }
                };
                DataProvider.prototype.setOwningResources = function (task, ownerId) {
                    var resourceIds = Scheduler.Container.ref.findResourcesByOwnerId(ownerId);
                    // 'resource_for_owner_notexist' is non existing id used to avoid attach source to any resource. null or empty array would accept all available resources
                    task.setLinkedResources(resourceIds && resourceIds.length > 0 ? resourceIds : ["resource_for_owner_notexist"]);
                };
                DataProvider.prototype.saveTask = function (task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var start, end, totalWork, status_1;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    start = +taskChanges.start;
                                    end = +taskChanges.end;
                                    totalWork = +taskChanges.totalWork;
                                    if (task.getStatus().isUnscheduled() && taskChanges.statuscode === undefined) {
                                        status_1 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                        if (!status_1)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.ScheduledAndConfirmedStatusNotExist") || "Activity entity can not be modified because no status is configured for \"Scheduled\" or \"In Progress\" action.");
                                        taskChanges.statuscode = status_1.value();
                                    }
                                    if (start && !end) {
                                        end = start + (totalWork || task.getTotalWorkTime());
                                        totalWork = undefined;
                                    }
                                    if (!(task.isUnscheduledNew() == false)) return [3 /*break*/, 2];
                                    return [4 /*yield*/, this._updateTask(task, taskChanges, start, end)];
                                case 1:
                                    _a.sent();
                                    return [3 /*break*/, 4];
                                case 2: return [4 /*yield*/, this._createNewTask(task, taskChanges, start, end)];
                                case 3:
                                    _a.sent();
                                    if (task.group)
                                        task.group.registerVisit(task);
                                    _a.label = 4;
                                case 4: return [4 /*yield*/, task.reloadTemplateData()];
                                case 5:
                                    _a.sent();
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype._createNewTask = function (task, taskChanges, start, end) {
                    return __awaiter(this, void 0, void 0, function () {
                        var resource, input, sourceInput, resourceInput, entity, props, status_2, status_3, ruleResult, _start, _end, result;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    resource = task.resource;
                                    input = this._inputData.scheduledTasks;
                                    sourceInput = this._inputData.unscheduledTasks;
                                    resourceInput = this._inputData.resources;
                                    entity = MobileCRM.DynamicEntity.createNew(input.entityName);
                                    props = entity.properties;
                                    props[input.attrScheduledStart] = new Date(start || task.getWorkStart());
                                    props[input.attrScheduledEnd] = new Date(end || task.getWorkEnd());
                                    if (input.attrStatus) {
                                        if (!props[input.attrStatus]) {
                                            status_2 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                            if (!status_2)
                                                throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.ScheduledAndConfirmedStatusNotExist") || "Activity entity can not be modified because no status is configured for \"Scheduled\" or \"In Progress\" action.");
                                            taskChanges.statuscode = status_2.value();
                                            props[input.attrStatus] = taskChanges.statuscode;
                                        }
                                        else {
                                            status_3 = props[input.attrStatus];
                                            taskChanges.statuscode = status_3;
                                        }
                                    }
                                    if (task.group && sourceInput && sourceInput.entityName)
                                        props[input.attrSourceRef] = new MobileCRM.Reference(sourceInput.entityName, task.group.id, task.group.name);
                                    if (resource)
                                        props[input.attrResourceRef] = new MobileCRM.Reference(resourceInput.entityName, resource.getID(), resource.getName());
                                    else if (taskChanges.parentID)
                                        props[input.attrResourceRef] = new MobileCRM.Reference(resourceInput.entityName, taskChanges.parentID, null);
                                    else
                                        throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoResourceIdForNewTask") || "New task must have valid resourceId.");
                                    if (!props[input.primaryFieldName])
                                        props[input.primaryFieldName] = task.name;
                                    if (!this.m_rule)
                                        this.m_rule = new Scheduler.CreateRule(this._inputData);
                                    return [4 /*yield*/, this.m_rule.executeCreateRule(entity)];
                                case 1:
                                    ruleResult = _a.sent();
                                    if (ruleResult) {
                                        if (ruleResult.errorMsg)
                                            throw new Resco.Exception(ruleResult.errorMsg);
                                    }
                                    _start = entity.properties[input.attrScheduledStart];
                                    if (_start != undefined)
                                        taskChanges.start = +_start;
                                    _end = entity.properties[input.attrScheduledEnd];
                                    if (_start != undefined && _end != undefined)
                                        taskChanges.totalWork = (+_end) - (+_start);
                                    return [4 /*yield*/, entity.saveAsync()];
                                case 2:
                                    result = _a.sent();
                                    props = result.properties;
                                    task.id = result.id;
                                    task.name = props[input.primaryFieldName];
                                    taskChanges.name = task.name;
                                    task.entityInput.entityName = result.entityName;
                                    if (!ruleResult) return [3 /*break*/, 4];
                                    return [4 /*yield*/, ruleResult.updateSource()];
                                case 3:
                                    _a.sent();
                                    _a.label = 4;
                                case 4: return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype._updateTask = function (task, taskChanges, start, end) {
                    return __awaiter(this, void 0, void 0, function () {
                        var input, entity, list, fetch, result;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    input = this._inputData.scheduledTasks;
                                    entity = new MobileCRM.FetchXml.Entity(input.entityName);
                                    if (!this._attributesToSave) {
                                        list = new Array();
                                        list.push(new MobileCRM.FetchXml.Attribute(input.primaryKeyName));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.primaryFieldName));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.attrResourceRef));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.attrScheduledStart));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.attrScheduledEnd));
                                        if (input.attrStatus)
                                            list.push(new MobileCRM.FetchXml.Attribute(input.attrStatus));
                                        if (input.attrSourceRef)
                                            list.push(new MobileCRM.FetchXml.Attribute(input.attrSourceRef));
                                        if (input.attrTravelFrom && input.attrTravelTo) {
                                            list.push(new MobileCRM.FetchXml.Attribute(input.attrTravelFrom));
                                            list.push(new MobileCRM.FetchXml.Attribute(input.attrTravelTo));
                                            if (input.attrTravelMode)
                                                list.push(new MobileCRM.FetchXml.Attribute(input.attrTravelMode));
                                        }
                                        this._attributesToSave = list;
                                    }
                                    entity.attributes = this._attributesToSave;
                                    entity.addFilter().where(input.primaryKeyName, "eq", task.id);
                                    fetch = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch.executeAsync("DynamicEntities")];
                                case 1:
                                    result = _a.sent();
                                    if (result.length === 0)
                                        throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoTasks") || "There are no tasks.");
                                    return [4 /*yield*/, this._updateTaskEntity(result[0], input, task, taskChanges, start, end)];
                                case 2:
                                    _a.sent();
                                    return [4 /*yield*/, this._updateSourceEntity(task, taskChanges)];
                                case 3:
                                    _a.sent();
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype._updateTaskEntity = function (entity, input, task, taskChanges, start, end) {
                    return __awaiter(this, void 0, void 0, function () {
                        var resource, prop, changes, oldStatuscode, travel, newValue, status_4, resId, newEntity;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    resource = task.resource;
                                    prop = entity.properties;
                                    changes = 0;
                                    oldStatuscode = 0;
                                    if (input.attrStatus) {
                                        oldStatuscode = prop[input.attrStatus];
                                        if (!Scheduler.Container.statusCodeTable.getStatusByValue(oldStatuscode).isEditable())
                                            throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.TaskStatusIsNotEditable") || "Task with current status is not editable.");
                                        if (taskChanges.statuscode !== undefined && taskChanges.statuscode !== oldStatuscode && Scheduler.Task.isValidStatusValue(taskChanges.statuscode)) {
                                            prop[input.attrStatus] = taskChanges.statuscode;
                                            changes++;
                                        }
                                    }
                                    if (start && !Scheduler.Utilities.equalDates(start, prop[input.attrScheduledStart])) {
                                        prop[input.attrScheduledStart] = new Date(start);
                                        changes++;
                                    }
                                    if (end && !Scheduler.Utilities.equalDates(end, prop[input.attrScheduledEnd])) {
                                        prop[input.attrScheduledEnd] = new Date(end);
                                        changes++;
                                    }
                                    if (taskChanges.name !== undefined) {
                                        prop[input.primaryFieldName] = taskChanges.name;
                                        changes++;
                                    }
                                    if (input.attrTravelFrom && input.attrTravelTo) {
                                        travel = task.getTravel();
                                        newValue = void 0;
                                        if (taskChanges.travelFrom !== undefined && (newValue = Scheduler.milisecondsToMinutes(+taskChanges.travelFrom)) !== travel.from) {
                                            prop[input.attrTravelFrom] = newValue;
                                            changes++;
                                        }
                                        if (taskChanges.travelTo !== undefined && (newValue = Scheduler.milisecondsToMinutes(+taskChanges.travelTo)) !== travel.to) {
                                            prop[input.attrTravelTo] = newValue;
                                            changes++;
                                        }
                                        if (input.attrTravelMode && taskChanges.travelMode !== undefined && taskChanges.travelMode !== travel.mode) {
                                            prop[input.attrTravelMode] = taskChanges.travelMode;
                                            changes++;
                                        }
                                    }
                                    if (input.attrStatus && Scheduler.Container.statusCodeTable.getStatusByValue(oldStatuscode).isUnscheduled()) {
                                        if (!resource)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoResourceIdForNewTask") || "New task must have valid resourceId.");
                                        status_4 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                        if (!status_4)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.ScheduledAndConfirmedStatusNotExist") || "Activity entity can not be modified because no status is configured for \"Scheduled\" or \"In Progress\" action.");
                                        prop[input.attrStatus] = status_4.value();
                                        prop[input.attrResourceRef] = resource.reference();
                                        changes++;
                                    }
                                    else if (resource) {
                                        resId = prop[input.attrResourceRef];
                                        if (!resId || resId.id !== resource.getID()) {
                                            prop[input.attrResourceRef] = resource.reference();
                                            changes++;
                                        }
                                    }
                                    if (!(changes > 0)) return [3 /*break*/, 2];
                                    return [4 /*yield*/, entity.saveAsync()];
                                case 1:
                                    newEntity = _a.sent();
                                    if (newEntity && task.isUnscheduledNew()) {
                                        task.id = newEntity.id;
                                        task.entityInput.entityName = input.entityName;
                                    }
                                    _a.label = 2;
                                case 2: return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype._updateSourceEntity = function (task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var input, workorderid, progress, entity, fetch, result, item;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    input = this._inputData.unscheduledTasks;
                                    workorderid = task.group ? task.group.id : 0;
                                    progress = taskChanges["progress"];
                                    if (!input || !input.attrProgress || progress === undefined || !workorderid || progress < 0 || progress > 100)
                                        return [2 /*return*/, true];
                                    entity = new MobileCRM.FetchXml.Entity(input.entityName);
                                    entity.addAttribute(input.primaryKeyName);
                                    entity.addAttribute(input.attrProgress);
                                    entity.addFilter().where(input.primaryKeyName, "eq", workorderid);
                                    fetch = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch.executeAsync("DynamicEntities")];
                                case 1:
                                    result = _a.sent();
                                    item = result[0];
                                    if (!(progress !== item.properties[input.attrProgress])) return [3 /*break*/, 3];
                                    item.properties[input.attrProgress] = progress;
                                    return [4 /*yield*/, item.saveAsync()];
                                case 2:
                                    _a.sent();
                                    _a.label = 3;
                                case 3: return [2 /*return*/];
                            }
                        });
                    });
                };
                /*
                public onTaskDlgInitialized(dialog: TaskPropertyDlg): void {
                    if (this._inputData.scheduledTasks.entityName == "fs_workorderschedule") {
                        for (let i = 0; i < dialog.pages.length; i++) {
                            let page = dialog.pages[i];
                            if (page instanceof InfoPage)
                                (<InfoPage>page).onStatusChanged = this._onStatusChanged.bind(this, dialog, page);
                        }
                    }
                }*/
                /*** PRIVATE METHODS ***/
                DataProvider.prototype._initListController = function (controllerName, onFinishCallback) {
                    var _this = this;
                    this._isListConfigInitialized = false;
                    var viewConfig;
                    var onMultiFinishCallback = function () {
                        if ((_this._isStylesConfigInitialized === AsyncInitState.Initialized) && (_this._isMetaDataInitialized === AsyncInitState.Initialized) && _this._isListConfigInitialized)
                            onFinishCallback(viewConfig);
                    };
                    var onInitViewConfig = function (config, callback) {
                        if (!config)
                            config = _this._createFallbackView(_this._inputData.resources);
                        viewConfig = config.split("\r\n");
                        _this._isListConfigInitialized = true;
                        callback();
                    };
                    this._initStylesConcurrently(onMultiFinishCallback);
                    this._initMetaDataConcurrently(onMultiFinishCallback);
                    this._readConfig("Controllers\\" + controllerName + ".list", function (view) { return onInitViewConfig(view, onMultiFinishCallback); }, function (err) {
                        if (_this._isListConfigInitialized) {
                            Scheduler.StringTable.alert(err);
                        }
                        else {
                            try {
                                onInitViewConfig(undefined, onMultiFinishCallback);
                            }
                            catch (ex) {
                                var msg = (ex instanceof Resco.Exception) ? ex.message : ex.toString();
                                Scheduler.StringTable.alert(msg);
                            }
                        }
                    });
                };
                DataProvider.prototype._initHorizontalListController = function (controllerName, onFinishCallback) {
                    var _this = this;
                    this._isHorizontalListConfigInitialized = false;
                    var viewConfig;
                    var onMultiFinishCallback = function () {
                        if ((_this._isStylesConfigInitialized === AsyncInitState.Initialized) && (_this._isMetaDataInitialized === AsyncInitState.Initialized) && _this._isHorizontalListConfigInitialized)
                            onFinishCallback(viewConfig);
                    };
                    var onInitViewConfig = function (config, callback) {
                        if (!config)
                            config = _this._createFallbackView(_this._inputData.unscheduledTasks);
                        viewConfig = config.split("\r\n");
                        _this._isHorizontalListConfigInitialized = true;
                        callback();
                    };
                    this._initStylesConcurrently(onMultiFinishCallback);
                    this._initMetaDataConcurrently(onMultiFinishCallback);
                    this._readConfig("Controllers\\" + controllerName + ".list", function (view) { return onInitViewConfig(view, onMultiFinishCallback); }, function (err) {
                        if (_this._isHorizontalListConfigInitialized) {
                            Scheduler.StringTable.alert(err);
                        }
                        else {
                            try {
                                onInitViewConfig(undefined, onMultiFinishCallback);
                            }
                            catch (ex) {
                                var msg = (ex instanceof Resco.Exception) ? ex.message : ex.toString();
                                Scheduler.StringTable.alert(msg);
                            }
                        }
                    });
                };
                DataProvider.prototype._initTaskController = function (controllerName, onFinishCallback) {
                    var _this = this;
                    this._isTaskConfigInitialized = false;
                    var viewConfig;
                    var onMultiFinishCallback = function () {
                        if ((_this._isStylesConfigInitialized === AsyncInitState.Initialized) && (_this._isMetaDataInitialized === AsyncInitState.Initialized) && _this._isTaskConfigInitialized)
                            onFinishCallback(viewConfig);
                    };
                    var onInitViewConfig = function (config, callback) {
                        if (!config)
                            config = _this._createFallbackView(_this._inputData.scheduledTasks);
                        viewConfig = config.split("\r\n");
                        _this._isTaskConfigInitialized = true;
                        callback();
                    };
                    this._initStylesConcurrently(onMultiFinishCallback);
                    this._initMetaDataConcurrently(onMultiFinishCallback);
                    this._readConfig("Controllers\\" + controllerName + ".list", function (view) { return onInitViewConfig(view, onMultiFinishCallback); }, function (err) {
                        if (_this._isTaskConfigInitialized) {
                            Scheduler.StringTable.alert(err);
                        }
                        else {
                            try {
                                onInitViewConfig(undefined, onMultiFinishCallback);
                            }
                            catch (ex) {
                                var msg = (ex instanceof Resco.Exception) ? ex.message : ex.toString();
                                Scheduler.StringTable.alert(msg);
                            }
                        }
                    });
                };
                DataProvider.prototype._createFallbackView = function (input) {
                    var fmtFallback = "V2\r\n" +
                        "@@FallbackView\r\n" +
                        "1\r\n" +
                        "{0}\r\n" +
                        "T;;240;40\r\n" +
                        "S;PrimaryName;0;Primary;10;8;220;36;13\r\n";
                    var fetchXml = Resco.formatString("<fetch><entity name=\"{0}\"><attribute name=\"{1}\" /><order attribute=\"{1}\" /></entity></fetch>", [input.entityName, input.primaryFieldName]);
                    return Resco.formatString(fmtFallback, [fetchXml]);
                };
                DataProvider.prototype.addFilters = function (entity, inputFilter) {
                    var filterList = this._inputData.filterList;
                    if (filterList && inputFilter) {
                        var customFilter = this.getSettings().customFilterSelection;
                        for (var i = 0; i < filterList.length; i++) {
                            var filter = filterList[i];
                            var filterLink = inputFilter[filter.name];
                            var filterIds = void 0;
                            if (filterLink && filterLink.attrToFilterBy && (filterIds = customFilter[filter.name]) && filterIds.length > 0) {
                                if (filterLink.entityName) {
                                    var linkEntity = entity.addLink(filterLink.entityName, filterLink.linkFromAttr, filterLink.linkToAttr, filterLink.linkType);
                                    linkEntity.filter.isIn(filterLink.attrToFilterBy, filterIds);
                                }
                                else
                                    entity.filter.isIn(filterLink.attrToFilterBy, filterIds);
                            }
                        }
                    }
                };
                DataProvider.prototype.getResourceEnumerator = function (fetch) {
                    var entity = fetch.entity;
                    this.addFilters(entity, this._inputData.resources.filterLinks);
                    return new MobileCrm.UI.JSBridgeEntityQuery(fetch);
                };
                DataProvider.prototype.addUnique = function (attribute, entity, len) {
                    if (attribute) {
                        for (var i = 0; i < len; i++) {
                            if (entity.attributes[i].name === attribute)
                                return;
                        }
                        entity.attributes.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(attribute, undefined)));
                    }
                };
                DataProvider.prototype.getUnscheduledTasksEnumerator = function (fetch) {
                    var entity = fetch.entity;
                    var input = this._inputData.unscheduledTasks;
                    //let scheduledTasks: ScheduledDataInput = this._inputData.scheduledTasks;
                    var address = input.linkAddress;
                    var attributesLen = entity.attributes.length;
                    this.addUnique(input.primaryKeyName, entity, attributesLen);
                    this.addUnique(input.primaryFieldName, entity, attributesLen);
                    this.addUnique(input.attrTerritoryRef, entity, attributesLen);
                    this.addUnique(input.attrSkillRef, entity, attributesLen);
                    this.addUnique(input.attrEstimatedDuration, entity, attributesLen);
                    this.addUnique(input.attrProgress, entity, attributesLen);
                    this.addUnique(input.attrOwnerId, entity, attributesLen);
                    if (address) {
                        if (!address.linkToAttr) {
                            this.addUnique(address.attrLatitude, entity, attributesLen);
                            this.addUnique(address.attrLongitude, entity, attributesLen);
                            this.addUnique(address.attrCountry, entity, attributesLen);
                            this.addUnique(address.attrStateorprovince, entity, attributesLen);
                            this.addUnique(address.attrCity, entity, attributesLen);
                            this.addUnique(address.attrPostalcode, entity, attributesLen);
                            this.addUnique(address.attrStreet1, entity, attributesLen);
                            this.addUnique(address.attrStreet2, entity, attributesLen);
                        }
                        else {
                            this.addUnique(address.linkToAttr, entity, attributesLen);
                            if (!this._addressAttributes) {
                                this._addressAttributes = Scheduler.Entity.CreateFetchAttributeList(address, true);
                            }
                            var linkEntity = entity.addLink(address.entityName, address.linkFromAttr, address.linkToAttr, address.linkType);
                            linkEntity.attributes = this._addressAttributes;
                        }
                    }
                    ////Container.ref.enabledFilterDoNotOfferScheduledTasks = false;
                    //if (scheduledTasks.entityName != "fs_workorderschedule") {
                    //	let addLink = true;
                    //	if (entity.links) {
                    //		for (var i = 0; i < entity.links.length; i++) {
                    //			var link = entity.links[i];
                    //			if (link.name == scheduledTasks.entityName &&
                    //				link.from == scheduledTasks.attrSourceRef &&
                    //				link.to == input.primaryKeyName) {
                    //				addLink = false;
                    //			}
                    //		}
                    //	}
                    //	if (addLink) {
                    //		let linkEntity = entity.addLink(scheduledTasks.entityName, scheduledTasks.attrSourceRef, input.primaryKeyName, "outer");
                    //		let days = this.getSettings().daysWhenSourcesIsNotOfferedForScheduling;
                    //		linkEntity.alias = "L0";
                    //		if (!days)
                    //			days = Container.constants.daysWhenSourcesIsNotOfferedForScheduling;
                    //		let filter: MobileCrm.Data.Fetch.Filter = entity.filter.or();
                    //		// Settings below will be set in corresponding view in Woodford
                    //		// show all accounts that do not have appointments
                    //		// show all accounts that have all appointments older than x days
                    //		//let c1 = settings.where(scheduledTasks.primaryKeyName, "null", null);
                    //		//let c2 = settings.where(scheduledTasks.attrScheduledStart, Container.constants.daysWhenSourcesIsNotOfferedForScheduling, "olderthan-x-days");
                    //		//c1.entityName = "L0";
                    //		//c2.entityName = "L0";
                    //		//Container.ref.enabledFilterDoNotOfferScheduledTasks = true;
                    //	}
                    //}
                    this.addFilters(entity, input.filterLinks);
                    if (Scheduler.Container.constants.hideUnscheduledTaskAfterScheduling && (this._hiddenHorizontalListEntitiesIds.length > 0))
                        entity.filter.notIn(input.primaryKeyName, this._hiddenHorizontalListEntitiesIds);
                    return new MobileCrm.UI.JSBridgeEntityQuery(fetch);
                };
                DataProvider.prototype._initStylesConcurrently = function (onMultiFinishCallback) {
                    var _this = this;
                    if (this._isStylesConfigInitialized === AsyncInitState.Initialized) {
                        onMultiFinishCallback();
                    }
                    else {
                        this._stylesCallbacks.push(onMultiFinishCallback);
                        if (this._isStylesConfigInitialized === AsyncInitState.NotRequested) {
                            this._isStylesConfigInitialized = AsyncInitState.Requested;
                            this._readConfig("Controllers\\Styles", function (result) {
                                MobileCrm.ControllerFactory.instance.initializeStyles(result.split("\r\n"));
                                _this._isStylesConfigInitialized = AsyncInitState.Initialized;
                                for (var i = 0; i < _this._stylesCallbacks.length; i++) {
                                    _this._stylesCallbacks[i]();
                                }
                                _this._stylesCallbacks = [];
                            }, function (err) {
                                MobileCRM.bridge.alert(err);
                            });
                        }
                    }
                };
                DataProvider.prototype._initMetaDataConcurrently = function (onMultiFinishCallback) {
                    var _this = this;
                    if (this._isMetaDataInitialized === AsyncInitState.Initialized) {
                        onMultiFinishCallback();
                    }
                    else {
                        this._metaDataCallbacks.push(onMultiFinishCallback);
                        if (this._isMetaDataInitialized === AsyncInitState.NotRequested) {
                            this._isMetaDataInitialized = AsyncInitState.Requested;
                            this._initMetaData(function () {
                                _this._isMetaDataInitialized = AsyncInitState.Initialized;
                                for (var i = 0; i < _this._metaDataCallbacks.length; i++) {
                                    _this._metaDataCallbacks[i]();
                                }
                                _this._metaDataCallbacks = [];
                            });
                        }
                    }
                };
                DataProvider.prototype._initMetaData = function (success) {
                    MobileCRM.Metadata.requestObject(function (metadata) {
                        var metaEntites = [];
                        var jsbMetadata = metadata;
                        for (var entityName in jsbMetadata.entities) {
                            var jsbMeta = jsbMetadata.entities[entityName];
                            var meta = new MobileCrm.Data.MetaEntity(jsbMeta.name, jsbMeta.primaryKeyName, jsbMeta.primaryFieldName, jsbMeta.objectTypeCode, jsbMeta.attributes);
                            meta.permissionMask = jsbMeta.permissionMask;
                            for (var j = 0; j < jsbMeta.properties.length; j++) {
                                var jsbProp = jsbMeta.properties[j];
                                var prop = new MobileCrm.Data.MetaProperty(jsbProp.name, jsbProp.type, jsbProp.targets);
                                prop.defaultValue = jsbProp.defaultValue;
                                prop.format = jsbProp.format;
                                prop.maximum = jsbProp.maximum;
                                prop.minimum = jsbProp.minimum;
                                prop.precision = jsbProp.precision;
                                prop.required = jsbProp.required;
                                prop.permissions = jsbProp.permission;
                                meta.add(prop);
                            }
                            metaEntites.push(meta);
                        }
                        MobileCrm.Data.MetaData.instance.init(metaEntites);
                        success();
                    }, MobileCRM.bridge.alert);
                };
                DataProvider.prototype._readConfig = function (path, success, failure) {
                    var reader = MobileCRM.bridge.exposeObjectAsync("MobileCrm.Data:MobileCrm.Configuration.Instance.OpenUIConfig", [path]);
                    reader.invokeMethodAsync("ReadToEnd", [], success, failure, this);
                    reader.invokeMethodAsync("Dispose", [], undefined, undefined, this);
                    reader.release();
                };
                DataProvider.prototype.getResourceIdIndex = function (row) {
                    var inputs = this._inputData.resources;
                    this.resourceIdIndex = -1;
                    this.resourceNameIndex = -1;
                    var repos = row.data.m_repository.properties;
                    for (var i = 0; i < repos.length; i++) {
                        var name_1 = repos[i].name;
                        var entity = repos[i].entity;
                        if (this.resourceIdIndex < 0 && name_1 == entity.m_primaryKeyName)
                            this.resourceIdIndex = i;
                        else if (this.resourceNameIndex < 0 && name_1 == entity.m_primaryFieldName)
                            this.resourceNameIndex = i;
                        else if (this.resourceOwnerIdIndex < 0 && name_1 == inputs.attrOwnerId)
                            this.resourceOwnerIdIndex = i;
                    }
                    return this.resourceIdIndex;
                };
                DataProvider.prototype.rowToResource = function (listRows, e) {
                    var length;
                    if (!listRows || !(length = listRows.length))
                        return null;
                    if (this.getResourceIdIndex(listRows[0]) < 0 || this.resourceNameIndex < 0)
                        return null;
                    if (e.startIndex === 0)
                        Scheduler.Source.reset();
                    var resources = [];
                    var startRow = e.startIndex;
                    var endRow = e.endIndex;
                    if (endRow === undefined || endRow === null || endRow < startRow)
                        endRow = startRow + length;
                    for (var i = startRow; i < endRow; i++) {
                        var row = listRows[i].data.m_data;
                        var resource = new Scheduler.Resource(row[this.resourceIdIndex], row[this.resourceNameIndex], this.resourceOwnerIdIndex < 0 ? null : row[this.resourceOwnerIdIndex], null, i, Scheduler.Container.defaultOffice);
                        listRows[i].userData = resource;
                        resources.push(resource);
                    }
                    return resources;
                };
                DataProvider.prototype.reasonTypeToReason = function (reasonValue) {
                    if (reasonValue === 1)
                        return Scheduler.StringTable.get("Msg.PersonalVacation") || "Personal vacation";
                    else if (reasonValue === 2)
                        return Scheduler.StringTable.get("Msg.SickLeave") || "Sick Leave";
                    else if (reasonValue === 3)
                        return Scheduler.StringTable.get("Msg.MaternityPaternityLeave") || "Maternity paternity leave";
                    else if (reasonValue === 4)
                        return Scheduler.StringTable.get("Msg.CompassionateLeave") || "Compassionate leave";
                    else
                        return Scheduler.StringTable.get("Msg.Unknown") || "Unknown";
                };
                DataProvider.prototype.loadTasks = function (inputTasks, timeOffs, resources, timeRange, filter, onFinishCallback) {
                    var _this = this;
                    this._loadTasks(inputTasks, resources, timeRange, filter, function (entityResult) {
                        var resourceDict = new Scheduler.ResourceDictionary();
                        resourceDict.add(resources);
                        _this._addTasksToResources(entityResult, inputTasks, resourceDict, timeRange);
                        if (!timeOffs)
                            onFinishCallback();
                        else {
                            _this._loadTimeOffs(timeOffs, undefined, timeRange, filter, function (entityResult) {
                                var lastResource = undefined;
                                var timeOffStatus = Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.TimeOff];
                                var isFsTimeOff = timeOffs.entityName == "fs_time_off";
                                for (var i = 0; i < entityResult.length; i++) {
                                    var prop = entityResult[i].properties;
                                    var start = prop[timeOffs.attrScheduledStart];
                                    var end = prop[timeOffs.attrScheduledEnd];
                                    var resourceid = prop[timeOffs.attrResourceRef];
                                    if (!start || !end || !resourceid)
                                        continue;
                                    if (!lastResource || (lastResource.getID() !== resourceid.id)) {
                                        var resource = resourceDict.Item(resourceid.id);
                                        if (!resource)
                                            continue;
                                        lastResource = resource;
                                    }
                                    var name_2 = prop[timeOffs.primaryFieldName];
                                    //if (isFsTimeOff)
                                    //	name = this.reasonTypeToReason(name);
                                    var task = new Scheduler.Task(timeOffs, prop[timeOffs.primaryKeyName], name_2, new Date(start).valueOf(), new Date(end).valueOf());
                                    task.setStatus(timeOffStatus);
                                    if (task && timeRange.contain(new Scheduler.TimeRange(task.getWorkStart(), task.getWorkStart() + task.getTotalWorkTime())))
                                        lastResource.addTask(task);
                                }
                                onFinishCallback();
                            });
                        }
                    });
                };
                DataProvider.prototype._loadTasks = function (inputData, resources, timeRange, filter, entityResultCallback) {
                    var entity = new MobileCRM.FetchXml.Entity(inputData.entityName);
                    var filters = [];
                    var _taskDataAttributes = this._createTaskDataAttributes(inputData);
                    entity.attributes = _taskDataAttributes.slice(); // !!!It is necessary to set a new copy (instance) here, because in other case calling "entity.addAttribute()" method below (in taskTemplateController.addAttributesAndLinks()) will accumulate attributes, by adding them to the same instance every call of that code!!!
                    if (resources) {
                        //for (let i = 0; i < resourceCount; i++)
                        //	resources[i].clearTasks();
                        var resourceIds = resources.map(function (i) { i.clearTasks(); return i.getID(); });
                        if (resourceIds && (resourceIds.length > 0)) {
                            var resourceFilter = new MobileCRM.FetchXml.Filter();
                            resourceFilter.isIn(inputData.attrResourceRef, resourceIds);
                            filters.push(resourceFilter);
                        }
                    }
                    if (inputData.attrStatus) {
                        var statusCodeTable = Scheduler.Container.statusCodeTable;
                        var statusArray = statusCodeTable.getSupportedStatusesValues();
                        if (statusArray && (statusArray.length > 0)) {
                            var statusFilter = new MobileCRM.FetchXml.Filter();
                            statusFilter.isIn(inputData.attrStatus, statusArray);
                            filters.push(statusFilter);
                        }
                        if ((statusArray = statusCodeTable.getUnscheduledStatusesValues()) && (statusArray.length > 0)) {
                            var unscheduledFilter = new MobileCRM.FetchXml.Filter();
                            unscheduledFilter.notIn(inputData.attrStatus, statusArray);
                            filters.push(unscheduledFilter);
                        }
                        if (!filter.showCompletedAndCanceled && !filter.monthOverviewMode() && (statusArray = statusCodeTable.getFinishedStatusesValues()) && (statusArray.length > 0)) {
                            var finishedFilter = new MobileCRM.FetchXml.Filter();
                            finishedFilter.notIn(inputData.attrStatus, statusArray);
                            filters.push(finishedFilter);
                        }
                    }
                    if (timeRange) {
                        var startPeriod = undefined;
                        var endPeriod = undefined;
                        if (timeRange.start > 0)
                            startPeriod = new Date(timeRange.start);
                        if (timeRange.end > timeRange.start)
                            endPeriod = new Date(timeRange.end);
                        if (startPeriod || endPeriod) {
                            var timeFilter = new MobileCRM.FetchXml.Filter();
                            // add tasks > as Schedules, when date is in range
                            var f1 = new MobileCRM.FetchXml.Filter();
                            var f2 = undefined;
                            var f3 = undefined;
                            if (inputData.attrStartedOn && inputData.attrEndedOn) {
                                f2 = new MobileCRM.FetchXml.Filter();
                                if (startPeriod) {
                                    f2.where(inputData.attrEndedOn, "not-null", null);
                                    f2.where(inputData.attrEndedOn, "ge", startPeriod);
                                }
                                if (endPeriod) {
                                    f2.where(inputData.attrStartedOn, "not-null", null);
                                    f2.where(inputData.attrStartedOn, "lt", endPeriod);
                                }
                            }
                            if (inputData.attrArrivedOn) {
                                f3 = new MobileCRM.FetchXml.Filter();
                                if (startPeriod) {
                                    f3.where(inputData.attrArrivedOn, "not-null", null);
                                    f3.where(inputData.attrArrivedOn, "ge", startPeriod);
                                }
                                if (endPeriod) {
                                    f3.where(inputData.attrArrivedOn, "not-null", null);
                                    f3.where(inputData.attrArrivedOn, "lt", endPeriod);
                                }
                            }
                            if (endPeriod)
                                f1.where(inputData.attrScheduledStart, "lt", endPeriod);
                            if (startPeriod)
                                f1.where(inputData.attrScheduledEnd, "ge", startPeriod);
                            timeFilter.type = "or";
                            timeFilter.filters = [f1];
                            if (f2)
                                timeFilter.filters.push(f2);
                            if (f3)
                                timeFilter.filters.push(f3);
                            filters.push(timeFilter);
                        }
                    }
                    /*
                    if (inputData.attrStatecode ) {
                        let statusCodeFilter = new MobileCRM.FetchXml.Filter();
                        statusCodeFilter.where(inputData.attrStatecode, "eq", 0);
                        filters.push(statusCodeFilter);
                    }*/
                    var sourceInputs = this._inputData.unscheduledTasks;
                    if (sourceInputs && sourceInputs.isValid && inputData.attrSourceRef) {
                        var linkEntity = entity.addLink(sourceInputs.entityName, sourceInputs.primaryKeyName, inputData.attrSourceRef, "inner");
                        if (sourceInputs.linkAddress) {
                            if (!sourceInputs.linkAddress.linkToAttr) // address is part of source entity
                                inputData.linkLocationRef = inputData.attrSourceRef;
                            else if (inputData.linkLocationRef)
                                linkEntity.addAttribute(sourceInputs.linkAddress.linkToAttr, inputData.linkLocationRef, null);
                        }
                        if (inputData.linkProgress)
                            linkEntity.addAttribute(sourceInputs.attrProgress, inputData.linkProgress, null);
                        if (inputData.linkTerritoryRef)
                            linkEntity.addAttribute(sourceInputs.attrTerritoryRef, inputData.linkTerritoryRef, null);
                        if (inputData.linkSkillRef)
                            linkEntity.addAttribute(sourceInputs.attrSkillRef, inputData.linkSkillRef, null);
                    }
                    entity.addFilter().filters = filters;
                    entity.orderBy(inputData.attrResourceRef, false);
                    if (Scheduler.Container.ref.taskTemplateCtrl.isInitialized)
                        Scheduler.Container.ref.taskTemplateCtrl.addAttributesAndLinks(entity);
                    var fetch = new Scheduler.MultipageFetch();
                    fetch.execute(entity, entityResultCallback);
                };
                DataProvider.prototype._loadTimeOffs = function (inputData, resources, timeRange, filter, entityResultCallback) {
                    var entity = new MobileCRM.FetchXml.Entity(inputData.entityName);
                    var filters = [];
                    if (!this._timeOffsDataAttributes)
                        this._timeOffsDataAttributes = this._createTaskDataAttributes(inputData);
                    entity.attributes = this._timeOffsDataAttributes;
                    if (resources) {
                        var resourceIds = resources.map(function (i) { return i.getID(); });
                        if (resourceIds && (resourceIds.length > 0)) {
                            var resourceFilter = new MobileCRM.FetchXml.Filter();
                            resourceFilter.isIn(inputData.attrResourceRef, resourceIds);
                            filters.push(resourceFilter);
                        }
                    }
                    if (timeRange) {
                        var startPeriod = undefined;
                        var endPeriod = undefined;
                        if (timeRange.start > 0)
                            startPeriod = new Date(timeRange.start);
                        if (timeRange.end > timeRange.start)
                            endPeriod = new Date(timeRange.end);
                        if (startPeriod || endPeriod) {
                            var timeFilter = new MobileCRM.FetchXml.Filter();
                            if (startPeriod)
                                timeFilter.where(inputData.attrScheduledEnd, "ge", startPeriod);
                            if (endPeriod)
                                timeFilter.where(inputData.attrScheduledStart, "lt", endPeriod);
                            filters.push(timeFilter);
                        }
                    }
                    if (filters.length > 0)
                        entity.addFilter().filters = filters;
                    entity.orderBy(inputData.attrResourceRef, false);
                    var fetch = new Scheduler.MultipageFetch();
                    fetch.execute(entity, entityResultCallback);
                };
                DataProvider.prototype._createTaskDataAttributes = function (inputData) {
                    var attrs = [];
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.primaryKeyName));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.primaryFieldName));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrResourceRef));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrScheduledStart));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrScheduledEnd));
                    if (inputData.attrStatus)
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrStatus));
                    if (inputData.attrSourceRef)
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrSourceRef));
                    if (inputData.attrTravelFrom && inputData.attrTravelTo) {
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrTravelTo));
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrTravelFrom));
                        if (inputData.attrTravelMode)
                            attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrTravelMode));
                    }
                    if (inputData.attrWorkduration)
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrWorkduration));
                    if (inputData.attrWindowStart) {
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrWindowStart));
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrWindowEnd));
                    }
                    return attrs;
                };
                DataProvider.prototype._addTasksToResources = function (entityResult, inputData, resourceDict, timeRange) {
                    var lastResource = undefined;
                    for (var i = 0; i < entityResult.length; i++) {
                        var prop = entityResult[i].properties;
                        var scheduledstart = prop[inputData.attrScheduledStart];
                        var scheduledend = prop[inputData.attrScheduledEnd];
                        var ownerid = prop[inputData.attrResourceRef];
                        if (!scheduledstart || !scheduledend)
                            continue;
                        if (!lastResource || (lastResource.getID() !== ownerid.id)) {
                            var resource = resourceDict.Item(ownerid.id);
                            if (!resource)
                                continue;
                            lastResource = resource;
                        }
                        var task = this.rowToScheduledTask(prop);
                        if (task) {
                            if (timeRange.contain(new Scheduler.TimeRange(task.getWorkStart(), task.getWorkStart() + task.getTotalWorkTime())))
                                lastResource.addTask(task);
                            if (this._inputData.sourceToOwnerRelationship && lastResource) {
                                var ownerId = lastResource.getOwnerRef();
                                task.setLinkedResources([ownerId ? ownerId.id : lastResource.getID()]);
                            }
                        }
                    }
                };
                DataProvider.prototype.rowToScheduledTask = function (prop, task) {
                    var inputData = this._inputData.scheduledTasks;
                    if (!task)
                        task = this._createScheduledTaskFromRow(prop, inputData);
                    else if (prop[inputData.primaryKeyName] === task.id)
                        this._updateScheduledTaskFromRow(prop, inputData, task);
                    task.updateTemplateData(inputData.entityName, prop);
                    return task;
                };
                DataProvider.prototype._createScheduledTaskFromRow = function (prop, inputData) {
                    var scheduledstart = prop[inputData.attrScheduledStart];
                    var scheduledend = prop[inputData.attrScheduledEnd];
                    var statuscode = inputData.attrStatus ? prop[inputData.attrStatus] : 1;
                    if (!scheduledstart || !scheduledend)
                        return null;
                    var startDate = new Date(scheduledstart);
                    var endDate = new Date(scheduledend);
                    var sourceRef = inputData.attrSourceRef ? prop[inputData.attrSourceRef] : null;
                    var travel;
                    var task = new Scheduler.Task(inputData, prop[inputData.primaryKeyName], prop[inputData.primaryFieldName], 0, 0);
                    task.progress = inputData.linkProgress ? (prop[inputData.linkProgress] || 0) : 0;
                    task.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(statuscode));
                    if (sourceRef && sourceRef.id) {
                        if (!(task.group = Scheduler.Source.find(sourceRef.id))) {
                            var locationRef = inputData.linkLocationRef ? prop[inputData.linkLocationRef] : undefined;
                            var territoryRef = inputData.linkTerritoryRef ? prop[inputData.linkTerritoryRef] : undefined;
                            var skillRef = inputData.linkSkillRef ? prop[inputData.linkSkillRef] : undefined;
                            task.group = Scheduler.Source.create(task, sourceRef.id, sourceRef.primaryName, locationRef, territoryRef, skillRef, prop);
                        }
                        else
                            task.group.registerVisit(task);
                    }
                    if (inputData.attrTravelFrom && inputData.attrTravelTo) {
                        travel = task.getTravel();
                        travel.to = (prop[inputData.attrTravelTo] || 0) * Scheduler.minuteInMiliseconds;
                        travel.from = (prop[inputData.attrTravelFrom] || 0) * Scheduler.minuteInMiliseconds;
                        if (!inputData.attrTravelMode || !(travel.mode = prop[inputData.attrTravelMode]))
                            travel.mode = Scheduler.TravelMode.Default;
                    }
                    task.requiredWindow = undefined;
                    if (inputData.attrWindowStart && inputData.attrWindowEnd) {
                        var windowstart = prop[inputData.attrWindowStart] || 0;
                        var windowend = prop[inputData.attrWindowEnd] || 0;
                        if (windowstart && windowend < windowstart)
                            task.requiredWindow = new Scheduler.TimeRange(windowstart, windowend);
                    }
                    if (!task.isEditable()) {
                        if (task.getStatus().isFinished() && inputData.linkProgress)
                            task.progress = 100;
                        if (startDate && endDate && inputData.attrStartedOn && inputData.attrEndedOn) {
                            var startedOn = void 0;
                            var arrivedOn = void 0;
                            var scheduledDuration = endDate.valueOf() - startDate.valueOf();
                            if ((startedOn = prop[inputData.attrStartedOn] || 0)) {
                                var endedOn = prop[inputData.attrEndedOn] || 0;
                                startDate = new Date(startedOn);
                                endDate = endedOn ? new Date(endedOn) : new Date(startDate.valueOf() + scheduledDuration);
                            }
                            else if ((arrivedOn = prop[inputData.attrArrivedOn] || 0)) {
                                startDate = new Date(arrivedOn);
                                endDate = new Date(startDate.valueOf() + scheduledDuration);
                            }
                        }
                    }
                    var start = startDate.valueOf();
                    task.setWorkStart(start);
                    task.hasScheduledStart = true;
                    var workduration;
                    if (inputData.attrWorkduration && (workduration = prop[inputData.attrWorkduration]) !== undefined)
                        task.setTotalWorkTime(Scheduler.minutesToMiliseconds(workduration));
                    else {
                        var end = endDate.valueOf();
                        if (end < start)
                            end = start;
                        task.setTotalWorkTime(end - start);
                    }
                    return task;
                };
                DataProvider.prototype._updateScheduledTaskFromRow = function (prop, inputData, task) {
                    var scheduledstart = prop[inputData.attrScheduledStart];
                    var scheduledend = prop[inputData.attrScheduledEnd];
                    var statuscode = inputData.attrStatus ? prop[inputData.attrStatus] : 1;
                    var startDate = scheduledstart ? new Date(scheduledstart) : undefined;
                    var endDate = scheduledend ? new Date(scheduledend) : undefined;
                    var travel = task.getTravel();
                    var s;
                    if ((s = prop[inputData.primaryFieldName]) !== undefined)
                        task.name = s;
                    if (inputData.attrTravelFrom) {
                        if ((s = prop[inputData.attrTravelFrom]) !== undefined)
                            travel.from = Scheduler.minutesToMiliseconds(+s);
                        if ((s = prop[inputData.attrTravelTo]) !== undefined)
                            travel.to = Scheduler.minutesToMiliseconds(+s);
                        if (inputData.attrTravelMode && (s = prop[inputData.attrTravelMode]) !== undefined)
                            travel.mode = +s;
                    }
                    if (inputData.attrWorkduration && (s = prop[inputData.attrWorkduration]) !== undefined)
                        task.setTotalWorkTime(Scheduler.minutesToMiliseconds(+s));
                    //if (prop.scheduledbreak !== undefined) // scheduledBreak is not used now
                    //	task.scheduledBreak = minutesToMiliseconds(+prop.scheduledbreak);
                    if (inputData.attrWindowStart) {
                        var wStart = prop[inputData.attrWindowStart];
                        var wEnd = prop[inputData.attrWindowEnd];
                        if (wStart > 0 && wStart < wEnd)
                            task.requiredWindow = new Scheduler.TimeRange(wStart, wEnd);
                    }
                    if (statuscode !== undefined) {
                        task.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(statuscode));
                        if (!task.isEditable()) {
                            if (startDate && endDate) {
                                var scheduledDuration = endDate.valueOf() - startDate.valueOf();
                                if (inputData.attrStartedOn) {
                                    if ((s = prop[inputData.attrStartedOn])) {
                                        startDate = new Date(s);
                                        s = prop[inputData.attrEndedOn];
                                        endDate = s ? new Date(s) : new Date(startDate.valueOf() + scheduledDuration);
                                    }
                                    else if ((s = prop[inputData.attrArrivedOn])) {
                                        startDate = new Date(s);
                                        endDate = new Date(startDate.valueOf() + scheduledDuration);
                                    }
                                }
                            }
                        }
                    }
                    if (startDate) {
                        task.setWorkStart(startDate.valueOf());
                        task.hasScheduledStart = true;
                    }
                    if (endDate) {
                        var start = task.getWorkStart();
                        var end = endDate.valueOf();
                        if (end < start)
                            end = start;
                        task.setTotalWorkTime(end - start);
                    }
                };
                DataProvider.prototype.hideUnscheduledTasksEntities = function (ids, redraw, onFinishCallback) {
                    if (Scheduler.Container.constants.hideUnscheduledTaskAfterScheduling) {
                        var wasAdded = false;
                        for (var i = 0; i < ids.length; i++) {
                            var id = ids[i];
                            if (Scheduler.Source.numberOfRequiredVisits(id) > 0)
                                continue;
                            var index = this._hiddenHorizontalListEntitiesIds.indexOf(id);
                            if (index === -1) {
                                this._hiddenHorizontalListEntitiesIds.push(id);
                                wasAdded = true;
                            }
                        }
                        if (wasAdded) {
                            Scheduler.Container.ref.updateHorizontalListController(redraw, onFinishCallback);
                            return;
                        }
                    }
                    if (onFinishCallback)
                        onFinishCallback();
                };
                DataProvider.prototype.showUnscheduledTasksEntities = function (ids, redraw, onFinishCallback) {
                    if (Scheduler.Container.constants.hideUnscheduledTaskAfterScheduling) {
                        var wasRemoved = false;
                        if (ids.length === 1) {
                            // search from end, because searched item will be the last item or close to end.
                            var index = this._hiddenHorizontalListEntitiesIds.lastIndexOf(ids[0]);
                            if ((0 <= index) && (index < this._hiddenHorizontalListEntitiesIds.length)) {
                                this._hiddenHorizontalListEntitiesIds.splice(index, 1);
                                wasRemoved = true;
                            }
                        }
                        else {
                            for (var i = 0; i < ids.length; i++) {
                                var index = this._hiddenHorizontalListEntitiesIds.indexOf(ids[i]);
                                if ((0 <= index) && (index < this._hiddenHorizontalListEntitiesIds.length)) {
                                    this._hiddenHorizontalListEntitiesIds.splice(index, 1);
                                    wasRemoved = true;
                                }
                            }
                        }
                        if (wasRemoved) {
                            Scheduler.Container.ref.updateHorizontalListController(redraw, onFinishCallback);
                            return;
                        }
                    }
                    if (onFinishCallback)
                        onFinishCallback();
                };
                return DataProvider;
            }());
            Scheduler.DataProvider = DataProvider;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=dataProvider.js.map