///<reference path="../../../MobileCrm/www/TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../../MobileCrm/www/Controls/popupMenu.ts"/>
///<reference path="../../../MobileCrm/www/Controls/gestureManager.ts"/>
///<reference path="data/resource.ts" />
///<reference path="data/source.ts" />
///<reference path="data/enums.ts" />
///<reference path="utilities.ts" />
///<reference path="container.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var Travel = /** @class */ (function () {
                function Travel(travelTo, travelFrom, mode) {
                    this.to = travelTo;
                    this.from = travelFrom;
                    this._mode = mode;
                    if (!this._mode)
                        this._mode = Scheduler.TravelMode.Default;
                    else
                        this.validate();
                }
                Object.defineProperty(Travel.prototype, "mode", {
                    get: function () {
                        return this._mode;
                    },
                    set: function (m) {
                        this._mode = m;
                        this.validate();
                    },
                    enumerable: true,
                    configurable: true
                });
                Travel.prototype.validate = function () {
                    if ((this._mode & Scheduler.TravelMode.ToNextClient) === Scheduler.TravelMode.ToNextClient) // duration is included in next client "this.to" value
                        this.from = 0;
                };
                Object.defineProperty(Travel.prototype, "toInMinutes", {
                    get: function () {
                        return Math.floor(this.to / Scheduler.minuteInMiliseconds);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Travel.prototype, "fromInMinutes", {
                    get: function () {
                        return Math.floor(this.from / Scheduler.minuteInMiliseconds);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Travel.prototype, "duration", {
                    get: function () {
                        return this.to + this.from;
                    },
                    enumerable: true,
                    configurable: true
                });
                Travel.prototype.equal = function (travel) {
                    return this.to === travel.to && this.from === travel.from && this.mode === travel.mode;
                };
                Travel.prototype.clone = function () {
                    return new Travel(this.to, this.from, this.mode);
                };
                return Travel;
            }());
            Scheduler.Travel = Travel;
            var TaskSchedule = /** @class */ (function () {
                function TaskSchedule(workStart, totalWorkTime, travel, entityInput, containerView) {
                    this._containerView = Scheduler.TaskContainerView.None; // determine parent view container where the TaskSchedule (task box) is currently present
                    this.hasScheduledStart = false; // is false when start is set to temporary Date.now() value
                    this.entityInput = entityInput;
                    this._containerView = ((containerView === undefined) || (containerView === null)) ? Scheduler.TaskContainerView.None : containerView;
                    this._updateTaskSchedule(workStart, totalWorkTime, travel);
                    this.hasScheduledStart = true;
                }
                Object.defineProperty(TaskSchedule.prototype, "containerView", {
                    /*
                    get entityInput(): ScheduledDataInput {
                        return this._entityInput;
                    }
            
                    set entityInput(value: ScheduledDataInput) {
                        if (value !== this._entityInput) {
                            this._entityInput = value;
                            this._updateTaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), this.getTravel());
                        }
                    }*/
                    get: function () {
                        return this._containerView;
                    },
                    set: function (value) {
                        if (value !== this._containerView) {
                            this._containerView = value;
                            this._updateTaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), this.getTravel());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                TaskSchedule.prototype.cloneTaskSchedule = function () {
                    return new TaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), this.getTravel(), this.entityInput, this.containerView);
                };
                TaskSchedule.prototype.getTotalWorkTime = function () {
                    return this._taskSchedule.getTotalWorkTime();
                };
                TaskSchedule.prototype.setTotalWorkTime = function (value) {
                    this._updateTaskSchedule(this.getWorkStart(), value, this.getTravel());
                };
                TaskSchedule.prototype.getWorkStart = function () {
                    return this._taskSchedule.getWorkStart();
                };
                TaskSchedule.prototype.setWorkStart = function (value) {
                    this._updateTaskSchedule(value, this.getTotalWorkTime(), this.getTravel());
                    this.hasScheduledStart = true;
                };
                TaskSchedule.prototype.getWorkEnd = function () {
                    return this._taskSchedule.getWorkEnd();
                };
                TaskSchedule.prototype.getStart = function () {
                    return this._taskSchedule.getStart();
                };
                TaskSchedule.prototype.getEnd = function () {
                    return this._taskSchedule.getEnd();
                };
                TaskSchedule.prototype.setTravel = function (travel) {
                    this._updateTaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), travel);
                };
                TaskSchedule.prototype.getTravel = function () {
                    return this._taskSchedule.getTravel();
                };
                TaskSchedule.prototype.getTotalTravelTo = function () {
                    return this._taskSchedule.getTotalTravelTo();
                };
                TaskSchedule.prototype.getTotalTravelFrom = function () {
                    return this._taskSchedule.getTotalTravelFrom();
                };
                TaskSchedule.prototype.createContent = function (task, parentElement, doNotCreateIfNotNecessary) {
                    if (this._taskSchedule instanceof SplittedSchedule) {
                        this._taskSchedule.createContent(task, parentElement);
                    }
                    else {
                        if (!doNotCreateIfNotNecessary || !SimpleSchedule.isDrawnAsSimple(parentElement)) {
                            parentElement.innerHTML = "";
                            this._taskSchedule.createContent(task, parentElement);
                        }
                    }
                };
                /**
                 * Returns true if work is scheduled outside working hours.
                 */
                TaskSchedule.prototype.isOutsideWorkingHours = function () {
                    return this._taskSchedule.isOutsideWorkingHours();
                };
                /**
                 * Returns true if there is not enough time for travel to and travel from.
                 * @param task Task for which TravelUnavailability should be checked.
                 * @param tasksInCollisionCount Tasks of this task resource in which is this task in collision. (Used to reduce resource.getPeriodCollisions() calls.)
                 */
                TaskSchedule.prototype.isTravelUnavailability = function (task, tasksInCollisionCount) {
                    return this._taskSchedule.isTravelUnavailability(task, tasksInCollisionCount);
                };
                TaskSchedule.prototype.isTimeOff = function () {
                    if (Scheduler.Container.inputs.timeOffSchedules && Scheduler.Container.inputs.timeOffSchedules.entityName) {
                        if (this.entityInput.entityName === Scheduler.Container.inputs.timeOffSchedules.entityName) {
                            return true;
                        }
                    }
                    return false;
                };
                TaskSchedule.prototype._updateTaskSchedule = function (workStart, totalWorkTime, travel) {
                    this._taskSchedule = this._createTaskSchedule(workStart, totalWorkTime, travel);
                };
                TaskSchedule.prototype._createTaskSchedule = function (workStart, totalWorkTime, travel) {
                    if (Scheduler.Container.constants.viewSplitOvertimeTasks && (this.containerView !== Scheduler.TaskContainerView.IsInUndefinedTasksContainer) && !this.isTimeOff()) {
                        var range = new Scheduler.TimeRange(workStart, workStart + totalWorkTime);
                        if (range.duration() > (Scheduler.Container.defaultOffice.workingDayDuration * Scheduler.minuteInMiliseconds)) {
                            var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(range, travel.to, travel.from);
                            if (workTimeRanges[0].start > range.start) {
                                // use implementation for splitted TaskSchedule with start in next working hours
                                return new SplittedNextSchedule(workStart, totalWorkTime, travel);
                            }
                            else if (workTimeRanges.length > 1) { // ((workTimeRanges[0].start === range.start) && (workTimeRanges.length > 1))
                                // use implementation for splitted TaskSchedule with start in current working hours
                                return new SplittedSchedule(workStart, totalWorkTime, travel);
                            }
                        }
                    }
                    // use implementation for simple TaskSchedule
                    return new SimpleSchedule(workStart, totalWorkTime, travel);
                };
                return TaskSchedule;
            }());
            Scheduler.TaskSchedule = TaskSchedule;
            // Implementation for simple TaskSchedule.
            var SimpleSchedule = /** @class */ (function () {
                function SimpleSchedule(workStart, totalWorkTime, travel) {
                    this._workStart = workStart;
                    this._totalWorkTime = totalWorkTime;
                    this._travel = travel.clone();
                }
                SimpleSchedule.prototype.getTotalWorkTime = function () {
                    return this._totalWorkTime;
                };
                SimpleSchedule.prototype.getWorkStart = function () {
                    return this._workStart;
                };
                SimpleSchedule.prototype.getWorkEnd = function () {
                    return this.getWorkStart() + this.getTotalWorkTime();
                };
                SimpleSchedule.prototype.getStart = function () {
                    return this.getWorkStart() - this.getTravel().to;
                };
                SimpleSchedule.prototype.getEnd = function () {
                    return this.getWorkEnd() + this.getTravel().from;
                };
                SimpleSchedule.prototype.getTravel = function () {
                    return this._travel;
                };
                SimpleSchedule.prototype.getTotalTravelTo = function () {
                    return this.getTravel().to;
                };
                SimpleSchedule.prototype.getTotalTravelFrom = function () {
                    return this.getTravel().from;
                };
                SimpleSchedule.prototype.createContent = function (task, element) {
                    element.classList.remove("splittedTask");
                    element.classList.add("taskStatusColor");
                    var taskStatus = task.getStatus();
                    var taskIsInPast = task.getEnd() < task.container.viewCtrl.timeNow;
                    if (taskIsInPast)
                        taskStatus.setElementCSS(element, Scheduler.StatusCSS.PastTask);
                    else
                        taskStatus.setElementCSS(element, Scheduler.StatusCSS.Default);
                    if (!this._createContentFromRowTemplate(task, element))
                        this._createContent(task, element, taskStatus, taskIsInPast);
                };
                SimpleSchedule.prototype._createContent = function (task, element, taskStatus, taskIsInPast) {
                    var taskNameDiv = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskNameDiv"]);
                    var taskBottomDiv = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskBottomDiv"]);
                    var nameText = Scheduler.Utilities.createNewHTMLElement("span", null, null, ["text"], task.name);
                    taskNameDiv.appendChild(nameText);
                    if (task.progress > 0 && taskStatus.hasProgress() && !task.isTimeOff()) {
                        var bkgProgressColor = taskStatus.progressColor();
                        var progress = task.progress;
                        if (progress > 100)
                            progress = 100;
                        var taskProgressBar = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: progress + "%" }], ["taskProgressBar"]);
                        var progressText = Scheduler.Utilities.createNewHTMLElement("span", null, null, ["taskProgress", "text"], progress + "%");
                        taskProgressBar.style.backgroundColor = taskIsInPast ? Scheduler.ColorCache.applyColorAlpha(bkgProgressColor, 0.3) : bkgProgressColor;
                        taskBottomDiv.appendChild(taskProgressBar);
                        taskBottomDiv.appendChild(progressText);
                    }
                    taskBottomDiv.appendChild(this._createTaskAlertElement(task));
                    element.appendChild(taskNameDiv);
                    element.appendChild(taskBottomDiv);
                };
                SimpleSchedule.prototype._createContentFromRowTemplate = function (task, element) {
                    if (task.container.taskTemplateCtrl.isInitialized) {
                        var taskTemplateHeight = task.container.taskTemplateHeight;
                        if (taskTemplateHeight || (taskTemplateHeight === 0)) {
                            var contentElement = task.container.taskTemplateCtrl.getTaskContent(task, taskTemplateHeight);
                            if (contentElement && (contentElement.length > 0)) {
                                element.appendChild(contentElement[0]);
                                element.appendChild(this._createTaskAlertElement(task));
                                return true;
                            }
                        }
                    }
                    return false;
                };
                /**
                 * Returns true if work is scheduled outside working hours.
                 */
                SimpleSchedule.prototype.isOutsideWorkingHours = function () {
                    var timeRange = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkEnd());
                    var workingHoursTimeRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(timeRange.start);
                    if (!timeRange.isInside(workingHoursTimeRange))
                        return true;
                    return false;
                };
                /**
                 * Returns true if there is not enough time for travel to and travel from.
                 * @param resource Task resource.
                 * @param tasksInCollisionCount Tasks of this task resource in which is this task in collision. (Used to reduce resource.getPeriodCollisions() calls.)
                 */
                SimpleSchedule.prototype.isTravelUnavailability = function (task, tasksInCollisionCount) {
                    var displayedTimeRange = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkEnd());
                    var earliestWorkingHoursRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(displayedTimeRange.start);
                    if (!displayedTimeRange.isInside(earliestWorkingHoursRange))
                        return { unavailable: false, collisions: [] };
                    var displayedTimeRangeWithTravel = new Scheduler.TimeRange(this.getStart(), this.getEnd());
                    if (displayedTimeRangeWithTravel.start < earliestWorkingHoursRange.start)
                        return { unavailable: true, collisions: [] };
                    if (displayedTimeRangeWithTravel.end > earliestWorkingHoursRange.end)
                        return { unavailable: true, collisions: [] };
                    if (task.resource) {
                        var tasksWithTravelInCollision = task.resource.getPeriodCollisions(displayedTimeRangeWithTravel, false, false, task.id);
                        if (tasksWithTravelInCollision.length > tasksInCollisionCount)
                            return { unavailable: true, collisions: tasksWithTravelInCollision };
                    }
                    return { unavailable: false, collisions: [] };
                };
                SimpleSchedule.prototype._createTaskAlertElement = function (task) {
                    var imageSize = 16;
                    var image = Scheduler.Utilities.createNewHTMLElement("image", null, [{ styleName: "width", styleValue: imageSize + "px" }, { styleName: "height", styleValue: imageSize + "px" }], ["taskAlert"]);
                    if (task.getStatus().isUnscheduled() && !task.isUnscheduledNew()) {
                        Scheduler.Container.setElementBackgroundImage(image, "jeopardy.png");
                        this._updateAlertElement(image, task.isInJeopardy());
                    }
                    else {
                        Scheduler.Container.setElementBackgroundImage(image, "ruleViolations.png");
                        this._updateAlertElement(image, task.hasViolations());
                    }
                    return image;
                };
                /**
                 * Use in case when task alert element is not appended yet to the ganttElement when task is constructing.
                 * @param visible
                 * @param alertElement
                 */
                SimpleSchedule.prototype._updateAlertElement = function (alertElement, visible) {
                    if (alertElement && alertElement.classList) {
                        if (visible)
                            alertElement.classList.add("visible");
                        else
                            alertElement.classList.remove("visible");
                    }
                };
                SimpleSchedule.isDrawnAsSimple = function (parentElement) {
                    if (parentElement) {
                        if (!parentElement.classList.contains("splittedTask") && (parentElement.children.length > 0))
                            return parentElement.children.item(0).classList.contains("taskNameDiv");
                    }
                    return false;
                };
                return SimpleSchedule;
            }());
            // Implementation for splitted TaskSchedule with start in current working hours.
            var SplittedSchedule = /** @class */ (function (_super) {
                __extends(SplittedSchedule, _super);
                function SplittedSchedule(workStart, totalWorkTime, travel) {
                    return _super.call(this, workStart, totalWorkTime, travel) || this;
                }
                SplittedSchedule.prototype.getWorkEnd = function () {
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime()), this.getTravel().to, this.getTravel().from);
                    return workTimeRanges[workTimeRanges.length - 1].end;
                };
                SplittedSchedule.prototype.getStart = function () {
                    return this.getWorkStart() - this.getTravel().to;
                };
                SplittedSchedule.prototype.getTotalTravelTo = function () {
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime()), this.getTravel().to, this.getTravel().from);
                    return workTimeRanges.length * this.getTravel().to;
                };
                SplittedSchedule.prototype.getTotalTravelFrom = function () {
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime()), this.getTravel().to, this.getTravel().from);
                    return workTimeRanges.length * this.getTravel().from;
                };
                SplittedSchedule.prototype.createContent = function (task, parentElement, hasStartInNext) {
                    parentElement.classList.remove("taskStatusColor");
                    parentElement.classList.add("splittedTask");
                    parentElement.style.backgroundColor = "";
                    parentElement.innerHTML = "";
                    var travel = this.getTravel();
                    var range = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime());
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(range, travel.to, travel.from);
                    var view = task.container.viewCtrl;
                    var taskBoxDashedDiv = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskBoxDashedDiv"]);
                    parentElement.appendChild(taskBoxDashedDiv);
                    var taskSubTravels = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskSubTravels"]);
                    var taskBoxDivOffset = view.zoom.timeToPixelPosition(range.start);
                    for (var i = 0; i < workTimeRanges.length; i++) {
                        var workTimeRange = workTimeRanges[i];
                        var x1 = view.zoom.timeToPixelPosition(workTimeRange.start) - taskBoxDivOffset;
                        var x2 = view.zoom.timeToPixelPosition(workTimeRange.end) - taskBoxDivOffset;
                        // travel to
                        if ((i > 0) || hasStartInNext) {
                            var tt1 = view.zoom.timeToPixelPosition(workTimeRange.start - travel.to) - taskBoxDivOffset;
                            var travelToElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "left", styleValue: tt1 + "px" },
                                { styleName: "width", styleValue: (x1 - tt1) + "px" }], ["taskTravelTo"]);
                            taskSubTravels.appendChild(travelToElement);
                        }
                        // subDiv
                        var taskBoxSubDiv = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "left", styleValue: x1 + "px" }, { styleName: "width", styleValue: (x2 - x1) + "px" }], ["taskBoxSubDiv"]);
                        _super.prototype.createContent.call(this, task, taskBoxSubDiv);
                        parentElement.appendChild(taskBoxSubDiv);
                        // travel from
                        if (i < (workTimeRanges.length - 1)) {
                            var tf2 = view.zoom.timeToPixelPosition(workTimeRange.end + travel.from) - taskBoxDivOffset;
                            var travelFromElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "left", styleValue: x2 + "px" }, { styleName: "width", styleValue: (tf2 - x2) + "px" }], ["taskTravelFrom"]);
                            taskSubTravels.appendChild(travelFromElement);
                        }
                    }
                    parentElement.appendChild(taskSubTravels);
                };
                /**
                 * Returns false always.
                 */
                SplittedSchedule.prototype.isOutsideWorkingHours = function () {
                    return false;
                };
                /**
                 * Returns true if there is not enough time for travel to and travel from.
                 * @param resource Task resource.
                 * @param tasksInCollisionCount Tasks of this task resource in which is this task in collision. (Used to reduce resource.getPeriodCollisions() calls.)
                 */
                SplittedSchedule.prototype.isTravelUnavailability = function (task, tasksInCollisionCount) {
                    var displayedTimeRange = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkEnd());
                    var earliestWorkingHoursRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(displayedTimeRange.start);
                    var lastWorkingHoursTimeRange = Scheduler.Container.defaultOffice.getLastWorkingHoursRange(displayedTimeRange.end);
                    var displayedTimeRangeWithTravel = new Scheduler.TimeRange(this.getStart(), this.getEnd());
                    if (displayedTimeRangeWithTravel.start < earliestWorkingHoursRange.start)
                        return { unavailable: true, collisions: [] };
                    if (displayedTimeRangeWithTravel.end > lastWorkingHoursTimeRange.end)
                        return { unavailable: true, collisions: [] };
                    if (task.resource) {
                        var tasksWithTravelInCollision = task.resource.getPeriodCollisions(displayedTimeRangeWithTravel, false, false, task.id);
                        if (tasksWithTravelInCollision.length > tasksInCollisionCount)
                            return { unavailable: true, collisions: tasksWithTravelInCollision };
                    }
                    return { unavailable: false, collisions: [] };
                };
                return SplittedSchedule;
            }(SimpleSchedule));
            // Implementation for splitted TaskSchedule with start in next working hours.
            var SplittedNextSchedule = /** @class */ (function (_super) {
                __extends(SplittedNextSchedule, _super);
                function SplittedNextSchedule() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                SplittedNextSchedule.prototype.getStart = function () {
                    return this.getWorkStart();
                };
                SplittedNextSchedule.prototype.createContent = function (task, parentElement) {
                    _super.prototype.createContent.call(this, task, parentElement, true);
                };
                return SplittedNextSchedule;
            }(SplittedSchedule));
            var Task = /** @class */ (function (_super) {
                __extends(Task, _super);
                //public static performances: Performance[] = []; //for performance measurement only
                //public static perfdata: number[] = []; //for performance measurement only
                function Task(input, id, name, start, end, workDuration) {
                    var _this = _super.call(this, start, workDuration ? workDuration : end - start, new Travel(0, 0), input) || this;
                    _this.ruleViolations = [];
                    _this.progress = 0;
                    _this._mouseenterCachedTask = undefined; // This mechanism allows to create tooltip properly, although mouseenter event occurs before the task has set correct position after drag & drop.
                    _this._timeoutID = null;
                    _this.id = id;
                    _this.name = name;
                    _this.container = Scheduler.Container.ref;
                    return _this;
                }
                Task.prototype.clone = function () {
                    var task = new Task(this.entityInput, this.id, this.name, this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime());
                    for (var key in this) {
                        if (typeof (this[key]) !== "function") {
                            task[key] = this[key];
                        }
                    }
                    return task;
                };
                ;
                Object.defineProperty(Task, "borderWidth", {
                    get: function () {
                        return Task._borderWidth;
                    },
                    set: function (value) {
                        Task._borderWidth = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Task, "borderRadius", {
                    get: function () {
                        return Task._borderRadius;
                    },
                    set: function (value) {
                        Task._borderRadius = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Task.prototype.getID = function () {
                    return this.id;
                };
                Task.prototype.getName = function () {
                    return this.name;
                };
                Task.prototype.getBoxPosition = function () {
                    return this.ganttElement.position();
                };
                Object.defineProperty(Task.prototype, "taskBoxDiv", {
                    get: function () {
                        return this.ganttElement.children(".taskBoxDiv");
                    },
                    enumerable: true,
                    configurable: true
                });
                Task.prototype.drawBox = function (parentElement, refreshableContainer) {
                    if (refreshableContainer && this.ganttElement) {
                        var taskBox = refreshableContainer.find(".taskBoxWrapper[data-taskid='" + this.id + "']");
                        if (taskBox && taskBox.length > 0)
                            return;
                    }
                    if (!this.getStatus().isUnscheduled() || this.isUnscheduledNew())
                        this.createTaskElement(parentElement);
                };
                Task.prototype.setValues = function (values, ignoreVerification) {
                    var changes = 0;
                    var resetSort = 0;
                    if (values.name) {
                        this.name = values.name;
                        changes++;
                    }
                    if (values.progress || values.progress === 0) {
                        this.progress = values.progress;
                        changes++;
                    }
                    if ((values.travelTo === 0 || values.travelTo > 0) ||
                        (values.travelFrom === 0 || values.travelFrom > 0)) {
                        if (values.travelTo === undefined)
                            values.travelTo = this.getTravel().to;
                        if (values.travelFrom === undefined)
                            values.travelFrom = this.getTravel().from;
                        this.setTravel(new Travel(values.travelTo, values.travelFrom, values.travelMode));
                        changes++;
                    }
                    //if (values.scheduledBreak === 0 && values.scheduledBreak > 0) { // scheduledBreak is not used now
                    //	this.scheduledBreak = values.scheduledBreak;
                    //	changes++;
                    //}
                    if (values.start) {
                        this.setWorkStart(values.start);
                        changes++;
                        resetSort++;
                    }
                    if (values.end) {
                        this.setTotalWorkTime(values.end - values.start);
                        changes++;
                        resetSort++;
                    }
                    // reassign must be after start/end save
                    var parentID = this.resource ? this.resource.getID() : undefined;
                    if (values.hasOwnProperty("parentID")) {
                        var statuscode = values.statuscode;
                        this.container.reassignTask(this, values.parentID, false);
                        if (statuscode !== undefined)
                            this.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(statuscode));
                        changes++;
                        resetSort++;
                    }
                    else if (values.statuscode !== undefined) {
                        this.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(values.statuscode));
                        if (this.getStatus().isUnscheduled() && !this.isUnscheduledNew())
                            this.container.setTaskAsUnscheduled(this, false);
                        resetSort++;
                        changes++;
                    }
                    if (resetSort && this.resource)
                        this.resource.resetSort();
                    return changes > 0;
                };
                /*
                public setTimes(workStart: number, workEnd: number, travelTo?: number, travelFrom?: number): boolean {
                    this.start = workStart;
                    this.end = workEnd;
                    if (travelTo )
                        this.travelTo = travelTo;
                    if (travelFrom)
                        this.travelFrom = travelFrom;
                    return true;
                }*/
                Task.prototype.isValidAssignment = function (newParent) {
                    if (!this.allowedResourceIds)
                        return this.allowedResourceIds === null; // if undefined, allowedResourceIds has not been loaded yet
                    if (newParent) {
                        if (this.allowedResourceIds.length === 0)
                            return true;
                        var id = newParent.getID();
                        if (this.resource && this.resource.getID() === id)
                            return true;
                        for (var i = 0; i < this.allowedResourceIds.length; i++) {
                            var resourceId = this.allowedResourceIds[i];
                            if (resourceId === id) {
                                return true;
                            }
                        }
                    }
                    return false;
                };
                Task.prototype.getParent = function () {
                    return this.resource;
                };
                Task.prototype.setParent = function (res) {
                    this.resource = res;
                };
                Task.prototype.hasViolations = function () {
                    return this.ruleViolations.length > 0;
                };
                Task.prototype.linkedResources = function () {
                    return this.allowedResourceIds;
                };
                Task.prototype.setLocation = function (location) {
                    this.location = location;
                };
                Task.prototype.getLocation = function () {
                    return this.location;
                };
                Task.prototype.loadLocation = function (onLoad) {
                    if (this.location !== undefined || !this.container) {
                        if (onLoad)
                            onLoad(null);
                    }
                    else
                        this.container.dataProvider.loadLocations([this], onLoad);
                };
                Task.prototype.removeBox = function () {
                    var draggableContainer = this.container.draggableContainer;
                    if (draggableContainer.isFocusedTask(this))
                        draggableContainer.takeFocusFromFocusedTask();
                    if (this.ganttElement) {
                        this.ganttElement.remove();
                        this.ganttElement = undefined;
                    }
                };
                Task.prototype.isUnscheduledNew = function () {
                    return this.id.indexOf("New_") === 0;
                };
                Task.prototype.getStatus = function () {
                    return this._status;
                };
                Task.prototype.setStatus = function (status) {
                    if (status) {
                        this._status = status;
                        if (this.getStatus().isFinished())
                            this.progress = 100;
                    }
                };
                Task.prototype.isEditable = function () {
                    return this.entityInput.canWrite && (this.container ? this.container.canModifyTasks : true) && this.getStatus().isEditable();
                };
                Task.isValidStatusValue = function (statusValue) {
                    var statusList = Scheduler.Container.statusCodeTable.statusList;
                    for (var i = 0; i < statusList.length; i++) {
                        if (statusList[i].value() === statusValue)
                            return true;
                    }
                    return false;
                };
                Task.prototype.getLinkedResources = function () {
                    return this.allowedResourceIds;
                };
                Task.prototype.setLinkedResources = function (resIds) {
                    this.allowedResourceIds = resIds;
                };
                Task.prototype.loadLinkedResources = function (onFinishCallback) {
                    if (this.allowedResourceIds !== undefined) {
                        if (onFinishCallback)
                            onFinishCallback(null);
                    }
                    else if (this.container) {
                        var self = this;
                        this.container.dataProvider.loadQualifiedResources([this], function (error) {
                            //self.allowedResourceIds = allowedResourceIds !== undefined ? allowedResourceIds : null;
                            if (onFinishCallback)
                                onFinishCallback(error);
                        });
                    }
                };
                Task.prototype.failed = function (errorCallback, errId) {
                    if (errorCallback)
                        errorCallback(Scheduler.StringTable.get(errId));
                    return false;
                };
                Task.prototype.isValidReassign = function (parent, start, end) {
                    var timeRangeWithTravel = new Scheduler.TimeRange(start, end);
                    if (!this.isEditable() || this.container.isLocked())
                        return { isValid: false, error: (Scheduler.StringTable.get("Err.CantModifyEntity") || "Can't modify entity") };
                    if (!timeRangeWithTravel.isValid() /*|| !timeRangeWithTravel.isInside(this.container.editableRange)*/)
                        return { isValid: false, error: (Scheduler.StringTable.get("Err.TimesOutOfScope") || "Start and end times are out of scope.") };
                    // validation of parent
                    var reassignOrMove = this._shouldReassignOrMove(parent);
                    if (reassignOrMove.reassign === null) {
                        return { isValid: false, error: reassignOrMove.error };
                    }
                    else if (parent !== this.resource) {
                        if (!this.isValidAssignment(parent))
                            return { isValid: false, error: (Scheduler.StringTable.get("Scheduler.Err.AssigmentFailed") || "Work scheduled can't be attached to the selected resource.") };
                    }
                    //scheduled during weekend
                    var office = parent ? parent.getOffice() : Scheduler.Container.defaultOffice;
                    if (!office.workingWeekends && Scheduler.Utilities.isWeekend(new Date(timeRangeWithTravel.start)))
                        return { isValid: false, error: (Scheduler.StringTable.get("Scheduler.Err.FreeWeekend") || "Work scheduled during weekend.") };
                    if (Scheduler.Utilities.isHoliday(new Date(timeRangeWithTravel.start)))
                        return { isValid: false, error: (Scheduler.StringTable.get("Scheduler.Err.FreeHoliday") || "Work scheduled during holiday.") };
                    var tasksInCollision;
                    if ((tasksInCollision = parent.getPeriodCollisions(timeRangeWithTravel, true, false, this.id)).length > 0) {
                        if (tasksInCollision[0].isTimeOff())
                            return { isValid: false, error: (Scheduler.StringTable.get("Scheduler.Err.ResourceHasTimeOff") || "At the required time the resource has planned Time-Off.") };
                        else
                            return { isValid: false, error: (Scheduler.StringTable.get("Scheduler.Err.TaskInConflict") || "Task is in conflict with another Task's time frame.") };
                    }
                    if (this.group)
                        return this.group.visitCanBeScheduled(this, parent, start, end);
                    return { isValid: true, error: "" }; // It is better to return explicit true if reassignment is valid, in case localization key or string returns "" also.
                };
                Task.prototype.getRowIndex = function () {
                    return this.resource ? this.resource.rowIndex : -1;
                };
                ;
                Task.prototype._checkSchedulingInPast = function (workStart, onFinishCallback) {
                    if (workStart < Date.now()) {
                        Task.wasMsgSchedulingInPast = true;
                        var yes_1 = Scheduler.StringTable.get("Cmd.Yes") || "Yes";
                        var no = Scheduler.StringTable.get("Cmd.No") || "No";
                        var popup = new MobileCRM.UI.MessageBox(Scheduler.StringTable.get("Scheduler.Msg.AskSchedulingInPast") || "Are you sure you want to schedule task in the past?");
                        popup.items = [yes_1, no];
                        popup.multiLine = true;
                        popup.show(function (button) {
                            onFinishCallback(button === yes_1);
                        });
                    }
                    else {
                        Task.wasMsgSchedulingInPast = false;
                        onFinishCallback(true);
                    }
                };
                // !!!If you call the tryReassign() method, Task.wasMsgSchedulingInPast property needs to be set to false in the onFinishCallback!!!
                Task.prototype.tryReassign = function (newParent, workStart, checkSchedulingInPast, onFinishCallback) {
                    var _this = this;
                    var newTaskSchedule = this.cloneTaskSchedule();
                    newTaskSchedule.setWorkStart(workStart);
                    if (this.isValidReassign(newParent, newTaskSchedule.getStart(), newTaskSchedule.getEnd()).isValid) {
                        var reassignOrMove_1 = this._shouldReassignOrMove(newParent);
                        if (reassignOrMove_1.reassign !== null) {
                            if (checkSchedulingInPast) {
                                this._checkSchedulingInPast(workStart, function (success) {
                                    if (success) {
                                        _this._save(newParent, workStart, reassignOrMove_1, onFinishCallback);
                                    }
                                    else {
                                        onFinishCallback(false);
                                    }
                                });
                            }
                            else {
                                this._save(newParent, workStart, reassignOrMove_1, onFinishCallback);
                            }
                            return;
                        }
                    }
                    onFinishCallback(false);
                };
                Task.prototype._save = function (newParent, workStart, reassignOrMove, onFinishCallback) {
                    var taskChanges = this.prepareTaskChanges(workStart, this.getTotalWorkTime(), reassignOrMove.reassign === true ? newParent : null);
                    this.container.saveTask(this, taskChanges)
                        .then(function () {
                        onFinishCallback(true);
                    })
                        .catch(function (error) {
                        var msg = (error instanceof Resco.Exception) ? error.message : error.toString();
                        Scheduler.StringTable.alert(msg);
                        onFinishCallback(false);
                    }); //@JC performs move, resize or parent task reassignment asynchronously if JSBridge finds taskChanges as valid.
                };
                Task.prototype._shouldReassignOrMove = function (newParent) {
                    if (!newParent) {
                        return { reassign: null, error: (Scheduler.StringTable.get("Scheduler.Err.NotValidNewResource") || "Task must have valid resource.") };
                    }
                    if (this.getStatus().isUnscheduled()) {
                        return { reassign: true, error: "" }; // reassign
                    }
                    else {
                        if (this.resource) {
                            if (newParent.getID() === this.resource.getID()) {
                                return { reassign: false, error: "" }; // move
                            }
                            else {
                                return { reassign: true, error: "" }; // reassign
                            }
                        }
                        else {
                            return { reassign: null, error: (Scheduler.StringTable.get("Scheduler.Err.NotValidTaskResource") || "Task has set invalid resource.") };
                        }
                    }
                };
                Task.prototype.prepareTaskChanges = function (workStart, totalWorkTime, newParent) {
                    var taskChanges = {};
                    if (this.isUnscheduledNew()) {
                        //copy all properties except internal
                        for (var key in this) {
                            if (Task.internalProperties.indexOf(key) === -1) {
                                taskChanges[key] = this[key];
                            }
                        }
                    }
                    taskChanges.id = this.id;
                    taskChanges.start = workStart;
                    taskChanges.totalWork = totalWorkTime;
                    if (newParent)
                        taskChanges.parentID = newParent.getID();
                    return taskChanges;
                };
                Task.prototype.applyChanges = function (taskChanges, redraw) {
                    if (taskChanges.name)
                        this.name = taskChanges.name;
                    if (taskChanges.progress !== undefined && taskChanges.progress !== null && taskChanges.progress >= 0)
                        this.progress = taskChanges.progress;
                    if (taskChanges.travelTo !== undefined || taskChanges.travelFrom !== undefined || taskChanges.travelMode !== undefined) {
                        var travel = this.getTravel().clone();
                        if (taskChanges.travelTo === 0 || taskChanges.travelTo >= 0)
                            travel.to = taskChanges.travelTo;
                        if (taskChanges.travelFrom === 0 || taskChanges.travelFrom >= 0)
                            travel.from = taskChanges.travelFrom;
                        if (taskChanges.travelMode !== undefined)
                            travel.mode = taskChanges.travelMode;
                        this.setTravel(travel);
                    }
                    //if (taskChanges.scheduledBreak !== undefined && taskChanges.scheduledBreak !== null && taskChanges.scheduledBreak >= 0)
                    //	this.scheduledBreak = taskChanges.scheduledBreak; // scheduledBreak is not used now
                    if (taskChanges.start || taskChanges.totalWork) {
                        if (taskChanges.start)
                            this.setWorkStart(taskChanges.start);
                        if (taskChanges.totalWork)
                            this.setTotalWorkTime(taskChanges.totalWork);
                        //taskChanges.end = this.getWorkEnd(); // we have to recalculate and save also new working end
                        if (this.resource)
                            this.resource.resetSort();
                    }
                    // reassign must be after start/totalWork save
                    if (taskChanges.hasOwnProperty("parentID"))
                        this.container.reassignTask(this, taskChanges.parentID, redraw);
                    if (taskChanges.statuscode !== undefined) {
                        this.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(taskChanges.statuscode));
                        if (this.getStatus().isUnscheduled() && !this.isUnscheduledNew()) {
                            this.container.setTaskAsUnscheduled(this, redraw);
                            return;
                        }
                        else if (this.resource)
                            this.resource.resetSort();
                    }
                    if (redraw) {
                        this._updateBoxElement();
                    }
                };
                Task.prototype.reloadTemplateData = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var templateData;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!Scheduler.Container.ref.taskTemplateCtrl.isInitialized) return [3 /*break*/, 2];
                                    return [4 /*yield*/, Scheduler.Container.ref.taskTemplateCtrl.loadTemplateData(this)];
                                case 1:
                                    templateData = _a.sent();
                                    if (templateData) {
                                        this.templateData = templateData;
                                    }
                                    _a.label = 2;
                                case 2: return [2 /*return*/];
                            }
                        });
                    });
                };
                Task.prototype.updateTemplateData = function (entityName, entityProperties) {
                    if (Scheduler.Container.ref.taskTemplateCtrl.isInitialized) {
                        var templateData = undefined;
                        if (entityName)
                            templateData = Scheduler.Container.ref.taskTemplateCtrl.toTemplateData(entityName, entityProperties);
                        if (templateData) {
                            if (!this.templateData) {
                                this.templateData = templateData;
                            }
                            else {
                                for (var i = 0; i < templateData.repository.properties.length; i++) {
                                    var propertyName = templateData.repository.properties[i].name;
                                    var propValue = templateData.tryGetValue(propertyName);
                                    if (propValue.result && (propValue.value !== undefined)) {
                                        this.templateData.trySetValue(propertyName, propValue.value);
                                    }
                                }
                            }
                        }
                    }
                };
                /*
                public isHorizontalChild(): boolean {
                    //var taskParent = this.getParent();
                    return this.resource != undefined;// && this.level > 0;//  taskParent ? taskParent.horizontalChildrenTasks : false;
                }*/
                /**
                 * Append task box from undefinedTasksContainer to draggableContainer
                 */
                Task.prototype.appendTaskBoxFromUTCToDC = function () {
                    if (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer) {
                        var undefinedTasksContainer = $("#undefinedTasks");
                        if (undefinedTasksContainer.length > 0) {
                            var draggableContainer = this.container.draggableContainer.element;
                            var delta = Scheduler.Utilities.getContainersOffsetDelta(undefinedTasksContainer, draggableContainer);
                            var taskBox = this.ganttElement;
                            if (taskBox) {
                                var taskBoxPosition = taskBox.position();
                                draggableContainer.append(taskBox);
                                taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                                this.containerView = Scheduler.TaskContainerView.IsInDraggableContainer;
                            }
                        }
                    }
                };
                /**
                 * Append task box from tasksContainer to draggableContainer
                 */
                Task.prototype.appendTaskBoxFromTCToDC = function () {
                    if (this.container.viewCtrl instanceof Scheduler.View) {
                        if (this.containerView === Scheduler.TaskContainerView.IsInTasksContainer) {
                            var draggableContainer = this.container.draggableContainer.element;
                            var delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.viewCtrl.viewBody.tasksContainerElement, draggableContainer);
                            var taskBox = this.ganttElement;
                            if (taskBox) {
                                var taskBoxPosition = taskBox.position();
                                draggableContainer.append(taskBox);
                                taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                                this.containerView = Scheduler.TaskContainerView.IsInDraggableContainer;
                            }
                        }
                    }
                };
                /**
                 * Append task box from draggableContainer to tasksContainer
                 */
                Task.prototype.appendTaskBoxFromDCToTC = function () {
                    if (this.container.viewCtrl instanceof Scheduler.View) {
                        if (this.containerView === Scheduler.TaskContainerView.IsInDraggableContainer) {
                            var tasksContainerElement = this.container.viewCtrl.viewBody.tasksContainerElement;
                            var delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.draggableContainer.element, tasksContainerElement);
                            var taskBox = this.ganttElement;
                            if (taskBox) {
                                var taskBoxPosition = taskBox.position();
                                tasksContainerElement.append(taskBox);
                                taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                                this.containerView = Scheduler.TaskContainerView.IsInTasksContainer;
                                if (taskBox.hasClass("unscheduledTask")) {
                                    taskBox.removeClass("unscheduledTask");
                                    var imageElement = taskBox.find(".taskAlert");
                                    Scheduler.Container.setElementBackgroundImage(imageElement[0], "ruleViolations.png");
                                }
                            }
                        }
                    }
                };
                /**
                 * Append task box from draggableContainer or tasksContainer to undefinedTasksContainer
                 */
                Task.prototype.appendTaskBoxFromDCOrTCToUTC = function () {
                    if (this.container.viewCtrl instanceof Scheduler.View) {
                        var undefinedTasksContainer = $("#undefinedTasks");
                        if (undefinedTasksContainer.length > 0) {
                            var delta = null;
                            if (this.containerView === Scheduler.TaskContainerView.IsInDraggableContainer) {
                                delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.draggableContainer.element, undefinedTasksContainer);
                            }
                            else if (this.containerView === Scheduler.TaskContainerView.IsInTasksContainer) {
                                delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.viewCtrl.viewBody.tasksContainerElement, undefinedTasksContainer);
                            }
                            if (delta) {
                                var taskBox = this.ganttElement;
                                if (taskBox) {
                                    var taskBoxPosition = taskBox.position();
                                    undefinedTasksContainer.append(taskBox);
                                    taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                                    this.containerView = Scheduler.TaskContainerView.IsInUndefinedTasksContainer;
                                    taskBox.addClass("unscheduledTask");
                                    var imageElement = taskBox.find(".taskAlert");
                                    Scheduler.Container.setElementBackgroundImage(imageElement[0], "jeopardy.png");
                                }
                            }
                        }
                    }
                };
                /**
                 * Update task box and recreate task box content DOM elements to match with task data
                 */
                Task.prototype._updateBoxElement = function () {
                    var view = this.container.viewCtrl;
                    if (this.containerView !== Scheduler.TaskContainerView.None) {
                        var taskBoxDimensions = this.getTaskBoxDimensions();
                        if (!taskBoxDimensions) {
                            if (view.hasTaskOutsideTimeRange(this)) {
                                view.container.removeTask(this);
                            }
                            else {
                                this.removeBox();
                                this.updateRuleViolations(true);
                            }
                            view.onTasksChanged();
                            return;
                        }
                        if (this.ganttElement) {
                            if (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer)
                                taskBoxDimensions.x = parseFloat(this.ganttElement[0].style.left); //this.ganttElement.position().left;
                            this.ganttElement[0].dataset.taskid = this.id;
                            this.ganttElement.css({ "left": taskBoxDimensions.x, "top": taskBoxDimensions.y });
                            this.updateBoxElementContent(taskBoxDimensions);
                        }
                    }
                    this._updateTaskOnEditEvent();
                    this.updateRuleViolations(true);
                    view.onTasksChanged();
                };
                //TODO: candidate for optimization
                //public createTaskBodyContent(view: View, svg: any, taskSvg: any, dimensions: Rectangle) {
                //	let task: Task = this;
                //	let isInUTRow: boolean = (task.containerView === TaskContainerView.IsInUndefinedTasksContainer);
                //	let radius = Container.constants.ganttTaskCornersRadius;
                //	let bodySvg = svg.svg(taskSvg, dimensions.x, dimensions.y, dimensions.width, dimensions.height, { class: "taskBoxBodySVG", draggable: "false" });
                //	//external box
                //	svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, radius, radius, { class: "taskLayout"} );
                //	svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, radius, radius, { fill: "rgba(255,255,255,.3)" });
                //	//svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, radius, radius, { class: "taskLayout", "opacity": "0.6" });
                //	if (!isInUTRow) {
                //		//external dep
                //		//if (task.hasExternalDep)
                //		//	svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, { fill: "url(#extDep)" });
                //		//break box
                //		if (task.scheduledBreak > 0) {
                //			let breakWidth = view.zoom.timeDurationToWidth(task.scheduledBreak);
                //			svg.rect(bodySvg, ((dimensions.width - breakWidth) / 2), 0, breakWidth, dimensions.height, { class: "taskBreak" });
                //		}
                //		//progress
                //		if (task.progress > 0) {
                //			let progress = (task.progress > 100 ? 100 : (task.progress < 0 ? 0 : task.progress));
                //			let progressBarWidth = (progress / 100) * dimensions.width;
                //			svg.rect(bodySvg, 0, dimensions.height / 2, progressBarWidth, dimensions.height / 2, radius, radius, { class: "taskProgress" });
                //			let progressDigits = progress.toString().length;
                //			let progressTextWidth = Task.cachedTextsBounds.tryGetProgressTextWidth(progressDigits);
                //			let progressTextYOffset = Task.cachedTextsBounds.progressTextYOffset;
                //			if (!Task.cachedTextsBounds.progressTextYOffset && Task.cachedTextsBounds.progressTextYOffset !== 0) {
                //				progressTextYOffset = null;
                //			}
                //			let progressTextOffset = 5;
                //			let progressText = svg.text(bodySvg, progressTextOffset, progressTextYOffset === null ? 0 : progressTextYOffset, progress + "%", { class: "taskProgressText" });
                //			if (progressTextYOffset === null || progressTextWidth === null) {
                //				let progressTextBBox = progressText.getBBox();
                //				if (progressTextYOffset === null) {
                //					Task.cachedTextsBounds.progressTextYOffset = Math.round(Math.floor(Math.abs(progressTextBBox.y) / 2) + ((dimensions.height * 3) / 4)); //@JC labelBBox.y value represents characters height that is drawn up on the row line
                //					progressText.setAttribute("y", Task.cachedTextsBounds.progressTextYOffset);
                //				}
                //				if (progressTextWidth === null) {
                //					progressTextWidth = Math.ceil(progressTextBBox.width);
                //					Task.cachedTextsBounds.trySetProgressTextWidth(progressDigits, progressTextWidth);
                //				}
                //			}
                //			if ((!progressTextWidth) || (dimensions.width < (2 * (progressTextOffset + progressTextWidth)))) {
                //				progressText.setAttribute("visibility", "hidden");
                //			}
                //			else {
                //				if ((progressBarWidth + progressTextOffset + progressTextWidth) < dimensions.width) {
                //					progressText.setAttribute("x", progressBarWidth + progressTextOffset);
                //				}
                //				else {
                //					progressText.setAttribute("x", progressBarWidth - (progressTextOffset + progressTextWidth));
                //				}
                //			}
                //		}
                //	}
                //	//task label
                //	let label;
                //	if (!Task.cachedTextsBounds.labelYOffset && Task.cachedTextsBounds.labelYOffset !== 0) {
                //		label = svg.text(bodySvg, 0, 0, task.name, { class: "taskLabelSVG", "text-anchor": "start" });
                //		let labelBBox = label.getBBox();
                //		Task.cachedTextsBounds.labelYOffset = Math.round(Math.floor(Math.abs(labelBBox.y) / 2) + (dimensions.height / 4)); //@JC labelBBox.y value represents characters height that is drawn up on the row line
                //		label.setAttribute("y", Task.cachedTextsBounds.labelYOffset);
                //	}
                //	else {
                //		label = svg.text(bodySvg, 0, Task.cachedTextsBounds.labelYOffset, task.name, { class: "taskLabelSVG", "text-anchor": "start" });
                //	}
                //	if (dimensions.width < view.taskMinWidthForText) {
                //		label.setAttribute("visibility", "hidden");
                //	}
                //	if (!isInUTRow) {
                //		// creates rule violations indicator image
                //		let imageSize = 16;
                //		let imagePadding = 2;
                //		svg.image(bodySvg, dimensions.width - (imageSize + imagePadding), dimensions.height - (imageSize + imagePadding), imageSize, imageSize, "res/ruleViolations.png", { class: "taskViolationAlert" });
                //		this._updateViolationAlert();
                //		// creates X elements
                //		svg.line(bodySvg, 0, 0, dimensions.width, dimensions.height, { class: "taskReassignmentIndicator" });
                //		svg.line(bodySvg, 0, dimensions.height, dimensions.width, 0, { class: "taskReassignmentIndicator" });
                //	}
                //	else {
                //		// creates jeopardy indicator image
                //		let imageSize = 16;
                //		let imagePadding = 2;
                //		svg.image(bodySvg, dimensions.width - (imageSize + imagePadding), dimensions.height - (imageSize + imagePadding), imageSize, imageSize, "res/jeopardy.png", { class: "taskJeopardyAlert" });
                //		this.updateJeopardyAlert(this.isInJeopardy());
                //	}
                //}
                //public createTaskContent(view: View, svg: any, taskSvg: any, taskBody: TaskRectangle) {
                //	let task: Task = this;
                //	var radius = Container.constants.ganttTaskCornersRadius + view.taskFocusWidth;
                //	var bodyRect: Rectangle = { x: 0, y: view.taskFocusWidth, width: taskBody.width, height: taskBody.height - 2 * view.taskFocusWidth };
                //	if (task.containerView !== TaskContainerView.IsInUndefinedTasksContainer) {
                //		var lineY = (taskBody.height - view.container.constants.ganttTaskTravelLineWidth) / 2;
                //		let travelToWidth = taskBody.travelToWidth < 0 ? 0 : taskBody.travelToWidth;
                //		let travelFromWidth = taskBody.travelFromWidth < 0 ? 0 : taskBody.travelFromWidth;
                //		if ((bodyRect.width - (travelToWidth + travelFromWidth)) < Container.constants.viewTaskMinWidth) {
                //			if ((travelToWidth > 0) && !(travelFromWidth > 0)) {
                //				travelToWidth = bodyRect.width - Container.constants.viewTaskMinWidth;
                //			}
                //			else if (!(travelToWidth > 0) && (travelFromWidth > 0)) {
                //				travelFromWidth = bodyRect.width - Container.constants.viewTaskMinWidth;
                //			}
                //			else if ((travelToWidth > 0) && (travelFromWidth > 0)) {
                //				travelToWidth = travelFromWidth = Math.floor((bodyRect.width - Container.constants.viewTaskMinWidth) / 2);
                //			}
                //		}
                //		if (travelToWidth > 0) {
                //			svg.rect(taskSvg, 0, lineY, travelToWidth, view.container.constants.ganttTaskTravelLineWidth, { class: "taskTravelTo" });
                //			bodyRect.x += travelToWidth;
                //			bodyRect.width -= travelToWidth;
                //		}
                //		if (travelFromWidth > 0) {
                //			bodyRect.width -= travelFromWidth;
                //			svg.rect(taskSvg, travelToWidth + bodyRect.width, lineY, travelFromWidth, view.container.constants.ganttTaskTravelLineWidth, { class: "taskTravelFrom" });
                //		}
                //	}
                //	// creates focused effect element
                //	svg.rect(taskSvg, bodyRect.x - view.taskFocusWidth, bodyRect.y - view.taskFocusWidth, bodyRect.width + (2 * view.taskFocusWidth), bodyRect.height + (2 * view.taskFocusWidth), radius, radius, { class: "taskFocusedLayout" });
                //	task.createTaskBodyContent(view, svg, taskSvg, bodyRect);
                //}
                /**
                 * Calculates dimension rectangle (size and position) for task DOM element box based on TaskContainerView.
                 */
                Task.prototype.getTaskBoxDimensions = function (workStart) {
                    var view = this.container.viewCtrl;
                    var constants = Scheduler.Container.constants;
                    var vertMargin = Scheduler.Container.constants.taskVerticalMargin;
                    var y = vertMargin;
                    var height = (view instanceof Scheduler.View) ? (view.rowHeight - (2 * vertMargin)) : 0;
                    if (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer) {
                        return { x: view.xOffsetUT + constants.unscheduledViewTaskSpacing, y: y, width: constants.unscheduledViewTaskWidth, height: height, travelFromWidth: 0, travelToWidth: 0 };
                    }
                    else {
                        var newTaskSchedule = this.cloneTaskSchedule();
                        if (workStart)
                            newTaskSchedule.setWorkStart(workStart);
                        var displayedTimeRangeWithTravel = new Scheduler.TimeRange(newTaskSchedule.getStart(), newTaskSchedule.getEnd());
                        var visibleRange = view.zoom.getVisibleTimeRange();
                        if (!visibleRange.contain(displayedTimeRangeWithTravel))
                            return undefined;
                        var x1 = view.zoom.timeToPixelPosition(displayedTimeRangeWithTravel.start, true);
                        var x2 = view.zoom.timeToPixelPosition(displayedTimeRangeWithTravel.end, true);
                        var width = x2 - x1;
                        var travelToWidth = 0;
                        var travelFromWidth = 0;
                        // @JC: There must be used not rounded width, because in case when zoom is to small, task with short duration disappear (are not drawn and count with in KPI).
                        if ((width <= 0) && (displayedTimeRangeWithTravel.start !== displayedTimeRangeWithTravel.end))
                            return undefined;
                        // @JC: Now it is necessary to round it.
                        x1 = Math.round(x1);
                        x2 = Math.round(x2);
                        width = x2 - x1;
                        if (this.resource) {
                            var rowIndex = this.resource.rowIndex;
                            y += (view instanceof Scheduler.View) ? view.getRowPosition(rowIndex) : 0;
                        }
                        // compute and restrict travel if necessary
                        if (width < constants.viewTaskMinWidth) {
                            width = constants.viewTaskMinWidth;
                        }
                        else {
                            var displayedTimeRange = new Scheduler.TimeRange(newTaskSchedule.getWorkStart(), newTaskSchedule.getWorkEnd());
                            if (this.getTravel().to > 0)
                                travelToWidth = view.zoom.timeToPixelPosition(displayedTimeRange.start) - x1;
                            if (this.getTravel().from > 0)
                                travelFromWidth = x2 - view.zoom.timeToPixelPosition(displayedTimeRange.end);
                            if ((width - (travelToWidth + travelFromWidth)) < constants.viewTaskMinWidth) {
                                if ((travelToWidth > 0) && !(travelFromWidth > 0)) {
                                    travelToWidth = width - constants.viewTaskMinWidth;
                                }
                                else if (!(travelToWidth > 0) && (travelFromWidth > 0)) {
                                    travelFromWidth = width - constants.viewTaskMinWidth;
                                }
                                else if ((travelToWidth > 0) && (travelFromWidth > 0)) {
                                    travelToWidth = travelFromWidth = Math.floor((width - constants.viewTaskMinWidth) / 2);
                                }
                            }
                        }
                        return { x: x1, y: y, width: width, height: height, travelFromWidth: travelFromWidth, travelToWidth: travelToWidth };
                    }
                };
                Task.prototype.getAvailableResorcesIdForMove = function () {
                    var ids = new Array();
                    if (this.allowedResourceIds && this.allowedResourceIds.length > 0) {
                        var resources = this.container.resourceDictionary;
                        var _loop_1 = function (resource) {
                            var id = { rowIndex: resource.rowIndex, canAssign: false };
                            if (this_1.allowedResourceIds.filter(function (i) { return i === resource.getID(); }).length === 1) {
                                id.canAssign = true;
                            }
                            ids.push(id);
                        };
                        var this_1 = this;
                        for (var _i = 0, _a = resources.Values(); _i < _a.length; _i++) {
                            var resource = _a[_i];
                            _loop_1(resource);
                        }
                    }
                    return ids;
                };
                Task.prototype.updateRuleViolations = function (updateTasksInCollision) {
                    var uniqueTasksInCollision = new Scheduler.Dictionary();
                    var oldTasksInCollision = [];
                    var newTasksInCollision = [];
                    if (updateTasksInCollision) {
                        //update old tasks in collision
                        oldTasksInCollision = this._getTasksInCollision(this.ruleViolations);
                        for (var i = 0; i < oldTasksInCollision.length; i++) {
                            var task = oldTasksInCollision[i];
                            if (!uniqueTasksInCollision.ContainsKey(task.id)) {
                                uniqueTasksInCollision.Add(task.id, task);
                            }
                        }
                    }
                    if (this.resource) {
                        if (!this.isTimeOff() && (!this.getStatus().isUnscheduled() && !this.getStatus().isFinished())) {
                            this.ruleViolations = this.resource.getRuleViolations(this);
                            this.updateAlert(this.hasViolations());
                            if (updateTasksInCollision) {
                                //update new tasks in collision
                                newTasksInCollision = this._getTasksInCollision(this.ruleViolations);
                                for (var i = 0; i < newTasksInCollision.length; i++) {
                                    var task = newTasksInCollision[i];
                                    if (!uniqueTasksInCollision.ContainsKey(task.id)) {
                                        uniqueTasksInCollision.Add(task.id, task);
                                    }
                                }
                            }
                        }
                    }
                    if (updateTasksInCollision) {
                        for (var i = 0; i < uniqueTasksInCollision.Keys().length; i++) {
                            uniqueTasksInCollision.Item(uniqueTasksInCollision.Keys()[i]).updateRuleViolations();
                        }
                    }
                };
                Task.prototype._getTasksInCollision = function (ruleViolations) {
                    var tasks = [];
                    for (var i = 0; i < ruleViolations.length; i++) {
                        var ruleViolation = ruleViolations[i];
                        if ((ruleViolation.violationType === Scheduler.RuleViolationType.OverlappingTasks) ||
                            (ruleViolation.violationType === Scheduler.RuleViolationType.OverlappingTimeOffs) ||
                            (ruleViolation.violationType === Scheduler.RuleViolationType.TravelUnavailability)) {
                            for (var j = 0; j < ruleViolation.tasksInCollision.length; j++) {
                                tasks.push(ruleViolation.tasksInCollision[j]);
                            }
                        }
                    }
                    return tasks;
                };
                /**
                 * Show or hide task alert.
                 * @param visible
                 */
                Task.prototype.updateAlert = function (visible) {
                    if (this.ganttElement) {
                        if (visible)
                            this.ganttElement.find(".taskAlert").addClass("visible");
                        else
                            this.ganttElement.find(".taskAlert").removeClass("visible");
                    }
                };
                Task.prototype.isInJeopardy = function () {
                    if (this.getStatus().isUnscheduled() && !this.isUnscheduledNew()) {
                        var beforeTime = Scheduler.Container.constants.jeopardyBeforeHours * Scheduler.hourInMiliseconds;
                        //if (this.hasScheduledStart) { // unscheduled task has always invalid time, therefore this case is not used now.
                        //	if ((this.start - beforeTime) < Date.now())
                        //		return true;
                        //}
                        //else
                        if (this.requiredWindow) {
                            if ((this.requiredWindow.end - (beforeTime + (this.getEnd() - this.getStart()))) < Date.now())
                                return true;
                        }
                    }
                    return false;
                };
                /**
                 * Returns true if work starts before requiredWindow start.
                 */
                Task.prototype.isBeforeWindowStart = function () {
                    if (this.requiredWindow && (this.requiredWindow.start > this.getWorkStart()))
                        return true;
                    return false;
                };
                /**
                 * Returns true if work ends after requiredWindow end.
                 */
                Task.prototype.isAfterWindowEnd = function () {
                    if (this.requiredWindow && (this.requiredWindow.end < this.getWorkEnd()))
                        return true;
                    return false;
                };
                Task.prototype.initContainerView = function () {
                    if (this.getStatus().isUnscheduled()) {
                        if (this.isUnscheduledNew()) {
                            this.containerView = Scheduler.TaskContainerView.IsInDraggableContainer;
                        }
                        else {
                            this.containerView = Scheduler.TaskContainerView.IsInUndefinedTasksContainer;
                        }
                    }
                    else {
                        var timeRange = new Scheduler.TimeRange(this.getStart(), this.getEnd());
                        if (!this.container.viewCtrl.zoom.getVisibleTimeRange().contain(timeRange)) {
                            return;
                        }
                        this.containerView = Scheduler.TaskContainerView.IsInTasksContainer;
                    }
                };
                Task.prototype.createTaskElement = function (parentElement) {
                    //@DM: this part of code have to be here because in method getTaskBoxDimensions is reference to task.containerView!!!
                    var taskDimensions = this.getTaskBoxDimensions();
                    if (taskDimensions === undefined)
                        return;
                    var isInUTRow = (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer);
                    var taskBoxWrapper = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "left", styleValue: taskDimensions.x + "px" }, { styleName: "top", styleValue: taskDimensions.y + "px" }, { styleName: "width", styleValue: taskDimensions.width + "px" }, { styleName: "height", styleValue: taskDimensions.height + "px" }], ["taskBoxWrapper", "taskBox", isInUTRow ? "unscheduledTask" : ""], null, [{ attributeName: "data-taskid", attributeValue: this.id }]);
                    var travelToElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: taskDimensions.travelToWidth + "px" }], ["taskTravelTo"]);
                    var travelFromElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: taskDimensions.travelFromWidth + "px" }], ["taskTravelFrom"]);
                    var taskBoxDiv = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: (taskDimensions.width - taskDimensions.travelToWidth - taskDimensions.travelFromWidth) + "px" }], ["taskBoxDiv"]);
                    var taskBoxDivContent = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskBoxDivContent"]);
                    //Task.performances[0].start(); //for performance measurement only
                    this.createContent(this, taskBoxDivContent);
                    //Task.perfdata[0] += Task.performances[0].end(); //for performance measurement only
                    taskBoxDiv.appendChild(taskBoxDivContent);
                    taskBoxWrapper.appendChild(travelToElement);
                    taskBoxWrapper.appendChild(taskBoxDiv);
                    taskBoxWrapper.appendChild(travelFromElement);
                    parentElement.appendChild(taskBoxWrapper);
                    this.ganttElement = $(taskBoxWrapper);
                    this._addDoubleTapEventToTaskElement();
                    if (Scheduler.Container.constants.taskTooltipEnabled)
                        this._addTooltipEvents();
                    this._updateTaskOnEditEvent();
                    if (this.getStatus().isUnscheduled() && !this.isUnscheduledNew()) {
                        var settings = Scheduler.Container.constants;
                        this.container.viewCtrl.xOffsetUT += settings.unscheduledViewTaskWidth + settings.unscheduledViewTaskSpacing;
                    }
                };
                Task.prototype._addTooltipEvents = function () {
                    var _this = this;
                    var taskBox = this.ganttElement;
                    taskBox.mouseenter(function (event) {
                        if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            if (_this._mouseenterCachedTask === null)
                                _this._mouseenterCachedTask = _this;
                            else
                                TaskTooltip.createTooltip(_this);
                        }
                    });
                    taskBox.mouseleave(function (event) {
                        if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            TaskTooltip.removeTooltip();
                        }
                    });
                };
                Task.prototype._addDoubleTapEventToTaskElement = function () {
                    var _this = this;
                    if (this.ganttElement) {
                        if (Controls.GestureManager.pointerEventType !== Controls.PointerEventType.mouse) {
                            //!!!UP event needs to be used there instead of the click event, because moveManager needs to call preventDefault during task moving, when touch events are used (iOS).
                            //On iOS 13+ click event is not raised, when pointer events are used. Therefore pointerup event needs to be used there.
                            this.ganttElement.on(Controls.GestureManager.UP + ".dblclick", null, function (e) {
                                _this._taskDblClick(e, function (e) {
                                    if (_this.container.loadingInProcess == false && !_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.DragRecognized)) {
                                        _this.container.showTaskDialog(_this);
                                        // e.stopPropagation() can not be called here, because moveManager will not be able to receive up event when touch events are used!
                                    }
                                });
                            });
                        }
                        else {
                            this.ganttElement.on("click", null, function (e) {
                                _this._taskDblClick(e, function (e) {
                                    if (_this.container.loadingInProcess == false && !_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.DragRecognized)) {
                                        _this.container.showTaskDialog(_this);
                                        e.stopPropagation();
                                    }
                                });
                            });
                        }
                    }
                };
                Task.prototype._taskDblClick = function (e, dblClick) {
                    var _this = this;
                    if (!this._timeoutID) {
                        this._timeoutID = window.setTimeout(function () {
                            _this._timeoutID = null;
                        }, 300);
                    }
                    else {
                        clearTimeout(this._timeoutID);
                        this._timeoutID = null;
                        if (dblClick) {
                            dblClick(e);
                        }
                    }
                };
                Task.prototype._updateTaskOnEditEvent = function () {
                    var _this = this;
                    var draggableContainer = this.container.draggableContainer;
                    var eventNameEnd = Controls.GestureManager.UP + ".focused";
                    if (this.isEditable()) {
                        if (draggableContainer.isFocusedTask(this)) { // @JC renews focus after redrawing if this task was focused
                            draggableContainer.setFocusToTask(this, true); // set this task (with the same id) that is appended to DOM to focusedTask what enable visually focus the correct task
                        }
                        if (this.ganttElement) {
                            this.ganttElement.off(eventNameEnd).on(eventNameEnd, null, function (e) {
                                if (!draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                    if (!draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.WasProcessed)) {
                                        draggableContainer.setFocusToTask(_this, false); // task got focus
                                    }
                                }
                            });
                        }
                    }
                    else {
                        if (draggableContainer.isFocusedTask(this))
                            draggableContainer.takeFocusFromFocusedTask();
                        if (this.ganttElement)
                            this.ganttElement.off(eventNameEnd);
                    }
                };
                Task.prototype.setFocus = function () {
                    if (this.ganttElement) {
                        this.ganttElement.addClass("focused");
                        this.ganttElement.find(".taskBoxDiv").css("outline-color", Scheduler.Container.inputs.scheduledTasks.focusedColor);
                        this._addEventTargetElement();
                    }
                };
                Task.prototype.takeFocus = function () {
                    if (this.ganttElement) {
                        this.ganttElement.removeClass("focused");
                        this.ganttElement.find(".taskBoxDiv").css("outline-color", "");
                        this._removeEventTargetElement();
                    }
                };
                Task.prototype._addEventTargetElement = function () {
                    if (this.ganttElement)
                        this.ganttElement.children(".taskBoxDiv").append("<div class='eventTargetElement'>");
                };
                Task.prototype._removeEventTargetElement = function () {
                    if (this.ganttElement)
                        this.ganttElement.find(".eventTargetElement").remove();
                };
                /**
                 * Returns distance in pixels between WorkStart (taskBoxDiv) and task box element.
                 */
                Task.prototype.getWorkStartXPosition = function () {
                    return this.ganttElement.children(".taskBoxDiv").position().left;
                };
                /**
                 * Handles operations that should be performed when task move started. Task box element is in the draggableContainer yet.
                 * @param owningResource Resource under which task box element is currently present.
                 * @param workStart Time in milliseconds when the work starts, given by move point position.
                 */
                Task.prototype.onDragStart = function (owningResource, workStart) {
                    TaskTooltip.removeTooltip();
                    var view = this.container.viewCtrl;
                    if (this.getStatus().isUnscheduled()) {
                        var startTime = view.zoom.getVisibleTimeRange().start;
                        var duration = this.getTotalWorkTime();
                        this.setWorkStart(startTime);
                        this.setTotalWorkTime(duration);
                    }
                    if (view instanceof Scheduler.View) {
                        if (this.isEditable() && !this.container.isLocked()) {
                            this.loadLinkedResources(function (error) { view.createCoverLayer(); });
                        }
                        view.taskPopupMenu.close();
                    }
                    this._createTextBoxElement(this.ganttElement.children(".taskBoxDiv")[0]);
                };
                /**
                 * Handles operations that should be performed when task is moving. Task box element is in the draggableContainer.
                 * @param owningResource Resource under which task box element is currently present.
                 * @param workStart Time in milliseconds when the work starts, given by move point position.
                 */
                Task.prototype.onDragMove = function (owningResource, workStart) {
                    var view = this.container.viewCtrl;
                    var taskBox = this.ganttElement;
                    // update task text element and violations checking
                    var textBox = taskBox.find(".taskText");
                    var textBoxText = "";
                    var canReassign = false;
                    var workStartRounded;
                    if (!workStart) {
                        textBoxText = Scheduler.StringTable.get("Err.TimesOutOfScope") || "Start and end times are out of scope.";
                    }
                    else {
                        var taskBoxDimensions = this.getTaskBoxDimensions(workStart);
                        if (!taskBoxDimensions)
                            return;
                        this.updateBoxElementContent(taskBoxDimensions, workStart, true);
                        workStartRounded = Scheduler.Container.roundTimeToMoveStep(workStart);
                        var newTaskSchedule = this.cloneTaskSchedule();
                        newTaskSchedule.setWorkStart(workStartRounded);
                        var reassign = this.isValidReassign(owningResource, newTaskSchedule.getStart(), newTaskSchedule.getEnd());
                        canReassign = reassign.isValid;
                        if (!canReassign) {
                            textBoxText = reassign.error;
                        }
                    }
                    this._updateDeniedColor(!canReassign);
                    if (textBox) {
                        if (canReassign)
                            textBox.removeClass("violation");
                        else
                            textBox.addClass("violation");
                        if (!textBoxText)
                            textBoxText = this._dateMillisecondsToText(workStartRounded);
                        $("span", textBox).text(textBoxText);
                    }
                };
                Task.prototype.calculateOptimalPosition = function (onCalculated, task, startWorkTime, resource) {
                    var settings = this.container.settings.autoPlanner;
                    if (settings.manualScheduleMode == Scheduler.eMode.Manual || settings.manualScheduleMode == Scheduler.eMode.RouteOptimization) {
                        startWorkTime = Scheduler.Container.roundTimeToMoveStep(startWorkTime);
                        onCalculated(new Scheduler.AutoPlanner.TaskWrapper(true, task, resource, startWorkTime));
                    }
                    else
                        Scheduler.AutoPlanner.Core.optimizeManuallyDroppedTask(onCalculated, task, startWorkTime, resource);
                };
                /**
                 * Handles operations that should be performed when task move ended. Task box element is in the tasksContainer yet.
                 * @param owningResource Resource under which task box element is currently present.
                 * @param workStart Time in milliseconds when the work starts, given by move point position.
                 * @param onFinishCallback Is called when task handle operations have finished. If argument success is set to false task move will be reverted.
                 */
                Task.prototype.onDrop = function (owningResource, workStart, onFinishCallback) {
                    var _this = this;
                    this._mouseenterCachedTask = null;
                    var view = this.container.viewCtrl;
                    var textBox = this.ganttElement.find(".taskText");
                    if (textBox)
                        textBox.remove();
                    if (view instanceof Scheduler.View)
                        view.removeCoverLayer();
                    var workStartRounded = Scheduler.Container.roundTimeToMoveStep(workStart);
                    if ((workStartRounded === null) || (!owningResource && this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.WasLeaved)) || (Scheduler.milisecondsToMinutes(this.getWorkStart()) === Scheduler.milisecondsToMinutes(workStartRounded) && owningResource === this.resource))
                        onFinishCallback(false); // revertMove
                    else {
                        var workDuration = this.getTotalWorkTime();
                        this.calculateOptimalPosition(function (result) {
                            if (result) {
                                _this.tryReassign(result.getParent(), result.getWorkStart(), true, function (success) {
                                    // second optimization is for situations, where work duration is set by creation rule during the save of the task
                                    if (workDuration == _this.getTotalWorkTime())
                                        onFinishCallback(success); // do nothing and simply finish with success value returned from tryReassign() method
                                    else {
                                        _this.calculateOptimalPosition(function (result) {
                                            if (result)
                                                _this.tryReassign(result.getParent(), result.getWorkStart(), false, onFinishCallback);
                                            else
                                                onFinishCallback(false); // revertMove
                                        }, _this, Scheduler.Container.roundTimeToMoveStep(_this.getWorkStart()), owningResource);
                                    }
                                });
                            }
                            else
                                onFinishCallback(false); // revertMove
                        }, this, workStartRounded, owningResource);
                    }
                };
                /**
                 * Handles operations that should be performed when task move was successful.
                 */
                Task.prototype.onMoveSuccessful = function () {
                    if (this._mouseenterCachedTask && !Task.wasMsgSchedulingInPast) {
                        TaskTooltip.createTooltip(this._mouseenterCachedTask);
                    }
                    this._mouseenterCachedTask = undefined;
                    Task.wasMsgSchedulingInPast = false;
                };
                /**
                 * Handles operations that should be performed when task move was reverted.
                 */
                Task.prototype.onMoveRevert = function () {
                    if (this.isUnscheduledNew()) {
                        //if (this.group) { // Temporary disabled due to low perfomance of showing items on horizontal list. Method that supports it needs to be added to HTML advanced list.
                        //	let scrollPosition = this.container.horizontalListCtrl.getScrollPosition();
                        //	this.container.dataProvider.showUnscheduledTasksEntities([this.group.id], true, () => {
                        //		this.container.revertSelectedItem();
                        //		if ((scrollPosition !== undefined) && (scrollPosition !== null))
                        //			this.container.horizontalListCtrl.setScrollPosition(scrollPosition);
                        //	});
                        //}
                        this.container.revertSelectedItem(); // Temporary added because above code was disabled and thus it does not call this method asynchronous more.
                        this.container.removeTask(this);
                    }
                    else {
                        var taskBox = this.ganttElement;
                        if (taskBox) {
                            var taskBoxDimensions = this.getTaskBoxDimensions();
                            if (taskBoxDimensions) {
                                this.updateBoxElementContent(taskBoxDimensions);
                                if (this._mouseenterCachedTask && !Task.wasMsgSchedulingInPast) {
                                    TaskTooltip.createTooltip(this._mouseenterCachedTask);
                                }
                            }
                        }
                    }
                    this._mouseenterCachedTask = undefined;
                    Task.wasMsgSchedulingInPast = false;
                };
                Task.prototype._createTextBoxElement = function (parentElement) {
                    var textBox = Scheduler.Utilities.createNewHTMLElement("div", "taskText" + this.id, null, ["taskText"]);
                    var span = Scheduler.Utilities.createNewHTMLElement("span");
                    textBox.appendChild(span);
                    parentElement.appendChild(textBox);
                };
                Task.prototype._dateMillisecondsToText = function (dateMilliseconds) {
                    if (!dateMilliseconds)
                        return "";
                    var date = new Date(dateMilliseconds);
                    var options = { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" };
                    return date.toLocaleString([], options);
                };
                Task.prototype._updateDeniedColor = function (isDenied) {
                    if (this.ganttElement) {
                        this.ganttElement.find(".taskStatusColor").css("background-color", isDenied ? Scheduler.Container.inputs.scheduledTasks.deniedColor : this.getStatus().color());
                        this.ganttElement.find(".taskText").css("color", isDenied ? Scheduler.Container.inputs.scheduledTasks.deniedColor : "rgb(0, 0, 0)");
                    }
                };
                /**
                 * Update size of taskBox container and its inner html elements.
                 * @param taskBoxDimensions
                 */
                Task.prototype.updateTaskBoxSize = function (taskBoxDimensions) {
                    if (this.ganttElement) {
                        this.ganttElement.css("width", taskBoxDimensions.width + "px");
                        this.ganttElement.children(".taskTravelTo").css("width", taskBoxDimensions.travelToWidth + "px");
                        this.ganttElement.children(".taskTravelFrom").css("width", taskBoxDimensions.travelFromWidth + "px");
                        this.ganttElement.children(".taskBoxDiv").css("width", (taskBoxDimensions.width - taskBoxDimensions.travelFromWidth - taskBoxDimensions.travelToWidth) + "px");
                    }
                };
                /**
                 * Update size of taskBox container and its inner html elements. Replace elements if it is necessary, when task become displayed as splitted or as normal.
                 * @param taskBoxDimensions
                 */
                Task.prototype.updateBoxElementContent = function (taskBoxDimensions, workStart, doNotCreateIfNotNecessary) {
                    this.updateTaskBoxSize(taskBoxDimensions);
                    var newTaskSchedule = this.cloneTaskSchedule();
                    if (workStart)
                        newTaskSchedule.setWorkStart(workStart);
                    newTaskSchedule.createContent(this, this.ganttElement.find(".taskBoxDivContent")[0], doNotCreateIfNotNecessary);
                };
                Task.prototype.setAsCompleted = function () {
                    this._setStatusAs(Scheduler.TaskStatusType.Completed);
                };
                Task.prototype.setAsCanceled = function () {
                    this._setStatusAs(Scheduler.TaskStatusType.Canceled);
                };
                Task.prototype._setStatusAs = function (taskStatusType) {
                    if (Scheduler.Container.statusCodeTable.isSupported(taskStatusType)) {
                        var taskChanges = {};
                        taskChanges["id"] = this.id;
                        taskChanges["statuscode"] = Scheduler.Container.statusCodeTable.primaryStatuses[taskStatusType].value();
                        this.container.saveTask(this, taskChanges).catch(function (error) {
                            var msg = (error instanceof Resco.Exception) ? error.message : error.toString();
                            Scheduler.StringTable.alert(msg);
                        });
                    }
                };
                Task.isElementOfFocusedTask = function (element) {
                    return $(element).closest(".taskBoxWrapper.focused").length > 0;
                };
                Task.getIdFromChildElement = function (element) {
                    var taskElement = $(element).closest(".taskBoxWrapper");
                    if (taskElement.length > 0)
                        return taskElement.attr("data-taskid");
                    return null;
                };
                Task._borderWidth = 1;
                Task._borderRadius = 0;
                Task.wasMsgSchedulingInPast = false;
                Task.internalProperties = ["ganttElement", "container", "resource"];
                return Task;
            }(TaskSchedule));
            Scheduler.Task = Task;
            /**
             * Creates and/or removes task tooltip under task box.
             */
            var TaskTooltip = /** @class */ (function (_super) {
                __extends(TaskTooltip, _super);
                function TaskTooltip() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                /**
                 * Creates tooltip for provided task and appends it to task box div.
                 * @param task Task to which tooltip should be created.
                 */
                TaskTooltip.createTooltip = function (task) {
                    TaskTooltip.removeTooltip();
                    if (task) {
                        var taskTooltip = new TaskTooltip();
                        taskTooltip._createTaskTooltip(task);
                        if (taskTooltip._element) {
                            Scheduler.BaseTooltip._instance = taskTooltip;
                        }
                    }
                };
                TaskTooltip.prototype._createTaskTooltip = function (task) {
                    if (task.ganttElement) {
                        this._element = this._createElement(task);
                        Scheduler.Utilities.bringToFront(this._element);
                        $("body").append(this._element);
                        var taskBoxDivOffset = task.taskBoxDiv.offset();
                        var taskBoxDivHeight = task.taskBoxDiv.outerHeight(true);
                        var elementHeight = this._element.outerHeight(true);
                        var offset = TaskTooltip.keepInsideBody(taskBoxDivOffset.left, taskBoxDivOffset.top + taskBoxDivHeight, this._element.outerWidth(true), elementHeight);
                        if (this._contain(taskBoxDivOffset.top, taskBoxDivHeight, offset.top, elementHeight)) {
                            offset.top = taskBoxDivOffset.top - elementHeight;
                        }
                        this._element.css("left", offset.left + "px");
                        this._element.css("top", offset.top + "px");
                    }
                };
                TaskTooltip.prototype._contain = function (taskBoxDivTop, taskBoxDivHeight, tooltipTop, tooltipHeight) {
                    return ((tooltipTop + tooltipHeight) > taskBoxDivTop) && (tooltipTop < (taskBoxDivTop + taskBoxDivHeight));
                };
                TaskTooltip.prototype._createElement = function (task) {
                    var start = task.getWorkStart();
                    var end = task.getWorkEnd();
                    var name = task.getName();
                    var content = "<div class=\"tooltip taskTooltip\">";
                    if (name)
                        content += "<h3>" + name + "</h3>";
                    if (start && end >= start) {
                        content += "<div>";
                        if (task.isTimeOff()) {
                            content += "<p><b>START:</b> " + Scheduler.Container.constants.fullDateTime(new Date(start)) + "</p>";
                            content += "<p><b>END:</b> " + Scheduler.Container.constants.fullDateTime(new Date(end)) + "</p>";
                        }
                        else if (task.isUnscheduledNew()) {
                            var range = new Scheduler.TimeRange(start, end);
                            content += "<p><b>DURATION:</b> " + range.durationToString() + "</p>";
                        }
                        else {
                            var range = new Scheduler.TimeRange(start, end);
                            content += "<p><b>STATUS:</b> " + task.getStatus().name() + "</p>";
                            content += "<p><b>WORK START:</b> " + Scheduler.Container.constants.fullDateTime(new Date(start)) + "</p>";
                            var travel = task.getTravel() ? task.getTravel().duration : 0;
                            if (range.days() > 0) {
                                content += "<p><b>WORK END:</b> " + Scheduler.Container.constants.fullDateTime(new Date(end)) + "</p>";
                                if (travel > 0) {
                                    content += "<p><b>TRAVEL:</b> " + Scheduler.TimeRange.convertDurationToString(travel) + "</p>";
                                }
                            }
                            else {
                                content += "<p><b>DURATION:</b> " + range.durationToString();
                                if (travel > 0) {
                                    content += "     <b>TRAVEL:</b> " + Scheduler.TimeRange.convertDurationToString(travel);
                                }
                                content += "</p>";
                            }
                        }
                        content += "</div>";
                    }
                    content += "</div>";
                    return $(content);
                };
                return TaskTooltip;
            }(Scheduler.BaseTooltip));
            Scheduler.TaskTooltip = TaskTooltip;
            var TaskDynamicEntityList = /** @class */ (function (_super) {
                __extends(TaskDynamicEntityList, _super);
                function TaskDynamicEntityList() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                TaskDynamicEntityList.prototype.prepareQuery = function (filterText) {
                    var fetch = MobileCrm.Data.Fetch.Fetch.deserializeJSON(this.m_repositoryConfig);
                    if (filterText) {
                        this._customizeQuery(filterText, fetch);
                    }
                    return fetch;
                };
                TaskDynamicEntityList.prototype._loadTemplateAndQuery = function () {
                    _super.prototype._loadTemplateAndQuery.call(this);
                    this._setupTemplates();
                };
                TaskDynamicEntityList.prototype.selectView = function (viewName) {
                    _super.prototype.selectView.call(this, viewName);
                    this._setupTemplates();
                };
                TaskDynamicEntityList.prototype._setupTemplates = function () {
                    if (this.rowTemplates) {
                        this.rowTemplates.forEach(function (template) {
                            MobileCrm.UI.ListTemplateManager.setCellStyle(null, MobileCrm.ControllerFactory.instance.listStyles, template, false);
                        }, this);
                    }
                };
                return TaskDynamicEntityList;
            }(MobileCrm.UI.DynamicEntityList));
            Scheduler.TaskDynamicEntityList = TaskDynamicEntityList;
            var TaskRow = /** @class */ (function () {
                //public $root: JQuery;
                function TaskRow(data) {
                    this.selected = false; // KnockoutObservable<boolean>;
                    this.data = data;
                }
                return TaskRow;
            }());
            var TaskTemplateManager = /** @class */ (function () {
                function TaskTemplateManager() {
                }
                TaskTemplateManager.prototype.addAttributesAndLinks = function (entity) {
                    this._addAttributesAndLinksToEntity(this.fetchEntity, entity);
                };
                TaskTemplateManager.prototype.toTemplateDataFromEntity = function (entity) {
                    if (entity)
                        return this.toTemplateData(entity.entityName, entity.properties);
                    else
                        return undefined;
                };
                TaskTemplateManager.prototype.toTemplateData = function (entityName, entityProperties) {
                    if (entityName && this.fetchEntity) {
                        // HACK: DynamicEntity needs to have properties that match with attributes followed by links attributes (that were added to MobileCRM.FetchXml.Entity fetch) in the same order, on the beginning of data array, to match with the template cells indexes that come from Woodford.
                        var repository = new MobileCrm.Data.DynamicRepository();
                        var values = [];
                        this._addAttributesToRepository(this.fetchEntity, entityProperties, repository, values);
                        this._addLinksToRepository(this.fetchEntity, entityProperties, repository, values);
                        var entity = new MobileCrm.Data.DynamicEntity(entityName, repository);
                        for (var i = 0; i < values.length; i++) {
                            entity.trySetValue(repository.properties[i].name, values[i]);
                        }
                        return entity;
                    }
                    return undefined;
                };
                TaskTemplateManager.prototype.loadTemplateData = function (task) {
                    return __awaiter(this, void 0, void 0, function () {
                        var entity, fetch_1, results;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!(task && task.entityInput && this.fetchEntity)) return [3 /*break*/, 2];
                                    entity = new MobileCRM.FetchXml.Entity(task.entityInput.entityName);
                                    entity.addAttribute(task.entityInput.primaryKeyName);
                                    this.addAttributesAndLinks(entity);
                                    entity.addFilter().where(task.entityInput.primaryKeyName, "eq", task.id);
                                    fetch_1 = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch_1.executeAsync("DynamicEntities")];
                                case 1:
                                    results = _a.sent();
                                    if (results && (results.length > 0)) {
                                        return [2 /*return*/, this.toTemplateDataFromEntity(results[0])];
                                    }
                                    _a.label = 2;
                                case 2: return [2 /*return*/, undefined];
                            }
                        });
                    });
                };
                TaskTemplateManager.prototype._addAttributesAndLinksToEntity = function (srcEntity, dstEntity) {
                    this._addAttributesToEntity(srcEntity, dstEntity);
                    this._addLinksToEntity(srcEntity, dstEntity);
                };
                TaskTemplateManager.prototype._addAttributesToEntity = function (srcEntity, dstEntity, aliasPrefix) {
                    // it is better to add attribute that already exist (because C# code behind JSBridge handle duplicity correctly) than, risk overriden or missing attribute in result.
                    if (dstEntity && srcEntity && srcEntity.attributes) {
                        if (aliasPrefix) {
                            for (var i = 0; i < srcEntity.attributes.length; i++) {
                                var attributeName = srcEntity.attributes[i].name;
                                dstEntity.addAttribute(attributeName, this._getAttributeAliasName(aliasPrefix, attributeName)); // !!!attribute alias must be constructing by the same way like in the _addAttributesToRepository() method!!!
                            }
                        }
                        else {
                            for (var i = 0; i < srcEntity.attributes.length; i++) {
                                dstEntity.addAttribute(srcEntity.attributes[i].name);
                            }
                        }
                    }
                };
                TaskTemplateManager.prototype._addLinksToEntity = function (srcEntity, dstEntity, aliasPrefix) {
                    // it is better to add link that already exist (because C# code behind JSBridge handle duplicity correctly) than, risk overriden or missing link attribute in result.
                    if (dstEntity && srcEntity && srcEntity.links) {
                        aliasPrefix = aliasPrefix || "";
                        for (var i = 0; i < srcEntity.links.length; i++) {
                            var link = srcEntity.links[i];
                            var linkEntity = dstEntity.addLink(link.name, link.from, link.to, link.linkType);
                            var linkAliasPrefix = this._getLinkAliasName(aliasPrefix, link.name, i); // !!!link attribute alias must be constructing by the same way like in the _addLinksToRepository() method!!!
                            this._addAttributesToEntity(link, linkEntity, linkAliasPrefix);
                            this._addLinksToEntity(link, linkEntity, linkAliasPrefix);
                        }
                    }
                };
                TaskTemplateManager.prototype._addAttributesToRepository = function (srcEntity, properties, repository, values, aliasPrefix) {
                    if (srcEntity && srcEntity.attributes && properties) {
                        aliasPrefix = aliasPrefix || "";
                        for (var i = 0; i < srcEntity.attributes.length; i++) {
                            var attributeName = this._getAttributeAliasName(aliasPrefix, srcEntity.attributes[i].name);
                            repository.properties.push(new MobileCrm.Data.MetaProperty(attributeName, undefined));
                            values.push(properties[attributeName]);
                        }
                    }
                };
                TaskTemplateManager.prototype._addLinksToRepository = function (srcEntity, properties, repository, values, aliasPrefix) {
                    if (srcEntity && srcEntity.links && properties) {
                        aliasPrefix = aliasPrefix || "";
                        for (var i = 0; i < srcEntity.links.length; i++) {
                            var link = srcEntity.links[i];
                            var linkAliasPrefix = this._getLinkAliasName(aliasPrefix, link.name, i);
                            this._addAttributesToRepository(link, properties, repository, values, linkAliasPrefix);
                            this._addLinksToRepository(link, properties, repository, values, linkAliasPrefix);
                        }
                    }
                };
                TaskTemplateManager.prototype._getAttributeAliasName = function (aliasPrefix, attributeName) {
                    return aliasPrefix + attributeName;
                };
                TaskTemplateManager.prototype._getLinkAliasName = function (aliasPrefix, linkName, linkIndex) {
                    return aliasPrefix + linkName + "_L" + linkIndex + "_";
                };
                return TaskTemplateManager;
            }());
            var TaskContentManager = /** @class */ (function () {
                function TaskContentManager() {
                }
                TaskContentManager.prototype.getTaskContent = function (task, template, height) {
                    if (task && task.templateData && template) {
                        var taskRow = new TaskRow(task.templateData);
                        return this._createTaskDOMObject(taskRow, template, height);
                    }
                    else {
                        return undefined;
                    }
                };
                TaskContentManager.prototype._createTaskDOMObject = function (row, template, height) {
                    var _this = this;
                    var templateHeight = height ? height : template.size.height();
                    var $row = $("<div />").addClass("alRow").css("height", templateHeight + "px");
                    if (template.backgroundColor) {
                        $row.css({ background: template.backgroundColor });
                    }
                    $row.css({ marginLeft: template.margin.left() + "px", marginTop: template.margin.top() + "px", marginRight: template.margin.width() + "px", marginBottom: template.margin.height() + "px" });
                    if (template.cellTemplates && template.cellTemplates.length > 0) {
                        template.cellTemplates.forEach(function (cellTemplate) { return $row.append(_this._createCellDOMObject(row, template, cellTemplate, templateHeight)); });
                    }
                    else if (template.htmlContent) {
                        var rowHtml = $(template.htmlContent);
                        $("*", rowHtml).not("img").each(function (index, element) {
                            var prop = $(element).data("bind");
                            if (row.data && prop && row.data[prop]) {
                                $(element).text(row.data[prop]);
                            }
                        });
                        $("img", rowHtml).each(function (index, element) {
                            var prop = $(element).data("bind");
                            if (row.data && prop) {
                                var imgData = row.data[prop];
                                if (!imgData) {
                                    imgData = $(element).data("placeholder");
                                }
                                if (imgData) {
                                    $(element).attr("src", imgData);
                                }
                            }
                        });
                        $row.append(rowHtml);
                    }
                    return $row;
                };
                TaskContentManager.prototype._createCellDOMObject = function (row, template, cellTemplate, templateHeight) {
                    var $cell = $("<div />").addClass("alCell");
                    // Create and set bounds of the cell
                    var bSkipWidth = false;
                    var bSkipHeight = false;
                    var anchLeft = (cellTemplate.anchor & Resco.ListCellAnchor.Left) > 0;
                    var anchRight = (cellTemplate.anchor & Resco.ListCellAnchor.Right) > 0;
                    var anchTop = (cellTemplate.anchor & Resco.ListCellAnchor.Top) > 0;
                    var anchBottom = (cellTemplate.anchor & Resco.ListCellAnchor.Bottom) > 0;
                    if (anchLeft || !anchRight) {
                        $cell.css({ left: cellTemplate.position.left() + "px" });
                    }
                    if (anchTop || !anchBottom) {
                        $cell.css({ top: cellTemplate.position.top() + "px" });
                    }
                    if (anchRight) {
                        var right = template.size.width() - (cellTemplate.position.left() + cellTemplate.size.width());
                        $cell.css({ right: right + "px" });
                        if (anchLeft) {
                            bSkipWidth = true;
                        }
                    }
                    if (anchBottom) {
                        var bottom = templateHeight - (cellTemplate.position.top() + cellTemplate.size.height());
                        $cell.css({ bottom: bottom + "px" });
                        if (anchTop) {
                            bSkipHeight = true;
                        }
                    }
                    if (!bSkipWidth) {
                        $cell.css({ width: cellTemplate.size.width() + "px" });
                    }
                    if (!bSkipHeight) {
                        $cell.css({ height: cellTemplate.size.height() + "px" });
                    }
                    // End create bounds
                    // TextCell
                    if (cellTemplate.kind == Resco.ListCellKind.Text) {
                        // Set style
                        var style = cellTemplate.style;
                        if (style) {
                            if (style.fontSize) {
                                $cell.css({ fontSize: style.fontSize + "px" });
                            }
                            if (style.fontWeight === 1) {
                                $cell.css({ fontWeight: "bold" });
                            }
                            if (style.foreColor) {
                                $cell.css({ color: style.foreColor });
                            }
                            if (style.backColor) {
                                $cell.css({ backgroundColor: style.backColor });
                            }
                            if (style.horizontalAlignment == Resco.ContentAlignment.Far) {
                                $cell.css({ textAlign: "right" });
                            }
                            else if (style.horizontalAlignment == Resco.ContentAlignment.Center) {
                                $cell.css({ textAlign: "center" });
                            }
                            if (style.verticalAlignment == Resco.ContentAlignment.Far) {
                                $cell.css({ paddingTop: (cellTemplate.size.height() - style.fontSize) + "px" });
                            }
                            else if (style.verticalAlignment == Resco.ContentAlignment.Center) {
                                $cell.css({ paddingTop: ((cellTemplate.size.height() - style.fontSize) / 2) + "px" });
                            }
                        }
                        // Set Content
                        $cell.text(this._getCellTextValue(row.data, cellTemplate));
                    }
                    // ImageCell
                    else if (cellTemplate.kind == Resco.ListCellKind.Image) {
                        var $img = $("<img />").addClass("imageCell").appendTo($cell);
                        var imgData = this._loadImage(row, cellTemplate, $cell[0].children[0]);
                        if (imgData) {
                            $img.attr("src", imgData);
                        }
                        if (cellTemplate.style.backColor) {
                            $img.css({ backgroundColor: cellTemplate.style.backColor });
                        }
                    }
                    return $cell;
                };
                TaskContentManager.prototype._getCellTextValue = function (item, cellTemplate) {
                    var result = "";
                    if (cellTemplate.constant) {
                        result = cellTemplate.dataMember;
                    }
                    else if (Resco.UI.isIListBindingItem(item)) {
                        var bindingItem = item;
                        result = bindingItem.getTextValue(cellTemplate.dataMember, true);
                    }
                    else {
                        result = item[cellTemplate.dataMember];
                    }
                    var style = cellTemplate.style;
                    if (style && style.formatString) {
                        result = Resco.formatString(style.formatString, [result]);
                    }
                    return result;
                };
                TaskContentManager.prototype._loadImage = function (row, cellTemplate, cellElement) {
                    if (this._imageLoader) {
                        var style = cellTemplate.style;
                        var isImageQuery = false;
                        if (style.imageQuery) {
                            isImageQuery = true;
                        }
                        var imageValue = { imageData: "", placeHolder: "" };
                        if (!cellTemplate.constant && Resco.UI.isIListBindingItem(row.data)) {
                            var bindingItem = row.data;
                            imageValue = bindingItem.getImageValue(cellTemplate.dataMember);
                            if (style && style.formatString) {
                                imageValue.imageData = Resco.formatString(style.formatString, [imageValue.imageData]);
                            }
                        }
                        else if (cellTemplate.constant) {
                            imageValue.imageData = cellTemplate.dataMember;
                        }
                        var imageData = isImageQuery ? style.imageQuery : imageValue.imageData;
                        return this._imageLoader(row, imageData, isImageQuery, cellElement, imageValue.placeHolder);
                    }
                    return "";
                };
                TaskContentManager.prototype._imageLoader = function (row, imageData, isImageQuery, cellElement, placeHolder) {
                    if (isImageQuery) {
                        var loaderResult = MobileCrm.Data.DataImageCache.loadImage(row.data, imageData, 100, 100, null, cellElement);
                        if (!loaderResult.isLocal) {
                            return loaderResult.data;
                        }
                        imageData = loaderResult.data;
                    }
                    // TODO: Platform
                    var unselCol = "black"; //Platform.instance.appStyle.listForeground ? Platform.instance.appStyle.listForeground : Platform.instance.appStyle.appColorStart;
                    //if (!unselCol) {
                    //    unselCol = "black";
                    //}
                    var selCol = "#0066CC"; //Platform.instance.appStyle.listSelForeground ? Platform.instance.appStyle.listSelForeground : "white";
                    // replace '.' with '\\' (except the last dot that separates the extension
                    if (imageData) {
                        //imageData = imageData.makePathFromDottedNotation();
                    }
                    else {
                        imageData = placeHolder;
                    }
                    if (imageData !== null && imageData !== undefined) {
                        return MobileCrm.ImageProvider.instance.getImage(imageData, (row.selected ? selCol : unselCol), null, cellElement, true, placeHolder);
                    }
                    return "";
                };
                return TaskContentManager;
            }());
            var TaskTemplateControl = /** @class */ (function (_super) {
                __extends(TaskTemplateControl, _super);
                function TaskTemplateControl() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this._taskContentManager = new TaskContentManager();
                    _this._templateIndex = 0;
                    return _this;
                }
                TaskTemplateControl.prototype.initialize = function (controller) {
                    if (controller) {
                        this._controller = controller;
                        var fetch_2 = controller.loadDataQuery(null);
                        this.fetchEntity = fetch_2 ? fetch_2.entity : undefined;
                    }
                };
                Object.defineProperty(TaskTemplateControl.prototype, "controller", {
                    get: function () {
                        return this._controller;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskTemplateControl.prototype, "templateIndex", {
                    get: function () {
                        return this._templateIndex;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskTemplateControl.prototype, "template", {
                    get: function () {
                        if (this.controller) {
                            return Scheduler.Container.tryGetTemplate(this.controller.rowTemplates, this.templateIndex);
                        }
                        return undefined;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskTemplateControl.prototype, "isInitialized", {
                    get: function () {
                        return (this.controller && this.fetchEntity) ? true : false;
                    },
                    enumerable: true,
                    configurable: true
                });
                TaskTemplateControl.prototype.getTaskContent = function (task, height) {
                    return this._taskContentManager.getTaskContent(task, this.template, height);
                };
                return TaskTemplateControl;
            }(TaskTemplateManager));
            Scheduler.TaskTemplateControl = TaskTemplateControl;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=task.js.map