/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
var DashboardDesigner;
(function (DashboardDesigner) {
    "use strict";
    /**
     * Class represents size of the actual window.
     */
    var Size = (function () {
        function Size(initialized) {
            var _this = this;
            this.m_headerSpace = 50;
            this.width = ko.observable();
            this.height = ko.observable();
            this.contentHeight = ko.computed(function () {
                return _this.height() - _this.m_headerSpace;
            }, this);
            if (initialized) {
                this.width(0);
                this.height(0);
            }
            else {
                this.changeSize();
            }
        }
        Size.prototype.changeSize = function () {
            this.width(window.innerWidth);
            this.height(window.innerHeight);
        };
        return Size;
    }());
    DashboardDesigner.Size = Size;
    var ContextMenu = (function () {
        function ContextMenu() {
            this.topPosition = ko.observable();
            this.leftPosition = ko.observable();
            this.labelRename = ko.observable();
            this.labelDelete = ko.observable();
            this.enabled = ko.observable();
        }
        return ContextMenu;
    }());
    /**
     * Representation of one dashboard item and its necessary properties.
     */
    var DashboardItem = (function () {
        function DashboardItem(name, edited) {
            var _this = this;
            this.name = ko.observable(name);
            this.name.subscribe(function (value) { return _this._trimName(value); });
            this.isEdited = ko.observable(edited);
        }
        DashboardItem.prototype._trimName = function (value) {
            this.name(value.trim());
        };
        return DashboardItem;
    }());
    DashboardDesigner.DashboardItem = DashboardItem;
    /**
     * Main designer class connected with js template.
     */
    var Designer = (function () {
        /**
         * @constructor
         * Initialize all property to default state, and calls callback to loading dashboard configucation from MCRM
         */
        function Designer() {
            var _this = this;
            //colors
            this.titleBackgroundColor = ko.observable();
            this.titleForegroundColor = ko.observable();
            this.formBackgroundColor = ko.observable();
            this.formItemBackgroundColor = ko.observable();
            this.formItemLabelForeground = ko.observable();
            //images
            this.backArrowImg = ko.observable();
            this.editButtonImg = ko.observable();
            this.finishEditButtonImg = ko.observable();
            this.addButtonImg = ko.observable();
            this.deleteButtonImg = ko.observable();
            this.actionButtonImg = ko.observable();
            //labels
            this.noData = ko.observable();
            this.designerLabel = ko.observable();
            this.m_dashboardExistsMessage = ko.observable();
            this.m_emptyDashboardName = ko.observable();
            this.m_deleteDasboardMessage = ko.observable();
            this.m_commandsLabels = new Array();
            this.dashboards = ko.observableArray();
            this.dashboardItemIsEdited = ko.observable(false);
            this.contextMenu = new ContextMenu();
            this.size = new Size();
            this.selectedDashboardItem = ko.observable();
            this._loadColors();
            this._loadImages();
            MobileCRM.bridge.command("getPrivateDashboards", {}, function (result) {
                var dashboards = result.trim().split(";");
                dashboards.pop(); // last item is ";"
                for (var _i = 0, dashboards_1 = dashboards; _i < dashboards_1.length; _i++) {
                    var dashboard = dashboards_1[_i];
                    var dashboardName = dashboard.substring(0, dashboard.length - 4);
                    _this.dashboards.push(new DashboardItem(dashboardName));
                }
            }, function (error) {
                console.log(error);
            }, this);
            MobileCRM.bridge.command("getLocalizedLabels", {}, function (result) {
                var localizedLabels = result;
                _this.designerLabel(localizedLabels[0]);
                _this.contextMenu.labelRename(localizedLabels[1]);
                _this.contextMenu.labelDelete(localizedLabels[2]);
                _this.noData(localizedLabels[3]);
                _this.m_dashboardExistsMessage(localizedLabels[4]);
                _this.m_emptyDashboardName(localizedLabels[5]);
                _this.m_deleteDasboardMessage(localizedLabels[6]);
                _this.m_commandsLabels[0] = localizedLabels[7];
                _this.m_commandsLabels[1] = localizedLabels[8];
            }, function (error) { }, this);
        }
        /**
         * After click to edit button on dashboard visual component in the list of dashboards
         * call function to open DashboardEditor for selected dashboard.
         * @param {any} sender It was clicked on this objects (in normal case is DashboardItem obj).
         * @param {any} e event
         */
        Designer.prototype.openSelectedDashboard = function (sender, e) {
            var item = sender;
            MobileCRM.bridge.command("openSelectedDashboard", item.name(), function (result) { }, function (error) { }, this);
            this.selectedDashboardItem(null);
            this.contextMenu.enabled(false);
        };
        /**
         * A method is called after click to the finishEditButton and it renames the dashboard config file
         * if exists or if it's creating new dasboards then calls method to create new file.
         * @param {number} index  index index if item where it was clicked.
         * @param {any} sender sender object
         * @param {any} e event
         */
        Designer.prototype.saveEditedDashboardList = function (index, sender, e) {
            var _this = this;
            var dashboard = sender;
            if (dashboard.name() === "") {
                Designer.showMessageBox(this.m_emptyDashboardName(), ["OK"]);
            }
            else {
                if (this.m_isCreatingNewDashboard) {
                    MobileCRM.bridge.command("createNewDashboard", dashboard.name(), function (result) {
                        if (result) {
                            _this.m_isCreatingNewDashboard = false;
                            _this.dashboards()[index].isEdited(false);
                            _this.dashboardItemIsEdited(false);
                        }
                        else {
                            Designer.showMessageBox(_this.m_dashboardExistsMessage(), ["OK"]);
                        }
                    }, function (err) {
                        Designer.showMessageBox(err, ["OK"]);
                    }, this);
                }
                else {
                    if (this.m_oldDashboardName === dashboard.name()) {
                        this.dashboards()[index].isEdited(false);
                        this.dashboardItemIsEdited(false);
                        this.m_oldDashboardName = "";
                        this.selectedDashboardItem(null);
                        this.contextMenu.enabled(false);
                        return;
                    }
                    var name = this.m_oldDashboardName + ";" + dashboard.name();
                    MobileCRM.bridge.command("renameDashboard", name, function (result) {
                        _this.dashboards()[index].isEdited(false);
                        _this.dashboardItemIsEdited(false);
                        _this.m_oldDashboardName = "";
                        _this.selectedDashboardItem(null);
                        _this.contextMenu.enabled(false);
                    }, function (error) {
                        Designer.showMessageBox(error, ["OK"]);
                    }, this);
                }
            }
        };
        /**
         *
         * @param sender
         * @param e
         */
        Designer.prototype.closeContext = function (sender, e) {
            if (this.contextMenu.enabled()) {
                this.contextMenu.enabled(false);
                this.selectedDashboardItem(null);
            }
        };
        /**
         *
         * @param sender
         * @param e
         */
        Designer.prototype.openContextMenu = function (sender, e) {
            var item = sender;
            this.selectedDashboardItem(item);
            var parentOffsetTop = e.target.offsetParent.offsetTop;
            this.contextMenu.topPosition(e.currentTarget.offsetTop + e.currentTarget.offsetHeight + +parentOffsetTop);
            var w = 150;
            var leftPosition = e.currentTarget.offsetLeft + e.currentTarget.offsetWidth - w; /// TODO: detect bottom!!!
            this.contextMenu.leftPosition(leftPosition);
            this.contextMenu.enabled(true);
        };
        /**
         * Remove selected dashboard from the list of dashboards and then call method to remove config file of this dashboard.
         * @param {any} sender It is dashboard item that will be removed.
         * @param {any} e
         */
        Designer.prototype.removeDashboard = function (sender, e) {
            var _this = this;
            this.contextMenu.enabled(false);
            var dashboard = this.selectedDashboardItem(); //<DashboardItem>sender;
            var popup = new MobileCRM.UI.MessageBox(this.m_deleteDasboardMessage(), "");
            popup.items = this.m_commandsLabels; //["Yes", "No"];
            popup.multiLine = true;
            popup.show(function (result) {
                if (result == _this.m_commandsLabels[0]) {
                    MobileCRM.bridge.command("removeDashboard", dashboard.name(), function (result) {
                        if (result) {
                            _this.selectedDashboardItem(null);
                            _this.dashboards.remove(dashboard);
                        }
                    }, function (error) {
                        Designer.showMessageBox(error, ["OK"]);
                    }, _this);
                }
            }, function (error) {
                Designer.showMessageBox(error, ["OK"]);
            }, this);
        };
        /**
         * A method called after click edit button in the dashboard item row.
         * @param {any} sender dasboardItem that will be edited.
         * @param {any} e event
         */
        Designer.prototype.editDashboardItem = function (sender, e) {
            if (!this.dashboardItemIsEdited()) {
                this._cancelEditingDashboardItem();
                var index = this.dashboards().indexOf(this.selectedDashboardItem());
                this.dashboards()[index].isEdited(true);
                this.dashboardItemIsEdited(true);
                this.m_oldDashboardName = this.selectedDashboardItem().name();
            }
        };
        /**
         * A public method that add new dashboardItem to the list of dashboards and this new dashboardItem to the change initialization name.
         * @param {any} sender sender object
         * @param {any} e event
         */
        Designer.prototype.addNewDashboard = function (sender, e) {
            if (!this.dashboardItemIsEdited()) {
                this._cancelEditingDashboardItem();
                var name = "";
                var newDashboard = new DashboardItem(name);
                newDashboard.isEdited(true);
                this.dashboards.push(newDashboard);
                this.dashboardItemIsEdited(true);
                this.m_isCreatingNewDashboard = true;
            }
        };
        /**
         * Call method through JSBridge for close designer.
         */
        Designer.prototype.closeDesigner = function () {
            MobileCRM.bridge.command("closeDashboardDesigner", "exit", function (result) { }, function (error) { }, this);
        };
        /**
         * static method for show message box with specific message.
         * @param message string message to show
         * @param items string array as button labels in the message.
         */
        Designer.showMessageBox = function (message, items) {
            var mb = new MobileCRM.UI.MessageBox(message, "");
            mb.multiLine = true;
            mb.items = items;
            mb.show(function (result) { }, function (failure) { }, this);
        };
        /**
         * A private method that goes through all dashboards items and cancel editing if some of item is edit.
         */
        Designer.prototype._cancelEditingDashboardItem = function () {
            this.contextMenu.enabled(false);
            for (var _i = 0, _a = this.dashboards(); _i < _a.length; _i++) {
                var item = _a[_i];
                if (item.isEdited()) {
                    item.isEdited(false);
                    this.dashboardItemIsEdited(false);
                    return;
                }
            }
        };
        /**
         * Call JSBrige function for get app colors.
         */
        Designer.prototype._loadColors = function () {
            var _this = this;
            MobileCRM.Application.getAppColor("TitleBackground", function (result) {
                _this.titleBackgroundColor(result);
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppColor("TitleForeground", function (result) {
                _this.titleForegroundColor(result);
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppColor("FormBackground", function (result) {
                _this.formBackgroundColor(result);
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppColor("FormItemBackground", function (result) {
                _this.formItemBackgroundColor(result);
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppColor("FormItemLabelForeground", function (result) {
                _this.formItemLabelForeground(result);
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
        };
        /**
         * Call JSBridge funtions for get som of images from MCRM.
         */
        Designer.prototype._loadImages = function () {
            var _this = this;
            MobileCRM.Application.getAppImage("Cmd.Back.png", "TitleForeground", function (result) {
                _this.backArrowImg("url('" + result + "')");
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppImage("Cmd.New.png", "TitleForeground", function (result) {
                _this.addButtonImg("url('" + result + "')");
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppImage("Cmd.Edit.png", "", function (result) {
                _this.editButtonImg("url('" + result + "')");
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppImage("Buttons.Select.png", "", function (result) {
                _this.finishEditButtonImg("url('" + result + "')");
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppImage("Cmd.Delete.png", "", function (result) {
                _this.deleteButtonImg("url('" + result + "')");
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
            MobileCRM.Application.getAppImage("Cmd.Action.png", "", function (result) {
                _this.actionButtonImg("url('" + result + "')");
            }, function (err) {
                Designer.showMessageBox(err, ["OK"]);
            }, null);
        };
        ;
        return Designer;
    }());
    DashboardDesigner.Designer = Designer;
})(DashboardDesigner || (DashboardDesigner = {}));
