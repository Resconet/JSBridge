///<reference path="../../TypeScriptDefinitions/JSBridge.d.ts"/>
///<reference path="../../TypeScriptDefinitions/jquery.d.ts"/>
///<reference path="../../Controls/event.ts" />
///<reference path="../../Controls/popupMenu.ts"/>
///<reference path="../../Controls/gestureManager.ts"/>
///<reference path="holidays.ts" />
///<reference path="timeRange.ts" />
///<reference path="settings.ts" />
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var Performance = (function () {
                function Performance() {
                    this._stopped = false;
                    if (!Performance.now) {
                        if (typeof performance === "object" &&
                            performance !== null &&
                            typeof performance.now === "function")
                            Performance.now = Performance.performanceNow;
                        else
                            Performance.now = Performance.internalNow;
                    }
                    this._value = Performance.now();
                }
                Performance.prototype.start = function () {
                    this._stopped = false;
                    this._value = Performance.now();
                };
                Performance.prototype.end = function () {
                    if (!this._stopped) {
                        this._stopped = true;
                        this._value = Math.round(Performance.now() - this._value);
                    }
                    return this._value;
                };
                Performance.prototype.durationInMiliseconds = function () {
                    return Math.round(this._stopped ? this._value : Performance.now() - this._value);
                };
                Performance.performanceNow = function () {
                    return performance.now();
                };
                Performance.internalNow = function () {
                    return Date.now().valueOf();
                };
                return Performance;
            }());
            Scheduler.Performance = Performance;
            var Utilities = (function () {
                function Utilities() {
                }
                Utilities.createFromTemplate = function (template) {
                    return $(template);
                };
                /**
                 * Obtain task that is in the same row in the list view like the row in the gantt view where was clicked is.
                 */
                //public static getTaskOwningRowFromY(container, yPositionInGanttSVGBox): number {
                //	return container.getResource(container.position2RowIndex(yPositionInGanttSVGBox));
                //}
                //<%------------------------------------------------------------------------ TASK ELEMENT BOX APPEND UTILITIES ---------------------------------------------------------------%>
                /**
                 * Returns delta offset between element1 and element2. (element1 distance from element2)
                 * @param element1
                 * @param element2
                 */
                Utilities.getContainersOffsetDelta = function (element1, element2) {
                    var element1Offset = element1.offset();
                    var element2Offset = element2.offset();
                    var deltaX = Math.round(element1Offset.left - element2Offset.left);
                    var deltaY = Math.round(element1Offset.top - element2Offset.top);
                    return { x: deltaX, y: deltaY };
                };
                //<%------------------------------------------------------------------------ DAYS AND DATE UTILITIES ---------------------------------------------------------------%>
                //////  Methods moved from i18nJs.js file ///////
                Utilities.isWeekend = function (date) {
                    var friIsHoly = false;
                    var satIsHoly = true;
                    var sunIsHoly = true;
                    var dayOfWeek = date.getDay();
                    return (dayOfWeek === 5 && friIsHoly) || (dayOfWeek === 6 && satIsHoly) || (dayOfWeek === 0 && sunIsHoly);
                };
                Utilities.isHoliday = function (date) {
                    var h = Scheduler.Holidays.isHoliday(date);
                    return (h && !h.isWorking) ? true : false; // Expression "return h && !h.isWorking;" returns undefined insetead false in some cases!
                };
                Utilities.isWeekendOrHoliday = function (date) {
                    return this.isWeekend(date) || this.isHoliday(date);
                };
                //////  Methods moved from i18nJs.js file ///////
                Utilities.equalDates = function (src, dst) {
                    if (!dst)
                        return false;
                    else {
                        var dateValue = new Date(dst).valueOf();
                        return Scheduler.milisecondsToMinutes(src) === Scheduler.milisecondsToMinutes(dateValue);
                    }
                };
                //<%------------------------------------------------------------------------ OTHER UTILITIES ---------------------------------------------------------------%>
                Utilities.createNewHTMLElement = function (elementType, id, style, classes, textContent, dataAttributes, attributes) {
                    var element = document.createElement(elementType);
                    if (id !== undefined && id !== null) {
                        element.id = id;
                    }
                    if (style !== undefined && style !== null) {
                        for (var _i = 0, style_1 = style; _i < style_1.length; _i++) {
                            var styleItem = style_1[_i];
                            if (styleItem !== undefined)
                                element.style[styleItem.styleName] = styleItem.styleValue;
                        }
                    }
                    if (classes !== undefined && classes !== null) {
                        for (var _a = 0, classes_1 = classes; _a < classes_1.length; _a++) {
                            var className = classes_1[_a];
                            if (className !== "")
                                element.classList.add(className);
                        }
                    }
                    if (textContent !== undefined && textContent !== null) {
                        element.textContent = textContent;
                    }
                    if (dataAttributes !== undefined && dataAttributes !== null) {
                        for (var _b = 0, dataAttributes_1 = dataAttributes; _b < dataAttributes_1.length; _b++) {
                            var attr = dataAttributes_1[_b];
                            element.setAttribute(attr.attributeName, attr.attributeValue);
                        }
                    }
                    if (attributes !== undefined && attributes !== null) {
                        for (var _c = 0, attributes_1 = attributes; _c < attributes_1.length; _c++) {
                            var attr = attributes_1[_c];
                            element.setAttribute(attr.attributeName, attr.attributeValue);
                        }
                    }
                    return element;
                };
                Utilities.bringToFront = function (element) {
                    var zIndex = 10;
                    var elements = $("*");
                    elements.each(function (index, elem) {
                        if ($(elem).css("position") !== "static") {
                            var current = parseInt($(elem).css("zIndex"));
                            if (current > zIndex)
                                zIndex = current;
                        }
                    });
                    element.css("zIndex", zIndex += 10);
                };
                /**
                 * Returns arrays of the days in the week sorted in correct order by the first day.
                 * @param firstDay number value of the first day in the week. //0 is Sunday
                 */
                Utilities.getAbbreviatedDayNames = function (firstDay) {
                    var daysNames = Scheduler.Container.constants.cultureInfo.dateTimeFormat.abbreviatedDayNames.slice();
                    if (firstDay === 0)
                        return daysNames;
                    var index = 0;
                    while (index !== firstDay) {
                        //@DM: remove first element and add it to the end of array;
                        daysNames.push(daysNames.splice(0, 1)[0]);
                        index++;
                    }
                    return daysNames;
                };
                return Utilities;
            }());
            Scheduler.Utilities = Utilities;
            //<%------------------------------------------------------------------------ SPLITTER CONTAINER ---------------------------------------------------------------%>
            var SplitterPrimaryPanel;
            (function (SplitterPrimaryPanel) {
                SplitterPrimaryPanel[SplitterPrimaryPanel["Left"] = 0] = "Left";
                SplitterPrimaryPanel[SplitterPrimaryPanel["Right"] = 1] = "Right";
            })(SplitterPrimaryPanel = Scheduler.SplitterPrimaryPanel || (Scheduler.SplitterPrimaryPanel = {}));
            var SplitterPanelsVisibility;
            (function (SplitterPanelsVisibility) {
                SplitterPanelsVisibility[SplitterPanelsVisibility["Both"] = 0] = "Both";
                SplitterPanelsVisibility[SplitterPanelsVisibility["LeftOnly"] = 1] = "LeftOnly";
                SplitterPanelsVisibility[SplitterPanelsVisibility["RightOnly"] = 2] = "RightOnly";
            })(SplitterPanelsVisibility = Scheduler.SplitterPanelsVisibility || (Scheduler.SplitterPanelsVisibility = {}));
            var Splitter = (function () {
                function Splitter(leftContainer, rightContainer, settings) {
                    var _this = this;
                    this._primaryPanelRatio = -1;
                    this._primaryPanelMinWidth = 0; // always in pixels
                    this._primaryPanelMaxWidth = 0; // always in pixels
                    this._onResizeCalled = false;
                    this._poinerDownOffset = 0;
                    this._gestureManager = new Controls.GestureManager();
                    //@JC performing schedulerElement workSpace splitting into first and second boxes during moving when mouse is down
                    this._onPointerDown = function (ge) {
                        var separatorElementOffsetX = _this._separatorElement.offset().left;
                        var touchAreaDelta = _this.separatorWidth;
                        if (ge.pointerType === "touch") {
                            if (Scheduler.Container.constants.splitterTouchAreaWidth > touchAreaDelta)
                                touchAreaDelta = Scheduler.Container.constants.splitterTouchAreaWidth;
                        }
                        ge.cancelDown = true;
                        if ((separatorElementOffsetX <= ge.pageX) && (ge.pageX < (separatorElementOffsetX + touchAreaDelta))) {
                            if (!_this._settings.splittingPredicate || _this._settings.splittingPredicate(ge)) {
                                ge.cancelDown = false;
                                _this._poinerDownOffset = ge.pageX - separatorElementOffsetX;
                                _this._separatorElement.css({ "background-color": _this._settings.separatorDraggedColor });
                                _this.resizeStarted.raise(new Resco.EventArgs());
                            }
                        }
                    };
                    this._onPointerMove = function (ge) {
                        //manage resizing
                        var availableWidth = _this.element.width() - _this.separatorWidth;
                        var positionX = ge.pageX - _this.element.offset().left;
                        positionX -= _this._poinerDownOffset;
                        var primaryPanelWidth = _this.isLeftPanelPrimary ? positionX : (availableWidth - positionX);
                        _this._setPrimaryPanelWidth(availableWidth, primaryPanelWidth);
                    };
                    this._onPointerUp = function (ge) {
                        _this._poinerDownOffset = 0;
                        _this._onResize();
                        _this._separatorElement.css({ "background-color": _this._settings.separatorColor });
                    };
                    this.leftContainer = leftContainer;
                    this.rightContainer = rightContainer;
                    this._initSettings(settings);
                    if (this.isLeftPanelPrimary) {
                        this._leftPanelWidth = this._settings.primaryPanelWidthInPercentage ? 0 : this._settings.primaryPanelWidth;
                        this._rightPanelWidth = 0;
                    }
                    else {
                        this._leftPanelWidth = 0;
                        this._rightPanelWidth = this._settings.primaryPanelWidthInPercentage ? 0 : this._settings.primaryPanelWidth;
                    }
                    this.resizeStarted = new Resco.Event(this);
                    this.resize = new Resco.Event(this);
                    this._initialize();
                    if (this._settings.manualResizingEnabled) {
                        this._addResizingEvents();
                    }
                }
                Object.defineProperty(Splitter.prototype, "element", {
                    get: function () {
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Splitter.prototype, "isLeftPanelPrimary", {
                    get: function () {
                        return this._settings.primaryPanel === SplitterPrimaryPanel.Left;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Splitter.prototype, "leftPanelWidth", {
                    get: function () {
                        return this._leftPanelWidth;
                    },
                    set: function (value) {
                        var availableWidth = this.element.width() - this.separatorWidth;
                        var primaryPanelWidth = this.isLeftPanelPrimary ? value : (availableWidth - value);
                        this._setPrimaryPanelWidth(availableWidth, primaryPanelWidth);
                        this._onPrimaryPanelWidthChanged();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Splitter.prototype, "rightPanelWidth", {
                    get: function () {
                        return this._rightPanelWidth;
                    },
                    set: function (value) {
                        var availableWidth = this.element.width() - this.separatorWidth;
                        var primaryPanelWidth = this.isLeftPanelPrimary ? (availableWidth - value) : value;
                        this._setPrimaryPanelWidth(availableWidth, primaryPanelWidth);
                        this._onPrimaryPanelWidthChanged();
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Splitter.prototype, "separatorWidth", {
                    get: function () {
                        return (this.shownPanels === SplitterPanelsVisibility.Both) ? this._settings.separatorWidth : 0;
                    },
                    set: function (value) {
                        if (value !== this._settings.separatorWidth) {
                            this._settings.separatorWidth = value;
                            this._separatorElement.css({ width: this.separatorWidth });
                            this._onResize();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Splitter.prototype, "shownPanels", {
                    get: function () {
                        return this._settings.shownPanels;
                    },
                    set: function (value) {
                        if (value !== this._settings.shownPanels) {
                            this._settings.shownPanels = value;
                            this._separatorElement.css({ width: this.separatorWidth });
                            if (this.shownPanels === SplitterPanelsVisibility.Both) {
                                var availableWidth = this.element.width() - this.separatorWidth;
                                if (this._cachedPrimaryPanelWidth === undefined) {
                                    if (this._settings.primaryPanelWidthInPercentage)
                                        this._cachedPrimaryPanelWidth = Math.round(availableWidth * (this._settings.primaryPanelWidth / 100));
                                    else
                                        this._cachedPrimaryPanelWidth = this._settings.primaryPanelWidth;
                                }
                                this._primaryPanelRatio = (availableWidth > 0) ? (this._cachedPrimaryPanelWidth / availableWidth) : 0;
                                if (this.isLeftPanelPrimary)
                                    this._leftPanelWidth = this._cachedPrimaryPanelWidth;
                                else
                                    this._rightPanelWidth = this._cachedPrimaryPanelWidth;
                                this._leftPanelElement.css({ "display": "" });
                                this._separatorElement.css({ "display": "" });
                                this._rightPanelElement.css({ "display": "" });
                            }
                            else {
                                this._cachedPrimaryPanelWidth = this.isLeftPanelPrimary ? this.leftPanelWidth : this.rightPanelWidth;
                                if (this.shownPanels === SplitterPanelsVisibility.LeftOnly) {
                                    this._rightPanelElement.css({ "display": "none" });
                                    this._separatorElement.css({ "display": "none" });
                                }
                                else {
                                    this._leftPanelElement.css({ "display": "none" });
                                    this._separatorElement.css({ "display": "none" });
                                }
                            }
                            this._onResize();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Splitter.prototype.onResize = function () {
                    this._onResizeCalled = true;
                    this._onResize();
                };
                Splitter.prototype._onResize = function () {
                    var availableWidth = this.element.width() - this.separatorWidth;
                    this._setPrimaryPanelMinMaxWidth(availableWidth);
                    var primaryPanelWidth = this._computePrimaryPanelWidth(availableWidth);
                    this._setPrimaryPanelWidth(availableWidth, primaryPanelWidth);
                    this._onPrimaryPanelWidthChanged();
                };
                Splitter.prototype._setPrimaryPanelMinMaxWidth = function (availableWidth) {
                    if (this.shownPanels === SplitterPanelsVisibility.Both) {
                        if (this._settings.primaryPanelMinWidthInPercentage)
                            this._primaryPanelMinWidth = Math.round(availableWidth * (this._settings.primaryPanelMinWidth / 100));
                        else
                            this._primaryPanelMinWidth = this._settings.primaryPanelMinWidth;
                        if (this._settings.primaryPanelMaxWidthInPercentage)
                            this._primaryPanelMaxWidth = Math.round(availableWidth * (this._settings.primaryPanelMaxWidth / 100));
                        else
                            this._primaryPanelMaxWidth = this._settings.primaryPanelMaxWidth;
                        if (this._primaryPanelMinWidth > availableWidth)
                            this._primaryPanelMinWidth = availableWidth;
                        if (this._primaryPanelMaxWidth > availableWidth)
                            this._primaryPanelMaxWidth = availableWidth;
                    }
                    else {
                        this._primaryPanelMinWidth = 0;
                        this._primaryPanelMaxWidth = availableWidth;
                    }
                };
                Splitter.prototype._computePrimaryPanelWidth = function (availableWidth) {
                    if (this.shownPanels === SplitterPanelsVisibility.Both) {
                        if (this._settings.keepPanelsRatio && (this._primaryPanelRatio !== -1)) {
                            return Math.round(availableWidth * this._primaryPanelRatio);
                        }
                        else {
                            if (this._settings.primaryPanelWidthInPercentage && (this._primaryPanelRatio === -1)) {
                                return Math.round(availableWidth * (this._settings.primaryPanelWidth / 100));
                            }
                            else {
                                return this.isLeftPanelPrimary ? this.leftPanelWidth : this.rightPanelWidth;
                            }
                        }
                    }
                    else {
                        if (this.shownPanels === SplitterPanelsVisibility.LeftOnly) {
                            return this.isLeftPanelPrimary ? availableWidth : 0;
                        }
                        else {
                            return this.isLeftPanelPrimary ? 0 : availableWidth;
                        }
                    }
                };
                Splitter.prototype._onPrimaryPanelWidthChanged = function () {
                    if (this._onResizeCalled) {
                        if (this.leftContainer && (this.shownPanels !== SplitterPanelsVisibility.RightOnly))
                            this.leftContainer.onResize();
                        if (this.rightContainer && (this.shownPanels !== SplitterPanelsVisibility.LeftOnly))
                            this.rightContainer.onResize();
                        this.resize.raise(new Resco.EventArgs());
                    }
                };
                Splitter.prototype._initSettings = function (settings) {
                    // Make copy of the settings to avoid interference with another splitter where the same settings object can be used.
                    this._settings = {};
                    if (settings) {
                        this._settings.primaryPanel = settings.primaryPanel;
                        this._settings.primaryPanelWidth = settings.primaryPanelWidth;
                        this._settings.primaryPanelWidthInPercentage = settings.primaryPanelWidthInPercentage;
                        this._settings.separatorWidth = settings.separatorWidth;
                        this._settings.separatorColor = settings.separatorColor;
                        this._settings.separatorDraggedColor = settings.separatorDraggedColor;
                        this._settings.manualResizingEnabled = settings.manualResizingEnabled;
                        this._settings.keepPanelsRatio = settings.keepPanelsRatio;
                        this._settings.primaryPanelMinWidth = settings.primaryPanelMinWidth;
                        this._settings.primaryPanelMinWidthInPercentage = settings.primaryPanelMinWidthInPercentage;
                        this._settings.primaryPanelMaxWidth = settings.primaryPanelMaxWidth;
                        this._settings.primaryPanelMaxWidthInPercentage = settings.primaryPanelMaxWidthInPercentage;
                        this._settings.shownPanels = settings.shownPanels;
                        this._settings.splittingPredicate = settings.splittingPredicate;
                    }
                    // Set valid values to settings
                    if (this._settings.primaryPanel === undefined)
                        this._settings.primaryPanel = SplitterPrimaryPanel.Left;
                    this._settings.primaryPanelWidthInPercentage = this._settings.primaryPanelWidthInPercentage ? true : false;
                    if ((this._settings.primaryPanelWidth === undefined) || (this._settings.primaryPanelWidth < 0))
                        this._settings.primaryPanelWidth = 0;
                    else if (this._settings.primaryPanelWidthInPercentage && (this._settings.primaryPanelWidth > 100))
                        this._settings.primaryPanelWidth = 100;
                    if ((this._settings.separatorWidth === undefined) || (this._settings.separatorWidth < 0))
                        this._settings.separatorWidth = 0;
                    if (!this._settings.separatorColor)
                        this._settings.separatorColor = Scheduler.Container.constants.componentsBorderColor;
                    if (!this._settings.separatorDraggedColor)
                        this._settings.separatorDraggedColor = Scheduler.Container.constants.componentsSelectedBorderColor;
                    this._settings.manualResizingEnabled = this._settings.manualResizingEnabled ? true : false;
                    this._settings.keepPanelsRatio = this._settings.keepPanelsRatio ? true : false;
                    this._settings.primaryPanelMinWidthInPercentage = this._settings.primaryPanelMinWidthInPercentage ? true : false;
                    if (this._settings.primaryPanelMinWidth === undefined || (this._settings.primaryPanelMinWidth < 0))
                        this._settings.primaryPanelMinWidth = 0;
                    else if (this._settings.primaryPanelMinWidthInPercentage && (this._settings.primaryPanelMinWidth > 100))
                        this._settings.primaryPanelMinWidth = 100;
                    this._settings.primaryPanelMaxWidthInPercentage = this._settings.primaryPanelMaxWidthInPercentage ? true : false;
                    if (this._settings.primaryPanelMaxWidth === undefined || (this._settings.primaryPanelMaxWidth < 0)) {
                        this._settings.primaryPanelMaxWidth = 100;
                        this._settings.primaryPanelMaxWidthInPercentage = true;
                    }
                    else if (this._settings.primaryPanelMaxWidthInPercentage && (this._settings.primaryPanelMaxWidth > 100))
                        this._settings.primaryPanelMaxWidth = 100;
                    if (this._settings.shownPanels === undefined)
                        this._settings.shownPanels = SplitterPanelsVisibility.Both;
                };
                Splitter.prototype._setPrimaryPanelWidth = function (availableWidth, primaryPanelWidth) {
                    if (availableWidth > 0) {
                        if (primaryPanelWidth < this._primaryPanelMinWidth)
                            primaryPanelWidth = this._primaryPanelMinWidth;
                        if (primaryPanelWidth > this._primaryPanelMaxWidth)
                            primaryPanelWidth = this._primaryPanelMaxWidth;
                        this._primaryPanelRatio = primaryPanelWidth / availableWidth;
                        var secondaryPanelWidth = availableWidth - primaryPanelWidth;
                        if (this.isLeftPanelPrimary) {
                            this._leftPanelWidth = primaryPanelWidth;
                            this._rightPanelWidth = secondaryPanelWidth;
                            this._leftPanelElement.css({ width: this.leftPanelWidth });
                            this._separatorElement.css({ left: this.leftPanelWidth });
                            this._rightPanelElement.css({ left: this.leftPanelWidth + this.separatorWidth, width: this.rightPanelWidth });
                        }
                        else {
                            this._leftPanelWidth = secondaryPanelWidth;
                            this._rightPanelWidth = primaryPanelWidth;
                            this._rightPanelElement.css({ width: this.rightPanelWidth });
                            this._separatorElement.css({ right: this.rightPanelWidth });
                            this._leftPanelElement.css({ right: this.rightPanelWidth + this.separatorWidth, width: this.leftPanelWidth });
                        }
                    }
                };
                Splitter.prototype._initialize = function () {
                    this._element = $("<div>").addClass("splitterContainer");
                    this._leftPanelElement = $("<div>").addClass("leftPanel splitElement");
                    this._separatorElement = $("<div>").addClass("separatorElement splitElement");
                    this._rightPanelElement = $("<div>").addClass("rightPanel splitElement");
                    if (this.isLeftPanelPrimary)
                        this._leftPanelElement.css({ left: 0 });
                    else
                        this._rightPanelElement.css({ right: 0 });
                    this._separatorElement.css({ width: this.separatorWidth }); // it is necessary to set width here to proper width() method functionality, because separatorElement is not appended in the DOM tree yet.
                    this._separatorElement.css({ "background-color": this._settings.separatorColor });
                    if (this._settings.manualResizingEnabled) {
                        this._separatorElement.addClass("draggable");
                        this._separatorElement.html("|");
                    }
                    if (this.shownPanels === SplitterPanelsVisibility.LeftOnly) {
                        this._rightPanelElement.css({ "display": "none" });
                        this._separatorElement.css({ "display": "none" });
                    }
                    else if (this.shownPanels === SplitterPanelsVisibility.RightOnly) {
                        this._leftPanelElement.css({ "display": "none" });
                        this._separatorElement.css({ "display": "none" });
                    }
                    if (this.leftContainer)
                        this._leftPanelElement.append(this.leftContainer.element);
                    if (this.rightContainer)
                        this._rightPanelElement.append(this.rightContainer.element);
                    this._element.append(this._leftPanelElement);
                    this._element.append(this._separatorElement);
                    this._element.append(this._rightPanelElement);
                };
                Splitter.prototype._addResizingEvents = function () {
                    this._gestureManager.onDownMoveUpCancel(this.element, this._onPointerDown, this._onPointerMove, this._onPointerUp, this._onPointerUp);
                };
                return Splitter;
            }());
            Scheduler.Splitter = Splitter;
            /// Slider control main class
            var Slider = (function () {
                function Slider(parentElement, startValue, endValue, isDisabled) {
                    var _this = this;
                    this.m_itemsCount = 25;
                    this.m_startX = 0;
                    this.m_endX = 0;
                    this._startPosition = 0;
                    this._endPosition = 0;
                    this._startSiblingValue = 0;
                    this._endSiblingValue = 0;
                    this._gestureManager = new Controls.GestureManager();
                    this._onPointerDownStart = function (ge) {
                        _this.m_startX = ge.pageX - _this._startPosition;
                        _this._setCorrectZindex(_this.m_sliderPointStart, 10);
                    };
                    this._onPointerMoveStart = function (ge) {
                        var newX = ge.pageX - _this.m_startX;
                        var value = _this._positionToValue(newX);
                        if (value < _this._endSiblingValue) {
                            _this._setStartValue(value);
                        }
                    };
                    this._onPointerUpStart = function (ge) {
                        var value = _this._positionToValue(_this._startPosition);
                        if (value < _this._endSiblingValue) {
                            _this._setStartValue(value);
                        }
                        _this._setCorrectZindex(_this.m_sliderPointStart, 0);
                        _this.startValueChanged.raise(new Resco.ValueChangedEventArgs(value), _this);
                    };
                    this._onPointerDownEnd = function (ge) {
                        _this.m_endX = ge.pageX - _this._endPosition;
                        _this._setCorrectZindex(_this.m_sliderPointEnd, 10);
                    };
                    this._onPointerMoveEnd = function (ge) {
                        var newX = ge.pageX - _this.m_endX;
                        var value = _this._positionToValue(newX);
                        if (value > _this._startSiblingValue) {
                            _this._setEndValue(value);
                        }
                    };
                    this._onPointerUpEnd = function (ge) {
                        var value = _this._positionToValue(_this._endPosition);
                        if (value > _this._startSiblingValue) {
                            _this._setEndValue(value);
                        }
                        _this._setCorrectZindex(_this.m_sliderPointEnd, 0);
                        _this.endValueChanged.raise(new Resco.ValueChangedEventArgs(value), _this);
                    };
                    var sliderTemplate = "\
			<div class='slider' data-isDisabled='" + isDisabled + "'>\
				<div class='sliderBar'>\
					<div class='sliderRangeBar'>\
					</div>\
					<div class='sliderPointStart' style='left: 0px'>\
						<div class='startValueArrow'></div>\
						<div class='startValue'></div>\
					</div>\
					<div class='sliderPointEnd' style='left: 150px'>\
						<div class='endValueArrow'></div>\
						<div class='endValue'></div>\
					</div>\
				</div>\
			</div>";
                    parentElement.innerHTML = sliderTemplate;
                    this.startValueChanged = new Resco.Event(this);
                    this.endValueChanged = new Resco.Event(this);
                    this.sliderHtmlElement = parentElement.getElementsByClassName("slider")[0];
                    this.m_sliderRangeElement = this.sliderHtmlElement.getElementsByClassName("sliderRangeBar")[0];
                    this.m_sliderPointStart = this.sliderHtmlElement.getElementsByClassName("sliderPointStart")[0];
                    this.m_sliderPointEnd = this.sliderHtmlElement.getElementsByClassName("sliderPointEnd")[0];
                    this._initReleasePoints();
                    this._setStartValue(this._positionToValue(this._valueToPosition(startValue)));
                    this._setEndValue(this._positionToValue(this._valueToPosition(endValue)));
                    if (!isDisabled) {
                        this._addEventListeners();
                    }
                }
                Slider.prototype._initReleasePoints = function () {
                    this.m_validPositions = new Array();
                    var sliderBar = this.sliderHtmlElement.getElementsByClassName("sliderBar")[0];
                    this.m_sliderBarWidth = sliderBar.getBoundingClientRect().width;
                    var scale = this.m_sliderBarWidth / (this.m_itemsCount - 1);
                    for (var i = 0; i < this.m_itemsCount; i++) {
                        this.m_validPositions.push(Math.round(i * scale));
                    }
                };
                Slider.prototype._addEventListeners = function () {
                    this._addMoveEventsToStartSliderPoint();
                    this._addMoveEventsToEndSliderPoint();
                };
                Slider.prototype._addMoveEventsToStartSliderPoint = function () {
                    this._gestureManager.onDownMoveUpCancel($(this.m_sliderPointStart), this._onPointerDownStart, this._onPointerMoveStart, this._onPointerUpStart, this._onPointerUpStart);
                };
                Slider.prototype._addMoveEventsToEndSliderPoint = function () {
                    this._gestureManager.onDownMoveUpCancel($(this.m_sliderPointEnd), this._onPointerDownEnd, this._onPointerMoveEnd, this._onPointerUpEnd, this._onPointerUpEnd);
                };
                Slider.prototype._setCorrectZindex = function (sliderPoint, zindex) {
                    sliderPoint.style.zIndex = zindex.toString();
                };
                Slider.prototype._setStartValue = function (value) {
                    if (0 <= value && value < this.m_validPositions.length) {
                        this._startPosition = this._valueToPosition(value);
                        this._startSiblingValue = value;
                        this.m_sliderRangeElement.style.left = this._startPosition + "px";
                        this.m_sliderPointStart.style.left = (this._startPosition - 10) + "px"; // 10px width
                        this.m_sliderPointStart.getElementsByClassName("startValue")[0].textContent = this._valueToHourFormat(value);
                    }
                };
                Slider.prototype._setEndValue = function (value) {
                    if (0 <= value && value < this.m_validPositions.length) {
                        this._endPosition = this._valueToPosition(value);
                        this._endSiblingValue = value;
                        this.m_sliderRangeElement.style.right = (this.m_sliderBarWidth - this._endPosition) + "px";
                        this.m_sliderPointEnd.style.left = (this._endPosition - 10) + "px"; // 10px width
                        this.m_sliderPointEnd.getElementsByClassName("endValue")[0].textContent = this._valueToHourFormat(value);
                    }
                };
                Slider.prototype._valueToHourFormat = function (value) {
                    var date = new Date();
                    date.setHours(value, 0, 0, 0);
                    var options = { hour: "2-digit", minute: "2-digit" };
                    return this._toLocaleTimeString(date, [], options);
                };
                // backup for iOS8 and iOS9 where date.toLocaleTimeString() method ignore options argument
                Slider.prototype._toLocaleTimeString = function (date, locales, options) {
                    var localeTimeString = date.toLocaleTimeString([], options);
                    var localeTimeString2 = date.toLocaleTimeString([]);
                    if (localeTimeString === localeTimeString2) {
                        var parts = localeTimeString.split(" ");
                        if (parts && parts.length > 0) {
                            var ampm = "";
                            for (var i = 0; i < parts.length; i++) {
                                var part = parts[i];
                                if ((part.indexOf("AM") !== -1) || (part.indexOf("am") !== -1)) {
                                    ampm = "AM";
                                    break;
                                }
                                else if ((part.indexOf("PM") !== -1) || (part.indexOf("pm") !== -1)) {
                                    ampm = "PM";
                                    break;
                                }
                            }
                            var hours = date.getHours();
                            var timeString = void 0;
                            if (ampm !== "") {
                                hours %= 12;
                                if (hours === 0)
                                    hours = 12;
                                timeString = hours.toString() + ":00";
                                timeString += " " + ampm;
                            }
                            else {
                                timeString = hours.toString() + ":00";
                            }
                            localeTimeString = timeString;
                        }
                    }
                    return localeTimeString;
                };
                Slider.prototype._valueToPosition = function (value) {
                    return this.m_validPositions[Math.floor(value)];
                };
                Slider.prototype._positionToValue = function (position) {
                    var oldPos = this.m_validPositions[0];
                    if (position <= oldPos) {
                        return 0;
                    }
                    for (var i = 1; i < this.m_validPositions.length; i++) {
                        var pos = this.m_validPositions[i];
                        var midPos = oldPos + Math.round((pos - oldPos) / 2);
                        if (position < midPos) {
                            return i - 1;
                        }
                        oldPos = pos;
                    }
                    return this.m_validPositions.length - 1;
                };
                return Slider;
            }());
            Scheduler.Slider = Slider;
            var AdvancedListEx = (function () {
                function AdvancedListEx() {
                }
                /**
                 * Returns mouse/touch point position relative to the list control root element in pixels.
                 * @param listControl - the list control where to find for item index.
                 * @param absolutePoint - mouse/touch point absolute position in the document element in pixels.
                 */
                AdvancedListEx.getRelativePoint = function (listControl, absolutePoint) {
                    var listControlElementOffset = listControl.htmlRoot.offset();
                    return { x: absolutePoint.x - listControlElementOffset.left, y: absolutePoint.y - listControlElementOffset.top };
                };
                AdvancedListEx.getItemBounds = function (listControl, item) {
                    var listControlElementOffset = listControl.htmlRoot.offset();
                    var itemElement = item.$root;
                    var itemElementOffset = itemElement.offset();
                    var itemX = itemElementOffset.left - listControlElementOffset.left;
                    var itemY = itemElementOffset.top - listControlElementOffset.top;
                    var itemWidth = itemElement.outerWidth(true);
                    var itemHeight = itemElement.outerHeight(true);
                    return { x: itemX, y: itemY, width: itemWidth, height: itemHeight };
                };
                /**
                 * Returns true if selected item is drawn under the point or false if not.
                 * @param listControl - the list control where to find for item index.
                 * @param point - mouse/touch point position relative to the list control root element in pixels.
                 */
                AdvancedListEx.isSelectedItemAtPoint = function (listControl, point) {
                    if ((0 <= listControl.selectedIndex) && (listControl.selectedIndex < listControl.rows.length)) {
                        var itemBounds = AdvancedListEx.getItemBounds(listControl, listControl.rows[listControl.selectedIndex]);
                        if ((itemBounds.x <= point.x) && (point.x < (itemBounds.x + itemBounds.width))) {
                            if ((itemBounds.y <= point.y) && (point.y < (itemBounds.y + itemBounds.height))) {
                                return true;
                            }
                        }
                    }
                    return false;
                };
                /**
                 * Returns index of the item that is drawn under the point, or -1 if there is not item present.
                 * @param listControl - the list control where to find for item index.
                 * @param point - mouse/touch point position relative to the list control root element in pixels.
                 */
                AdvancedListEx.getItemIndexAtPoint = function (listControl, point) {
                    var listControlElementOffset = listControl.htmlRoot.offset();
                    for (var i = 0; i < listControl.rows.length; i++) {
                        var itemBounds = AdvancedListEx.getItemBounds(listControl, listControl.rows[i]);
                        if ((itemBounds.x <= point.x) && (point.x < (itemBounds.x + itemBounds.width))) {
                            if ((itemBounds.y <= point.y) && (point.y < (itemBounds.y + itemBounds.height))) {
                                return i;
                            }
                        }
                    }
                    return -1;
                };
                /**
                 * Returns array of T objects based on list rows, where convert method is used to transform individual row to the T object.
                 * @param listControl - the list control where to find for row.
                 * @param convert - method that will be used to transform row to the T object.
                 */
                AdvancedListEx.getTObjectFromLoadedRows = function (listControl, convert) {
                    var objects = [];
                    if (listControl && listControl.rows) {
                        for (var i = 0; i < listControl.rows.length; i++) {
                            objects.push(convert(listControl.rows[i]));
                        }
                    }
                    return objects;
                };
                return AdvancedListEx;
            }());
            Scheduler.AdvancedListEx = AdvancedListEx;
            /**
             * Extends Promise class functionality.
             */
            var PromiseEx = (function () {
                function PromiseEx() {
                }
                /**
                 * Creates a Promise that is resolved with an array of results when all of the provided Promises
                 * resolve (or iterable values argument contains no promises), or rejected with an array of reasons, when any Promise is rejected.
                 * @param values An array of Promises.
                 * @returns A new Promise.
                 */
                PromiseEx.allEx = function (values) {
                    return __awaiter(this, void 0, void 0, function () {
                        var executor, promise;
                        return __generator(this, function (_a) {
                            PromiseEx._promisesCount = values ? values.length : 0;
                            PromiseEx._fulfilledList = [];
                            PromiseEx._rejectedList = [];
                            executor = function (resolve, reject) {
                                PromiseEx._resolve = resolve;
                                PromiseEx._reject = reject;
                                if (values && (values.length > 0)) {
                                    for (var i = 0; i < values.length; i++) {
                                        var value = values[i];
                                        value.then(PromiseEx._onfulfilled);
                                        value.catch(PromiseEx._onrejected);
                                    }
                                }
                                else {
                                    PromiseEx._onFinished();
                                }
                            };
                            promise = new Promise(executor);
                            return [2 /*return*/, promise];
                        });
                    });
                };
                PromiseEx._onfulfilled = function (value) {
                    PromiseEx._fulfilledList.push(value);
                    PromiseEx._onFinished();
                };
                PromiseEx._onrejected = function (reason) {
                    PromiseEx._rejectedList.push(reason);
                    PromiseEx._onFinished();
                };
                PromiseEx._onFinished = function () {
                    if ((PromiseEx._fulfilledList.length + PromiseEx._rejectedList.length) === PromiseEx._promisesCount) {
                        if (PromiseEx._rejectedList.length > 0) {
                            PromiseEx._reject(PromiseEx._rejectedList);
                        }
                        else {
                            PromiseEx._resolve(PromiseEx._fulfilledList);
                        }
                        // release references stored in static fields to allow GC reclaim resources
                        PromiseEx._fulfilledList = [];
                        PromiseEx._rejectedList = [];
                        PromiseEx._resolve = undefined;
                        PromiseEx._reject = undefined;
                    }
                };
                return PromiseEx;
            }());
            PromiseEx._fulfilledList = [];
            PromiseEx._rejectedList = [];
            Scheduler.PromiseEx = PromiseEx;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
