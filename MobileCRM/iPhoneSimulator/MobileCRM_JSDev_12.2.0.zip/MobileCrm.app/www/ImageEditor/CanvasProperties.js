var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var CanvasImageProperties = /** @class */ (function () {
            function CanvasImageProperties(canvas) {
                this.canvas = canvas;
                this.imageWidth = 0;
                this.imageHeight = 0;
                this.viewImageWidth = 0;
                this.viewImageHeight = 0;
                this.viewWidth = 0;
                this.viewHeight = 0;
                this.scale = 1;
                this.rotation = 0;
                this.imagePath = null;
                this.isFormDirty = false;
                this.mimeType = null;
            }
            Object.defineProperty(CanvasImageProperties.prototype, "ImageWidth", {
                get: function () {
                    if (this.DimensionsFlipped)
                        return this.imageHeight;
                    return this.imageWidth;
                },
                set: function (value) {
                    this.imageWidth = value;
                    this.recalculateSizes();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "ImageHeight", {
                get: function () {
                    if (this.DimensionsFlipped)
                        return this.imageWidth;
                    return this.imageHeight;
                },
                set: function (value) {
                    this.imageHeight = value;
                    this.recalculateSizes();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "ViewWidth", {
                get: function () {
                    return this.viewWidth;
                },
                set: function (value) {
                    this.viewWidth = value;
                    this.recalculateSizes();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "ViewHeight", {
                get: function () {
                    return this.viewHeight;
                },
                set: function (value) {
                    this.viewHeight = value;
                    this.recalculateSizes();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "ImageRatio", {
                get: function () {
                    return this.imageWidth / this.viewImageWidth;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "ViewImageHeight", {
                get: function () {
                    return this.viewImageHeight;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "ViewImageWidth", {
                get: function () {
                    return this.viewImageWidth;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "DimensionsFlipped", {
                get: function () {
                    return this.rotation === 90 || this.rotation === 270;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "Scale", {
                get: function () {
                    return this.scale;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "ImagePath", {
                get: function () {
                    return this.imagePath;
                },
                set: function (value) {
                    this.imagePath = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasImageProperties.prototype, "IsFormDirty", {
                get: function () {
                    return this.isFormDirty;
                },
                enumerable: true,
                configurable: true
            });
            CanvasImageProperties.prototype.MakeFormDirty = function () {
                if (typeof MobileCRM !== 'undefined')
                    MobileCRM.bridge.command("makeEntityDirty", "", null, null, null);
                this.isFormDirty = true;
            };
            Object.defineProperty(CanvasImageProperties.prototype, "MimeType", {
                get: function () {
                    return this.mimeType;
                },
                set: function (value) {
                    this.mimeType = value;
                },
                enumerable: true,
                configurable: true
            });
            CanvasImageProperties.prototype.ApplyZoom = function (scale) {
                this.scale = scale;
                this.recalculateSizes();
            };
            Object.defineProperty(CanvasImageProperties.prototype, "Rotation", {
                get: function () {
                    return this.rotation;
                },
                set: function (value) {
                    value = value % 360;
                    this.rotation = value;
                },
                enumerable: true,
                configurable: true
            });
            CanvasImageProperties.prototype.recalculateSizes = function () {
                if (!this.imageWidth
                    || !this.imageHeight
                    || !this.viewWidth
                    || !this.viewHeight)
                    return;
                var ratio = 1;
                if (this.imageWidth > this.imageHeight) {
                    ratio = this.viewWidth / this.imageWidth;
                    this.viewImageWidth = this.imageWidth * ratio;
                    this.viewImageHeight = this.imageHeight * ratio;
                    if (this.viewImageHeight > this.viewHeight) {
                        ratio = this.viewHeight / this.imageHeight;
                        this.viewImageWidth = this.imageWidth * ratio;
                        this.viewImageHeight = this.imageHeight * ratio;
                    }
                }
                else {
                    ratio = this.viewHeight / this.imageHeight;
                    this.viewImageWidth = this.imageWidth * ratio;
                    this.viewImageHeight = this.imageHeight * ratio;
                    if (this.viewImageWidth > this.viewWidth) {
                        ratio = this.viewWidth / this.imageWidth;
                        this.viewImageWidth = this.imageWidth * ratio;
                        this.viewImageHeight = this.imageHeight * ratio;
                    }
                }
                this.viewImageWidth = Math.ceil(this.ViewImageWidth * this.scale);
                this.viewImageHeight = Math.ceil(this.ViewImageHeight * this.scale);
                if (this.DimensionsFlipped) {
                    this.canvas.width = this.viewImageHeight;
                    this.canvas.height = this.viewImageWidth;
                }
                else {
                    this.canvas.width = this.viewImageWidth;
                    this.canvas.height = this.viewImageHeight;
                }
            };
            return CanvasImageProperties;
        }());
        ImageEditor.CanvasImageProperties = CanvasImageProperties;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=CanvasProperties.js.map