///<reference path="../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../Controls/advancedList-1.0.3.ts" />
///<reference path="../Controllers/controllerFactory.ts" />
///<reference path="../Controllers/dynamicEntityList.ts" />
///<reference path="../Helpers/common.ts" />
///<reference path="../Data/metaEntity.ts" />
///<reference path="../Data/dataImageCache.ts" />
///<reference path="../Controls/filterGroup.ts" />
///<reference path="../Controls/Scheduler/container.ts" />
///<reference path="WorkOrders/workOrderPlanner.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var DefaultContainer = (function (_super) {
                __extends(DefaultContainer, _super);
                function DefaultContainer(dataSource) {
                    var _this = this;
                    var constants = new Scheduler.Constants();
                    constants.viewSplitOvertimeTasks = false; //Only WorkOrder Scheduler supports split of overtime tasks
                    _this = _super.call(this, "planner", "../Controls/Scheduler/res/", dataSource, new Scheduler.DataProvider(dataSource), constants) || this;
                    return _this;
                }
                DefaultContainer.create = function (onCreated) {
                    Scheduler.defineMissingProperties();
                    MobileCRM.bridge.command("getConfig", null, function (configData) {
                        DefaultContainer._initialize(configData, onCreated);
                    }, function (error) {
                        Scheduler.StringTable.alert(error);
                        DefaultContainer._initialize(undefined, onCreated);
                    }, this);
                };
                DefaultContainer._initialize = function (inputData, onInitialized) {
                    if (inputData && inputData.scheduledTasks && inputData.scheduledTasks.entityName != "fs_workorderschedule") {
                        // inputData = undefined; 
                        onInitialized(new DefaultContainer(inputData));
                    }
                    else {
                        var isDefaultConfigData_1 = false;
                        if (!inputData) {
                            inputData = new Scheduler.ConfigData();
                            isDefaultConfigData_1 = true;
                        }
                        inputData = Scheduler.WorkOrderPlanner.modifyDataSource(inputData);
                        //inputData = undefined;
                        if (!inputData)
                            onInitialized(new Scheduler.WorkOrderPlanner(inputData, isDefaultConfigData_1));
                        else {
                            Scheduler.ConfigData.Validate(inputData, function (error) {
                                if (error)
                                    onInitialized(undefined);
                                else
                                    onInitialized(new Scheduler.WorkOrderPlanner(inputData, isDefaultConfigData_1));
                            });
                        }
                    }
                };
                return DefaultContainer;
            }(Scheduler.Container));
            Scheduler.DefaultContainer = DefaultContainer;
            var TimeOffEntity = (function () {
                function TimeOffEntity() {
                }
                TimeOffEntity.reasonTypeToReason = function (reasonValue) {
                    if (reasonValue === 1)
                        return Scheduler.StringTable.get("Msg.PersonalVacation") || "Personal vacation";
                    else if (reasonValue === 2)
                        return Scheduler.StringTable.get("Msg.SickLeave") || "Sick Leave";
                    else if (reasonValue === 3)
                        return Scheduler.StringTable.get("Msg.MaternityPaternityLeave") || "Maternity paternity leave";
                    else if (reasonValue === 4)
                        return Scheduler.StringTable.get("Msg.CompassionateLeave") || "Compassionate leave";
                    else
                        return Scheduler.StringTable.get("Msg.Unknown") || "Unknown";
                };
                TimeOffEntity.load = function (resources, timeRange, onFinishCallback) {
                    if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.TimeOff) && (resources.length > 0)) {
                        //let startTime: Performance = new Performance();
                        if (!TimeOffEntity.timeOffInput) {
                            TimeOffEntity.timeOffInput = new Scheduler.ScheduledDataInput();
                            TimeOffEntity.timeOffInput.canWrite = false;
                            TimeOffEntity.timeOffInput.entityName = "fs_time_off";
                            TimeOffEntity.timeOffInput.primaryKeyName = "id";
                            TimeOffEntity.timeOffInput.primaryKeyName = "name";
                            TimeOffEntity.timeOffInput.attrScheduledStart = "from";
                            TimeOffEntity.timeOffInput.attrScheduledEnd = "to";
                            TimeOffEntity.timeOffInput.attrResourceRef = "ownerid";
                        }
                        var input_1 = TimeOffEntity.timeOffInput;
                        var entity = new MobileCRM.FetchXml.Entity(input_1.entityName);
                        entity.attributes = TimeOffEntity._attributes;
                        var filters = [];
                        var resourceIds = resources.map(function (i) { return i.getID(); });
                        if (resourceIds && (resourceIds.length > 0)) {
                            var resourceFilter = new MobileCRM.FetchXml.Filter();
                            resourceFilter.isIn(input_1.attrResourceRef, resourceIds);
                            filters.push(resourceFilter);
                        }
                        var startDate = new Date(timeRange.start);
                        var endDate = new Date(timeRange.end);
                        var timeFilter = new MobileCRM.FetchXml.Filter();
                        timeFilter.where(input_1.attrScheduledEnd, "ge", startDate);
                        timeFilter.where(input_1.attrScheduledStart, "lt", endDate);
                        filters.push(timeFilter);
                        entity.addFilter().filters = filters;
                        entity.orderBy(input_1.attrResourceRef, false);
                        var fetch_1 = new Scheduler.MultipageFetch();
                        fetch_1.execute(entity, function (entityResult) {
                            var lastResurce = undefined;
                            for (var i = 0; i < entityResult.length; i++) {
                                var prop = entityResult[i].properties;
                                if (!prop.from || !prop.to)
                                    continue;
                                if (!lastResurce || (lastResurce.getID() !== prop.ownerid.id)) {
                                    var resource = TimeOffEntity.findResource(resources, prop.ownerid.id);
                                    if (!resource)
                                        continue;
                                    lastResurce = resource;
                                }
                                var task = TimeOffEntity._entityToTask(input_1, prop);
                                if (task && timeRange.contain(new Scheduler.TimeRange(task.getWorkStart(), task.getWorkStart() + task.getTotalWorkTime())))
                                    lastResurce.addTask(task);
                            }
                            onFinishCallback();
                        });
                    }
                    else
                        onFinishCallback();
                };
                TimeOffEntity.findResource = function (resources, id) {
                    for (var i = 0; i < resources.length; i++) {
                        if (resources[i].getID() === id)
                            return resources[i];
                    }
                    return null;
                };
                TimeOffEntity._entityToTask = function (inputData, prop) {
                    if (!prop.from || !prop.to)
                        return null;
                    var reason = TimeOffEntity.reasonTypeToReason(+prop.type);
                    var task = new Scheduler.Task(inputData, prop.id, reason, new Date(prop.from).valueOf(), new Date(prop.to).valueOf());
                    task.setStatus(Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.TimeOff]);
                    return task;
                };
                return TimeOffEntity;
            }());
            TimeOffEntity._attributes = [
                new MobileCRM.FetchXml.Attribute("ownerid"),
                new MobileCRM.FetchXml.Attribute("id"),
                new MobileCRM.FetchXml.Attribute("from"),
                new MobileCRM.FetchXml.Attribute("to"),
                new MobileCRM.FetchXml.Attribute("type") //4
            ];
            Scheduler.TimeOffEntity = TimeOffEntity;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
