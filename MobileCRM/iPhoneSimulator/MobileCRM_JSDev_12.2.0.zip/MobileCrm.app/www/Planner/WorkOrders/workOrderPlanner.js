///<reference path="../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../Controls/advancedList-1.0.3.ts" />
///<reference path="../../Controllers/controllerFactory.ts" />
///<reference path="../../Controllers/dynamicEntityList.ts" />
///<reference path="../../Helpers/common.ts" />
///<reference path="../../Data/metaEntity.ts" />
///<reference path="../../Data/dataImageCache.ts" />
///<reference path="../../Controls/filterGroup.ts" />
///<reference path="../../Controls/Scheduler/container.ts" />
///<reference path="../../Controls/Scheduler/statusCodeTable.ts" />
///<reference path="../../Controls/Scheduler/dialogs/taskPropertyDlg.ts" />
///<reference path="workOrderDataProvider.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var WorkOrderPlanner = (function (_super) {
                __extends(WorkOrderPlanner, _super);
                function WorkOrderPlanner(inputData, isDefaultConfigData) {
                    var _this = this;
                    if (inputData && !inputData.resources)
                        Scheduler.StringTable.alert("Empty Resource");
                    _this = _super.call(this, "planner", "../Controls/Scheduler/res/", inputData, new Scheduler.WorkOrderDataProvider(inputData), new Scheduler.Constants()) || this;
                    if (isDefaultConfigData)
                        _this._useTaskTemplateContent = false;
                    return _this;
                }
                WorkOrderPlanner.modifyDataSource = function (dataSource) {
                    if (!dataSource.resources) {
                        var input = new Scheduler.ResourceDataInput();
                        input.entityViews = "fs_resource.*:fs_resource.@Resources";
                        input.entityName = "fs_resource";
                        input.imagePlaceholder = "Home.fs_resource.png";
                        input.imageQuery = "annotation;documentbody;subject;ListImage;objectid;{id}|Home.fs_resource.png";
                        dataSource.resources = input;
                    }
                    else if (dataSource.resources.entityName = "fs_resource") {
                        dataSource.resources.imagePlaceholder = "Home.fs_resource.png";
                        dataSource.resources.imageQuery = "annotation;documentbody;subject;ListImage;objectid;{id}|Home.fs_resource.png";
                    }
                    if (!dataSource.resources.filterLinks) {
                        dataSource.resources.filterLinks = {};
                        dataSource.resources.filterLinks["Territories"] = new Scheduler.LinkedData("territoryid", "fs_resourceterritory", "resourceid", "id", "inner");
                        dataSource.resources.filterLinks["Skills"] = new Scheduler.LinkedData("skillid", "fs_resourceskill", "resourceid", "id", "inner");
                    }
                    // Unscheduled
                    if (!dataSource.unscheduledTasks) {
                        var input = new Scheduler.UnscheduledDataInput();
                        input.entityViews = null;
                        input.entityName = "fs_workorder";
                        input.attrEstimatedDuration = "estimatedduration";
                        input.attrProgress = "completionpercent";
                        input.attrTerritoryRef = "territoryid";
                        input.linkAddress = new Scheduler.AddressAttributes("account", "id", "customerid", "outer");
                        dataSource.unscheduledTasks = input;
                    }
                    else if (dataSource.unscheduledTasks.entityName == "fs_workorder") {
                        if (!dataSource.unscheduledTasks.attrEstimatedDuration)
                            dataSource.unscheduledTasks.attrEstimatedDuration = "estimatedduration";
                        if (!dataSource.unscheduledTasks.attrProgress)
                            dataSource.unscheduledTasks.attrProgress = "completionpercent";
                        if (!dataSource.unscheduledTasks.linkAddress)
                            dataSource.unscheduledTasks.linkAddress = new Scheduler.AddressAttributes("account", "id", "customerid", "outer");
                        if (!dataSource.unscheduledTasks.attrTerritoryRef)
                            dataSource.unscheduledTasks.attrTerritoryRef = "territoryid";
                    }
                    //dataSource.unscheduledTasks.filterLinks = null;
                    if (!dataSource.unscheduledTasks.filterLinks) {
                        var territoryRef = dataSource.unscheduledTasks.attrTerritoryRef;
                        dataSource.unscheduledTasks.filterLinks = {};
                        dataSource.unscheduledTasks.filterLinks["Territories"] = new Scheduler.LinkedData(territoryRef ? territoryRef : "territoryid", undefined, undefined, undefined);
                        dataSource.unscheduledTasks.filterLinks["Skills"] = new Scheduler.LinkedData("skillid", "fs_workorderskill", "workorderid", "id", "inner");
                    }
                    // Tasks
                    if (!dataSource.scheduledTasks) {
                        var input = new Scheduler.ScheduledDataInput();
                        input.entityName = "fs_workorderschedule";
                        input.attrStatus = "statuscode";
                        input.attrScheduledStart = "scheduledstart";
                        input.attrScheduledEnd = "scheduledend";
                        input.attrWindowStart = "windowstart";
                        input.attrWindowEnd = "windowend";
                        input.attrResourceRef = "resourceid";
                        input.attrSourceRef = "workorderid";
                        input.attrArrivedOn = "arrivedon";
                        input.attrStartedOn = "startedon";
                        input.attrEndedOn = "endedon";
                        input.attrTravelFrom = "scheduledtravelfrom";
                        input.attrTravelTo = "scheduledtravelto";
                        input.attrTravelMode = "travelmode";
                        input.attrWorkduration = "workduration";
                        input.linkLocationRef = "customerid";
                        input.linkTerritoryRef = "territoryid";
                        input.linkProgress = "completionpercent";
                        input.crmFormTabRef = "scheduleid";
                        dataSource.scheduledTasks = input;
                    }
                    if ((dataSource.scheduledTasks.entityName === "fs_workorderschedule") && !dataSource.scheduledTasks.crmFormTabRef) {
                        dataSource.scheduledTasks.crmFormTabRef = "scheduleid";
                    }
                    if (!dataSource.timeOffSchedules) {
                        var input = new Scheduler.TimeOffsDataInput();
                        input.canWrite = false;
                        input.entityName = "fs_time_off";
                        input.attrScheduledStart = "from";
                        input.attrScheduledEnd = "to";
                        input.attrResourceRef = "resourceid";
                        input.color = "rgba(163,164,165,0.8)";
                        dataSource.timeOffSchedules = input;
                    }
                    if (!dataSource.statusList || !dataSource.statusList.length) {
                        var statusList = [];
                        statusList.push(new Scheduler.TaskStatusCode(1, "Planned", "Scheduler.WOS.statuscode.1", Scheduler.TaskStatusType.Scheduled, "rgb(39,196,105)"));
                        statusList.push(new Scheduler.TaskStatusCode(2, "Traveling", "Scheduler.WOS.statuscode.2", Scheduler.TaskStatusType.Confirmed, "rgb(72,151,230)", "rgb(26,188,156)", true));
                        statusList.push(new Scheduler.TaskStatusCode(3, "Arrived", "Scheduler.WOS.statuscode.3", Scheduler.TaskStatusType.Confirmed, "rgb(163,203,242)", "rgb(72,151,230)", true));
                        statusList.push(new Scheduler.TaskStatusCode(4, "Working", "Scheduler.WOS.statuscode.4", Scheduler.TaskStatusType.Confirmed, "rgb(72,151,230)", "rgba(72,151,230,0.5)"));
                        statusList.push(new Scheduler.TaskStatusCode(5, "OnBreak", "Scheduler.WOS.statuscode.5", Scheduler.TaskStatusType.CoffeeBreak, "rgb(201,224,248)"));
                        statusList.push(new Scheduler.TaskStatusCode(6, "Completed", "Scheduler.WOS.statuscode.6", Scheduler.TaskStatusType.Completed, "rgb(255,196,0)", "rgba(113,183,230,0.5)"));
                        statusList.push(new Scheduler.TaskStatusCode(7, "Canceled", "Scheduler.WOS.statuscode.7", Scheduler.TaskStatusType.Canceled, "rgb(242,201,201)"));
                        statusList.push(new Scheduler.TaskStatusCode(8, "AutoScheduled", "Scheduler.WOS.statuscode.8", Scheduler.TaskStatusType.AutoScheduled, "rgb(39,196,105)"));
                        statusList.push(new Scheduler.TaskStatusCode(9, "Locked", "Scheduler.WOS.statuscode.9", Scheduler.TaskStatusType.ScheduledAndLocked, "rgb(39,196,105)"));
                        //statusList.push(new TaskStatusCode(8, "TimeOff", "Scheduler.WOS.statuscode.5", TaskStatusType.TimeOff, "rgb(144,144,144)"));
                        dataSource.statusList = statusList;
                    }
                    if (!dataSource.filterList) {
                        var filterList = [];
                        filterList.push(new Scheduler.FilterDataSource("Skills", "Scheduler.Msg.SKILLS", "Scheduler.Msg.FilteredBySkills", "<fetch><entity name='fs_skill'><attribute name='id'/><attribute name='name'/>" +
                            "<filter type='and'><condition attribute='statecode' operator='eq' value='0' /></filter>" +
                            "<order attribute='name' descending= 'true'/>" +
                            "</entity></fetch>"));
                        filterList.push(new Scheduler.FilterDataSource("Territories", "Scheduler.Msg.TERRITORIES", "Scheduler.Msg.FilteredByTerritories", "<fetch><entity name='fs_territory'><attribute name='id'/><attribute name='name'/>" +
                            "<filter type='and'><condition attribute='statecode' operator='eq' value='0' /></filter>" +
                            "<order attribute='name' descending= 'true'/>" +
                            "</entity></fetch>"));
                        dataSource.filterList = filterList;
                    }
                    return dataSource;
                };
                WorkOrderPlanner.prototype.onInitialized = function (error, officeData) {
                    _super.prototype.onInitialized.call(this, error, officeData);
                    this._constants.viewSplitOvertimeTasks = (this._inputData && this._inputData.scheduledTasks.attrWorkduration) ? true : false;
                };
                return WorkOrderPlanner;
            }(Scheduler.Container));
            Scheduler.WorkOrderPlanner = WorkOrderPlanner;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
