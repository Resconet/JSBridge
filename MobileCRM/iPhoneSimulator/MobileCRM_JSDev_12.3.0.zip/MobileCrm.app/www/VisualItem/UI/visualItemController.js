var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var VisualItem;
(function (VisualItem) {
    var UI;
    (function (UI) {
        var VisualItemController = /** @class */ (function () {
            function VisualItemController() {
                this.size = new Resco.Size(0, 0);
                this.imageSize = new Resco.Size(0, 0);
                this.containerPosition = new Resco.Position(0, 0);
                this.containerSize = new Resco.Size(0, 0);
                this.imageDataB64 = ko.observable();
                this.isDropActive = ko.observable(false);
                this.answers = ko.observableArray();
                this.itemList = new UI.ItemList(this);
                this.dropBin = new DropBin(this);
                this.allowCapturePhoto = ko.observable(false);
                this.allowPickImage = ko.observable(false);
                this.readOnly = ko.observable(true);
            }
            VisualItemController.prototype.load = function (cfg) {
                return __awaiter(this, void 0, void 0, function () {
                    var groupTemplates, itemPositions, groupsCfg, index, dropGroup, groupItem, grTemplate, data, groupCfg, itemPosition;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                groupTemplates = new Resco.Dictionary();
                                itemPositions = [];
                                this.question = cfg.visualQuestion;
                                if (this.question.properties.resco_value)
                                    itemPositions = JSON.parse(this.question.properties.resco_value);
                                this.readOnly(cfg.readOnly);
                                this.allowCapturePhoto(cfg.docActions && (cfg.docActions & 2) > 0);
                                this.allowPickImage(cfg.docActions && (cfg.docActions & 4) > 0);
                                if (cfg.droppableGroupsConfig)
                                    groupsCfg = JSON.parse(cfg.droppableGroupsConfig);
                                for (index = 0; index < cfg.droppableGroups.length; index++) {
                                    dropGroup = cfg.droppableGroups[index];
                                    groupItem = new VisualItem.Data.GroupItem(dropGroup, this.readOnly(), cfg.displayNames[index]);
                                    grTemplate = groupTemplates.getValue(groupItem.templateId);
                                    if (!grTemplate) {
                                        data = new MobileCRM.DynamicEntity("resco_questiongroup", groupItem.templateId, groupItem.templatePrimaryName);
                                        data.properties.resco_label = groupItem.name;
                                        data.properties.resco_repeatconfig = dropGroup.properties.resco_repeatconfig;
                                        grTemplate = new VisualItem.Data.GroupTemplateItem(data, cfg.groupIcons[groupItem.templatePrimaryName], this.readOnly());
                                        groupTemplates.set(grTemplate.id, grTemplate);
                                    }
                                    groupItem.groupTemplate = grTemplate;
                                    groupCfg = groupsCfg.firstOrDefault(function (item) { return item.name === grTemplate.primaryName; });
                                    if (groupCfg) {
                                        grTemplate.required = groupCfg.required;
                                        grTemplate.color = groupCfg.color;
                                    }
                                    if (groupItem.groupTemplate.repeatable) {
                                        // Check if there is already a item for 'repeating' the group, if not, add one to the item list
                                        this._updateRepeatableGroupItem(groupItem);
                                    }
                                    itemPosition = itemPositions.firstOrDefault(function (ip) { return ip.id === groupItem.id; });
                                    if (itemPosition && "x" in itemPosition) {
                                        groupItem.position.left(itemPosition.x);
                                        groupItem.position.top(itemPosition.y);
                                        this.addAnswer(groupItem);
                                    }
                                    else {
                                        this.itemList.addItem(groupItem);
                                    }
                                }
                                if (!(!cfg.image && !this.readOnly())) return [3 /*break*/, 1];
                                if ((cfg.defaultAction & 4) > 0)
                                    this.pickImage();
                                else
                                    this.capturePhoto();
                                return [3 /*break*/, 3];
                            case 1: return [4 /*yield*/, this._setImageSource(cfg.image)];
                            case 2:
                                _a.sent();
                                _a.label = 3;
                            case 3: return [2 /*return*/];
                        }
                    });
                });
            };
            VisualItemController.prototype.save = function () {
                var result = "";
                if (this.m_imageName && this.m_imageData)
                    result += this.m_imageName + ":" + (this.m_imageData) + ";";
                var serializedPositions = "";
                for (var _i = 0, _a = this.answers(); _i < _a.length; _i++) {
                    var answer = _a[_i];
                    serializedPositions += "{\"id\": \"" + answer.id + "\", \"name\": \"" + answer.primaryName + "\", \"x\": " + answer.position.left() + ", \"y\": " + answer.position.top() + "},";
                }
                if (serializedPositions)
                    result += "[" + serializedPositions.substr(0, serializedPositions.length - 1) + "]";
                return result;
            };
            VisualItemController.prototype.updateDisplayName = function (grId, newDisplayName) {
                var gr = this.answers().firstOrDefault(function (a) { return a.id === grId; });
                if (!gr)
                    gr = this.itemList.items().firstOrDefault(function (i) { return i.id === grId; });
                if (gr)
                    gr.displayName(newDisplayName);
            };
            VisualItemController.prototype.canDrop = function () {
                return true;
            };
            VisualItemController.prototype.drop = function (draggedItem, l, t) {
                var _this = this;
                var answRatio = this.containerSize.width() / this.imageSize.width();
                if (draggedItem instanceof VisualItem.Data.GroupTemplateItem) {
                    // TODO: show please wait
                    if (MobileCRM.bridge) {
                        MobileCRM.bridge.command("initNewGroup", draggedItem.id, function (data) {
                            var newGroup = new VisualItem.Data.GroupItem(data, false);
                            newGroup.groupTemplate = draggedItem;
                            _this.addAnswer(newGroup);
                            newGroup.ratio(answRatio);
                            newGroup.position.left(Math.floor(l / answRatio));
                            newGroup.position.top(Math.floor(t / answRatio));
                        }, MobileCRM.bridge.alert);
                    }
                    else {
                        var newGroup = new VisualItem.Data.GroupItem(new MobileCRM.DynamicEntity("resco_questiongroup", "1234", "", { resco_templategroupid: draggedItem.id }), false);
                        newGroup.groupTemplate = draggedItem;
                        this.addAnswer(newGroup);
                        newGroup.ratio(answRatio);
                        newGroup.position.left(Math.floor(l / answRatio));
                        newGroup.position.top(Math.floor(t / answRatio));
                    }
                    return;
                }
                var answerItem = draggedItem;
                answerItem.ratio(answRatio);
                answerItem.position.left(Math.floor(l / answRatio));
                answerItem.position.top(Math.floor(t / answRatio));
                if (this.answers().indexOf(answerItem) < 0)
                    this.addAnswer(answerItem);
            };
            VisualItemController.prototype.addAnswer = function (ans) {
                ans.dragStopped.add(this, this._answerDragStopped);
                this.answers.push(ans);
                this._updateRepeatableGroupItem(ans);
            };
            VisualItemController.prototype.removeAnswer = function (ans) {
                var index = this.answers.indexOf(ans);
                if (index >= 0) {
                    var answer = this.answers()[index];
                    answer.dragStopped.remove(this, this._answerDragStopped);
                    this.answers.splice(index, 1);
                    this.itemList.addItem(answer);
                    this._updateRepeatableGroupItem(answer);
                }
            };
            VisualItemController.prototype._answerDragStopped = function (sender, e) {
                //if (!e.dropZone) {
                //	// answer was dragged out of the answer area remove it from answser area and add it to item list (it can be positioned later)
                //	this.removeAnswer(e.item);
                //}
            };
            VisualItemController.prototype._updateRepeatableGroupItem = function (item) {
                if (item instanceof VisualItem.Data.GroupItem) {
                    var instancesLength = 1;
                    instancesLength += this.answers().filter(function (answer) { return answer !== item && answer instanceof VisualItem.Data.GroupItem && answer.templateId === item.templateId; }).length;
                    instancesLength += this.itemList.items().filter(function (listItem) { return listItem !== item && listItem instanceof VisualItem.Data.GroupItem && listItem.templateId === item.templateId; }).length;
                    // if there is not yet the item for a new repeatable group template and it can be added (maxCount), add it now
                    var existingItemIndex = this.itemList.items().findIndex(function (templateItem) { return templateItem instanceof VisualItem.Data.GroupTemplateItem && templateItem.id === item.templateId; });
                    if (existingItemIndex < 0 && instancesLength < item.groupTemplate.maxRepeat)
                        this.itemList.addItem(item.groupTemplate);
                    else if (existingItemIndex >= 0 && instancesLength >= item.groupTemplate.maxRepeat)
                        this.itemList.removeItemAt(existingItemIndex);
                }
            };
            VisualItemController.prototype.appended = function (elements) {
                this.m_domRoot = elements.firstOrDefault(function (el) { return el.className && el.className.indexOf("visualItem") >= 0; });
                this.onResize();
            };
            VisualItemController.prototype.onResize = function () {
                this.size.width(this.m_domRoot.clientWidth);
                this.size.height(this.m_domRoot.clientHeight);
                this._recalculatePositions();
            };
            VisualItemController.prototype.toggleList = function () {
                this.itemList.visible(!this.itemList.visible());
            };
            VisualItemController.prototype.close = function () {
                MobileCRM.bridge.closeForm();
            };
            VisualItemController.prototype._saveDocument = function (fileInfo) {
                var _this = this;
                if (fileInfo && fileInfo.filePath) {
                    MobileCRM.Application.fileExists(fileInfo.filePath, function (exists) {
                        if (exists)
                            MobileCRM.Application.readFileAsBase64(fileInfo.filePath, function (b64Data) {
                                _this._setImageSource(b64Data);
                                _this.m_imageName = _this._getFileNameFromFilePath(fileInfo.filePath);
                                _this.m_imageData = b64Data;
                            }, MobileCRM.bridge.alert, _this);
                    }, MobileCRM.bridge.alert, this);
                }
            };
            VisualItemController.prototype._getFileNameFromFilePath = function (filePath) {
                var index = filePath.lastIndexOf("\\");
                if (index <= 0)
                    index = filePath.lastIndexOf("/");
                return (index >= 0) ? filePath.substr(index + 1) : filePath;
            };
            VisualItemController.prototype._setImageSource = function (b64Data) {
                return __awaiter(this, void 0, void 0, function () {
                    var img, orientation, imgW, imgH, prevW, prevH, answers, _i, answers_1, answer;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0: return [4 /*yield*/, this.createImageFromBase64("data:image/png;base64," + b64Data)];
                            case 1:
                                img = _a.sent();
                                return [4 /*yield*/, this.getImageOrientation(img)];
                            case 2:
                                orientation = _a.sent();
                                imgW = img.width;
                                imgH = img.height;
                                if (!orientation) return [3 /*break*/, 5];
                                if (!(MobileCRM.bridge.platform === "iOS")) return [3 /*break*/, 3];
                                if (orientation > 4) {
                                    imgW = img.height;
                                    imgH = img.width;
                                }
                                return [3 /*break*/, 5];
                            case 3: return [4 /*yield*/, this.rotateImg(img, orientation)];
                            case 4:
                                img = _a.sent();
                                imgW = img.width;
                                imgH = img.height;
                                _a.label = 5;
                            case 5:
                                prevW = this.imageSize.width();
                                prevH = this.imageSize.height();
                                if (prevW > imgW || prevH > imgH) {
                                    answers = this.answers();
                                    for (_i = 0, answers_1 = answers; _i < answers_1.length; _i++) {
                                        answer = answers_1[_i];
                                        if (answer.position.left() > img.width)
                                            answer.position.left(img.width - 1);
                                        if (answer.position.top() > img.height)
                                            answer.position.top(img.height - 1);
                                    }
                                }
                                this.imageSize.width(imgW);
                                this.imageSize.height(imgH);
                                this.imageDataB64(img.src);
                                this._recalculatePositions();
                                return [2 /*return*/];
                        }
                    });
                });
            };
            VisualItemController.prototype.rotateImg = function (img, orientation) {
                return __awaiter(this, void 0, void 0, function () {
                    var canvas, ctx, newImgB64, newImage;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                canvas = document.createElement("canvas");
                                ctx = canvas.getContext("2d");
                                if (4 < orientation && orientation < 9) {
                                    canvas.width = img.height;
                                    canvas.height = img.width;
                                }
                                else {
                                    canvas.width = img.width;
                                    canvas.height = img.height;
                                }
                                switch (orientation) {
                                    case 2:
                                        ctx.transform(-1, 0, 0, 1, img.width, 0);
                                        break;
                                    case 3:
                                        ctx.transform(-1, 0, 0, -1, img.width, img.height);
                                        break;
                                    case 4:
                                        ctx.transform(1, 0, 0, -1, 0, img.height);
                                        break;
                                    case 5:
                                        ctx.transform(0, 1, 1, 0, 0, 0);
                                        break;
                                    case 6:
                                        ctx.transform(0, 1, -1, 0, img.height, 0);
                                        break;
                                    case 7:
                                        ctx.transform(0, -1, -1, 0, img.height, img.width);
                                        break;
                                    case 8:
                                        ctx.transform(0, -1, 1, 0, 0, img.width);
                                        break;
                                    default: break;
                                }
                                ctx.drawImage(img, 0, 0);
                                newImgB64 = canvas.toDataURL();
                                return [4 /*yield*/, this.createImageFromBase64(newImgB64)];
                            case 1:
                                newImage = _a.sent();
                                return [2 /*return*/, newImage];
                        }
                    });
                });
            };
            VisualItemController.prototype.getImageOrientation = function (img) {
                return __awaiter(this, void 0, void 0, function () {
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve) {
                                EXIF.getData(img, function () { return resolve(EXIF.getTag(img, "Orientation")); });
                            })];
                    });
                });
            };
            VisualItemController.prototype.createImageFromBase64 = function (base64) {
                return __awaiter(this, void 0, void 0, function () {
                    return __generator(this, function (_a) {
                        return [2 /*return*/, new Promise(function (resolve, reject) {
                                var img = new Image();
                                img.onload = function () { return resolve(img); };
                                img.onerror = function (err) { return reject(err); };
                                img.src = base64;
                            })];
                    });
                });
            };
            VisualItemController.prototype.capturePhoto = function () {
                var _this = this;
                var service = new MobileCRM.Services.DocumentService();
                service.capturePhoto(function (fileInfo) { return _this._saveDocument(fileInfo); }, MobileCRM.bridge.alert, this);
            };
            VisualItemController.prototype.pickImage = function () {
                var _this = this;
                var service = new MobileCRM.Services.DocumentService();
                service.selectPhoto(function (fileInfo) { return _this._saveDocument(fileInfo); }, MobileCRM.bridge.alert, this);
            };
            VisualItemController.prototype._recalculatePositions = function () {
                if (this.imageSize.width() === 0 || this.imageSize.height() === 0)
                    return;
                var ctrlRatio = this.size.width() / this.size.height();
                var imgRatio = this.imageSize.width() / this.imageSize.height();
                if (ctrlRatio > imgRatio) {
                    this.containerPosition.top(0);
                    this.containerSize.height(this.size.height());
                    this.containerSize.width(this.imageSize.width() * (this.size.height() / this.imageSize.height()));
                    this.containerPosition.left((this.size.width() - this.containerSize.width()) / 2);
                }
                else {
                    this.containerPosition.left(0);
                    this.containerSize.width(this.size.width());
                    this.containerSize.height(this.imageSize.height() * (this.size.width() / this.imageSize.width()));
                    this.containerPosition.top((this.size.height() - this.containerSize.height()) / 2);
                }
                var answers = this.answers();
                var answRatio = this.containerSize.width() / this.imageSize.width();
                for (var _i = 0, answers_2 = answers; _i < answers_2.length; _i++) {
                    var answer = answers_2[_i];
                    answer.ratio(answRatio);
                }
            };
            return VisualItemController;
        }());
        UI.VisualItemController = VisualItemController;
        var DropBin = /** @class */ (function () {
            function DropBin(parent) {
                this.isDropActive = ko.observable(false);
                this.m_parent = parent;
            }
            DropBin.prototype.canDrop = function () {
                return true;
            };
            DropBin.prototype.drop = function (draggedItem, l, t) {
                var answerItem = draggedItem;
                if (this.m_parent.answers().indexOf(answerItem) >= 0)
                    this.m_parent.removeAnswer(answerItem);
                this.isDropActive(false);
            };
            return DropBin;
        }());
        UI.DropBin = DropBin;
    })(UI = VisualItem.UI || (VisualItem.UI = {}));
})(VisualItem || (VisualItem = {}));
//# sourceMappingURL=visualItemController.js.map