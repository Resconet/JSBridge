function Settings() {
	/// <summary>Constructor of the Settings object that stores data related to chart settings.</summary>
	/// usefull tricks https://leanpub.com/D3-Tips-and-Tricks/read

	var _this = this;
	this.isVisible = false;
	this.name = "";
	this.noDataText = "";
	this.seriesColors = {}
	this.seriesTitles = {}
	this.title = "";
	this.type = new Number();
	this.selectedName = "";
	this.labelAxisTitle = "";
	this.valueAxisTitle = "";
	this.currency = "";
	this.currencySymbol = "";
	this.thousandSeparator = "";
	this.valuePrecision = new Number();
	this.pieDonutRatio = 70;
	this.pieLabelStyle = 0;
	this.chartStyle = 0;
	this.disableDrilldown = false;
	this.backColor = undefined;
	this.foreColor = undefined;
	this.textColors = [];
	this.localeOptions = {
		minimumFractionDigits: undefined,
		maximumFractionDigits: undefined,
		style: undefined,
		currency: undefined,
		currencySymbol: undefined,
		useGrouping: undefined
	};
	this.seriesFormattingInfo = [];

	this.jsonData = {};
	this.chartWrapper = {};
	this.chartWrapperMargin = 20;

	this.height = 0,
		this.width = 0,
		this.maxXLabelLength = 0,
		this.maxYLabelLength = 0,
		this.maxLabelsLength = 15; // @JC x and y axis labels longer than 'settings.maxLabelsLength' will be abbreviated to 'settings.maxLabelsLength' characters and "..." string will be added to the end of the label.
	this.angle = 0,
		this.letterPixelSize = 8;
	this.letterHeight = this.letterPixelSize * 2; // @JC constant value used as height of letters used in chart computing
	this.xComponentOfLetterHeight = this.letterHeight / 1.4142; //@JC Length component of the text height rotated under -45 degree. This length component is different for different rotation angle!
	this.minItemSize = this.letterHeight * 1.2; //@JC "letterHeight" value is default value for column bars, horizontal bars, line and area point items to keep axis labels readable. The value is forced to 0 if less than 14 items are used, to ensure that at least 13 bars or points will be visible.
	this.maxItemSize = 200; // @JC maximal width of column bar, line and area item or maximal height of horizontal bar (what represents bar's width in this case). This maxItemSize is used to avoid too wide (ugly) bars and line and area items.
	this.minimumXaxisMargin = 30;
	this.minimumYaxisMargin = 30;
	this.minRoundingMargin = 1; // @JC minimal margin that needs to be used for charts to avoid showing scrollbars that appear due to greater background size caused by rounding (0.0 <= 0.4999, 0.4999999999 => 1.0)
	this.windowRatio = 0;
	this.isStacked;
	this.showRecords;
	//this.translateShowControls = "translate(0,0)"; // for isStacked buttons translation. // @JC: Translation of controls can not be used more, because it influences chart's availableHeight and thus causes inaccurate chart layout. Controls layout was remade, so its manual translation is not more needed.
	this.gaugeTarget;   // @JM constant values for gauge chart (if provided)
	this.gaugeMin;
	this.gaugeMax;

	// public functions to keep computation got from d3.min on one place.
	// computation is made by the same way like in the d3.svg.axis function where rangeBand is used for this computation.
	this.getItemSize = fGetItemSize;
	this.getItemGroupSpacingSize = fGetItemGroupSpacingSize;
	this.getWidthFromItemSize = fGetWidthFromItemSize;

	function fGetItemSize(chartAreaWidth, valuesCount, groupSpacing) {
		var step = chartAreaWidth / (valuesCount + groupSpacing);
		var barWidth = step * (1 - groupSpacing);
		return barWidth;
	}

	function fGetItemGroupSpacingSize(chartAreaWidth, valuesCount, groupSpacing) {
		var step = chartAreaWidth / (valuesCount + groupSpacing);
		var groupSpacingWidth = step * groupSpacing;
		return groupSpacingWidth;
	}

	function fGetWidthFromItemSize(itemSize, valuesCount, groupSpacing) {
		var step = (valuesCount + groupSpacing);
		var width = (itemSize * step) / (1 - groupSpacing);
		return width;
	}
}

Settings.prototype.updateProperties = function (json) {
	/// <summary> Public method of the Settings object that updates all fields of Settings object, that are included as function parameter. </summary>
	/// <param name="json" type="Object">Object obtained from JSBridge with properties of the chart</param>

	this.isVisible = json.isVisible;
	this.labelAxisTitle = json.labelAxisTitle;
	this.name = json.name;
	this.noDataText = json.noDataText;
	this.seriesColors = json.seriesColors;
	this.seriesTitles = json.seriesTitles;
	this.title = json.title;
	this.type = json.type;
	this.selectedName = json.selectedName;
	this.valueAxisTitle = json.valueAxisTitle;
	this.currency = json.currency;
	this.currencySymbol = json.currencySymbol;
	this.seriesFormattingInfo = json.seriesFormattingInfo;
	this.thousandSeparator = json.thousandSeparator;
	this.valuePrecision = new Number(json.valuePrecision);
	this.showRecords = json.showRecords;
	this.isStacked = json.isStacked;
	this.chartsLocalization = json.chartsLocalization;

	if (json.hasOwnProperty("backColor")) {
		this.backColor = json.backColor;
		this.foreColor = json.foreColor;
	}
	if (json.settings) { // @MS specific chart setting coming with version 5
		this.disableDrilldown = json.settings.disableDrilldown;
		this.pieLabelStyle = json.settings.labelStyle;
		this.pieDonutRatio = json.settings.donutRatio;

		this.chartStyle = json.settings.style;      // 0-user select, 1-grouped, 2-stacked
		if (this.chartStyle === 0 && (json.type === 0 || json.type === 1)) {     // @MS if neibor bars in bar or collumn chart has some color, only grouped mode is logic
			if (this.isStacked === false)
				this.chartStyle = 2;                // stacked mode
			else if (this.chartStyle !== 0)
				this.isStacked = this.chartStyle === 2;
		}
		// @JM set additional parameters for gauge chart
		if (json.type === 6) {
			this.gaugeTarget = json.settings.targetValue;
			this.gaugeMin = json.settings.minValue;
			this.gaugeMax = json.settings.maxValue;
		}
	}

	if (!isNaN(this.valuePrecision) && this.valuePrecision >= 0) {
		this.localeOptions.minimumFractionDigits = this.valuePrecision;
		this.localeOptions.maximumFractionDigits = this.valuePrecision;
		this.localeOptions.thousandSeparator = this.thousandSeparator;
	}
	if (this.currency) {
		this.localeOptions.style = "currency";
		this.localeOptions.currency = this.currency;
		this.localeOptions.currencySymbol = this.currencySymbol;
	}
	else
		this.localeOptions.useGrouping = false;

	if (json.decimalSeparator && json.decimalSeparator !== ".")
		this.localeOptions.decimalSeparator = json.decimalSeparator;

	// convert colors
	if (this.seriesColors != undefined) {
		var colors = [];
		for (var i = 0; i < this.seriesColors.length; i++) {
			colors[i] = '#' + ('000000' + (this.seriesColors[i] & 0xFFFFFF).toString(16)).slice(-6);
			this.textColors.push(invertColor(colors[i]));
		}
		this.seriesColors = colors;
	}

	// change text color to assure readability
	function invertColor(color) {
		var c = color;

		c = c.substring(1);      // strip #
		var rgb = parseInt(c, 16);   // convert rrggbb to decimal
		var r = (rgb >> 16) & 0xff;  // extract red
		var g = (rgb >> 8) & 0xff;  // extract green
		var b = (rgb >> 0) & 0xff;  // extract blue

		var luma = 0.2126 * r + 0.7152 * g + 0.0722 * b; // per ITU-R BT.709

		return luma < 40 ? "#FFFFFF" : "#000000";
	}
}


function JSChart() {
	/// <summary>Main constructor of the JSChart object. Object has one property where are saved all settings of the chart  
	/// and seccond property of the nvchart object.</summary>

	var _this = this;
	this.settings = new Settings();
	this.nvChart = {};
}




JSChart.prototype.createChartJS = function (json) {

	var chartType = '';
	var chartData = {};

	this.labelAxisTitle = json.labelAxisTitle;
	this.settings.jsonData = json;
	this.seriesColors = json.seriesColors;
	this.seriesTitles = json.seriesTitles;
	this.textColors = [];
	var displayLabel = false;
	var displayFill = true;
	var displayAxisLabels = true;
	var horizontalLabels = false;
	var labelPosition = 'end';

	//document.write(this.settings.type);

	switch (this.settings.type) {
		case 0:
			chartType = 'bar';
			break;
		case 1:
			chartType = 'horizontalBar';
			horizontalLabels = true;
			break;
		case 2:
			chartType = 'line';
			displayFill = false;
			break;
		case 3:
			chartType = 'pie';
			displayLabel = true;
			displayAxisLabels = false;
			labelPosition = 'start';
			break;
		case 4:
			chartType = 'funnel';
			displayLabel = true;
			displayAxisLabels = false;
			labelPosition = 'start';
			break;
		case 5:
			chartType = 'doughnut';
			displayLabel = true;
			displayAxisLabels = false;
			labelPosition = 'start';
			break;
		case 6:
			// @MS Gauge chart
			chartType = 'tsgauge';
			displayLabel = false;
			displayAxisLabels = false;
			break;
		case 7:
			// @MS Stack area chart
			chartType = 'line';
			displayLabel = false;
			break;
	}

	chartData = parseJson(this.settings.jsonData, this.settings.seriesTitles, this.settings.seriesColors, this.settings.textColors);  // create of dataset according to the requirements nvd3 chart

	var valuesx = [];
	var valuesy = [];
	var labels = [];


	for (var i = 0; i < chartData.length; i++) {
		for (var j = 0; j < chartData[i].values.length; j++) {

			valuesx.push(chartData[i].values[j].x);
			valuesy.push(chartData[i].values[j].y);
			labels.push(chartData[i].values[j].label);

		}
	}


	var n = 0;
	var coloR = [];
	var dynColors = function (i) {
		if (n == 7) { n = 0 } else { n++ }
		var arrColors = ['rgb(255, 99, 132)', 'rgb(255, 159, 64)', 'rgb(255, 205, 86)', 'rgb(75, 192, 192)', 'rgb(54, 162, 235)', 'rgb(153, 102, 255)', 'rgb(201, 203, 207)']
		return arrColors[n];
	};
	for (var i = 0; i < valuesy.length; i++) {
		coloR.push(dynColors(i));
	}
	chartcolors = coloR;

	// prepare data

	var settings = this.settings;
	var _gValue = 0; // value must be provided
	var _gTarget = null;
	var _gMax = null;
	var _gMin = null;
	var toolTipsEnabled = true;
	var resizeChartLimit = 500; // Width limit for changing legend position
	

	var currencySymbol = settings.currencySymbol;


	if (this.settings.type == 6) {  // Gauge chart

		

		// check for value and if target, mix or max comes from entity / fetch
		for (var i = 0; i < chartData.length; i++) {
			switch (chartData[i].key) {
				case "MinValue":
					_gMin = chartData[i].values[0].y;
					break;
				case "MaxValue":
					_gMax = chartData[i].values[0].y;
					break;
				case "TargetValue":
					_gTarget = chartData[i].values[0].y;
					break;
				case "chartseries0":
				default:
					_gValue = chartData[i].values[0].y;
					break;
			}
		}


		// if target, mix or max comes from constant - zero is the default value
		_gMin = (_gMin ? _gMin : settings.gaugeMin);
		_gMax = (_gMax ? _gMax : settings.gaugeMax);
		_gTarget = (_gTarget ? _gTarget : (settings.gaugeTarget == 0 ? null : settings.gaugeTarget)); // don't use target if set to default



		var _gTaragetText = _gTarget;
		var _gValueText = _gValue;

		// prepare the values 
		_gMax = (_gMax ? _gMax : _gValue * 2);
		if (_gTarget && _gTarget > _gMax)
			_gMax = _gTarget;

		if (_gValue > _gMax)
			_gMax = _gValue;

		if (_gMin) {
			_gValue -= _gMin;
			_gMax -= _gMin;
			if (_gTarget) {
				_gTarget -= _gMin;
				_gTarget = (_gTarget < 0 ? 0 : _gTarget);
			}

			// don't allow negative values
			_gValue = (_gValue < 0 ? 0 : _gValue);
			_gMax = (_gMax < 0 ? 0 : _gMax);
		}

		_gMin = (_gMin ? _gMin : 0);

		chartcolors = ['rgb(255, 159, 64)', 'rgb(238, 238, 238)'];
		toolTipsEnabled = false;
	};

	Chart.helpers.merge(Chart.defaults.global.plugins.datalabels, {

		display: this.settings.type == 6 ? false : true
	});

	var config = {
		type: chartType,
		data: {
			datasets: [{
				data: valuesy,
				datalabels: {
					align: labelPosition,
					anchor: 'end',
					backgroundColor: "#FFF",
					borderColor: "#CCC",
					borderWidth: 1,
					borderRadius: 3,
					padding: 1,
					offset: 5,
					formatter: function (value, ctx) {

						var strVal;
						if (currencySymbol) { strVal = currencySymbol + " " + addCommas(Number(value).toFixed(2)) } else { strVal = addCommas(value) }

						return strVal;
					}
				},
				backgroundColor: this.settings.type == 7 ? "#4BC0C0" : chartcolors,
				label: this.settings.labelAxisTitle,
				pointBackgroundColor: chartcolors,
				fillColor: "#ffff00",
				fill: displayFill,
				gaugeData: {
					value: _gTarget,
					valueColor: "#000000",
					currency: currencySymbol
				},
				gaugeLimits: [_gMin, _gValue, _gMax],
				pointRadius: 9,
				pointHoverRadius: 20
			}],
			labels: labels,
			charttype: this.settings.type,
			nodatatext: this.settings.noDataText
		},
		options: {
			layout: {
				padding: {
					left: 20,
					right: 20,
					top: 40,
					bottom: 20
				}
			},
			tooltips: {
				custom: function (tooltip) {
					if (!tooltip) return;
					tooltip.displayColors = true;
					tooltip.displayLabel = false;
				},
				enabled: toolTipsEnabled,
				callbacks: {
					label: function (tooltipItem, data) {

						var datasetLabel;
						var value;

						if (data.charttype == 3 || data.charttype == 4 || data.charttype == 5) {
						datasetLabel = data.labels[tooltipItem.index];
						value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];
						} else {
							datasetLabel = data.datasets[tooltipItem.datasetIndex].label || 'Other';
							value = tooltipItem.value;
						}
						

						var strVal;
						if (currencySymbol) { strVal = currencySymbol + " " + addCommas(Number(value).toFixed(2)) } else { strVal = addCommas(value) }

						return datasetLabel + ': ' + strVal;
					}
				}
			},
			plugins: {
				datalabels: {
					color: '#666666',

					font: {
						weight: 'normal',
					    size: 10 
					}

				}
			},
			responsive: true,
			maintainAspectRatio: false,
			title: {
				display: false

			},
			legend: {
				display: displayLabel,
				position: $(window).width() > resizeChartLimit && _chart.settings.type == 3 ? 'right': 'bottom'
				
			},
			onResize: function (myChart, size) {
				if (displayLabel && _chart.settings.type == 3) {
					this.legend = {
						position: $(window).width() > resizeChartLimit ? 'right' : 'bottom'
					}
				}
			}
		}
		
	};

	var ticksWithCurrency = {
		ticks: {
			lineHeight: 2,
			display: this.settings.type == 6 ? false : !displayLabel,
			beginAtZero: true,
			userCallback: function (value, index, values) {

				var strVal;
				if (currencySymbol) { strVal = currencySymbol + " " + addCommas(value) } else { strVal = addCommas(value) }

				return strVal;
			}
		},
		gridLines: { display: this.settings.type == 6 ? false : !displayLabel },
		scaleLabel: {
			display: this.settings.labelAxisTitle == undefined ? false : displayAxisLabels,
			labelString: this.settings.valueAxisTitle
		}
	};


	var ticksWithoutCurrency = {
		ticks: {
			lineHeight: 2,
			display: this.settings.type == 6 ? false : !displayLabel,
			beginAtZero: true,
			maxLabelsLength: this.settings.maxLabelsLength,
			callback: function (label, index, values) {

				var max = this.options.ticks.maxLabelsLength;
				var valLength = label.length;
				if (valLength > max) {
					valLength = max + 3; // Add 3 chars for ...
					label = label.substring(0, max) + "...";
				}

				return label;

			}
		},
		gridLines: { display: this.settings.type == 6 ? false : !displayLabel },
		scaleLabel: {
			display: this.settings.labelAxisTitle == undefined ? false : displayAxisLabels,
			labelString: this.settings.labelAxisTitle
		}
	};

	if (horizontalLabels) {
		config.options.scales = {
			xAxes: [ticksWithCurrency],
			yAxes: [ticksWithoutCurrency]
		}
	} else {
		config.options.scales = {
			xAxes: [ticksWithoutCurrency],
			yAxes: [ticksWithCurrency]
		}
	};


	var elem = document.getElementById('chart-area');
	var wrapper = document.getElementById('chartWrapper');

	if (this.settings.type == 6) {
		config.options.events = [];
		config.options.hover = { mode: null };
	};


	Chart.plugins.register({
		afterDraw: function (chart) {
			if (valuesy.length === 0) {
				// No data is present
				var ctx = chart.chart.ctx;
				var width = chart.chart.width;
				var height = chart.chart.height;
				chart.clear();

				ctx.save();
				ctx.textAlign = 'center';
				ctx.textBaseline = 'middle';
				ctx.fillColor = '#000000';
				ctx.fillText(chart.config.data.nodatatext, width / 2, height / 2);
				ctx.restore();
			}
		}
	});

	
	var ctx = document.getElementById('chart-area').getContext('2d');

	var myChart = new Chart(ctx, config);

	var valuesLength = valuesy.length;
	var valuesLengthHeight = valuesLength * 20;
	var valuesLengthPieChart = valuesLength * 10;
		

	if ((this.settings.type == 0 || this.settings.type == 2 || this.settings.type == 5 || this.settings.type == 7) && valuesLength > 20 && valuesLengthHeight > window.innerWidth) {
		wrapper.style.width = valuesLengthHeight + 'px';
		wrapper.width = valuesLengthHeight + 'px';
	} else if ((this.settings.type == 1 || this.settings.type == 4) && valuesLength > 20 && valuesLengthHeight > window.innerHeight) {
		wrapper.style.height = valuesLengthHeight + 'px';
		wrapper.height = valuesLengthHeight + 'px';
	} else if ((this.settings.type == 3) && valuesLength > 20 && valuesLengthPieChart > window.innerWidth) {
		wrapper.style.width = valuesLengthPieChart + 'px';
		wrapper.width = valuesLengthPieChart + 'px';

	}

	if (this.settings.type != 6) {  // Gauge chart
		elem.addEventListener('click', function (event) {

			var activePoints = myChart.getElementsAtEventForMode(event, 'point', myChart.options);
			var firstPoint = activePoints[0];
			//var label = myChart.data.labels[firstPoint._index];
			//var value = myChart.data.datasets[firstPoint._datasetIndex].data[firstPoint._index];
			if (firstPoint == undefined) { onClick(-1, -1) } else { onClick(1, firstPoint._index) }
			

		}, false);
	};

	function addCommas(nStr) {
		nStr += '';
		x = nStr.split('.');
		x1 = x[0];
		x2 = x.length > 1 ? '.' + x[1] : '';
		var rgx = /(\d+)(\d{3})/;
		while (rgx.test(x1)) {
			x1 = x1.replace(rgx, '$1' + ',' + '$2');
		}
		return x1 + x2;
	};


	function parseJson(jsonData, seriesTitles, seriesColors, textColors) {
		/// <summary>Function create data object according to requirements NVD3 charts.</summary>
		/// <param name="jsonData" type="Object">Object with original data from MCRM.</param> 
		/// <param name="seriesTitles" type="Array<String>">List of titles for series.</param>
		/// <param name="seriesColors" type="Array<String>">List of colors for series.</param>
		/// <param name="textColors" type="Array<String>">List of colors for text in series.</param>
		/// <returns  type="Object">Object of series data where are defined key, index, values and color for every serie.</returns>

		function setValues(count, index, textColor) {
			/// <summary>Create object of values for chart.</summary>
			/// <param name="count" type="Integer">Count of series.</param>
			/// <param name="index" type="Integer">Index for a specific serie.</param>
			/// <param name="textColors" type="Array<String>">List of colors for text in series.</param>
			/// <returns type="Object">Object of the values for specific serie with x, y and label for every value.</returns>
			values = []
			for (var i = 0; i < count; i++) {
				values.push({
					x: i,
					y: jsonData[i].values[index],
					label: jsonData[i].key,
					textColor: textColor
				})
			}

			//values = []
			//for (var i = 0; i < 100; i++) {
			//	values.push({
			//		x: i,
			//		y: 200,
			//		label: "test",
			//		textColor: textColor
			//	})
			//}

			return values;
		}

		data = [];
		if (jsonData.length > 0) {
			var nSeries = jsonData[0].values.length;
			for (var i = 0; i < nSeries; i++) {
				data.push({
					key: (seriesTitles != undefined) ? seriesTitles[i] : "",
					index: i,
					values: setValues(jsonData.length, i, textColors[i]),
					color: (seriesColors != undefined) ? seriesColors[i] : "",
				});
			}
		}
		return data;
	}


}

