/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../Controls/datePicker.ts" />
/// <reference path="../Controls/comboBox.ts" />
/// <reference path="./Utils.ts" />
/// <reference path="./ConditionOperator.ts" />
/// <reference path="./LinkAlias.ts" />
var FetchQueryBuilder;
(function (FetchQueryBuilder) {
    var SelectedItem = (function () {
        function SelectedItem(parents, entity, filter, target) {
            this.parents = parents;
            this.entity = entity;
            this.filter = filter;
            this.target = target;
        }
        SelectedItem.prototype.toArray = function () {
            return [this.parents, this.entity, this.filter, this.target];
        };
        return SelectedItem;
    }());
    FetchQueryBuilder.SelectedItem = SelectedItem;
    var QueryBuilder = (function () {
        function QueryBuilder() {
            var _this = this;
            this.editorPlaceholder = "Enter Value...";
            QueryBuilder._instance = this;
            var settings = {
                firstWeekDay: 0,
                actualDate: new Date(),
                dayNames: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                images: [],
                platform: MobileCRM.bridge.platform
            };
            MobileCRM.Application.getAppImage("Controls.arrow_down.png", "", function (result) {
                settings.images.push(result);
                MobileCRM.Application.getAppImage("Controls.arrow_up.png", "", function (result) {
                    settings.images.push(result);
                    _this._datePicker = new Resco.Controls.RescoDatePicker(settings, document.body, false);
                }, function (error) {
                    console.log("Error occurred during image loading\n" + error);
                }, null);
            }, function (error) {
                console.log("Error occurred during image loading\n" + error);
            }, null);
            this._cmdCancel = MobileCRM.Localization.getTextOrDefault("Cmd.Cancel", "Cancel");
            this._selectedEditor = null;
            this.fetch = ko.observable();
            this.metadata = [];
            this.canEditFields = ko.observable();
            this.viewName = ko.observable();
            this._selectedItems = ko.observableArray([]);
            this.canAddConditionToGroup = ko.computed(function () {
                if (_this._selectedItems().length === 2
                    && ((_this._selectedItems()[0].target instanceof FetchQueryBuilder.OCondition && _this._selectedItems()[1].target instanceof FetchQueryBuilder.OFilter)
                        || (_this._selectedItems()[0].target instanceof FetchQueryBuilder.OFilter && _this._selectedItems()[1].target instanceof FetchQueryBuilder.OCondition))) {
                    var cond = null;
                    var filter = null;
                    if (_this._selectedItems()[0].target instanceof FetchQueryBuilder.OCondition) {
                        cond = _this._selectedItems()[0];
                        filter = _this._selectedItems()[1];
                    }
                    else {
                        cond = _this._selectedItems()[1];
                        filter = _this._selectedItems()[0];
                    }
                    if (cond.entity === filter.entity && cond.filter != filter.target)
                        return true;
                }
                return false;
            });
            this.canSelectMultiple = ko.computed(function () {
                if (_this._selectedItems().length <= 1)
                    return false;
                else
                    return true;
            });
            this.canInvertFilter = ko.computed(function () {
                if (!_this.canSelectMultiple()
                    && _this._selectedItems().length > 0
                    && _this._selectedItems()[0].target instanceof FetchQueryBuilder.OFilter)
                    return true;
                return false;
            });
            this.isGroupingEnabled = ko.computed(function () {
                if (_this._selectedItems().length < 2)
                    return false;
                for (var _i = 0, _a = _this._selectedItems(); _i < _a.length; _i++) {
                    var item = _a[_i];
                    if (!(item.target instanceof FetchQueryBuilder.OCondition))
                        return false;
                }
                for (var i = 0; i < _this._selectedItems().length; i++)
                    for (var j = 0; j < _this._selectedItems().length; j++)
                        if (_this._selectedItems()[i].filter != _this._selectedItems()[j].filter)
                            return false;
                return true;
            });
            /*this.canSelectMultiple.subscribe(() => {
                this.resetSelectedItems();
            });*/
            this.fetch.subscribe(function () {
                MobileCRM.UI.IFrameForm.setDirty(true);
            });
            $(document).click(function () {
                _this.showEditor(_this._selectedEditor, false);
            });
            $('#faded-background').click(function () {
                _this._selectedItems([]);
            });
            this.fetchData();
            return this;
        }
        QueryBuilder.getInstance = function () {
            if (QueryBuilder._instance)
                return QueryBuilder._instance;
            QueryBuilder._instance = new QueryBuilder();
            return QueryBuilder._instance;
        };
        QueryBuilder.prototype.getSelectedItems = function () {
            return this._selectedItems;
        };
        QueryBuilder.prototype.getFetch = function () {
            return QueryBuilder._fetch;
        };
        /**
         * Requests fetch in XML format through JSBridge
         */
        QueryBuilder.prototype.fetchData = function () {
            var _this = this;
            // Loads the query in supplied in the form
            MobileCRM.bridge.command("getCurrentFilter", null, function (obj) {
                _this.viewName(obj["viewName"]);
                _this.canEditFields(obj["canEditFields"]);
                _this.displayQuery(obj["fetchXml"], obj["entityName"]);
            }, MobileCRM.bridge.alert);
        };
        /**
         * Deserialize passed in query or prepares default query for passed in entity
         * and displays it in the editor
         * @param query The XML query
         * @param memberType Entity number
         */
        QueryBuilder.prototype.displayQuery = function (query, memberType) {
            var _this = this;
            if (query) {
                MobileCRM.FetchXml.Fetch.deserializeFromXml(query, function (fetch) {
                    _this.getMetadata(fetch);
                }, MobileCRM.bridge.alert, this);
            }
            else {
                var fetch = this.prepareFetchXml(memberType);
                if (fetch) {
                    this.getMetadata(fetch);
                }
            }
        };
        /**
         * Loads metadata for the entity in the fetch
         * @param fetch {MobileCRM.FetXml.Fetch} object representing the fetch
         */
        QueryBuilder.prototype.getMetadata = function (fetch) {
            QueryBuilder._fetch = fetch;
            MobileCRM.Metadata.requestObject(function (metadata) {
                this.onMetadataLoaded(metadata, fetch);
            }, MobileCRM.bridge.alert, this);
        };
        /**
         * Creates aliases for linked entities and observable object for view after the fetch is successfully loaded
         * @param metadata {MobileCRM.Metadata} entities metadata
         * @param fetch {MobileCRM.FetchXml.Fetch} observable object representing the fetch
         */
        QueryBuilder.prototype.onMetadataLoaded = function (metadata, fetch) {
            this._linkAlias = new FetchQueryBuilder.LinkAlias(fetch);
            this.metadata = metadata.entities;
            this._getEntityMetadata(fetch.entity);
            MobileCRM.Localization.initialize(function (metadata) {
                this.onLocalizationLoaded(fetch);
            }, MobileCRM.bridge.alert, this);
        };
        /**
         * Gets the metadata for the passed in entity
         * @param entity passed in entity
         */
        QueryBuilder.prototype._getEntityMetadata = function (entity) {
            var _this = this;
            if (entity.linkentities) {
                entity.linkentities.forEach(function (e) {
                    _this._getEntityMetadata(e);
                }, this);
            }
        };
        QueryBuilder.prototype.onLocalizationLoaded = function (fetch) {
            // get localizations
            this.getEntityLocalization();
            this.fetch(new FetchQueryBuilder.OFetch(fetch));
            this.resetSelectedItems();
            // handle onSave event
            MobileCRM.UI.IFrameForm.onSave(this.onSave, true, this);
            // bind view model
            ko.applyBindings(this);
        };
        /**
         * Localize metadata
         */
        QueryBuilder.prototype.getEntityLocalization = function () {
            this._cmdCancel = MobileCRM.Localization.getTextOrDefault("Cmd.Cancel", "Cancel");
            for (var m in this.metadata) {
                var meta = this.metadata[m];
                meta.DisplayName = MobileCRM.Localization.get(meta.name);
                if (meta.properties) {
                    this._getPropertiesLocalization(meta.properties, meta.name);
                }
            }
        };
        /**
         * Localize entity properties
         * @param properties Entity properties
         * @param metaName Entity name
         */
        QueryBuilder.prototype._getPropertiesLocalization = function (properties, metaName) {
            properties.forEach(function (a) {
                var id = metaName + "." + a.name;
                a.DisplayName = MobileCRM.Localization.get(metaName + "." + a.name);
                if (a.isPicklist) {
                    a.options = new Object();
                    var id = id + ".";
                    var idLen = id.length;
                    var stringTable = MobileCRM.Localization.stringTable;
                    for (var i in stringTable) {
                        if (i && i.substr(0, idLen) == id) {
                            var val = parseInt(i.substr(idLen), 10);
                            if (val !== NaN) {
                                a.options[val] = stringTable[i];
                            }
                        }
                    }
                }
            });
        };
        /**
         * Prepares pure new fetch for the passed in entity number
         * @param memberType {Number} representing the entity
         */
        QueryBuilder.prototype.prepareFetchXml = function (memberType) {
            var entityName = null;
            switch (memberType) {
                case 1:
                    entityName = "account";
                    break;
                case 2:
                    entityName = "contact";
                    break;
                case 4:
                    entityName = "lead";
                    break;
            }
            if (entityName == null) {
                this.showPopup("Entity name unknown!");
                return null;
            }
            var entity = new MobileCRM.FetchXml.Entity(entityName);
            return new MobileCRM.FetchXml.Fetch(entity, 0, 0);
        };
        QueryBuilder.prototype.replace = function (target, search, replacement) {
            var regEx = new RegExp(search, 'g');
            return target.replace(regEx, replacement);
        };
        /**
         * Searches the entity for linked entities with passed in alias
         * @param parent Entity
         * @param alias {String} representing alias to look for
         */
        QueryBuilder.prototype.getLinkedEntityByAlias = function (parent, alias) {
            var res = null;
            for (var _i = 0, _a = parent.linkentities(); _i < _a.length; _i++) {
                var link = _a[_i];
                if (alias === link.alias())
                    return link;
                if (link.linkentities && link.linkentities().length > 0)
                    res = this.getLinkedEntityByAlias(link, alias);
            }
            return res;
        };
        /**
         * Gets the entity attributes
         * @param entity
         * @param all condition if all properties will be returned
         */
        QueryBuilder.prototype.getAttributes = function (entity, all) {
            var properties = this.metadata[entity.name].properties.filter(function (item) {
                return all || !entity.attributes || !entity.attributes().some(function (element, index, array) {
                    return element.name == item.name;
                });
            });
            return properties.sort(function (a, b) {
                if (a.DisplayName > b.DisplayName)
                    return 1;
                else if (a.DisplayName < b.DisplayName)
                    return -1;
                else
                    return 0;
            });
        };
        /**
         * Gets the attributes of the linked entities
         * @param linkentities entities linked to the parent entity
         */
        QueryBuilder.prototype._getChildrenAttributes = function (linkentities) {
            var attributes = [];
            for (var _i = 0, linkentities_1 = linkentities; _i < linkentities_1.length; _i++) {
                var link = linkentities_1[_i];
                var alias = link.alias();
                var entityname = link.name;
                attributes[attributes.length] = [alias, entityname].concat(this.getAttributes(link, true));
                if (link.linkentities && link.linkentities().length > 0)
                    attributes = attributes.concat(this._getChildrenAttributes(link.linkentities()));
            }
            return attributes;
        };
        /**
         * Gets the candidates for the entity condition
         * @param parents Parent nodes in the view
         */
        QueryBuilder.prototype.getFilterAttributes = function (parents) {
            var attributes = [];
            var parent = this.getEntityParent(parents);
            if (parent) {
                // There is no alias for the current entity
                attributes[attributes.length] = ["", parent.name].concat(this.getAttributes(parent, true));
            }
            if (parent && parent.linkentities)
                attributes = attributes.concat(this._getChildrenAttributes(parent.linkentities()));
            return attributes;
        };
        /**
         * Gets the display name of the attribute of the passed in entity
         * @param entity
         * @param attribute the attribute name
         * @alias alias of the entity in the filter
         * @plural determines if the function should return plural of the entity name
         */
        QueryBuilder.prototype.getDisplayName = function (entity, attribute, alias, isPlural, target, isLink) {
            if (attribute === void 0) { attribute = null; }
            if (alias === void 0) { alias = null; }
            if (isPlural === void 0) { isPlural = false; }
            if (target === void 0) { target = null; }
            if (isLink === void 0) { isLink = false; }
            var meta = this.metadata[entity];
            if (meta) {
                if (isPlural) {
                    var entityNamePlural = MobileCRM.Localization.getPlural(entity);
                    if (attribute && meta.properties && meta.getProperty(attribute)) {
                        if (meta.getProperty(attribute).DisplayName)
                            return alias ? (alias + '.' + meta.getProperty(attribute).DisplayName) : (entityNamePlural + ' (' + meta.getProperty(attribute).DisplayName + ')');
                        else
                            return alias ? (alias + '.' + meta.getProperty(attribute).name) : (entityNamePlural + ' (' + meta.getProperty(attribute).name + ')');
                    }
                    return entityNamePlural;
                }
                else {
                    if (isLink && attribute && meta.properties) {
                        var displayEntityName = false;
                        var displayEntityNameReverse = false;
                        if (isLink && meta) {
                            var props = meta.properties;
                            var cnt = 0;
                            for (var _i = 0, props_1 = props; _i < props_1.length; _i++) {
                                var prop = props_1[_i];
                                if (prop.isReference && prop.targets) {
                                    if (prop.targets.some(function (val, arr, i) {
                                        return val === target;
                                    })) {
                                        cnt++;
                                    }
                                    if (cnt > 1) {
                                        displayEntityName = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if (meta.getProperty(attribute).targets.length > 1) {
                            displayEntityNameReverse = true;
                        }
                        if (displayEntityName) {
                            if (meta.getProperty(attribute) && meta.getProperty(attribute).DisplayName)
                                return this.metadata[target].DisplayName + ' (' + meta.getProperty(attribute).DisplayName + ')';
                            else if (meta.getProperty(attribute))
                                return this.metadata[target].DisplayName + ' (' + meta.getProperty(attribute).name + ')';
                            else
                                return this.metadata[target].DisplayName + ' (' + attribute + ')';
                        }
                        else if (displayEntityNameReverse) {
                            if (meta.getProperty(attribute) && meta.getProperty(attribute).DisplayName)
                                return meta.getProperty(attribute).DisplayName + ' (' + this.metadata[target].DisplayName + ')';
                            else if (meta.getProperty(attribute))
                                return meta.getProperty(attribute).name + ' (' + this.metadata[target].DisplayName + ')';
                            else
                                return attribute + ' (' + this.metadata[target].DisplayName + ')';
                        }
                        else {
                            if (isLink)
                                return meta.getProperty(attribute).name;
                            return meta.getProperty(attribute).DisplayName ? meta.getProperty(attribute).DisplayName : meta.getProperty(attribute).name;
                        }
                    }
                    else if (isLink) {
                        return this.metadata[target].DisplayName ? (this.metadata[target].DisplayName + ' (' + attribute + ')') : (target + ' (' + attribute + ')');
                    }
                    else if (attribute && meta.properties && meta.getProperty(attribute)) {
                        if (meta.getProperty(attribute).DisplayName)
                            return alias ? (alias + '.' + meta.getProperty(attribute).DisplayName) : meta.getProperty(attribute).DisplayName;
                        else
                            return alias ? (alias + '.' + meta.getProperty(attribute).name) : meta.getProperty(attribute).name;
                    }
                    return meta.DisplayName;
                }
            }
            var name = entity;
            if (attribute) {
                if (alias)
                    name = alias + '.' + attribute;
                else
                    name = name + "." + attribute;
            }
            return name;
        };
        /**
         * Gets the attribute of the entity according to the passed in name
         * @param entity The string representing entity name
         * @param attribute The string representing attribute name
         */
        QueryBuilder.prototype.getAttribute = function (entity, attribute) {
            var meta = this.metadata[entity];
            if (!meta) {
                if (entity) {
                    meta = this.metadata[this.fetch().entity().name];
                }
                else {
                    var link = this.getLinkedEntityByAlias(this.fetch().entity(), entity);
                    meta = this.metadata[link.name];
                }
            }
            if (meta) {
                if (attribute && meta.properties) {
                    return meta.getProperty(attribute);
                }
            }
            return null;
        };
        QueryBuilder.prototype.getFilterType = function (type) {
            if (type) {
                return type;
            }
            return "and";
        };
        QueryBuilder.prototype.getFilterDisplayName = function (parents, attributeName, condition) {
            var parent = this.getEntityParent(parents);
            if (condition.entityname()) {
                var linkedEntity = this.getLinkedEntityByAlias(parent, condition.entityname());
                return this.getDisplayName(linkedEntity.name, condition.attribute(), condition.entityname());
            }
            if (parent) {
                return this.getDisplayName(parent.name, attributeName);
            }
            return attributeName;
        };
        QueryBuilder.prototype.getOperatorDisplayName = function (condition) {
            var operator = condition.operator();
            for (var c in FetchQueryBuilder.ConditionOperator.operators) {
                var op = FetchQueryBuilder.ConditionOperator.operators[c];
                if (op.Value === operator) {
                    if ((op.Value === FetchQueryBuilder.ConditionOperator.operators.Contain.Value ||
                        op.Value === FetchQueryBuilder.ConditionOperator.operators.NotContain.Value) &&
                        condition.stringOperator()) {
                        return condition.stringOperator();
                    }
                    else if (op.Value === FetchQueryBuilder.ConditionOperator.operators.Contain.Value ||
                        op.Value === FetchQueryBuilder.ConditionOperator.operators.NotContain.Value) {
                        if (condition.value() && condition.value()[0] == "%" && !op.WildcardStart)
                            continue;
                        if (condition.value() && condition.value()[condition.value().length - 1] == "%" && !op.WildcardEnd)
                            continue;
                        condition.stringOperator(op.Key);
                    }
                    return op.Key;
                }
            }
            return operator;
        };
        QueryBuilder.prototype.removeWildcards = function (value) {
            if (value && value[0] == "%")
                value = value.substring(1);
            if (value && value[value.length - 1] == "%")
                value = value.substring(0, value.length - 1);
            return value;
        };
        QueryBuilder.prototype.getConditionValue = function (parents, condition) {
            if (FetchQueryBuilder.ConditionOperator.getArity(condition.operator()) === 0) {
                return "";
            }
            var values = !condition.value() ? condition.values() : [condition.value()];
            var returnValues = [];
            if (values && condition.operator() === FetchQueryBuilder.ConditionOperator.operators.Contain.Value || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotContain.Value) {
                for (var v = 0; v < values.length; v++) {
                    if (values.length === 0)
                        break;
                    values[v] = this.removeWildcards(values[v]);
                    if (values[v] === "" || values[v] === null)
                        values.splice(v--, 1);
                }
            }
            if (values === null || values.length === 0) {
                return this.editorPlaceholder;
            }
            var entity = this.getEntityParent(parents);
            if (condition.entityname()) {
                var linkedEntity = this.getLinkedEntityByAlias(entity, condition.entityname());
                if (linkedEntity)
                    entity = linkedEntity;
            }
            if (entity) {
                var attribute = this.getAttribute(entity.name, condition.attribute());
                if (attribute) {
                    if (attribute.isPicklist) {
                        for (var _i = 0, values_1 = values; _i < values_1.length; _i++) {
                            var val = values_1[_i];
                            if (attribute.options && attribute.options.hasOwnProperty(val)) {
                                var text = attribute.options[val];
                                returnValues.push(text);
                            }
                        }
                    }
                    else if (attribute.isReference || attribute.type === CrmType.PrimaryKey) {
                        if (condition.uiname()) {
                            returnValues.push(condition.uiname());
                        }
                        else {
                            returnValues.push(condition.value());
                        }
                    }
                }
            }
            return returnValues && returnValues.length > 0 ? returnValues : values;
        };
        QueryBuilder.prototype.getEntityParent = function (parents) {
            for (var i = 0; i < parents.length; i++) {
                var parent = parents[i];
                if (parent instanceof FetchQueryBuilder.OEntity) {
                    return parent;
                }
            }
            return null;
        };
        QueryBuilder.prototype.getFilterParent = function (parents, level) {
            if (level === void 0) { level = 0; }
            for (var i = 0; i < parents.length; i++) {
                var parent = parents[i];
                if (parent instanceof FetchQueryBuilder.OFilter) {
                    if (level <= 0)
                        return parent;
                    else
                        level--;
                }
            }
            for (var i = 0; i < parents.length; i++) {
                var parent = parents[i];
                if (parent instanceof FetchQueryBuilder.OEntity) {
                    if (level <= 0)
                        return parent;
                    else
                        level--;
                }
            }
            return null;
        };
        QueryBuilder.prototype.isReverseLink = function (parents, link) {
            var e = this.getEntityParent(parents);
            if (link instanceof FetchQueryBuilder.OLinkEntity) {
                if (link.to() === this.metadata[e.name].primaryKeyName)
                    return true;
            }
            return false;
        };
        QueryBuilder.prototype.getLinks = function (entity) {
            var links = [];
            var currentEntityLinks = [];
            for (var m in this.metadata) {
                var meta = this.metadata[m];
                var isCurrent = meta.name === entity.name;
                var props = meta.properties;
                var _loop_1 = function (p) {
                    var prop = props[p];
                    if (prop.isReference && prop.targets) {
                        var targets = props[p].targets;
                        var isTargetingCurrent = targets.some(function (val, arr, i) {
                            return val === entity.name;
                        });
                        if (!isCurrent && !isTargetingCurrent)
                            return "continue";
                        var _loop_2 = function (target) {
                            var isReverse = false;
                            if (!isCurrent && target != entity.name)
                                return "continue";
                            // Make the target the other entity no the one the function is returning links for
                            if (!isCurrent && target == entity.name) {
                                target = meta.name;
                                isReverse = true;
                            }
                            if (entity.linkentities()) {
                                var hasLink = entity.linkentities().some(function (element, index, array) {
                                    if (isReverse)
                                        return element.name == target && element.from() == prop.name;
                                    else
                                        return element.name == target && element.to() == prop.name;
                                });
                                if (hasLink)
                                    return "continue";
                            }
                            var link = null;
                            if (isReverse) {
                                link = {
                                    entity: target,
                                    from: prop.name,
                                    to: this_1.metadata[entity.name].primaryKeyName,
                                    DisplayName: this_1.getDisplayName(target, prop.name, null, isReverse, entity.name, true),
                                    reverse: isReverse
                                };
                                links.push(link);
                            }
                            else {
                                link = {
                                    entity: target,
                                    from: this_1.metadata[target].primaryKeyName,
                                    to: prop.name,
                                    DisplayName: this_1.getDisplayName(entity.name, prop.name, null, isReverse, target, true),
                                    reverse: isReverse
                                };
                                currentEntityLinks.push(link);
                            }
                        };
                        for (var _i = 0, targets_1 = targets; _i < targets_1.length; _i++) {
                            var target = targets_1[_i];
                            _loop_2(target);
                        }
                    }
                };
                var this_1 = this;
                for (var p in props) {
                    _loop_1(p);
                }
            }
            currentEntityLinks.sort(function (a, b) {
                if (a.DisplayName > b.DisplayName)
                    return 1;
                else if (a.DisplayName < b.DisplayName)
                    return -1;
                else
                    return 0;
            });
            links.sort(function (a, b) {
                if (a.DisplayName > b.DisplayName)
                    return 1;
                else if (a.DisplayName < b.DisplayName)
                    return -1;
                else
                    return 0;
            });
            return currentEntityLinks.concat(links);
        };
        QueryBuilder.prototype.onCheckBoxClicked = function (parents, entity, filter, target, event) {
            var item = new SelectedItem(parents, entity, filter, target);
            if (event) {
                var target_1 = $(event.target);
                if (target_1.hasClass('select') && item.target.isSelected()) {
                    return;
                }
                else if (item.target.isSelected()) {
                    var isSelect_1 = false;
                    target_1.parentsUntil(".entity").each(function (i, el) {
                        if ($(el).hasClass('select'))
                            isSelect_1 = true;
                    });
                    if (isSelect_1)
                        return;
                }
            }
            var index = -1;
            for (var i = 0; i < this._selectedItems().length; i++) {
                if (item.target == this._selectedItems()[i].target) {
                    index = i;
                    break;
                }
            }
            if (index != -1) {
                this._selectedItems.splice(index, 1);
            }
            else {
                this._selectedItems.push(item);
            }
        };
        QueryBuilder.prototype.shouldBeChecked = function (item) {
            var index = -1;
            for (var i = 0; i < this._selectedItems().length; i++) {
                if (item.target == this._selectedItems()[i].target) {
                    index = i;
                    break;
                }
            }
            if (index !== -1)
                return true;
            return false;
        };
        QueryBuilder.prototype.executeAddAction = function () {
            if (this._selectedItems().length === 0) {
                this.showPopup("No item selected!");
                return;
            }
            var items = [];
            if (!this.canSelectMultiple()) {
                items.push({ DisplayName: "Add Condition", Value: (_a = this.addCondition).bind.apply(_a, [this].concat(this._selectedItems()[0].toArray())) });
                items.push({ DisplayName: "Add Link", Value: (_b = this.addLink).bind.apply(_b, [this].concat(this._selectedItems()[0].toArray())) });
                if (!(this.getFilterParent(this._selectedItems()[0].parents) instanceof FetchQueryBuilder.OEntity)
                    && !(this.getFilterParent(this._selectedItems()[0].parents, 1) instanceof FetchQueryBuilder.OEntity)
                    && this._selectedItems()[0].target instanceof FetchQueryBuilder.OCondition)
                    items.push({ DisplayName: 'Ungroup Item', Value: this._unGroupItems.bind(this, this._selectedItems()[0].parents, this._selectedItems()[0].filter, false) });
            }
            if (this.isGroupingEnabled()) {
                items.push({ DisplayName: "Create 'OR' group", Value: this._groupItems.bind(this, this._selectedItems()[0].filter, "or", this._selectedItems()[0].entity) });
                items.push({ DisplayName: "Create 'AND' group", Value: this._groupItems.bind(this, this._selectedItems()[0].filter, "and", this._selectedItems()[0].entity) });
                if (!(this.getFilterParent(this._selectedItems()[0].parents) instanceof FetchQueryBuilder.OEntity)
                    && !(this.getFilterParent(this._selectedItems()[0].parents, 1) instanceof FetchQueryBuilder.OEntity))
                    items.push({ DisplayName: 'Ungroup Items', Value: this._unGroupItems.bind(this, this._selectedItems()[0].parents, this._selectedItems()[0].filter, false) });
            }
            if (this.canAddConditionToGroup()) {
                if (this._selectedItems()[0].target instanceof FetchQueryBuilder.OCondition)
                    items.push({ DisplayName: "Move Condition", Value: this._moveCondition.bind(this, this._selectedItems()[0].target, this.getFilterParent(this._selectedItems()[0].parents), this.getFilterParent(this._selectedItems()[0].parents, 1), this._selectedItems()[1].target) });
                else
                    items.push({ DisplayName: "Move Condition", Value: this._moveCondition.bind(this, this._selectedItems()[1].target, this.getFilterParent(this._selectedItems()[1].parents), this.getFilterParent(this._selectedItems()[1].parents, 1), this._selectedItems()[0].target) });
            }
            if (this.canInvertFilter()) {
                var filter = this._selectedItems()[0].target;
                if (filter.type() === "or")
                    items.push({ DisplayName: "Change to AND", Value: this.onFilterTypeClick.bind(this, filter) });
                else
                    items.push({ DisplayName: "Change to OR", Value: this.onFilterTypeClick.bind(this, filter) });
                if (!(this.getFilterParent(this._selectedItems()[0].parents) instanceof FetchQueryBuilder.OEntity))
                    items.push({ DisplayName: 'Ungroup Items', Value: this._unGroupItems.bind(this, [this._selectedItems()[0].filter].concat(this._selectedItems()[0].parents), this._selectedItems()[0].filter, true) });
            }
            var popup = new MobileCRM.UI.MessageBox("Select Field");
            popup.items = items.map(function (a) {
                return a.DisplayName;
            });
            popup.multiLine = true;
            popup.defaultText = this._cmdCancel;
            popup.show(function (button) {
                var selected = null;
                for (var _i = 0, items_1 = items; _i < items_1.length; _i++) {
                    var i = items_1[_i];
                    if (i.DisplayName === button) {
                        selected = i;
                    }
                }
                if (selected) {
                    selected.Value();
                }
            }, MobileCRM.bridge.alert, this);
            var _a, _b;
        };
        QueryBuilder.prototype.executeDeleteAction = function () {
            if (this._selectedItems().length === 0) {
                this.showPopup("No item selected!");
                return;
            }
            for (var _i = 0, _a = this._selectedItems(); _i < _a.length; _i++) {
                var item = _a[_i];
                if (item.target instanceof FetchQueryBuilder.OCondition)
                    this.removeCondition(this.getFilterParent(item.parents), item.filter, item.target);
                else if (item.target instanceof FetchQueryBuilder.OLinkEntity) {
                    item.parents.splice(0, 1);
                    this.removeLink(item);
                }
                else if (item.target instanceof FetchQueryBuilder.OFilter) {
                    var parentFilter = this.getFilterParent(item.parents);
                    this.removeFilter(parentFilter, item.target);
                }
            }
            // Clear everything after delete
            this._selectedItems([]);
        };
        QueryBuilder.prototype.OnOrderByFieldClick = function (entity) {
            var _this = this;
            var properties = this.getAttributes(entity, true);
            var popup = new MobileCRM.UI.MessageBox("Select Field");
            popup.items = properties.map(function (a) {
                return a.DisplayName;
            });
            popup.multiLine = true;
            popup.defaultText = this._cmdCancel;
            popup.show(function (button) {
                var selected = null;
                for (var i = 0; i < properties.length; i++) {
                    if (properties[i].DisplayName === button) {
                        selected = properties[i];
                    }
                }
                if (selected) {
                    if (entity.order().length > 0) {
                        entity.order([]);
                    }
                    var order = new FetchQueryBuilder.OOrder();
                    order.attribute(selected.name);
                    order.descending(true);
                    entity.order.push(order);
                    _this.fetch().entity().order.valueHasMutated();
                }
            }, MobileCRM.bridge.alert, this);
        };
        QueryBuilder.prototype.OnOrderByDirectionClick = function (entity) {
            entity.order()[0].descending(entity.order()[0].descending() ? false : true);
        };
        QueryBuilder.prototype.addAttribute = function (entity) {
            var properties = this.getAttributes(entity);
            var popup = new MobileCRM.UI.MessageBox("Select Field");
            popup.items = properties.map(function (a) {
                return a.DisplayName;
            });
            popup.multiLine = true;
            popup.defaultText = this._cmdCancel;
            popup.show(function (button) {
                var selected = null;
                for (var i = 0; i < properties.length; i++) {
                    if (properties[i].DisplayName === button) {
                        selected = properties[i];
                    }
                }
                if (selected) {
                    if (entity.attributes() == null) {
                        entity.attributes([]);
                    }
                    var hasAttribute = entity.attributes().some(function (element, index, array) {
                        return element.name == selected.name;
                    });
                    if (!hasAttribute) {
                        entity.attributes.push(entity.toEntity().addAttribute(selected.name));
                        entity.attributes.valueHasMutated();
                    }
                }
            }, MobileCRM.bridge.alert, this);
        };
        QueryBuilder.prototype.removeAttribute = function (entity, attribute) {
            var attributes = entity.attributes();
            if (attributes) {
                for (var i = attributes.length - 1; i >= 0; i--) {
                    if (attributes[i].name === attribute) {
                        attributes.splice(i, 1);
                        entity.attributes(attributes);
                        break;
                    }
                }
            }
        };
        QueryBuilder.prototype.addLink = function (parents, entity) {
            var _this = this;
            var links = this.getLinks(entity);
            if (links.length === 0) {
                this.showPopup("No more entities to link");
                return;
            }
            var popup = new MobileCRM.UI.MessageBox("Link");
            popup.items = links.map(function (a) {
                return a.DisplayName;
            });
            popup.multiLine = true;
            popup.defaultText = this._cmdCancel;
            popup.show(function (button) {
                if (button) {
                    var selected = null;
                    for (var i = 0; i < links.length; i++) {
                        if (links[i].DisplayName === button) {
                            selected = links[i];
                            break;
                        }
                    }
                    if (selected) {
                        if (entity.linkentities() == null) {
                            entity.linkentities([]);
                        }
                        var hasLink = entity.linkentities().some(function (element, index, array) {
                            return element.name == selected.entity && element.to == selected.to && element.from == selected.from;
                        });
                        if (!hasLink) {
                            var link = new FetchQueryBuilder.OLinkEntity();
                            link.name = selected.entity;
                            link.from(selected.from);
                            link.to(selected.to);
                            link.linktype("inner");
                            link.alias(_this._linkAlias.generateNew());
                            link.filter(new FetchQueryBuilder.OFilter(link.name));
                            entity.linkentities.push(link);
                            entity.linkentities.valueHasMutated();
                        }
                    }
                }
            }, MobileCRM.bridge.alert, this);
        };
        QueryBuilder.prototype.changeLinkType = function (link) {
            if (link.linktype() === "inner")
                link.linktype("outer");
            else
                link.linktype("inner");
        };
        QueryBuilder.prototype.removeAliasConditions = function (parent, filter, alias) {
            if (filter.filters()) {
                for (var _i = 0, _a = filter.filters(); _i < _a.length; _i++) {
                    var f = _a[_i];
                    this.removeAliasConditions(filter, f, alias);
                }
            }
            if (filter.conditions()) {
                for (var _b = 0, _c = filter.conditions(); _b < _c.length; _b++) {
                    var cond = _c[_b];
                    if (cond.entityname() === alias) {
                        this.removeCondition(parent, filter, cond);
                    }
                }
            }
        };
        QueryBuilder.prototype.removeLinkConditions = function (selectedItem) {
            if (selectedItem.entity instanceof FetchQueryBuilder.OLinkEntity && selectedItem.entity.alias()) {
                for (var _i = 0, _a = selectedItem.parents; _i < _a.length; _i++) {
                    var parent_1 = _a[_i];
                    if (parent_1 instanceof FetchQueryBuilder.OEntity && parent_1.filter() && parent_1.filter().filters()) {
                        for (var _b = 0, _c = parent_1.filter().filters(); _b < _c.length; _b++) {
                            var f = _c[_b];
                            this.removeAliasConditions(parent_1, f, selectedItem.entity.alias());
                        }
                        if (parent_1.filter && parent_1.filter().conditions()) {
                            for (var _d = 0, _e = parent_1.filter().conditions(); _d < _e.length; _d++) {
                                var c = _e[_d];
                                if (c.entityname() === selectedItem.entity.alias()) {
                                    this.removeCondition(parent_1, parent_1.filter(), c);
                                }
                            }
                        }
                    }
                }
            }
        };
        QueryBuilder.prototype.removeLink = function (selectedItem) {
            var entity = this.getEntityParent(selectedItem.parents);
            if (!entity || !(selectedItem.entity instanceof FetchQueryBuilder.OLinkEntity))
                return;
            selectedItem.parents.unshift(entity);
            this.removeLinkConditions(selectedItem);
            var index = entity.linkentities().indexOf(selectedItem.entity);
            if (index !== -1)
                entity.linkentities().splice(index, 1);
            entity.linkentities.valueHasMutated();
        };
        QueryBuilder.prototype.addCondition = function (parents, entity, filter) {
            var _this = this;
            var conditions = this.getFilterAttributes(parents);
            var andFilter = "Add 'And' Group";
            var orFilter = "Add 'Or' Group";
            var popup = new MobileCRM.UI.MessageBox("Condition");
            for (var _i = 0, conditions_1 = conditions; _i < conditions_1.length; _i++) {
                var cond = conditions_1[_i];
                var alias = cond[0];
                var entityName = cond[1];
                for (var i = 2; i < cond.length; i++) {
                    popup.items.push(this.getDisplayName(entityName, cond[i].name, alias));
                }
            }
            // Add OR and AND always so branch like AND	-	OR
            //											-	OR
            // is possible to do without any other unwanted condition
            popup.items = [andFilter, orFilter].concat(popup.items);
            popup.multiLine = true;
            popup.defaultText = this._cmdCancel;
            popup.show(function (button) {
                if (button === andFilter) {
                    var newFilter = _this.addFilter(filter, "and", entity);
                }
                else if (button === orFilter) {
                    var newFilter = _this.addFilter(filter, "or", entity);
                }
                else {
                    var selected = null;
                    var alias = null;
                    for (var i = 0; i < conditions.length; i++) {
                        for (var j = 1; j < conditions[i].length; j++) {
                            if (conditions[i][0]) {
                                if ((conditions[i][0] + '.' + conditions[i][j].DisplayName) === button) {
                                    selected = conditions[i][j];
                                    alias = conditions[i][0];
                                    break;
                                }
                            }
                            else {
                                if (conditions[i][j].DisplayName === button) {
                                    selected = conditions[i][j];
                                    break;
                                }
                            }
                        }
                    }
                    if (selected) {
                        if (filter === null) {
                            entity.filter(new FetchQueryBuilder.OFilter(entity.name));
                            filter = entity.filter();
                            filter.type("and");
                        }
                        if (filter.conditions() === null) {
                            filter.conditions([]);
                        }
                        _this._appendConditionToFilter(selected.name, alias, filter, entity);
                    }
                }
            }, MobileCRM.bridge.alert, this);
        };
        QueryBuilder.prototype._appendConditionToFilter = function (attr, alias, filter, entity, operator, value, values) {
            if (operator === void 0) { operator = null; }
            if (value === void 0) { value = null; }
            if (values === void 0) { values = null; }
            var cond = new FetchQueryBuilder.OCondition(entity.name);
            cond.attribute(attr);
            if (value)
                cond.value(value);
            else
                cond.value(null);
            if (values)
                cond.values(values);
            else
                cond.values(null);
            var entityName = entity.name;
            if (alias) {
                entityName = this.getLinkedEntityByAlias(entity, alias).name;
            }
            var attribute = this.getAttribute(entityName, attr);
            if (operator) {
                cond.operator(operator);
            }
            else if (attribute) {
                var operators = cond.getOperators(attribute);
                cond.operator(operators[0].Value);
            }
            else {
                cond.operator("eq");
            }
            cond.isValueEditable(FetchQueryBuilder.ConditionOperator.getArity(cond.operator()) != 0);
            if (alias)
                cond.entityname(alias);
            else
                cond.entityname(null);
            filter.conditions.push(cond);
            filter.conditions.valueHasMutated();
        };
        QueryBuilder.prototype.editCondition = function (parents, condition) {
            var _this = this;
            if (!condition.isSelected()) {
                var parentFilter = this.getFilterParent(parents);
                if (parentFilter instanceof FetchQueryBuilder.OEntity)
                    parentFilter = parentFilter.filter();
                this.onCheckBoxClicked(parents, this.getEntityParent(parents), parentFilter, condition, event);
            }
            var conditions = this.getFilterAttributes(parents);
            var filter = this.getFilterParent(parents);
            var popup = new MobileCRM.UI.MessageBox("Condition");
            for (var _i = 0, conditions_2 = conditions; _i < conditions_2.length; _i++) {
                var cond = conditions_2[_i];
                var alias = cond[0];
                var entityName = cond[1];
                for (var i = 2; i < cond.length; i++) {
                    popup.items.push(this.getDisplayName(entityName, cond[i].name, alias));
                }
            }
            popup.multiLine = true;
            popup.defaultText = this._cmdCancel;
            popup.show(function (button) {
                var selected = null;
                var alias = null;
                for (var i = 0; i < conditions.length; i++) {
                    for (var j = 1; j < conditions[i].length; j++) {
                        if (conditions[i][0]) {
                            if ((conditions[i][0] + '.' + conditions[i][j].DisplayName) === button) {
                                selected = conditions[i][j];
                                alias = conditions[i][0];
                                break;
                            }
                        }
                        else {
                            if (conditions[i][j].DisplayName === button) {
                                selected = conditions[i][j];
                                break;
                            }
                        }
                    }
                }
                if (selected) {
                    if (filter === null || filter.conditions == null) {
                        return;
                    }
                    condition.attribute(selected.name);
                    condition.value(null);
                    condition.values(null);
                    var entity = _this.getEntityParent(parents);
                    var entityName = entity.name;
                    if (alias)
                        entityName = _this.getLinkedEntityByAlias(entity, alias).name;
                    var attribute = _this.getAttribute(entityName, selected.name);
                    var operators = condition.getOperators(attribute);
                    condition.operator(operators[0].Value);
                    condition.isValueEditable(FetchQueryBuilder.ConditionOperator.getArity(condition.operator()) != 0);
                    _this._selectedEditor = null;
                    if (alias)
                        condition.entityname(alias);
                    else
                        condition.entityname(null);
                }
            }, MobileCRM.bridge.alert, this);
        };
        QueryBuilder.prototype.removeCondition = function (parent, filter, condition) {
            if (filter instanceof FetchQueryBuilder.OEntity)
                filter = filter.filter();
            if (filter.conditions().length === 0 || !filter.conditions().some(function (v) {
                return v === condition;
            }))
                return;
            filter.conditions.remove(condition);
            if (filter.conditions().length === 0 && (!filter.filters() || filter.filters().length === 0)) {
                this.removeFilter(parent, filter);
            }
        };
        /*public removeCondition(parent: OEntity | OFilter, filter: OFilter, condition: OCondition) {
            filter.conditions.remove(condition);

        }*/
        QueryBuilder.prototype._groupItems = function (filter, operator, parent, items) {
            var newFilter = this.addFilter(filter, operator, parent);
            for (var _i = 0, _a = this._selectedItems(); _i < _a.length; _i++) {
                var item = _a[_i];
                if (item.target instanceof FetchQueryBuilder.OCondition) {
                    var cond = item.target;
                    this._appendConditionToFilter(cond.attribute(), cond.entityname(), newFilter, parent, cond.operator(), cond.value(), cond.values());
                    filter.conditions.remove(cond);
                }
            }
            this._selectedItems([]);
        };
        QueryBuilder.prototype._unGroupItems = function (parents, filter, all) {
            if (filter instanceof FetchQueryBuilder.OEntity)
                return;
            var parentFilter = this.getFilterParent(parents, 1);
            if (parentFilter instanceof FetchQueryBuilder.OEntity)
                return;
            var _loop_3 = function (c) {
                if (!all && !this_2._selectedItems().some(function (v, i, a) {
                    if (v.target === filter.conditions()[c])
                        return true;
                    return false;
                }))
                    return out_c_1 = c, "continue";
                if (parentFilter instanceof FetchQueryBuilder.OEntity) {
                    parentFilter.filter().conditions.push(filter.conditions()[c]);
                    filter.conditions.remove(filter.conditions()[c--]);
                }
                else if (parentFilter instanceof FetchQueryBuilder.OFilter) {
                    parentFilter.conditions.push(filter.conditions()[c]);
                    filter.conditions.remove(filter.conditions()[c--]);
                }
                out_c_1 = c;
            };
            var this_2 = this, out_c_1;
            for (var c = 0; c < filter.conditions().length; c++) {
                _loop_3(c);
                c = out_c_1;
            }
            if (filter.conditions().length === 1) {
                parentFilter.conditions.push(filter.conditions()[0]);
                filter.conditions.pop();
            }
            if (parentFilter instanceof FetchQueryBuilder.OFilter && filter.conditions().length === 0) {
                if (filter.filters().length > 0)
                    for (var _i = 0, _a = filter.filters(); _i < _a.length; _i++) {
                        var f = _a[_i];
                        parentFilter.filters.push(f);
                    }
                parentFilter.filters.remove(filter);
                parentFilter.conditions.valueHasMutated();
            }
            this._selectedItems([]);
        };
        QueryBuilder.prototype._moveCondition = function (cond, filter, parentFilter, targetFilter) {
            if (!targetFilter.conditions())
                targetFilter.conditions([]);
            targetFilter.conditions.push(cond);
            if (filter instanceof FetchQueryBuilder.OEntity) {
                filter.filter().conditions.remove(cond);
            }
            else {
                filter.conditions.remove(cond);
                if (!filter.conditions() && !filter.filters)
                    if (parentFilter instanceof FetchQueryBuilder.OFilter)
                        parentFilter.filters.remove(filter);
            }
            this._selectedItems([]);
        };
        QueryBuilder.prototype.addFilter = function (filter, operator, parent) {
            if (operator) {
                if (filter.filters === null) {
                    filter.filters([]);
                }
                var newFilter = new FetchQueryBuilder.OFilter(parent.name);
                newFilter.type(operator);
                filter.filters.push(newFilter);
                filter.filters.valueHasMutated();
                return newFilter;
            }
        };
        QueryBuilder.prototype.removeFilter = function (parentFilter, filter) {
            if (parentFilter instanceof FetchQueryBuilder.OEntity)
                parentFilter.filter(null);
            else if (parentFilter instanceof FetchQueryBuilder.OFilter) {
                var filters = parentFilter.filters();
                if (filters) {
                    for (var i = filters.length - 1; i >= 0; i--) {
                        if (filters[i] === filter) {
                            filters.splice(i, 1);
                            parentFilter.filters(filters);
                            break;
                        }
                    }
                }
            }
        };
        QueryBuilder.prototype.onFilterTypeClick = function (filter) {
            if (filter.type() === "or")
                filter.type("and");
            else
                filter.type("or");
        };
        QueryBuilder.prototype.onConditionClick = function (e, parents, condition) {
            var _this = this;
            e.stopPropagation();
            if (!condition.isSelected()) {
                var parentFilter = this.getFilterParent(parents);
                if (parentFilter instanceof FetchQueryBuilder.OEntity)
                    parentFilter = parentFilter.filter();
                this.onCheckBoxClicked(parents, this.getEntityParent(parents), parentFilter, condition, event);
            }
            var target = $(e.target);
            if (target.is("select") || target.is("option")) {
                return;
            }
            if (target.has("select").length > 0) {
                var field = target.find("select");
                this.showEditor(field, true);
                return;
            }
            var field = $("<select style='position: absolute; top:0px; left:0px;width:100%; margin-top:1px'/>");
            var entity = this.getEntityParent(parents);
            if (condition.entityname) {
                var linkedEntity = this.getLinkedEntityByAlias(entity, condition.entityname());
                if (linkedEntity)
                    entity = linkedEntity;
            }
            var attribute = this.getAttribute(entity.name, condition.attribute());
            if (!attribute) {
                return;
            }
            var operators = condition.getOperators(attribute);
            var popup = new MobileCRM.UI.MessageBox("Condition");
            popup.items = operators.map(function (a) {
                return a.Key;
            });
            popup.multiLine = true;
            popup.defaultText = this._cmdCancel;
            popup.show(function (button) {
                condition.operator(FetchQueryBuilder.ConditionOperator.getValue(button));
                if (condition.operator() === FetchQueryBuilder.ConditionOperator.operators.Contain.Value
                    || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotContain.Value)
                    condition.stringOperator(button);
                else
                    condition.stringOperator(null);
                condition.isValueEditable(FetchQueryBuilder.ConditionOperator.getArity(condition.operator()) != 0);
                condition.value(null);
                condition.values([]);
                condition.uiname(null);
                condition.uitype(null);
                _this._selectedEditor = null;
            });
        };
        QueryBuilder.prototype.showEditor = function (field, show) {
            if (show) {
                if (!this._selectedEditor)
                    this._selectedEditor = field;
                this._selectedEditor.show();
            }
            else if (this._selectedEditor) {
                this._selectedEditor.parent().css("flex-basis", "auto");
                this._selectedEditor.parent().css("min-width", "0px");
                this._selectedEditor = null;
                if (field) {
                    if (field.onHide) {
                        field.onHide();
                    }
                    field.hide();
                }
            }
        };
        QueryBuilder.prototype.getConditionOptions = function (condition, parents) {
            var options = [];
            var entity = this.getEntityParent(parents);
            var attribute = this.getAttribute(entity.name, condition.attribute());
            if (!attribute) {
                return null;
            }
            for (var option in attribute.options) {
                options.push({ "value": option, "label": attribute.options[option] });
            }
            return options;
        };
        QueryBuilder.prototype._getBestPosition = function (target, width, height) {
            var _top = 0, _left = 0, parent;
            parent = target;
            _top += parent.offsetHeight;
            while (parent != null) {
                _top += parent.offsetTop;
                parent = parent.offsetParent;
            }
            parent = target;
            _left += (parent.offsetWidth / 2 - width / 2);
            _left += parent.offsetLeft;
            parent = parent.offsetParent;
            while (parent != null) {
                _left += parent.offsetLeft;
                parent = parent.offsetParent;
            }
            var maxWidth = window.innerWidth
                || document.documentElement.clientWidth
                || document.body.clientWidth;
            var maxHeight = window.innerHeight
                || document.documentElement.clientHeight
                || document.body.clientHeight;
            if ((_left + width) > maxWidth)
                _left -= (_left + width - maxWidth);
            if ((_top + height) > maxHeight)
                _top -= (_top + height - maxHeight) - target.offsetHeight;
            return ({
                top: _top,
                left: _left,
                height: height,
                width: width,
                parentHeight: target.offsetHeight,
                parentWidth: target.offsetWidth
            });
        };
        QueryBuilder.prototype.onConditionValueClick = function (parents, condition, e) {
            var _this = this;
            e.stopPropagation();
            if (!condition.isSelected()) {
                var parentFilter = this.getFilterParent(parents);
                if (parentFilter instanceof FetchQueryBuilder.OEntity)
                    parentFilter = parentFilter.filter();
                this.onCheckBoxClicked(parents, this.getEntityParent(parents), parentFilter, condition, event);
            }
            var target = $(e.target);
            // Ignore if the target is currently edited field
            if (this._selectedEditor && this._selectedEditor[0] === target[0]) {
                return;
            }
            else if (this._selectedEditor) {
                this.showEditor(this._selectedEditor, false);
            }
            var entity = this.getEntityParent(parents);
            if (condition.entityname) {
                var linkedEntity = this.getLinkedEntityByAlias(entity, condition.entityname());
                if (linkedEntity)
                    entity = linkedEntity;
            }
            var attribute = this.getAttribute(entity.name, condition.attribute());
            if (!attribute) {
                return;
            }
            var editorKey = EditorType.Empty;
            if (FetchQueryBuilder.ConditionOperator.getArity(condition.operator()) > 0) {
                if (attribute.type === CrmType.Memo
                    || attribute.type === CrmType.String)
                    editorKey = EditorType.String;
                if (attribute.isReference || attribute.type === CrmType.PrimaryKey) {
                    if (condition.operator() === FetchQueryBuilder.ConditionOperator.operators.Contain.Value
                        || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotContain.Value)
                        editorKey = EditorType.String;
                    else
                        editorKey = EditorType.Lookup;
                }
                else if (attribute.isPicklist || attribute.isStringList) {
                    if (condition.operator() === FetchQueryBuilder.ConditionOperator.operators.Contain.Value
                        || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotContain.Value)
                        editorKey = EditorType.String;
                    else
                        editorKey = EditorType.Picklist;
                }
                else {
                    var type = attribute.type;
                    if (type === CrmType.DateTime) {
                        if (condition.operator().substring(0, "on".length) === "on")
                            editorKey = EditorType.Date;
                        else if (condition.operator().search("-x-") != -1)
                            editorKey = EditorType.Number;
                    }
                    else if (type === CrmType.Integer || type === CrmType.Float || type === CrmType.Double || type === CrmType.Decimal || type === CrmType.Money)
                        editorKey = EditorType.Number;
                }
            }
            var editor = null;
            if (EditorType.String & editorKey) {
                editor = $("<input type='text' />");
                editor.focusout(function (e) {
                    if ($(e.target)[0].parentElement !== editor[0].parentElement)
                        _this.showEditor(editor, false);
                });
                editor.onHide = function () {
                    var val = editor.val();
                    if (val !== condition.value()) {
                        var wildcards = FetchQueryBuilder.ConditionOperator.getWildcards(condition.stringOperator());
                        condition.value(wildcards.WildcardStart + val + wildcards.WildcardEnd);
                    }
                    condition.value.valueHasMutated();
                };
                editor.keyup(function (event) {
                    if (event.keyCode == 13 && _this._selectedEditor) {
                        _this.showEditor(_this._selectedEditor, false);
                    }
                });
                this._appendEditor(target, editor, editorKey, condition.value());
            }
            if (EditorType.Number & editorKey) {
                editor = $("<input type='number' />");
                editor.focusout(function (e) {
                    if ($(e.target)[0].parentElement !== editor[0].parentElement)
                        _this.showEditor(editor, false);
                });
                editor.onHide = function () {
                    var val = parseInt(editor.val());
                    if (attribute.type === CrmType.Float
                        || attribute.type === CrmType.Double
                        || attribute.type === CrmType.Money)
                        val = parseFloat(editor.val());
                    if (val && val !== condition.value()) {
                        condition.value(val);
                    }
                    else if (!val) {
                        condition.value(null);
                    }
                    condition.value.valueHasMutated();
                };
                editor.keyup(function (event) {
                    if (event.keyCode == 13 && _this._selectedEditor) {
                        _this.showEditor(_this._selectedEditor, false);
                    }
                });
                this._appendEditor(target, editor, editorKey, condition.value());
            }
            if (EditorType.Date & editorKey) {
                var bestPosition = this._getBestPosition(e.target, this._datePicker.getDimension().width, this._datePicker.getDimension().height);
                this._datePicker.datePickerClicked.add(this, function (sender, e) {
                    condition.value(_this._formatISOLocalDate(e.item.date, false, false));
                });
                this._datePicker.showRescoDatePicker();
                this._datePicker.updatePosition(bestPosition.top, bestPosition.left, undefined, true);
                this._datePicker.datePickerBlur.add(this, function (e) {
                    _this._datePicker.hideRescoDatePicker();
                    _this._datePicker.datePickerClicked.clear();
                    _this._datePicker.datePickerBlur.clear();
                });
                this._appendEditor(target, editor, editorKey, condition.value());
            }
            if (EditorType.Lookup & editorKey) {
                var lookupForm = new MobileCRM.UI.LookupForm();
                for (var _i = 0, _a = attribute.targets; _i < _a.length; _i++) {
                    var target_2 = _a[_i];
                    lookupForm.addView(target_2, null, null);
                }
                if (attribute.type === CrmType.PrimaryKey) {
                    lookupForm.addView(entity.name, null, null);
                }
                lookupForm.allowNull = true; // Allow choosing empty value
                lookupForm.show(function (accountRef) {
                    condition.value(accountRef ? accountRef.id : null);
                    condition.uiname(accountRef ? accountRef.primaryName : null);
                }, MobileCRM.bridge.alert, null);
                this._appendEditor(target, editor, editorKey, condition.value());
            }
            if (EditorType.Picklist & editorKey) {
                editor = $("<div class='picklist'></div>");
                var meta = attribute;
                var selectedOptions = !condition.value() ? condition.values() : [condition.value()];
                for (var optionValue in meta.options) {
                    var selected = false;
                    if (selectedOptions != null) {
                        for (var j = 0; j < selectedOptions.length; j++) {
                            if (optionValue == selectedOptions[j])
                                selected = true;
                        }
                    }
                    editor.append($("<div><input id=" + (entity.name + condition.attribute() + meta.options[optionValue] + optionValue) + " type= 'checkbox' " + (selected ? "checked" : "") + " value= '" + optionValue + "' /><label for=" + (entity.name + condition.attribute() + meta.options[optionValue] + optionValue) + ">" + meta.options[optionValue] + "</label></div>"));
                }
                var stringListOptions_1 = MobileCRM.Metadata.getStringListOptions(entity.name, condition.attribute());
                if (meta.isStringList) {
                    for (var option in stringListOptions_1) {
                        var selected = false;
                        if (selectedOptions != null) {
                            for (var j_1 in selectedOptions) {
                                if (selectedOptions[j_1]) {
                                    var optionParts = selectedOptions[j_1].split(";");
                                    for (var k in optionParts) {
                                        if (stringListOptions_1[option] == (optionParts[k]).trim())
                                            selected = true;
                                    }
                                }
                            }
                        }
                        if (meta.isMultiValueStringList)
                            editor.append($("<div><input id='" + (entity.name + condition.attribute() + stringListOptions_1[option] + option) + "' class='global-checkbox' type='checkbox' " + (selected ? "checked" : "") + " value= '" + option + "' /><label for='" + (entity.name + condition.attribute() + stringListOptions_1[option] + option) + "'>" + stringListOptions_1[option] + "</label></div>"));
                        else
                            editor.append($("<div><input name='" + (entity.name + condition.attribute()) + "' id='" + (entity.name + condition.attribute() + stringListOptions_1[option] + option) + "' type='radio' " + (selected ? 'checked' : '') + " value= '" + option + "' /><label for='" + (entity.name + condition.attribute() + stringListOptions_1[option] + option) + "'>" + stringListOptions_1[option] + "</label></div>"));
                    }
                    if (meta.isStringListWithInput) {
                        var contains = false;
                        var values = [];
                        if ((condition.values() && condition.values().length > 0) || condition.value())
                            values = condition.values() ? condition.values() : [condition.value()];
                        var vals = [];
                        for (var _b = 0, values_2 = values; _b < values_2.length; _b++) {
                            var v = values_2[_b];
                            var strVals = v.split(";");
                            for (var _c = 0, strVals_1 = strVals; _c < strVals_1.length; _c++) {
                                var val = strVals_1[_c];
                                contains = false;
                                for (var s in stringListOptions_1) {
                                    if (stringListOptions_1[s] === val) {
                                        contains = true;
                                        break;
                                    }
                                }
                                if (!contains) {
                                    vals.push(val);
                                }
                            }
                        }
                        var customInput = vals.join(";");
                        if (!customInput)
                            editor.append($("<input placeholder='Custom value...' type='text' />"));
                        else
                            editor.append($("<input placeholder='Custom value...' value='" + customInput + "' type='text' />"));
                    }
                }
                if (editor.children().length === 0) {
                    this.showPopup("No options available");
                    return;
                }
                editor.click(function (e) {
                    e.stopPropagation();
                });
                editor.onHide = function () {
                    var selected = editor.find(":checked").map(function () {
                        if (!stringListOptions_1[this.value])
                            return parseInt(this.value);
                    }).toArray();
                    var stringOptionsSelected = editor.find(":checked").map(function () {
                        if (stringListOptions_1[this.value])
                            return this.nextSibling.innerText;
                    }).toArray();
                    var selectedStrings = stringOptionsSelected.join(";");
                    if (attribute.isStringListWithInput && editor.find("input[type=text]")[0].value) {
                        if (attribute.isSingleValueStringList)
                            selectedStrings = editor.find("input[type=text]")[0].value;
                        else
                            selectedStrings = stringOptionsSelected.concat([editor.find("input[type=text]")[0].value]).join(";");
                    }
                    selected = selected.concat([selectedStrings]);
                    if (selected && selected.length <= 1) {
                        condition.value(selected.length === 1 ? selected[0] : null);
                        condition.values(null);
                        if (condition.operator() === FetchQueryBuilder.ConditionOperator.operators.In.Value
                            || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.Equal.Value)
                            condition.operator(FetchQueryBuilder.ConditionOperator.operators.Equal.Value);
                        else if (condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotIn.Value
                            || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotEqual.Value)
                            condition.operator(FetchQueryBuilder.ConditionOperator.operators.NotEqual.Value);
                    }
                    else {
                        condition.value(null);
                        condition.values(selected);
                        if (condition.operator() === FetchQueryBuilder.ConditionOperator.operators.In.Value
                            || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.Equal.Value)
                            condition.operator(FetchQueryBuilder.ConditionOperator.operators.In.Value);
                        else if (condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotIn.Value
                            || condition.operator() === FetchQueryBuilder.ConditionOperator.operators.NotEqual.Value)
                            condition.operator(FetchQueryBuilder.ConditionOperator.operators.NotIn.Value);
                    }
                };
                editor.css("text-align", "left");
                this._appendEditor(target, editor, editorKey, condition.value());
            }
        };
        QueryBuilder.prototype._appendEditor = function (target, editor, editorType, value) {
            if (editorType & (EditorType.Lookup | EditorType.Date)) {
                editor = null;
                return;
            }
            if (editorType & EditorType.String || editorType & EditorType.Number) {
                target.css("min-width", target.width() + "px");
                target.css("flex-basis", "0");
                editor.css("max-width", "calc(100% - 10px)");
                value = this.removeWildcards(value);
                target[0].innerText = "";
            }
            else {
                editor.css("position", "absolute");
            }
            editor.prop("value", value);
            target.append(editor);
            this.showEditor(editor, true);
            editor.focus();
        };
        QueryBuilder.prototype._formatISOLocalDate = function (date, includeTime, includeOffset) {
            var tzo = -date.getTimezoneOffset(), dif = tzo >= 0 ? '+' : '-', pad = function (num) {
                var norm = Math.abs(Math.floor(num));
                return (norm < 10 ? '0' : '') + norm;
            };
            if (includeTime && includeTime)
                return date.getFullYear()
                    + '-' + pad(date.getMonth() + 1)
                    + '-' + pad(date.getDate())
                    + 'T' + pad(date.getHours())
                    + ':' + pad(date.getMinutes())
                    + ':' + pad(date.getSeconds())
                    + dif + pad(tzo / 60)
                    + ':' + pad(tzo % 60);
            else if (includeTime)
                return date.getFullYear()
                    + '-' + pad(date.getMonth() + 1)
                    + '-' + pad(date.getDate())
                    + 'T' + pad(date.getHours())
                    + ':' + pad(date.getMinutes())
                    + ':' + pad(date.getSeconds());
            else if (includeOffset)
                return date.getFullYear()
                    + '-' + pad(date.getMonth() + 1)
                    + '-' + pad(date.getDate())
                    + dif + pad(tzo / 60)
                    + ':' + pad(tzo % 60);
            else
                return date.getFullYear()
                    + '-' + pad(date.getMonth() + 1)
                    + '-' + pad(date.getDate());
        };
        /**
         * Generates random ID with passed in length
         * @param length The length of the generated ID, must be multiple of 4
         */
        QueryBuilder.prototype._generateIdentifier = function (length) {
            if (length % 4 !== 0)
                throw "Invalid length of the ID";
            var rID = "";
            while (length > 0) {
                rID += Math.random().toString(16).slice(-5).toLowerCase();
                length /= 4;
            }
            return rID;
        };
        /**
         * Refreshes the DOM on the change
         */
        QueryBuilder.prototype.onChange = function () {
            $('body').addClass('waiting');
            MobileCRM.UI.IFrameForm.setDirty(true);
            this.fetch.valueHasMutated();
            $('body').removeClass('waiting');
        };
        QueryBuilder.prototype.createObjectFromObservable = function (parent) {
            var retObj;
            for (var attr in parent) {
                if (parent instanceof FetchQueryBuilder.OLinkEntity ||
                    parent instanceof FetchQueryBuilder.OEntity ||
                    parent instanceof FetchQueryBuilder.OCondition ||
                    parent instanceof FetchQueryBuilder.OFetch ||
                    parent instanceof FetchQueryBuilder.OOrder) {
                    retObj[attr] = this.createObjectFromObservable(parent[attr]());
                }
                else if (parent instanceof Array) {
                    retObj[attr] = [];
                    for (var i in retObj[attr]) {
                        retObj[attr].push(this.createObjectFromObservable(retObj[attr][i]));
                    }
                }
                else {
                    return parent;
                }
            }
            return retObj;
        };
        /**
         * Saves the fetch to the properties of currently opened entity
         * @param form
         */
        QueryBuilder.prototype.onSave = function (form) {
            var _this = this;
            var fetch = this.fetch().toFetch();
            var handler = form.suspendSave();
            return fetch.serializeToXml(function (fetchXml) {
                var obj = JSON.stringify({
                    "viewName": _this.viewName(),
                    "fetchXml": fetchXml
                });
                MobileCRM.bridge.command("onSaveReady", obj);
                handler.resumeSave(null);
                return true;
            }, function (err) {
                handler.resumeSave(err);
                return false;
            });
        };
        QueryBuilder.prototype.resetSelectedItems = function () {
            this._selectedItems([]);
            if (this.fetch().entity() instanceof FetchQueryBuilder.OEntity) {
                var parents = [this.fetch().entity(), this.fetch()];
                this._selectedItems([]);
                //this.fetch().entity().isSelected(true);
                var selectedItem = new SelectedItem(parents, this.fetch().entity(), this.fetch().entity().filter(), this.fetch().entity());
                this._selectedItems.push(selectedItem);
            }
        };
        QueryBuilder.prototype.showPopup = function (title, message, buttons, success, error) {
            if (message === void 0) { message = null; }
            if (buttons === void 0) { buttons = ["OK"]; }
            if (success === void 0) { success = function () { }; }
            if (error === void 0) { error = null; }
            var mb = new MobileCRM.UI.MessageBox(title, message);
            mb.items = buttons;
            mb.multiLine = true;
            mb.show(success, error, this);
        };
        QueryBuilder.prototype.fadedClicked = function () {
            this._selectedItems([]);
        };
        return QueryBuilder;
    }());
    FetchQueryBuilder.QueryBuilder = QueryBuilder;
})(FetchQueryBuilder || (FetchQueryBuilder = {}));
