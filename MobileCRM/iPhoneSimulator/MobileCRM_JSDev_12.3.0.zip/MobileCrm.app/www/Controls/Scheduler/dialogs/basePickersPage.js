///<reference path="../../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../data/enums.ts" />
///<reference path="../data/settings.ts" />
///<reference path="../container.ts" />
///<reference path="baseDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var PageExpandedCollapsedEventArgs = (function () {
                function PageExpandedCollapsedEventArgs(pageId, isCollapsed) {
                    this._pageId = pageId;
                    this._isCollapsed = isCollapsed;
                }
                Object.defineProperty(PageExpandedCollapsedEventArgs.prototype, "pageId", {
                    get: function () {
                        return this._pageId;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(PageExpandedCollapsedEventArgs.prototype, "isCollapsed", {
                    get: function () {
                        return this._isCollapsed;
                    },
                    enumerable: true,
                    configurable: true
                });
                return PageExpandedCollapsedEventArgs;
            }());
            Scheduler.PageExpandedCollapsedEventArgs = PageExpandedCollapsedEventArgs;
            var BasePage = (function () {
                function BasePage(id, tabLocalizationKey, tabName, tabContentLocalizationKey, tabContentName, isCollapsable) {
                    //private _tabContentBodyElement: JQuery;
                    this._isCollapsable = false;
                    this._isCollapsed = false;
                    this.onExpandedCollapsed = new Resco.Event(this);
                    this._id = id;
                    this._tabLocalizationKey = tabLocalizationKey;
                    this._tabName = tabName;
                    this._tabContentLocalizationKey = tabContentLocalizationKey;
                    this._tabContentName = tabContentName;
                    this._isCollapsable = isCollapsable || false;
                    this._tabElement = this._createTabElement();
                    this._tabContentElement = this._createTabContentElement();
                    if (this._isCollapsable) {
                        this._updateCollapseImage();
                        this._addCollapseEvent();
                    }
                }
                Object.defineProperty(BasePage.prototype, "id", {
                    get: function () {
                        return this._id;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasePage.prototype, "tabElement", {
                    get: function () {
                        return this._tabElement;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasePage.prototype, "tabContentElement", {
                    get: function () {
                        return this._tabContentElement;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasePage.prototype, "tabContentBodyElement", {
                    get: function () {
                        return this.tabContentElement.find(".rescoTabBodyContent");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasePage.prototype, "isCollapsed", {
                    get: function () {
                        return this._isCollapsed;
                    },
                    set: function (value) {
                        if (this._isCollapsable) {
                            if (value !== this.isCollapsed) {
                                this._isCollapsed = value;
                                this._updateCollapseImage();
                                this.tabContentBodyElement.css("display", this.isCollapsed ? "none" : "");
                                this.onExpandedCollapsed.raise(new PageExpandedCollapsedEventArgs(this.id, this.isCollapsed));
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                BasePage.prototype._createTabElement = function () {
                    var template = '<li><a data-id="tab_' + this._id + '" href="javascript: void(0)" class="rescoTabButton text" draggable="false" data-localization="' + this._tabLocalizationKey + '">' + this._tabName + '</a></li>\"';
                    return $(template);
                };
                BasePage.prototype._createTabContentElement = function () {
                    var template1 = '\
				<div data-id="' + this._id + '" class="rescoTabContent">\
					<div class="rescoTabHeaderContent">\
						<p class="title" data-localization="' + this._tabContentLocalizationKey + '">' + this._tabContentName + '</p>\
				';
                    var template2 = '\
				<div class="pageCollapsableImage">\
				</div>';
                    var template3 = '\
					</div>\
					<div class="rescoTabBodyContent"></div>\
				</div>';
                    return $(template1 + (this._isCollapsable ? template2 : "") + template3);
                };
                BasePage.prototype.addBodyContent = function (template) {
                    this.tabContentBodyElement.append(template);
                };
                BasePage.prototype.removeRescoComponents = function () {
                    // this method can remove used resources/components in derived classes
                };
                BasePage.prototype._updateCollapseImage = function () {
                    this.tabContentElement.find(".pageCollapsableImage").css("background-image", "url(" + Scheduler.Container.imageFolder + (this.isCollapsed ? "arrow_down_solid.png" : "arrow_up_solid.png") + ")");
                };
                BasePage.prototype._addCollapseEvent = function () {
                    var _this = this;
                    this.tabContentElement.find(".pageCollapsableImage").click(function () {
                        _this._onCollapseClicked();
                    });
                };
                BasePage.prototype._onCollapseClicked = function () {
                    this.isCollapsed = !this.isCollapsed;
                };
                return BasePage;
            }());
            Scheduler.BasePage = BasePage;
            var BasePickersPage = (function (_super) {
                __extends(BasePickersPage, _super);
                function BasePickersPage() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                BasePickersPage.prototype.createRescoInputDatePicker = function (element, date, dimention, isEditable, zIndex) {
                    var firstDay = Scheduler.Container.defaultOffice.firstDayOfWeek;
                    var _datePickerSettings = {
                        firstWeekDay: firstDay,
                        actualDate: date,
                        dayNames: Scheduler.Utilities.getAbbreviatedDayNames(firstDay),
                        monthNames: Scheduler.Container.constants.cultureInfo.dateTimeFormat.monthNames.slice(),
                        images: [
                            Scheduler.Container.imageFolder + "arrow_left.png",
                            Scheduler.Container.imageFolder + "arrow_right.png" //ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_right.png", ""),
                        ],
                        platform: MobileCRM.bridge.platform,
                    };
                    var settings = {
                        actualDate: date,
                        parentElement: element[0],
                        datePickerIcon: Scheduler.Container.imageFolder + "arrow_down.png",
                        iconContainerSize: { width: 22, height: 22 },
                        datePickerSetting: _datePickerSettings,
                        dateFormat: Controls.RescoInputDatePicker.dateFormat[0],
                        readOnly: true,
                        dimension: dimention,
                        useRotationForIcon: true,
                        isEditable: isEditable,
                        zIndex: zIndex
                    };
                    return new Resco.Controls.RescoInputDatePicker(settings);
                };
                BasePickersPage.prototype.createRescoInputTimePicker = function (element, minRange, time, dimension, isEditable, zIndex, format) {
                    var actualTime;
                    if (time instanceof Date) {
                        actualTime = new Resco.Controls.RescoTime();
                        actualTime.hour = time.getHours();
                        actualTime.minute = time.getMinutes();
                    }
                    else {
                        actualTime = time;
                    }
                    var timePickerSettings = {
                        format: format || Resco.Controls.RescoTimePickerFormat.format24,
                        minRange: minRange,
                        arrowImages: [
                            Scheduler.Container.imageFolder + "arrow_up.png",
                            Scheduler.Container.imageFolder + "arrow_down.png" //ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_down.png", "")
                        ],
                        platform: MobileCRM.bridge.platform,
                        time: actualTime,
                    };
                    var settings = {
                        actualTime: actualTime,
                        parentElement: element[0],
                        timePickerIcon: Scheduler.Container.imageFolder + "arrow_down.png",
                        iconContainerSize: { width: 22, height: 22 },
                        useRotationForIcon: true,
                        timePickerSettings: timePickerSettings,
                        readOnly: true,
                        dimension: dimension,
                        isEditable: isEditable,
                        zIndex: zIndex
                    };
                    return new Resco.Controls.RescoInputTimePicker(settings);
                };
                BasePickersPage.prototype.disposeRescoDateControls = function (inputDatePicker) {
                    if (inputDatePicker) {
                        inputDatePicker.valueChanged.clear();
                        inputDatePicker.disposeRescoDatePickerElement();
                    }
                };
                BasePickersPage.prototype.disposeRescoTimeControls = function (inputTimePicker) {
                    if (inputTimePicker) {
                        inputTimePicker.valueChanged.clear();
                        inputTimePicker.disposeRescoTimePickerElement();
                    }
                };
                return BasePickersPage;
            }(BasePage));
            Scheduler.BasePickersPage = BasePickersPage;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
