///<reference path="../../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../data/enums.ts" />
///<reference path="../data/settings.ts" />
///<reference path="../container.ts" />
///<reference path="baseDlg.ts" />
///<reference path="basePickersPage.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var MinutesCtrl = (function () {
                function MinutesCtrl() {
                }
                MinutesCtrl.convertTime2HHMM = function (m, clockFormat) {
                    m = Math.floor(m);
                    var h = Math.floor(m / 60);
                    m -= h * 60;
                    var time;
                    if (clockFormat)
                        time = (h < 10 ? "0" + h : h) + ":" + (m < 10 ? "0" + m : m);
                    else {
                        var hLabel = Scheduler.StringTable.get("Scheduler.Msg.HoursShort") || "h";
                        hLabel = hLabel ? hLabel : "h";
                        var mLabel = Scheduler.StringTable.get("Scheduler.Msg.MinutesShort3") || "min";
                        mLabel = mLabel ? mLabel : "min";
                        time = h + hLabel + " " + m + mLabel;
                    }
                    return time;
                };
                MinutesCtrl.convertTime2DDHHMM = function (m, clockFormat) {
                    m = Math.floor(m);
                    var d = Math.floor(m / (24 * 60));
                    m -= d * (24 * 60);
                    var h = Math.floor(m / 60);
                    m -= h * 60;
                    var time;
                    if (clockFormat)
                        time = (h < 10 ? "0" + h : h) + ":" + (m < 10 ? "0" + m : m);
                    else {
                        var hLabel = Scheduler.StringTable.get("Scheduler.Msg.HoursShort") || "h";
                        hLabel = hLabel ? hLabel : "h";
                        var mLabel = Scheduler.StringTable.get("Scheduler.Msg.MinutesShort3") || "min";
                        mLabel = mLabel ? mLabel : "min";
                        time = h + hLabel + " " + m + mLabel;
                    }
                    if (d > 1) {
                        var dsLabel = Scheduler.StringTable.get("Scheduler.Msg.Days") || "days";
                        dsLabel = dsLabel ? dsLabel : "days";
                        return d + dsLabel + " " + time;
                    }
                    else if (d == 1) {
                        var dLabel = Scheduler.StringTable.get("Scheduler.Msg.Day") || "day";
                        dLabel = dLabel ? dLabel : "day";
                        return d + dLabel + " " + time;
                    }
                    else
                        return time;
                };
                return MinutesCtrl;
            }());
            var TaskPropertyDlg = (function (_super) {
                __extends(TaskPropertyDlg, _super);
                function TaskPropertyDlg(container, task) {
                    var _this = _super.call(this) || this;
                    _this._canSave = false;
                    _this._changes = {};
                    _this._pages = [];
                    _this._container = container;
                    _this._task = task;
                    _this.onShowDialog();
                    return _this;
                }
                TaskPropertyDlg.isShown = function () {
                    return TaskPropertyDlg._dialogInstance ? true : false;
                };
                TaskPropertyDlg.show = function (container, task) {
                    if (TaskPropertyDlg._dialogInstance)
                        TaskPropertyDlg._dialogInstance.destroy();
                    TaskPropertyDlg._dialogInstance = new TaskPropertyDlg(container, task);
                };
                TaskPropertyDlg.prototype.onShowDialog = function () {
                    var _this = this;
                    this.dialog = this._createTaskPropertyDlgElement();
                    this.resource = this._task.resource;
                    this._saveButton = this.dialog.find(".saveButton");
                    this._canSave = this.container.loadingInProcess === false && this._task.isEditable();
                    if (this._canSave && (this._task.getStatus().isUnscheduled() || this.container.isLocked()))
                        this._canSave = false;
                    if (!this._task.hasScheduledStart) {
                        var now = Date.now();
                        var newTaskSchedule = this._task.cloneTaskSchedule();
                        newTaskSchedule.setWorkStart(now);
                        this._workStart = new Date(newTaskSchedule.getWorkStart());
                        this._workEnd = new Date(newTaskSchedule.getWorkEnd());
                    }
                    else {
                        this._workStart = new Date(this._task.getWorkStart());
                        this._workEnd = new Date(this._task.getWorkEnd());
                    }
                    var travel = this._task.getTravel();
                    this.totalWorkTime = this._task.getTotalWorkTime();
                    this.travel = new Scheduler.Travel(travel.to, travel.from, travel.mode);
                    if (this._task.isTimeOff()) {
                        this.addPage(new TimeOffPage(this));
                        this._disableEdit();
                    }
                    else {
                        this._saveButton.prop("disabled", true);
                        this.addPage(new InfoPage(this));
                        this.addPage(new ResourcePage(this));
                        if (this._task.entityInput.attrTravelFrom)
                            this.addPage(new RoutePage(this));
                        if (this._task.ruleViolations.length > 0)
                            this.addPage(new ViolationsPage(this));
                        if (this._canSave)
                            this._saveButton.click(function (e) {
                                _this._saveAndClose();
                            });
                        else
                            this._disableEdit();
                    }
                    this.initializeTabDialog(this.dialog);
                    Scheduler.StringTable.localizeElements(this.dialog);
                    this.dialog.find(".openFormButton").click(function (e) {
                        if (_this._canSave) {
                            _this._saveChanges(function (oldResource, taskChanged, error) {
                                _this.container.onTaskDialogSaved(_this._task, oldResource, taskChanged);
                                if (!error)
                                    _this._openForm(_this._task);
                            });
                        }
                        else
                            _this._openForm(_this._task);
                    });
                    _super.prototype.create.call(this, this.dialog, 400, 500);
                    //this.container.dataProvider.onTaskDlgInitialized(this);
                };
                Object.defineProperty(TaskPropertyDlg.prototype, "canSave", {
                    get: function () {
                        return this._canSave;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskPropertyDlg.prototype, "container", {
                    get: function () {
                        return this._container;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskPropertyDlg.prototype, "task", {
                    get: function () {
                        return this._task;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskPropertyDlg.prototype, "workStart", {
                    get: function () {
                        return this._workStart;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskPropertyDlg.prototype, "workEnd", {
                    get: function () {
                        return this._workEnd;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TaskPropertyDlg.prototype, "pages", {
                    get: function () {
                        return this._pages;
                    },
                    enumerable: true,
                    configurable: true
                });
                TaskPropertyDlg.prototype._disableEdit = function () {
                    this.dialog.find("input,textarea").attr("readOnly", "true");
                    this.dialog.find("input:checkbox,select").attr("disabled", "true");
                    this.dialog.find("button.calculateTravelTime").attr("disabled", "true");
                    this.dialog.find(".saveButton").remove();
                };
                TaskPropertyDlg.prototype.loadResourceImage = function (page, resource) {
                    var imageElement = page.find(".resourceImage");
                    if (imageElement !== undefined && imageElement.length > 0) {
                        imageElement.attr("src", Scheduler.Resource.getDefaultImage());
                        resource.getImage(function (image) {
                            if (image)
                                imageElement.attr("src", image);
                        });
                    }
                };
                TaskPropertyDlg.prototype.destroy = function () {
                    for (var i = 0; i < this._pages.length; i++) {
                        this._pages[i].removeRescoComponents();
                    }
                    TaskPropertyDlg._dialogInstance = null;
                    _super.prototype.destroy.call(this);
                };
                TaskPropertyDlg.prototype.onChange = function (name, value) {
                    this._changes[name] = value;
                    this._saveButton.prop("disabled", false);
                };
                //private _validateNumber(event: JQueryEventObject): boolean {
                //	var key = window.event ? event.keyCode : event.which;
                //	if (event.keyCode === 8 || event.keyCode === 46) {
                //		return true;
                //	} else if (key < 48 || key > 57) {
                //		return false;
                //	} else {
                //		return true;
                //	}
                //};
                TaskPropertyDlg.prototype._openForm = function (task) {
                    this.destroy();
                    if (!task.entityInput || !task.entityInput.entityName)
                        return;
                    if (task.entityInput.crmFormTabRef && task.group) {
                        if (this.container.sourceDefined) {
                            var options = {};
                            options[task.entityInput.crmFormTabRef] = new MobileCRM.Reference(task.entityInput.entityName, task.getID());
                            MobileCRM.UI.FormManager.showEditDialog(Scheduler.Container.inputs.unscheduledTasks.entityName, task.group.id, null, options);
                        }
                    }
                    else
                        MobileCRM.UI.FormManager.showEditDialog(task.entityInput.entityName, task.id, null, null);
                };
                TaskPropertyDlg.prototype._saveAndClose = function () {
                    var _this = this;
                    this._saveChanges(function (oldResource, taskChanged, error) {
                        _this.container.onTaskDialogSaved(_this._task, oldResource, taskChanged);
                        if (!error)
                            _this.destroy();
                    });
                };
                TaskPropertyDlg.prototype._saveChanges = function (onResult) {
                    var _this = this;
                    var hasChanges = false;
                    var taskChanges = this._changes;
                    var task = this._task;
                    for (var key in taskChanges) {
                        hasChanges = true;
                        break;
                    }
                    if (!hasChanges) {
                        onResult(task.resource, false, null);
                        return;
                    }
                    var newParent;
                    if (taskChanges.hasOwnProperty("parentID")) {
                        var newParentId = taskChanges["parentID"];
                        newParent = this.container.findResource(newParentId);
                        // Do not check newParent to undefined here, because isValidReassign method handle it correctly below!
                        if (newParent === task.resource)
                            taskChanges.parentID = undefined;
                    }
                    else {
                        newParent = task.resource;
                    }
                    var workStartValue = this._workStart.valueOf();
                    if (taskChanges.hasOwnProperty("start")) {
                        workStartValue = taskChanges.start;
                        this.onChange("end", this._workEnd.valueOf());
                    }
                    if (taskChanges.hasOwnProperty("totalWork")) {
                        this.totalWorkTime = taskChanges.totalWork;
                        if (!taskChanges.hasOwnProperty("start")) {
                            this.onChange("start", workStartValue);
                            this.onChange("end", this._workEnd.valueOf());
                        }
                    }
                    if (taskChanges.hasOwnProperty("travelTo"))
                        this.travel.to = taskChanges.travelTo;
                    if (taskChanges.hasOwnProperty("travelFrom"))
                        this.travel.from = taskChanges.travelFrom;
                    if (taskChanges.hasOwnProperty("travelMode"))
                        this.travel.mode = taskChanges.travelMode;
                    if ((workStartValue === undefined) || (workStartValue === null))
                        workStartValue = task.getWorkStart();
                    if ((this.totalWorkTime === undefined) || (this.totalWorkTime === null))
                        this.totalWorkTime = task.getTotalWorkTime();
                    var newTaskSchedule = task.cloneTaskSchedule();
                    newTaskSchedule.setWorkStart(workStartValue);
                    newTaskSchedule.setTotalWorkTime(this.totalWorkTime);
                    newTaskSchedule.setTravel(this.travel);
                    if (!taskChanges.hasOwnProperty("statuscode") || !Scheduler.Container.statusCodeTable.getStatusByValue(taskChanges.statuscode).isUnscheduled()) {
                        var reassign = task.isValidReassign(newParent, newTaskSchedule.getStart(), newTaskSchedule.getEnd());
                        if (!reassign.isValid) {
                            var yes_1 = Scheduler.StringTable.get("Cmd.Yes") || "Yes";
                            var no = Scheduler.StringTable.get("Cmd.No") || "No";
                            var prompt_1 = reassign.error + " " + (Scheduler.StringTable.get("Scheduler.Msg.SavePrompt") || "Do you still want to save task?");
                            var popup = new MobileCRM.UI.MessageBox(prompt_1);
                            popup.items = [yes_1, no];
                            popup.multiLine = true;
                            popup.show(function (button) {
                                if (button === yes_1)
                                    _this._saveToTask(task, taskChanges, onResult);
                                else
                                    onResult(task.resource, false, null);
                            });
                            return;
                        }
                    }
                    this._saveToTask(task, taskChanges, onResult);
                };
                TaskPropertyDlg.prototype._saveToTask = function (task, taskChanges, onResult) {
                    var oldResource = task.resource;
                    this.container.saveTask(task, taskChanges)
                        .then(function () { onResult(oldResource, true, null); })
                        .catch(function (e) {
                        var err = (e instanceof Resco.Exception) ? e.message : e.toString();
                        onResult(oldResource, false, err);
                    });
                };
                TaskPropertyDlg.prototype.updateEndAndTaskDuration = function () {
                    var newTaskSchedule = this._task.cloneTaskSchedule();
                    newTaskSchedule.setWorkStart(this._workStart.valueOf());
                    newTaskSchedule.setTotalWorkTime(this.totalWorkTime);
                    newTaskSchedule.setTravel(this.travel);
                    this._workEnd.setTime(newTaskSchedule.getWorkEnd());
                    for (var i = 0; i < this._pages.length; i++) {
                        var page = this._pages[i];
                        if (page instanceof InfoPage)
                            page.updateTaskEnd();
                    }
                };
                TaskPropertyDlg.prototype.addPage = function (page) {
                    var rescoTabCtrl = this.dialog.find(".rescoTabCtrl");
                    var dialogControlContainer = this.dialog.find(".dialogControlContainer");
                    rescoTabCtrl.append(page.tabElement);
                    dialogControlContainer.before(page.tabContentElement);
                    this._pages.push(page);
                };
                TaskPropertyDlg.prototype._createTaskPropertyDlgElement = function () {
                    var element = Scheduler.Utilities.createFromTemplate(TaskPropertyDlg._template);
                    element.find("ul.rescoTabCtrl").css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    return element;
                };
                return TaskPropertyDlg;
            }(Scheduler.BaseDlg));
            TaskPropertyDlg._dialogInstance = null;
            TaskPropertyDlg._template = '\
			<div class="rescoDialog">\
				<ul class="rescoTabCtrl">\
				</ul>\
				<div class="dialogControlContainer">\
				  <button class="closeButton" data-localization="Msg.Cancel">Cancel</button>&nbsp;\
				  <button class="openFormButton" data-localization="Msg.OpenForm">Open Form</button>&nbsp;\
				  <button class="saveButton" data-localization="Msg.Save">Save</button>\
				</div>\
			</div>\
		';
            Scheduler.TaskPropertyDlg = TaskPropertyDlg;
            var TimeOffPage = (function (_super) {
                __extends(TimeOffPage, _super);
                function TimeOffPage(dialog) {
                    var _this = _super.call(this, "INFO", "Scheduler.Msg.INFO", "INFO", "Msg.ResTimeOffInfo", "Resource time off details.") || this;
                    _this.template = '\
			<image class="resourceImage" width="64" height="64" draggable="false" style="horizontal-align: center;"/>\
			<p data-localization="Msg.Name">Name</p>\
			<input type="text" class="resourceName" style="width:100%">\
			<!--<br>\
			<p data-localization="Msg.TimeOffReason">Time off reason</p>\
			<input type="text" class="reason" style="width:100%">-->\
			<br>\
			<div>\
				<p data-localization="Msg.From">From</p>\
				<div class="flexPart">\
					<div data-datevalue="From" class="timeOffFromDate"></div>\
					<div data-timeField="From" class="timeOffFromTime" style="margin-left: 30px;"></div>\
				</div>\
			</div>\
			<div>\
				<p data-localization="Msg.To">To</p>\
				<div class="flexPart">\
					<div data-datevalue="To" class="timeOffToDate"></div>\
					<div data-timeField="To" class="timeOffToTime" style="margin-left: 30px;"></div>\
				</div>\
			</div>\
		';
                    _this._propertyDlg = dialog;
                    _this.addBodyContent(_this.template);
                    if (_this._propertyDlg.resource !== undefined) {
                        _this._propertyDlg.loadResourceImage(_this.tabContentElement, _this._propertyDlg.resource);
                        _this.tabContentElement.find(".resourceName").val(_this._propertyDlg.resource.getName());
                    }
                    _this.tabContentElement.find(".reason").val(_this._propertyDlg.task.name);
                    _this._initDateFields();
                    _this._initTimeFields();
                    return _this;
                }
                TimeOffPage.prototype.removeRescoComponents = function () {
                    this.disposeRescoDateControls(this._timeOffFromInputDatePicker);
                    this.disposeRescoDateControls(this._timeOffToInputDatePicker);
                    this.disposeRescoTimeControls(this._timeOffFromInputTimePicker);
                    this.disposeRescoTimeControls(this._timeOffToInputTimePicker);
                };
                TimeOffPage.prototype._initDateFields = function () {
                    var element = this.tabContentElement.find(".timeOffFromDate");
                    if (element.length === 1) {
                        this._timeOffFromInputDatePicker = this.createRescoInputDatePicker(element, this._propertyDlg.workStart, { width: 190, height: 27, left: 0, top: 0 }, false, this._propertyDlg.zIndex + 10);
                    }
                    var element2 = this.tabContentElement.find(".timeOffToDate");
                    if (element2.length === 1) {
                        this._timeOffToInputDatePicker = this.createRescoInputDatePicker(element2, this._propertyDlg.workEnd, { width: 190, height: 27, left: 0, top: 0 }, false, this._propertyDlg.zIndex + 10);
                    }
                };
                TimeOffPage.prototype._initTimeFields = function () {
                    var minRange = this._propertyDlg.container.settings.roundMinutes;
                    var element = this.tabContentElement.find(".timeOffFromTime");
                    if (element.length === 1) {
                        this._timeOffFromInputTimePicker = this.createRescoInputTimePicker(element, minRange, this._propertyDlg.workStart, { width: 100, height: 27, left: 0, top: 0 }, false, this._propertyDlg.zIndex + 10);
                    }
                    var element2 = this.tabContentElement.find(".timeOffToTime");
                    if (element2.length === 1) {
                        this._timeOffToInputTimePicker = this.createRescoInputTimePicker(element2, minRange, this._propertyDlg.workEnd, { width: 100, height: 27, left: 0, top: 0 }, false, this._propertyDlg.zIndex + 10);
                    }
                };
                return TimeOffPage;
            }(Scheduler.BasePickersPage));
            var InfoPage = (function (_super) {
                __extends(InfoPage, _super);
                function InfoPage(dialog) {
                    var _this = _super.call(this, "INFO", "Scheduler.Msg.INFO", "INFO", "Scheduler.Msg.TaskInfo", "Task basic information.") || this;
                    _this.template = '\
			<p data-localization="Msg.Name">Name</p>\
			<input type="text" class="name" style="width:100%">\
			<br><br>\
			<div id="taskInfoStatusDiv" style="display:-webkit-flex;display:flex;flex-direction:row;">\
				<div class="statuscodediv">\
					<p data-localization="Msg.StatusReason">Status Reason</p>\
					<select class="statuscode" style="width:190px; min-height:27px;">\
					</select>\
				</div>\
				<div id="taskInfoProgressDiv" style="margin-left: 30px;">\
					<p data-localization="Msg.Progress">Progress</p>\
					<input type="number" inputmode="numeric" pattern="[0-9]*" class="progress" value="" size="4" min="0" max="100" style="height: 27px; width: 50px;">%\
				</div>\
			</div>\
			<div>\
				<p data-localization="Msg.Start">Start</p>\
				<div class="flexPart">\
					<div data-datevalue="start" class="startDate"></div>\
					<div data-timeField="start" class="startTime" style="margin-left: 30px;"></div>\
				</div>\
			</div>\
			<div>\
				<p data-localization="Scheduler.Msg.TotalWorkDuration">Total Work Duration</p>\
				<div class="flexPart">\
					<div class="totalWorkTime" style="margin-left: 220px;"></div>\
				</div>\
			</div>\
			<div>\
				<p data-localization="Msg.End">End</p>\
				<div class="flexPart">\
					<div data-datevalue="end" class="endDate"></div>\
					<div data-timeField="end" class="endTime" style="margin-left: 30px;"></div>\
				</div>\
			</div>\
			<p data-localization="Scheduler.Msg.TaskDuration">Task Duration</p>\
			<span class="taskDuration" style="font-size:16px;"></span>\
		';
                    _this._propertyDlg = dialog;
                    _this.addBodyContent(_this.template);
                    var statusElement = _this.tabContentElement.find(".statuscode");
                    var isWorkOrderScheduler = Scheduler.Container.inputs.scheduledTasks.entityName == "fs_workorderschedule";
                    _this._addStatuses(statusElement);
                    statusElement.val(_this._propertyDlg.task.getStatus().value());
                    statusElement.change(function (e) {
                        var ctrlTarget = e.target;
                        var option = ctrlTarget.options[ctrlTarget.selectedIndex];
                        var valueType = option.getAttribute("data-value-type");
                        var value = (valueType === "number") ? +option.value : option.value;
                        if (Scheduler.Task.isValidStatusValue(value)) {
                            _this._propertyDlg.onChange("statuscode", value);
                            if (isWorkOrderScheduler)
                                _this._onStatusChanged(Scheduler.Container.statusCodeTable.getStatusByValue(value));
                        }
                    });
                    _this.tabContentElement.find(".name")
                        .val(_this._propertyDlg.task.name)
                        .change(function (e) {
                        var name = e.target.value;
                        if (!name || name === "")
                            Scheduler.StringTable.alert(Scheduler.StringTable.get("Err.NameCantBeEmpty") || "Name must not be empty!");
                        else
                            _this._propertyDlg.onChange("name", name);
                    });
                    if (_this._propertyDlg.task.entityInput.linkProgress) {
                        _this.tabContentElement.find(".progress")
                            .val(_this._propertyDlg.task.progress && _this._propertyDlg.task.progress > 0 ? _this._propertyDlg.task.progress : 0)
                            .change(function (e) {
                            var inp = $(_this);
                            var value = parseInt(e.target.value);
                            if (value < 0)
                                value = 0;
                            else if (value > 100)
                                value = 100;
                            _this._propertyDlg.onChange("progress", value);
                        });
                    }
                    else
                        _this.tabContentElement.find("#taskInfoProgressDiv").css({ display: "none" });
                    _this._initDateFields();
                    _this._initTimeFields();
                    _this.tabContentElement.find(".taskDuration").text(MinutesCtrl.convertTime2HHMM(_this._taskDurationInMinutes(), false));
                    return _this;
                }
                InfoPage.prototype._onStatusChanged = function (status) {
                    var _this = this;
                    if (status.isFinished()) {
                        if (this.tabContentElement.find("#taskInfoStatusCheckboxDiv").length === 0) {
                            var statusCheckBox = $("<input>");
                            statusCheckBox.attr("type", "checkbox");
                            statusCheckBox.prop("checked", false);
                            statusCheckBox.change(function (e) {
                                _this._propertyDlg.onChange("applyStatusforWorkOrder", e.target.checked);
                            });
                            var localizationSpan = $("<span>");
                            localizationSpan.attr("data-localization", "Scheduler.Msg.ApplyStatus");
                            localizationSpan.text("Apply status to whole WorkOrder");
                            var checkBoxDiv = $("<div>");
                            checkBoxDiv.attr("id", "taskInfoStatusCheckboxDiv");
                            checkBoxDiv.append($("<p>"));
                            checkBoxDiv.append(statusCheckBox);
                            checkBoxDiv.append(localizationSpan);
                            Scheduler.StringTable.localizeElements(checkBoxDiv);
                            this.tabContentElement.find("#taskInfoStatusDiv").after(checkBoxDiv);
                        }
                    }
                    else {
                        this.tabContentElement.find("#taskInfoStatusCheckboxDiv").remove();
                    }
                };
                InfoPage.prototype.removeRescoComponents = function () {
                    this.disposeRescoDateControls(this._startInputDatePicker);
                    this.disposeRescoDateControls(this._endInputDatePicker);
                    this.disposeRescoTimeControls(this._startInputTimePicker);
                    this.disposeRescoTimeControls(this._endInputTimePicker);
                    this.disposeRescoTimeControls(this._totalWorkInputTimePicker);
                };
                InfoPage.prototype.updateTaskEnd = function () {
                    this._endInputDatePicker.changeValue(this._propertyDlg.workEnd);
                    this._endInputTimePicker.changeTime(new Resco.Controls.RescoTime(this._propertyDlg.workEnd));
                    this.tabContentElement.find(".taskDuration").text(MinutesCtrl.convertTime2HHMM(this._taskDurationInMinutes(), false));
                };
                InfoPage.prototype._initDateFields = function () {
                    var element = this.tabContentElement.find(".startDate");
                    if (element.length === 1) {
                        this._startInputDatePicker = this.createRescoInputDatePicker(element, this._propertyDlg.workStart, { width: 190, height: 27, left: 0, top: 0 }, this._propertyDlg.canSave, this._propertyDlg.zIndex + 10);
                        this._startInputDatePicker.valueChanged.add(this, this._startDateValueChanged);
                    }
                    var element2 = this.tabContentElement.find(".endDate");
                    if (element2.length === 1) {
                        this._endInputDatePicker = this.createRescoInputDatePicker(element2, this._propertyDlg.workEnd, { width: 190, height: 27, left: 0, top: 0 }, false, this._propertyDlg.zIndex + 10);
                    }
                };
                InfoPage.prototype._initTimeFields = function () {
                    var minRange = this._propertyDlg.container.settings.roundMinutes;
                    var element = this.tabContentElement.find(".startTime");
                    if (element.length === 1) {
                        this._startInputTimePicker = this.createRescoInputTimePicker(element, minRange, this._propertyDlg.workStart, { width: 100, height: 27, left: 0, top: 0 }, this._propertyDlg.canSave, this._propertyDlg.zIndex + 10);
                        this._startInputTimePicker.valueChanged.add(this, this._startTimeValueChanged);
                    }
                    var element2 = this.tabContentElement.find(".endTime");
                    if (element2.length === 1) {
                        this._endInputTimePicker = this.createRescoInputTimePicker(element2, minRange, this._propertyDlg.workEnd, { width: 100, height: 27, left: 0, top: 0 }, false, this._propertyDlg.zIndex + 10);
                    }
                    var element3 = this.tabContentElement.find(".totalWorkTime");
                    if (element3.length === 1) {
                        this._totalWorkInputTimePicker = this.createRescoInputTimePicker(element3, minRange, new Controls.RescoTime(this._propertyDlg.totalWorkTime), { width: 100, height: 27, left: 0, top: 0 }, this._propertyDlg.canSave, this._propertyDlg.zIndex + 10, Resco.Controls.RescoTimePickerFormat.formatUnlimited);
                        this._totalWorkInputTimePicker.valueChanged.add(this, this._totalWorkTimeValueChanged);
                    }
                };
                InfoPage.prototype._startDateValueChanged = function (sender, e) {
                    var newStartDateValue = e.value;
                    var diff = 0;
                    this._propertyDlg.workStart.setFullYear(newStartDateValue.getFullYear(), newStartDateValue.getMonth(), newStartDateValue.getDate());
                    this._propertyDlg.onChange("start", this._propertyDlg.workStart.valueOf());
                    this._propertyDlg.updateEndAndTaskDuration();
                };
                InfoPage.prototype._startTimeValueChanged = function (sender, e) {
                    var newStartTime = e.value;
                    if (!this._isNewTimeValueSame(this._propertyDlg.workStart, newStartTime)) {
                        this._setNewTimeValues(this._propertyDlg.workStart, newStartTime);
                        this._propertyDlg.onChange("start", this._propertyDlg.workStart.valueOf());
                        this._propertyDlg.updateEndAndTaskDuration();
                    }
                };
                InfoPage.prototype._totalWorkTimeValueChanged = function (sender, e) {
                    var newTotalWorkTime = Controls.RescoTime.convertFromRescoTimeToMilisecond(e.value);
                    if (newTotalWorkTime !== this._propertyDlg.totalWorkTime) {
                        this._propertyDlg.totalWorkTime = newTotalWorkTime;
                        this._propertyDlg.onChange("start", this._propertyDlg.workStart.valueOf());
                        this._propertyDlg.onChange("totalWork", this._propertyDlg.totalWorkTime);
                        this._propertyDlg.updateEndAndTaskDuration();
                    }
                };
                InfoPage.prototype._taskDurationInMinutes = function () {
                    return Scheduler.milisecondsToMinutes(this._propertyDlg.workEnd.valueOf() - this._propertyDlg.workStart.valueOf());
                };
                InfoPage.prototype._isNewTimeValueSame = function (oldTime, newTime) {
                    return (oldTime.getHours() === newTime.hour && oldTime.getMinutes() === newTime.minute);
                };
                InfoPage.prototype._setNewTimeValues = function (oldTime, newTime) {
                    oldTime.setHours(newTime.hour);
                    oldTime.setMinutes(newTime.minute);
                    oldTime.setSeconds(0);
                    oldTime.setMilliseconds(0);
                };
                InfoPage.prototype._addStatuses = function (statusElement) {
                    if (Scheduler.Container.inputs.scheduledTasks.attrStatus) {
                        for (var i = 0; i < Scheduler.Container.statusCodeTable.statusList.length; i++) {
                            var status_1 = Scheduler.Container.statusCodeTable.statusList[i];
                            var statusValue = status_1.value();
                            if (statusValue !== -1) {
                                var tmp = "<option value='" + statusValue + "' data-value-type='" + (typeof statusValue) + "' data-localization='" + status_1.localizationKey() + "'>" + status_1.name() + "</option>";
                                statusElement.append($(tmp));
                            }
                        }
                    }
                    else {
                        //$(statusElement).hide();
                        this.tabContentBodyElement.find(".statuscodediv").hide();
                        this.tabContentElement.find("#taskInfoProgressDiv").css({ "margin-left": 0 });
                    }
                };
                return InfoPage;
            }(Scheduler.BasePickersPage));
            Scheduler.InfoPage = InfoPage;
            var ResourcePage = (function (_super) {
                __extends(ResourcePage, _super);
                function ResourcePage(dialog) {
                    var _this = _super.call(this, "RESOURCE", "Scheduler.Msg.RESOURCE", "RESOURCE", "Scheduler.Msg.TaskResource", "Task resource.") || this;
                    _this.template = '\
			<image class="resourceImage" width="64" height="64" draggable="false" style="horizontal-align: center;"/>\
			<p data-localization="Msg.Name">Name</p>\
			<select class="resourceName" style="width:100%">\
			</select>\
			<p></p>\
		';
                    _this._propertyDlg = dialog;
                    _this.addBodyContent(_this.template);
                    var resourceListElement = _this.tabContentElement.find(".resourceName");
                    var resourceId = "";
                    var resourceName = "Undefined";
                    if (_this._propertyDlg.resource !== undefined) {
                        resourceId = _this._propertyDlg.resource.getID();
                        resourceName = _this._propertyDlg.resource.getName();
                        _this._propertyDlg.loadResourceImage(_this.tabContentElement, _this._propertyDlg.resource);
                    }
                    if (!_this._propertyDlg.canSave) {
                        var option = document.createElement('option');
                        option.text = resourceName;
                        option.value = resourceId;
                        option.selected = true;
                        resourceListElement.append(option);
                    }
                    else {
                        //var allowedResourceIds = this.task.allowedResourceIds;
                        var isInList = false;
                        _this._propertyDlg.task.loadLinkedResources(function (error) {
                            var allowedResourceIds = _this._propertyDlg.task.getLinkedResources();
                            var resourceList;
                            if (!allowedResourceIds)
                                resourceList = _this._propertyDlg.container.resourceDictionary.Values();
                            else {
                                resourceList = [];
                                for (var i = 0; i < allowedResourceIds.length; i++) {
                                    var resource = _this._propertyDlg.container.resourceDictionary.Item(allowedResourceIds[i]);
                                    if (resource)
                                        resourceList.push(resource);
                                }
                            }
                            resourceList.sort(function (a, b) {
                                return a.getName().localeCompare(b.getName());
                            });
                            for (var i = 0; i < resourceList.length; i++) {
                                var resource = resourceList[i];
                                var option = document.createElement('option');
                                option.text = resource.getName();
                                option.value = resource.getID();
                                if (resourceId === resource.getID()) {
                                    option.selected = true;
                                    isInList = true;
                                }
                                resourceListElement.append(option);
                            }
                            if (!isInList && resourceName) {
                                var option = document.createElement('option');
                                option.text = resourceName;
                                option.value = resourceId;
                                option.selected = true;
                                resourceListElement.append(option);
                            }
                            resourceListElement.change(function (e) {
                                var item = e.target;
                                if (item.selectedIndex >= 0) {
                                    resourceId = item[item.selectedIndex].value;
                                    _this._propertyDlg.onChange("parentID", resourceId);
                                    _this._propertyDlg.resource = _this._propertyDlg.container.resourceDictionary.Item(resourceId);
                                    _this._propertyDlg.loadResourceImage(_this.tabContentElement, _this._propertyDlg.resource);
                                }
                            });
                        });
                    }
                    return _this;
                }
                return ResourcePage;
            }(Scheduler.BasePage));
            var RoutePage = (function (_super) {
                __extends(RoutePage, _super);
                function RoutePage(dialog) {
                    var _this = _super.call(this, "ROUTE", "Scheduler.Msg.ROUTE", "ROUTE", "Msg.TravelInfo", "Travel information.") || this;
                    _this.startTravelMask = Scheduler.TravelMode.FromOffice | Scheduler.TravelMode.FromPreviousClient;
                    _this.endTravelMask = Scheduler.TravelMode.ToOffice | Scheduler.TravelMode.ToNextClient;
                    _this._travelModeSupported = false;
                    _this.template = '\
			<div>\
				<select class="taskAddress startTravelMode" style="width:300px; min-height:27px;" disabled></select>\
				<div style="margin:0.5em 0"><input class="taskAddress startAddress" type="text" readonly></div>\
				<p data-localization="Msg.Duration">Duration</p>\
				<div data-timeField="travelTo" class="travelTo"></div>\
			</div>\
			</br>\
			<div style="border-top: 1px solid gray; margin-top: 1em">\
				<select class="taskAddress endTravelMode" style="width:300px; min-height:27px; margin-top:5px" disabled></select>\
				<div style="margin:0.5em 0"><input class="taskAddress afterEndAddress" type="text" readonly></div>\
				<p data-localization="Msg.Duration">Duration</p>\
				<div data-timeField="travelFrom" class="travelFrom"></div>\
			</div>\
			<div style="border-top: 1px solid gray; margin: 1em 0; display: flex;display: -webkit-flex; justify-content:flex-end;-webkit-justify-content:flex-end;">\
				<button class="calculateTravelTime" style="margin:1em 0" data-localization="Msg.Calculate">Calculate</button>\
			</div>\
		';
                    _this._propertyDlg = dialog;
                    _this.addBodyContent(_this.template);
                    var task = _this._propertyDlg.task;
                    _this._travelModeSupported = Scheduler.Container.inputs.scheduledTasks.attrTravelMode && Scheduler.Container.inputs.scheduledTasks.attrTravelMode.length > 0;
                    _this._officeAddress = Scheduler.Container.defaultOffice.locationAddress;
                    _this._calculateButton = _this.tabContentElement.find(".calculateTravelTime");
                    _this._loadTaskAddress(task);
                    if (_this._calculateButton.length === 1) {
                        _this._calculateButton.on("click", null, function (e) {
                            _this._calculateTravelDuration();
                        });
                    }
                    _this._initTimeFields();
                    return _this;
                }
                RoutePage.prototype._loadTaskAddress = function (task) {
                    var _this = this;
                    var startAddressElement = this.tabContentElement.find(".startAddress");
                    var endAddressElement = this.tabContentElement.find(".afterEndAddress");
                    var startTravelMode = this.tabContentElement.find(".startTravelMode");
                    var endTravelMode = this.tabContentElement.find(".endTravelMode");
                    endAddressElement.val(this._officeAddress);
                    this._setTravelMode(startTravelMode, this.startTravelMask);
                    this._setTravelMode(endTravelMode, this.endTravelMask);
                    task.loadLocation(function (error) {
                        if (!error && task.location) {
                            if (startAddressElement.length === 1) {
                                startAddressElement
                                    .val(task.location.address())
                                    .change(function (e) {
                                    var address = e.target.value;
                                    if (address !== "" && (!task.location || task.location.address() != address)) {
                                        task.location = new Scheduler.Location(address, undefined, undefined);
                                        startAddressElement.val(address);
                                    }
                                });
                            }
                            if (_this._travelModeSupported) {
                                var neighbors_1 = task.resource.getNeighbors(task);
                                if (neighbors_1 && neighbors_1.prev) {
                                    neighbors_1.prev.loadLocation(function (error) {
                                        if (!error && neighbors_1.prev.location) {
                                            _this._prevClientAddress = neighbors_1.prev.location.address();
                                            if (_this._prevClientAddress)
                                                startTravelMode.prop("disabled", false);
                                        }
                                    });
                                }
                                if (neighbors_1 && neighbors_1.next) {
                                    neighbors_1.next.loadLocation(function (error) {
                                        if (!error && neighbors_1.next.location) {
                                            _this._nextClientAddress = neighbors_1.next.location.address();
                                            if (endAddressElement && (task.getTravel().mode & _this.endTravelMask) == Scheduler.TravelMode.ToNextClient)
                                                endAddressElement.val(_this._nextClientAddress);
                                            endTravelMode.prop("disabled", false);
                                        }
                                    });
                                }
                            }
                        }
                        else {
                            _this._calculateButton.prop("disabled", true);
                        }
                    });
                };
                RoutePage.prototype._setTravelMode = function (travelMaskElement, travelMask) {
                    var task = this._propertyDlg.task;
                    var self = this;
                    if (travelMaskElement.length > 0) {
                        var travelMode = task.getTravel().mode;
                        if (travelMask === this.startTravelMask) {
                            travelMaskElement.append($("<option value='" + (+Scheduler.TravelMode.FromOffice) + "' data-localization='Msg.TravelFromOffice'>Travel from the office to</option>"));
                            if (this._travelModeSupported)
                                travelMaskElement.append($("<option value='" + (+Scheduler.TravelMode.FromPreviousClient) + "' data-localization='Msg.TravelFromClient'>Travel from the previous client to</option>"));
                        }
                        else {
                            travelMaskElement.append($("<option value='" + (+Scheduler.TravelMode.ToOffice) + "' data-localization='Msg.TravelToOffice'>Travel back to the office</option>"));
                            if (this._travelModeSupported)
                                travelMaskElement.append($("<option value='" + (+Scheduler.TravelMode.ToNextClient) + "' data-localization='Msg.TravelToNextClient'>Travel to the next client</option>"));
                        }
                        travelMode = travelMode & travelMask;
                        travelMaskElement.val(travelMode);
                        if (this._travelModeSupported) {
                            travelMaskElement.change(function (e) {
                                var ctrlTarget = e.target;
                                var idx = ctrlTarget.selectedIndex;
                                self._onTravelModeChanged(+ctrlTarget.options[idx].value, travelMask);
                            });
                        }
                    }
                    return travelMaskElement;
                };
                RoutePage.prototype._onTravelModeChanged = function (mode, travelMask) {
                    var travel = this._propertyDlg.travel;
                    var travelMode = +travel.mode;
                    if (travelMask == this.startTravelMask) {
                        if ((travelMode & Scheduler.TravelMode.ToNextClient) == Scheduler.TravelMode.ToNextClient && !this._nextClientAddress)
                            return;
                    }
                    else if (travelMask == this.endTravelMask) {
                        if ((travelMode & Scheduler.TravelMode.FromPreviousClient) == Scheduler.TravelMode.FromPreviousClient && !this._prevClientAddress)
                            return;
                        var endAddressElement = this.tabContentElement.find(".afterEndAddress");
                        if (endAddressElement.length === 1) {
                            var address = (mode & Scheduler.TravelMode.ToNextClient) ? this._nextClientAddress : this._officeAddress;
                            endAddressElement.val(address);
                        }
                    }
                    travel.mode = (travelMode & ~travelMask) | (+mode);
                    this._propertyDlg.onChange("travelMode", travel.mode);
                };
                RoutePage.prototype.removeRescoComponents = function () {
                    this.disposeRescoTimeControls(this._travelFromInputTimePicker);
                    this.disposeRescoTimeControls(this._travelToInputTimePicker);
                };
                RoutePage.prototype._initTimeFields = function () {
                    var minRange = this._propertyDlg.container.settings.roundMinutes;
                    var travelFromElement = this.tabContentElement.find(".travelFrom");
                    if (travelFromElement.length === 1) {
                        var time = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(this._propertyDlg.travel.from));
                        this._travelFromInputTimePicker = this.createRescoInputTimePicker(travelFromElement, minRange, time, { width: 100, height: 27, left: 0, top: 0 }, this._propertyDlg.canSave, this._propertyDlg.zIndex + 10);
                        this._travelFromInputTimePicker.valueChanged.add(this, this._travelFromValueChanged);
                    }
                    var travelToElement = this.tabContentElement.find(".travelTo");
                    if (travelToElement.length === 1) {
                        var time = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(this._propertyDlg.travel.to));
                        this._travelToInputTimePicker = this.createRescoInputTimePicker(travelToElement, minRange, time, { width: 100, height: 27, left: 0, top: 0 }, this._propertyDlg.canSave, this._propertyDlg.zIndex + 10);
                        this._travelToInputTimePicker.valueChanged.add(this, this._travelToValueChanged);
                    }
                };
                RoutePage.prototype._travelFromValueChanged = function (sender, e) {
                    var newValue = Resco.Controls.RescoTime.convertFromRescoTimeToMilisecond(e.value);
                    var travel = this._propertyDlg.travel;
                    if (newValue !== travel.from) {
                        travel.from = newValue;
                        this._propertyDlg.onChange("travelFrom", travel.from);
                        this._propertyDlg.updateEndAndTaskDuration();
                    }
                };
                RoutePage.prototype._travelToValueChanged = function (sender, e) {
                    var newValue = Resco.Controls.RescoTime.convertFromRescoTimeToMilisecond(e.value);
                    var travel = this._propertyDlg.travel;
                    if (newValue !== travel.to) {
                        travel.to = newValue;
                        this._propertyDlg.onChange("travelTo", travel.to);
                        this._propertyDlg.updateEndAndTaskDuration();
                    }
                };
                RoutePage.prototype._calculateTravelDuration = function () {
                    var _this = this;
                    var dlg = this._propertyDlg;
                    var travel = dlg.travel;
                    if (dlg.resource) {
                        Scheduler.Resource.calculateTravelInfo(dlg.task, function (travelInfo) {
                            if (!travelInfo || !travelInfo.fromDuration || !travelInfo.toDuration)
                                Scheduler.StringTable.alert(Scheduler.StringTable.get("Err.RouteNotFound") || "Route not found.");
                            else if (travel.from != travelInfo.fromDuration || travel.to != travelInfo.toDuration) {
                                travel.from = travelInfo.fromDuration;
                                travel.to = travelInfo.toDuration;
                                var timeFrom = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(travel.from));
                                var timeTo = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(travel.to));
                                _this._travelFromInputTimePicker.changeTime(timeFrom);
                                _this._travelToInputTimePicker.changeTime(timeTo);
                                dlg.onChange("travelTo", travel.to);
                                dlg.onChange("travelFrom", travel.from);
                                dlg.updateEndAndTaskDuration();
                            }
                        }, travel.mode);
                    }
                };
                return RoutePage;
            }(Scheduler.BasePickersPage));
            var ViolationsPage = (function (_super) {
                __extends(ViolationsPage, _super);
                function ViolationsPage(dialog) {
                    var _this = _super.call(this, "VIOLATIONS", "Scheduler.Msg.VIOLATIONS", "VIOLATIONS", "Scheduler.Msg.TaskViolatios", "Task rule violations.") || this;
                    _this._propertyDlg = dialog;
                    var list = _this.tabContentBodyElement;
                    list.css({ "font-size": "14px" });
                    for (var i = 0; i < _this._propertyDlg.task.ruleViolations.length; i++) {
                        var ruleViolation = _this._propertyDlg.task.ruleViolations[i];
                        var messageLocalizationKey = Scheduler.RuleViolation.messages.Item(ruleViolation.violationType.toString());
                        var messageLocalizationBackup = Scheduler.RuleViolation.messagesBackup.Item(ruleViolation.violationType.toString());
                        var text = Scheduler.StringTable.get(messageLocalizationKey, ruleViolation.data) || Scheduler.StringTable.replaceBracketsWithArgs(messageLocalizationBackup, ruleViolation.data);
                        if (ruleViolation.violationType === Scheduler.RuleViolationType.OverlappingTasks) {
                            text += " " + _this._getDataText(ruleViolation.data);
                        }
                        else if (ruleViolation.violationType === Scheduler.RuleViolationType.MissingSkills) {
                            text += " " + _this._getDataText(ruleViolation.data);
                        }
                        else if (ruleViolation.violationType === Scheduler.RuleViolationType.MissingTerritories) {
                            text += " " + _this._getDataText(ruleViolation.data);
                        }
                        var item = $("<div>").text(text);
                        if (i > 0)
                            list.append($("<p>"));
                        list.append(item);
                    }
                    return _this;
                }
                ViolationsPage.prototype._getDataText = function (data) {
                    var dataText = "";
                    for (var j = 0; j < data.length; j++) {
                        if (j > 0)
                            dataText += ", ";
                        dataText += data[j];
                    }
                    return dataText;
                };
                return ViolationsPage;
            }(Scheduler.BasePage));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
