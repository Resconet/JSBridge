///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../libs/google.maps.d.ts" />
///<reference path="../container.ts" />
///<reference path="../gridView.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var MapView = (function (_super) {
                __extends(MapView, _super);
                function MapView(container) {
                    var _this = _super.call(this, container) || this;
                    _this._boundingRect = [];
                    _this._markersOfAllSources = new Scheduler.Dictionary();
                    _this._sourcesColor = "red";
                    _this._showHideAllSources = true; // if is set to true, sources are shown on the map
                    _this._showHideTasksOfAllResourcesByDefault = false; // if is set to true, tasks of all resources are shown on the map by default, otherwise no resource have shown its tasks on the map by default.
                    _this._resourceDataRows = [];
                    _this.useTrackedGPSData = false;
                    _this._initShowHideTasksOfAllResources();
                    _this.element = _this._createViewElement();
                    _this._updateViewElement();
                    _this._initOfficeLocation();
                    _this._init(_this.element[0]);
                    return _this;
                }
                /**
                 * Initializes MapView by loading google maps API script.
                 * @param apiKey The API key to authenticate requests.
                 * @param onFinishCallback A callback function that is called when initialization has finished.
                 */
                MapView.initialize = function (apiKey, onFinishCallback) {
                    if (MapView.isInitialized) {
                        onFinishCallback(null);
                    }
                    else {
                        if (apiKey) {
                            $.getScript("https://maps.googleapis.com/maps/api/js?key=" + apiKey + "&sensor=true")
                                .done(function (data, textStatus, jqXHR) {
                                if (((typeof google) !== "undefined") && ((typeof google.maps) !== "undefined")) {
                                    MapView._isInitialized = true;
                                    onFinishCallback(null);
                                }
                                else {
                                    onFinishCallback(Scheduler.StringTable.get("Scheduler.Err.CouldNotAccessGoogleMaps") || "Could not access Google Maps services! Please check your internet connection.");
                                }
                            })
                                .fail(function (xhr, textStatus, errorThrown) {
                                onFinishCallback(Scheduler.StringTable.get("Scheduler.Err.CouldNotAccessGoogleMaps") || "Could not access Google Maps services! Please check your internet connection.");
                            });
                            return;
                        }
                        else {
                            onFinishCallback(Scheduler.StringTable.get("Scheduler.Err.MissingGoogleMapsAPIKey") || "Google Maps API key was not provided by project configuration!");
                        }
                    }
                };
                Object.defineProperty(MapView, "isInitialized", {
                    get: function () {
                        return MapView._isInitialized;
                    },
                    enumerable: true,
                    configurable: true
                });
                MapView.prototype.dispose = function () {
                    ResourceDataRow.removeAllResourcesCheckBoxes();
                };
                MapView.prototype._initShowHideTasksOfAllResources = function () {
                    if (this._showHideTasksOfAllResourcesByDefault) {
                        this._showTasksOfAllResources = true;
                        this._hideTasksOfAllResources = false;
                    }
                    else {
                        this._showTasksOfAllResources = false;
                        this._hideTasksOfAllResources = true;
                    }
                };
                MapView.prototype._createViewElement = function () {
                    var element = $("<div>");
                    element.attr("id", "mapView");
                    return element;
                };
                MapView.prototype._updateViewElement = function () {
                    this.timeNow = new Date().getTime();
                    this._initializeWidth();
                    if (this.element) {
                        this.element.css({ width: this._viewWidth });
                    }
                };
                MapView.prototype._initializeWidth = function () {
                    var computedViewWidth = this._getComputedWidth();
                    if (computedViewWidth)
                        this._viewWidth = computedViewWidth;
                    this.zoom.setContentWidth(this._viewWidth);
                };
                MapView.prototype.redraw = function (resourcesNotReloaded, sourcesNotReloaded) {
                    var _this = this;
                    this._updateViewElement();
                    this.updateTasks();
                    this.onTasksChanged();
                    var promises = [];
                    this._addOfficeMarker().then(function (fitToNeeded) {
                        if (_this.container.isSourceDataReady) {
                            _this._removeMarkersOfAllSources();
                            if (_this.showHideAllSources) {
                                promises.push(_this.container.loadAllDelayedSourceData().then(function () {
                                    return _this._addMarkersOfAllSources();
                                }));
                            }
                        }
                        if (_this.container.isDataReady) {
                            if (_this._resourceDataRows.length === 0) {
                                _this._addResourceDataRows(0);
                                _this._updateSelectedRow();
                            }
                            else {
                                if (resourcesNotReloaded) {
                                    _this._removeRoutesOfAllResources();
                                    _this._updateCheckBoxVisibilityOfAllResources();
                                }
                                else {
                                    _this._removeResourceDataRows();
                                    _this._addResourceDataRows(0);
                                    _this._initShowHideTasksOfAllResources();
                                    _this._updateSelectedRow(); // can be called when ShowHideTasksOfAllResources are initialized yet
                                }
                            }
                            if (_this.showTasksOfAllResources) {
                                promises.push(_this.container.loadAllDelayedData().then(function () {
                                    _this._updateResourcesSelection(true);
                                    return _this._addRoutesOfAllResources();
                                }));
                            }
                            else if (_this.hideTasksOfAllResources) {
                                // all routes were already removed above
                                _this._updateResourcesSelection(false);
                            }
                            else {
                                promises.push(_this._addRoutesOfAllSelectedResources());
                            }
                        }
                        Promise.all(promises).then(function (fitToNeeded) {
                            _this._fitToBounds(); // fitToBounds is always needed in redraw method since we do not know what all was changed
                        });
                    });
                    _super.prototype.redraw.call(this, resourcesNotReloaded, sourcesNotReloaded);
                };
                MapView.prototype._addResourceDataRows = function (startIndex) {
                    for (var i = startIndex; i < this.container.listCtrl.rows.length; i++) {
                        this._resourceDataRows.push(new ResourceDataRow(this.container.getResourceByRowIndex(i), this._showHideTasksOfAllResourcesByDefault, Scheduler.ColorGenerator.getColorFromArray(i)));
                    }
                };
                MapView.prototype._removeResourceDataRows = function () {
                    this._removeRoutesOfAllResources();
                    this._resourceDataRows = [];
                    ResourceDataRow.removeAllResourcesCheckBoxes();
                };
                MapView.prototype._updateResourcesSelection = function (selected) {
                    for (var i = 0; i < this._resourceDataRows.length; i++) {
                        this._resourceDataRows[i].selected = selected;
                    }
                    if (selected) {
                        this.hideTasksOfAllResources = false;
                    }
                    else {
                        this.showTasksOfAllResources = false;
                    }
                };
                MapView.prototype.appendRows = function () {
                    var startIndex = this._resourceDataRows.length;
                    this.updateTasksInRange(startIndex);
                    this.onTasksChanged();
                    this._addResourceDataRows(startIndex);
                };
                MapView.prototype.onResize = function () {
                    this._updateViewElement();
                    this._fitToBounds();
                    _super.prototype.redraw.call(this, true, true);
                };
                Object.defineProperty(MapView.prototype, "showHideAllSources", {
                    get: function () {
                        return this._showHideAllSources;
                    },
                    set: function (value) {
                        var _this = this;
                        if (value !== this.showHideAllSources) {
                            this._showHideAllSources = value;
                            if (this.showHideAllSources) {
                                this.container.loadAllDelayedSourceData().then(function () {
                                    _this._addMarkersOfAllSources().then(function (fitToNeeded) {
                                        if (fitToNeeded) {
                                            _this._fitToBounds();
                                        }
                                    });
                                });
                            }
                            else {
                                if (this._removeMarkersOfAllSources()) {
                                    this._fitToBounds();
                                }
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(MapView.prototype, "showTasksOfAllResources", {
                    get: function () {
                        return this._showTasksOfAllResources;
                    },
                    set: function (value) {
                        var _this = this;
                        if (value !== this.showTasksOfAllResources) {
                            this._showTasksOfAllResources = value;
                            if (this.showTasksOfAllResources) {
                                this.container.loadAllDelayedData().then(function () {
                                    _this._updateResourcesSelection(true);
                                    _this._addRoutesOfAllResources().then(function (fitToNeeded) {
                                        if (fitToNeeded) {
                                            _this._fitToBounds();
                                        }
                                    });
                                });
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(MapView.prototype, "hideTasksOfAllResources", {
                    get: function () {
                        return this._hideTasksOfAllResources;
                    },
                    set: function (value) {
                        if (value !== this.hideTasksOfAllResources) {
                            this._hideTasksOfAllResources = value;
                            if (this.hideTasksOfAllResources) {
                                this._updateResourcesSelection(false);
                                if (this._removeRoutesOfAllResources()) {
                                    this._fitToBounds();
                                }
                            }
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                MapView.prototype._init = function (element) {
                    if (MapView.isInitialized && element && !this._map) {
                        try {
                            this._map = new google.maps.Map(element, {
                                center: new google.maps.LatLng(0, 0),
                                zoom: MapView.initialZoomLevel,
                                mapTypeId: google.maps.MapTypeId.ROADMAP
                            });
                            this._map.addListener("click", function (e) {
                                MarkerTooltip.removeTooltip();
                                if (e) {
                                    e.stop(); // disable showing place popup and possibility to go to the Google Maps page to show details, reviews, photos, etc. about the place
                                }
                            });
                        }
                        catch (ex) {
                        }
                    }
                };
                MapView.prototype._fitToBounds = function () {
                    if (this._map) {
                        this._updateBounds();
                        if (this._boundingRect.length === 4) {
                            this._map.fitBounds(new google.maps.LatLngBounds(new google.maps.LatLng(this._boundingRect[0], this._boundingRect[1]), new google.maps.LatLng(this._boundingRect[2], this._boundingRect[3])));
                        }
                    }
                };
                MapView.prototype._updateBounds = function () {
                    var _this = this;
                    this._boundingRect = [];
                    this._forEachMarker(function (marker) {
                        var position = marker.getPosition();
                        MapView._updateBoundingBox(_this._boundingRect, position.lat(), position.lng());
                    });
                };
                MapView._updateBoundingBox = function (boundingRect, latitude, longitude) {
                    if (boundingRect.length == 0) {
                        boundingRect.push(latitude);
                        boundingRect.push(longitude);
                        boundingRect.push(latitude);
                        boundingRect.push(longitude);
                    }
                    else {
                        if (latitude < boundingRect[0])
                            boundingRect[0] = latitude;
                        else if (latitude > boundingRect[2])
                            boundingRect[2] = latitude;
                        if (longitude < boundingRect[1])
                            boundingRect[1] = longitude;
                        else if (longitude > boundingRect[3])
                            boundingRect[3] = longitude;
                    }
                };
                MapView.prototype._forEachSourceMarker = function (proc) {
                    this._markersOfAllSources.ForEach(proc);
                };
                MapView.prototype._forEachResourceTaskMarker = function (proc) {
                    for (var i = 0; i < this._resourceDataRows.length; i++) {
                        this._resourceDataRows[i].markers.ForEach(proc);
                    }
                };
                MapView.prototype._forEachMarker = function (proc) {
                    if (this._officeMarker) {
                        proc(this._officeMarker);
                    }
                    this._forEachSourceMarker(proc);
                    this._forEachResourceTaskMarker(proc);
                };
                MapView.prototype._getVisitedMarkerIcon = function (color) {
                    return {
                        //  anchor, fillColor, fillOpacity, labelOrigin, path, rotation, scale, strokeColor, strokeOpacity, strokeWeight
                        path: "M10,21c0.1,0.5,0.4,1,1,1s0.9-0.5,1-1c0.4-2.4,2.6-7,4-9c1-1.5,2-3,2-5c0-3.9-3.1-7-7-7S4,3.1,4,7c0,2,1.1,3.5,2.1,5C7.5,14,9.6,18.6,10,21z",
                        anchor: new google.maps.Point(11, 22),
                        //labelOrigin: { x: 11, y: 8 },
                        strokeColor: color,
                        strokeWeight: 1,
                        strokeOpacity: 1,
                        fillColor: color,
                        fillOpacity: 0.7,
                        scale: 1.5
                    };
                };
                MapView.prototype._getPendingVisitsMarkerIcon = function (color) {
                    var icon = this._getVisitedMarkerIcon(color);
                    icon.strokeWeight = 3;
                    icon.fillColor = "transparent";
                    icon.fillOpacity = 1;
                    return icon;
                };
                MapView.prototype._initOfficeLocation = function () {
                    if (MapView.isInitialized) {
                        this._geocoder = new google.maps.Geocoder();
                    }
                };
                MapView.prototype._geocodeOfficeLocation = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        var request_1;
                        return __generator(this, function (_a) {
                            if (this._geocoder) {
                                request_1 = {};
                                request_1.address = Scheduler.Container.defaultOffice.location.address();
                                return [2 /*return*/, new Promise(function (resolve, reject) {
                                        _this._geocoder.geocode(request_1, function (results, status) {
                                            if (status === google.maps.GeocoderStatus.OK) {
                                                if (results && (results.length > 0)) {
                                                    var result = results[0];
                                                    if (result && result.geometry && result.geometry.location) {
                                                        var latlng = result.geometry.location;
                                                        Scheduler.Container.defaultOffice.location.setLocation(latlng.lat(), latlng.lng());
                                                    }
                                                }
                                            }
                                            resolve();
                                        });
                                    })];
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                MapView.prototype._loadOfficeLocation = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var location;
                        return __generator(this, function (_a) {
                            location = Scheduler.Container.defaultOffice.location;
                            if (location.hasGPS()) {
                                return [2 /*return*/];
                            }
                            else if (location.address()) {
                                return [2 /*return*/, this._geocodeOfficeLocation()];
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                MapView.prototype._addOfficeMarker = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        return __generator(this, function (_a) {
                            return [2 /*return*/, this._loadOfficeLocation().then(function () {
                                    var location = Scheduler.Container.defaultOffice.location;
                                    if (location.hasGPS()) {
                                        var icon = _this._getVisitedMarkerIcon("black");
                                        _this._createOfficeMarker(location.latitude, location.longitude, icon);
                                        return true;
                                    }
                                    return false;
                                })];
                        });
                    });
                };
                MapView.prototype._createOfficeMarker = function (lat, lng, icon) {
                    if (this._officeMarker) {
                        this._officeMarker.setMap(null); // remove old marker from map
                    }
                    this._officeMarker = new google.maps.Marker({
                        map: this._map,
                        position: new google.maps.LatLng(lat, lng),
                        icon: icon,
                        clickable: true,
                        visible: true
                    });
                    this._addOfficeMarkerEvents();
                };
                MapView.prototype._addMarkersOfAllSources = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        var tasks, icon_1;
                        return __generator(this, function (_a) {
                            tasks = this.container.getTasksFromHorizontalListItems();
                            if (tasks.length > 0) {
                                icon_1 = this._getVisitedMarkerIcon(this._sourcesColor);
                                return [2 /*return*/, new Promise(function (resolve, reject) {
                                        _this.container.loadCustomerAddresses(tasks, function (loadedCount) {
                                            _this._addMarkersForTasks(tasks, _this._markersOfAllSources, icon_1);
                                            resolve(true);
                                        });
                                    })];
                            }
                            return [2 /*return*/, false];
                        });
                    });
                };
                MapView.prototype._removeMarkersOfAllSources = function () {
                    var fitToNeeded = this._removeAllMarkersFromMap(this._markersOfAllSources);
                    this._markersOfAllSources = new Scheduler.Dictionary();
                    return fitToNeeded;
                };
                MapView.prototype._addRoutesOfAllResources = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        var allFilteredTasks, i;
                        return __generator(this, function (_a) {
                            allFilteredTasks = [];
                            for (i = 0; i < this._resourceDataRows.length; i++) {
                                allFilteredTasks.push.apply(allFilteredTasks, this._resourceDataRows[i].getFilteredTasks());
                            }
                            if (allFilteredTasks.length > 0) {
                                return [2 /*return*/, new Promise(function (resolve, reject) {
                                        _this.container.loadCustomerAddresses(allFilteredTasks, function (loadedCount) {
                                            var fitToNeeded = false;
                                            for (var i = 0; i < _this._resourceDataRows.length; i++) {
                                                if (_this._addResourceRoute(_this._resourceDataRows[i])) {
                                                    fitToNeeded = true;
                                                }
                                            }
                                            resolve(fitToNeeded);
                                        });
                                    })];
                            }
                            return [2 /*return*/, false];
                        });
                    });
                };
                MapView.prototype._addRoutesOfAllSelectedResources = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        var allFilteredTasks, i, resourceDataRow;
                        return __generator(this, function (_a) {
                            allFilteredTasks = [];
                            for (i = 0; i < this._resourceDataRows.length; i++) {
                                resourceDataRow = this._resourceDataRows[i];
                                if (resourceDataRow.selected) {
                                    allFilteredTasks.push.apply(allFilteredTasks, resourceDataRow.getFilteredTasks());
                                }
                            }
                            if (allFilteredTasks.length > 0) {
                                return [2 /*return*/, new Promise(function (resolve, reject) {
                                        _this.container.loadCustomerAddresses(allFilteredTasks, function (loadedCount) {
                                            var fitToNeeded = false;
                                            for (var i = 0; i < _this._resourceDataRows.length; i++) {
                                                var resourceDataRow = _this._resourceDataRows[i];
                                                if (resourceDataRow.selected) {
                                                    if (_this._addResourceRoute(resourceDataRow)) {
                                                        fitToNeeded = true;
                                                    }
                                                }
                                            }
                                            resolve(fitToNeeded);
                                        });
                                    })];
                            }
                            return [2 /*return*/, false];
                        });
                    });
                };
                MapView.prototype._removeRoutesOfAllResources = function () {
                    var fitToNeeded = false;
                    for (var i = 0; i < this._resourceDataRows.length; i++) {
                        if (this._removeResourceRoute(this._resourceDataRows[i])) {
                            fitToNeeded = true;
                        }
                    }
                    return fitToNeeded;
                };
                MapView.prototype._removeAllMarkersFromMap = function (markers) {
                    var fitToNeeded = false;
                    if (markers) {
                        markers.ForEach(function (item) {
                            item.setMap(null);
                            fitToNeeded = true;
                        });
                    }
                    return fitToNeeded;
                };
                // temporary unused
                //private _removeMarkersForTasks(tasks: Task[], markers: Dictionary<google.maps.Marker>): void {
                //	if (!tasks || !markers) {
                //		return;
                //	}
                //	for (let i = 0; i < tasks.length; i++) {
                //		let id = tasks[i].id;
                //		if (markers.ContainsKey(id)) {
                //			markers.Remove(id).setMap(null); // setMap(null) removes old marker from map
                //		}
                //	}
                //}
                MapView.prototype._addResourceMarkers = function (resourceDataRow) {
                    var fitToNeeded = this._removeResourceMarkers(resourceDataRow);
                    var completedTasksLength = 0;
                    if (this.container.settings.showCompletedAndCanceled) {
                        var completedTasks = resourceDataRow.getCompletedTasks();
                        completedTasksLength = completedTasks.length;
                        this._addMarkersForTasks(completedTasks, resourceDataRow.markers, this._getVisitedMarkerIcon(resourceDataRow.color));
                    }
                    var reschedulableTasks = resourceDataRow.getReschedulableTasks();
                    this._addMarkersForTasks(reschedulableTasks, resourceDataRow.markers, this._getPendingVisitsMarkerIcon(resourceDataRow.color));
                    return fitToNeeded || ((completedTasksLength + reschedulableTasks.length) > 0);
                };
                MapView.prototype._removeResourceMarkers = function (resourceDataRow) {
                    var fitToNeeded = this._removeAllMarkersFromMap(resourceDataRow.markers);
                    resourceDataRow.markers = new Scheduler.Dictionary();
                    return fitToNeeded;
                };
                MapView.prototype._addMarkersForTasks = function (tasks, markers, icon) {
                    if (!tasks || !markers) {
                        return;
                    }
                    for (var i = 0; i < tasks.length; i++) {
                        var task = tasks[i];
                        var location_1 = task.location;
                        if (location_1 && location_1.hasGPS()) {
                            this._createMarker(markers, task, location_1.latitude, location_1.longitude, icon);
                        }
                    }
                };
                /**
                 * Creates new marker or update existing marker.
                 */
                MapView.prototype._createMarker = function (markers, task, lat, lng, icon) {
                    var marker = new google.maps.Marker({
                        map: this._map,
                        position: new google.maps.LatLng(lat, lng),
                        icon: icon,
                        clickable: true,
                        visible: true
                    });
                    if (markers.ContainsKey(task.id)) {
                        markers.Item(task.id).setMap(null); // remove old marker from map
                    }
                    this._addMarkersEvents(marker, task);
                    markers.Add(task.id, marker); // add or replace
                };
                MapView.prototype._addMarkersEvents = function (marker, task) {
                    var _this = this;
                    var timeoutId;
                    marker.addListener("mouseover", function () {
                        if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            MarkerTooltip.createMarkerTooltip(_this._map, marker, task);
                        }
                    });
                    marker.addListener("mouseout", function () {
                        if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            MarkerTooltip.removeTooltip();
                        }
                    });
                    marker.addListener("click", function () {
                        if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                            timeoutId = setTimeout(function () {
                                timeoutId = undefined;
                                if (!Scheduler.TaskPropertyDlg.isShown()) {
                                    MarkerTooltip.createMarkerTooltip(_this._map, marker, task);
                                }
                            }, 300);
                        }
                    });
                    marker.addListener("dblclick", function () {
                        if (task.isUnscheduledNew()) {
                            if (task.group) {
                                clearTimeout(timeoutId);
                                timeoutId = undefined;
                                Scheduler.TaskTooltip.removeTooltip();
                                _this.container.openSourceForm(task.group.id);
                            }
                        }
                        else {
                            clearTimeout(timeoutId);
                            timeoutId = undefined;
                            _this.container.showTaskDialog(task);
                        }
                    });
                };
                MapView.prototype._addOfficeMarkerEvents = function () {
                    var _this = this;
                    var marker = this._officeMarker;
                    var name = Scheduler.StringTable.get("Scheduler.Msg.Office") || "Office";
                    if (this._officeMarker) {
                        marker.addListener("mouseover", function () {
                            if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                MarkerTooltip.createMarkerTooltip(_this._map, marker, name);
                            }
                        });
                        marker.addListener("mouseout", function () {
                            if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                MarkerTooltip.removeTooltip();
                            }
                        });
                        marker.addListener("click", function () {
                            if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                if (!Scheduler.TaskPropertyDlg.isShown()) {
                                    MarkerTooltip.createMarkerTooltip(_this._map, marker, name);
                                }
                            }
                        });
                    }
                };
                MapView.prototype._updateSelectedRow = function () {
                    var rowIndex = this.container.getSelectedRow();
                    if ((0 <= rowIndex) && (rowIndex < this._resourceDataRows.length)) {
                        var resourceDataRow = this._resourceDataRows[rowIndex];
                        resourceDataRow.selected = true;
                        this._updateShowTasksOfAllResources();
                    }
                };
                /**
                 * Shows all reschedulable and completed tasks (based on filter settings) of the resource on the map.
                 * @param rowIndex The rowIndex of the resource of the tasks to show.
                 */
                MapView.prototype.selectResource = function (rowIndex) {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        var resourceDataRow_1, filteredTasks_1;
                        return __generator(this, function (_a) {
                            if ((0 <= rowIndex) && (rowIndex < this._resourceDataRows.length)) {
                                resourceDataRow_1 = this._resourceDataRows[rowIndex];
                                resourceDataRow_1.selected = true;
                                this._updateShowTasksOfAllResources();
                                filteredTasks_1 = resourceDataRow_1.getFilteredTasks();
                                if (filteredTasks_1.length > 0) {
                                    return [2 /*return*/, new Promise(function (resolve, reject) {
                                            _this.container.loadCustomerAddresses(filteredTasks_1, function (loadedCount) {
                                                if (_this._addResourceRoute(resourceDataRow_1)) {
                                                    _this._fitToBounds();
                                                }
                                                resolve();
                                            });
                                        })];
                                }
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                /**
                 * Hides all reschedulable tasks of the resource on the map.
                 * @param rowIndex The rowIndex of the resource of the tasks to show.
                 */
                MapView.prototype.unselectResource = function (rowIndex) {
                    if ((0 <= rowIndex) && (rowIndex < this._resourceDataRows.length)) {
                        var resourceDataRow = this._resourceDataRows[rowIndex];
                        resourceDataRow.selected = false;
                        this._updateHideTasksOfAllResources();
                        if (this._removeResourceRoute(resourceDataRow)) {
                            this._fitToBounds();
                        }
                    }
                };
                /**
                 * Redraws all reschedulable and completed tasks (based on filter settings) of the resource and the route between them on the map.
                 * @param rowIndex The rowIndex of the resource of the tasks to show.
                 */
                MapView.prototype.updateResource = function (rowIndex) {
                    if ((0 <= rowIndex) && (rowIndex < this._resourceDataRows.length)) {
                        var resourceDataRow = this._resourceDataRows[rowIndex];
                        resourceDataRow.updateCheckBoxVisibility();
                        if (resourceDataRow.selected) {
                            if (this._addResourceRoute(resourceDataRow)) {
                                this._fitToBounds();
                            }
                        }
                    }
                };
                MapView.prototype._updateCheckBoxVisibilityOfAllResources = function () {
                    for (var i = 0; i < this._resourceDataRows.length; i++) {
                        this._resourceDataRows[i].updateCheckBoxVisibility();
                    }
                };
                /**
                 * Returns value that indicates whether resource given by argument is selected.
                 * @param rowIndex The rowIndex of the resource that we want to test.
                 */
                MapView.prototype.isSelected = function (rowIndex) {
                    if ((0 <= rowIndex) && (rowIndex < this._resourceDataRows.length)) {
                        return this._resourceDataRows[rowIndex].selected;
                    }
                    return false;
                };
                /**
                 * Creates and adds color element and "eye" checkbox element to the resource row element.
                 * @param rowIndex The rowIndex of the resource.
                 */
                MapView.prototype.addResourceCheckBox = function (rowIndex) {
                    if ((0 <= rowIndex) && (rowIndex < this._resourceDataRows.length)) {
                        var resourceDataRow = this._resourceDataRows[rowIndex];
                        resourceDataRow.removeResourceCheckBox();
                        resourceDataRow.addResourceCheckBox();
                    }
                };
                /**
                 * Removes color element and "eye" checkbox element from the resource row element.
                 * @param rowIndex The rowIndex of the resource.
                 */
                MapView.prototype.removeResourceCheckBox = function (rowIndex) {
                    if ((0 <= rowIndex) && (rowIndex < this._resourceDataRows.length)) {
                        var resourceDataRow = this._resourceDataRows[rowIndex];
                        resourceDataRow.removeResourceCheckBox();
                    }
                };
                MapView.prototype._addResourceRoute = function (resourceDataRow) {
                    // Old markers and polyline (route) are removed before new markers and polyline (route) are added.
                    var fitToNeeded = this._addResourceMarkers(resourceDataRow);
                    this._addResourcePolyline(resourceDataRow);
                    return fitToNeeded;
                };
                MapView.prototype._removeResourceRoute = function (resourceDataRow) {
                    this._removeResourcePolyline(resourceDataRow); // Polyline is removed before markers, because in opposite case it does not look well when polyline stays alone on map for few milliseconds.
                    return this._removeResourceMarkers(resourceDataRow);
                };
                MapView.prototype._updateShowTasksOfAllResources = function () {
                    this._hideTasksOfAllResources = false;
                    if (this.container.allDataLoaded) {
                        for (var i = 0; i < this._resourceDataRows.length; i++) {
                            if (!this._resourceDataRows[i].selected) {
                                this._showTasksOfAllResources = false;
                                return;
                            }
                        }
                        this._showTasksOfAllResources = true;
                    }
                    else {
                        this._showTasksOfAllResources = false;
                    }
                };
                MapView.prototype._updateHideTasksOfAllResources = function () {
                    this._showTasksOfAllResources = false;
                    for (var i = 0; i < this._resourceDataRows.length; i++) {
                        if (this._resourceDataRows[i].selected) {
                            this._hideTasksOfAllResources = false;
                            return;
                        }
                    }
                    this._hideTasksOfAllResources = true;
                };
                MapView.prototype._addResourcePolyline = function (resourceDataRow) {
                    this._removeResourcePolyline(resourceDataRow);
                    // PastPolyline
                    var pastPoints = resourceDataRow.getPastPolylinePoints(this.useTrackedGPSData);
                    if (pastPoints.length > 1) {
                        var pastLineOptions = {
                            strokeColor: resourceDataRow.color,
                            strokeOpacity: 0.90,
                            strokeWeight: 5,
                            icons: undefined
                        };
                        resourceDataRow.pastPointsPolyline = this.appendPolyline(pastPoints, pastLineOptions, this.useTrackedGPSData ? PolylineRenderMode.BSpline : PolylineRenderMode.DirectionsService);
                    }
                    // PendingVisitsPolyline
                    var pointsToVisit = [];
                    pointsToVisit = resourceDataRow.getPendingVisitsPolylinePoints();
                    if (pastPoints.length > 0) {
                        pointsToVisit.splice(0, 0, pastPoints[pastPoints.length - 1]);
                    }
                    if (pointsToVisit.length > 1) {
                        var pendingLineOptions = {
                            strokeColor: resourceDataRow.color,
                            strokeOpacity: 0,
                            //directionsCallback: legs => user.predictPoints(legs),
                            icons: [MapDataPresenter.getPolylinePathIcon()]
                        };
                        resourceDataRow.pendingVisitsPolyline = this.appendPolyline(pointsToVisit, pendingLineOptions, PolylineRenderMode.DirectionsService);
                    }
                };
                MapView.prototype.appendPolyline = function (coordinates, lineOptions, renderMode) {
                    if (!coordinates || coordinates.length < 2)
                        return undefined;
                    if (renderMode == PolylineRenderMode.DirectionsService) {
                        var polyline_1 = this._appendPolyline(undefined, lineOptions);
                        this._getDirections(coordinates, function (result, status) {
                            if (status == google.maps.DirectionsStatus.OK) {
                                var bestRoute = result.routes[0];
                                if ("directionsCallback" in lineOptions) {
                                    var callback = lineOptions["directionsCallback"];
                                    callback(bestRoute.legs);
                                }
                                polyline_1.setPath(bestRoute.overview_path);
                            }
                        });
                        return polyline_1;
                    }
                    var wayPoints = [];
                    if (renderMode == PolylineRenderMode.BSpline && coordinates.length >= 4) {
                        wayPoints = MapView.bspline(coordinates);
                    }
                    else {
                        for (var _i = 0, coordinates_1 = coordinates; _i < coordinates_1.length; _i++) {
                            var c = coordinates_1[_i];
                            wayPoints.push({ lat: +c.lat, lng: +c.lon });
                        }
                    }
                    return this._appendPolyline(wayPoints, lineOptions);
                };
                MapView.prototype._appendPolyline = function (path, lineOptions) {
                    var options = lineOptions || {};
                    options.path = path;
                    options.geodesic = true;
                    var polyline = new google.maps.Polyline(options);
                    polyline.setMap(this._map);
                    return polyline;
                };
                MapView.bspline = function (coordinates) {
                    var ax, ay, bx, by, cx, cy, dx, dy, lat, lon, points;
                    var nCoords = coordinates.length;
                    var p = coordinates[0];
                    points = [{ lat: p.lat, lng: p.lon }];
                    for (var i = 2; i < nCoords - 1; i++) {
                        var prepreC = coordinates[i - 2];
                        var preC = coordinates[i - 1];
                        var thisC = coordinates[i];
                        var nextC = coordinates[i + 1];
                        ax = (-prepreC.lat + 3 * preC.lat - 3 * thisC.lat + nextC.lat) / 6;
                        ay = (-prepreC.lon + 3 * preC.lon - 3 * thisC.lon + nextC.lon) / 6;
                        bx = (prepreC.lat - 2 * preC.lat + thisC.lat) / 2;
                        by = (prepreC.lon - 2 * preC.lon + thisC.lon) / 2;
                        cx = (-prepreC.lat + thisC.lat) / 2;
                        cy = (-prepreC.lon + thisC.lon) / 2;
                        dx = (prepreC.lat + 4 * preC.lat + thisC.lat) / 6;
                        dy = (prepreC.lon + 4 * preC.lon + thisC.lon) / 6;
                        for (var t = 0; t < 1; t += 0.2) {
                            lat = ax * Math.pow(t + 0.1, 3) + bx * Math.pow(t + 0.1, 2) + cx * (t + 0.1) + dx;
                            lon = ay * Math.pow(t + 0.1, 3) + by * Math.pow(t + 0.1, 2) + cy * (t + 0.1) + dy;
                            points.push({ lat: lat, lng: lon });
                        }
                    }
                    p = coordinates[nCoords - 1];
                    points.push({ lat: p.lat, lng: p.lon });
                    return points;
                };
                MapView.prototype._removeResourcePolyline = function (resourceDataRow) {
                    if (resourceDataRow.pastPointsPolyline) {
                        resourceDataRow.pastPointsPolyline.setMap(null);
                        resourceDataRow.pastPointsPolyline = undefined;
                    }
                    if (resourceDataRow.pendingVisitsPolyline) {
                        resourceDataRow.pendingVisitsPolyline.setMap(null);
                        resourceDataRow.pendingVisitsPolyline = undefined;
                    }
                };
                MapView.prototype._getDirections = function (coordinates, callback) {
                    if (!coordinates || coordinates.length < 2)
                        return false;
                    if (!this._directionsService)
                        this._directionsService = new google.maps.DirectionsService();
                    var wayPoints = [];
                    for (var i = 1; i < coordinates.length - 1; i++) {
                        wayPoints.push({ location: this._createMarkerCoordinate(coordinates[i]) });
                    }
                    var request = { origin: this._createMarkerCoordinate(coordinates[0]), destination: this._createMarkerCoordinate(coordinates[coordinates.length - 1]), waypoints: wayPoints, travelMode: google.maps.TravelMode.DRIVING };
                    this._directionsService.route(request, callback.bind(this));
                    return true;
                };
                MapView.prototype._createMarkerCoordinate = function (location) {
                    return location.lat + "," + location.lon;
                };
                return MapView;
            }(Scheduler.BaseView));
            MapView._isInitialized = false;
            MapView.initialZoomLevel = 2;
            Scheduler.MapView = MapView;
            var MapLocation = (function () {
                function MapLocation(lat, lon) {
                    this.lat = lat;
                    this.lon = lon;
                }
                MapLocation.prototype.equals = function (other) {
                    return other && this.lat == other.lat && this.lon == other.lon;
                };
                MapLocation.prototype.distanceTo = function (point) {
                    return GeoTools.getDistanceInMeters(this.lat, this.lon, point.lat, point.lon);
                };
                MapLocation.prototype.hasGPS = function () {
                    return (this.lat !== undefined && this.lat !== null) && (this.lon !== undefined && this.lon !== null);
                };
                return MapLocation;
            }());
            var GeoTools = (function () {
                function GeoTools() {
                }
                GeoTools.getDistanceInMeters = function (lat1, lon1, lat2, lon2) {
                    var latRad1 = lat1 * GeoTools.deg2rad;
                    var longRad1 = lon1 * GeoTools.deg2rad;
                    var latRad2 = lat2 * GeoTools.deg2rad;
                    var longRad2 = lon2 * GeoTools.deg2rad;
                    var diffLongRad = longRad2 - longRad1;
                    var diffLatRad = latRad2 - latRad1;
                    var a = Math.pow(Math.sin(diffLatRad / 2.0), 2.0) + ((Math.cos(latRad1) * Math.cos(latRad2)) * Math.pow(Math.sin(diffLongRad / 2.0), 2.0));
                    var c = 2.0 * Math.atan2(Math.sqrt(a), Math.sqrt(1.0 - a));
                    return GeoTools.avg_earth_radius * c;
                };
                return GeoTools;
            }());
            GeoTools.PI = 3.1415926535897932384626433832795028841971693993751;
            GeoTools.deg2rad = GeoTools.PI / 180.0;
            GeoTools.avg_earth_radius = 6376500.0; // 6378100; // True radius varies from 6356752.3m (polar) to 6378137m (equatorial).
            var TimedMapLocation = (function (_super) {
                __extends(TimedMapLocation, _super);
                function TimedMapLocation(lat, lon, loggedOn) {
                    var _this = _super.call(this, lat, lon) || this;
                    _this.loggedOn = loggedOn;
                    return _this;
                }
                return TimedMapLocation;
            }(MapLocation));
            var PolylineRenderMode;
            (function (PolylineRenderMode) {
                PolylineRenderMode[PolylineRenderMode["None"] = 0] = "None";
                PolylineRenderMode[PolylineRenderMode["BSpline"] = 1] = "BSpline";
                PolylineRenderMode[PolylineRenderMode["DirectionsService"] = 2] = "DirectionsService";
            })(PolylineRenderMode = Scheduler.PolylineRenderMode || (Scheduler.PolylineRenderMode = {}));
            var MapDataPresenter = (function () {
                function MapDataPresenter() {
                }
                MapDataPresenter.getPolylinePathIcon = function () {
                    if (!MapDataPresenter._polylinePathIcon)
                        MapDataPresenter._polylinePathIcon = {
                            icon: {
                                path: google.maps.SymbolPath.CIRCLE,
                                fillOpacity: 0.9,
                                scale: 4
                            },
                            offset: "0",
                            repeat: "14px"
                        };
                    return MapDataPresenter._polylinePathIcon;
                };
                return MapDataPresenter;
            }());
            /**
             * Preserves additional row data necessary for map view, where row represents individual resource in the list.
             */
            var ResourceDataRow = (function () {
                /**
                 * Creates instance of ResourceDataRow object.
                 * @param rowIndex Row index of the resource in the resource list. Value must be greater or equal than 0 and less than Container.ref.listCtrl.rows.length.
                 * @param selected If set to true, resource check box will be checked.
                 * @param color Color that will be used for resource.
                 */
                function ResourceDataRow(resource, selected, color) {
                    this._selected = false;
                    this.markers = new Scheduler.Dictionary();
                    this.points = []; // tracked way points
                    this.color = "red";
                    this._resource = resource;
                    this.selected = selected;
                    this.color = color;
                    this.addResourceCheckBox();
                }
                Object.defineProperty(ResourceDataRow.prototype, "resource", {
                    get: function () {
                        return this._resource;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceDataRow.prototype, "rowIndex", {
                    get: function () {
                        return this.resource.rowIndex;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceDataRow.prototype, "selected", {
                    get: function () {
                        return this._selected;
                    },
                    set: function (value) {
                        if (value !== this.selected) {
                            this._selected = value;
                            this._updateResourceCheckBoxSelection();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceDataRow.prototype, "hasFilteredTasks", {
                    get: function () {
                        return this.getFilteredTasks(true).length > 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ResourceDataRow.prototype, "hasCheckBox", {
                    get: function () {
                        if ((0 <= this.rowIndex) && (this.rowIndex < Scheduler.Container.ref.listCtrl.rows.length)) {
                            var row = Scheduler.Container.ref.listCtrl.rows[this.rowIndex];
                            return row.$root.find(".mapResourceCheckBox").length > 0;
                        }
                        return false;
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                 * Shows or hides "eye" checkbox on the row resource.
                 */
                ResourceDataRow.prototype.updateCheckBoxVisibility = function () {
                    this._updateResourceCheckBoxVisibility();
                };
                /**
                 * Returns all reschedulable tasks of the row resource.
                 */
                ResourceDataRow.prototype.getReschedulableTasks = function () {
                    var filteredTasks = [];
                    var tasks = this.resource.getTasks();
                    if (tasks && (tasks.length > 0)) {
                        filteredTasks = tasks.filter(function (task) {
                            return task.getStatus().canBeRescheduled();
                        });
                    }
                    return filteredTasks;
                };
                /**
                 * Returns all completed tasks of the row resource.
                 */
                ResourceDataRow.prototype.getCompletedTasks = function () {
                    var filteredTasks = [];
                    var tasks = this.resource.getTasks();
                    if (tasks && (tasks.length > 0)) {
                        filteredTasks = tasks.filter(function (task) {
                            return task.getStatus().taskStatusType() === Scheduler.TaskStatusType.Completed;
                        });
                    }
                    return filteredTasks;
                };
                /**
                 * Returns all reschedulable and completed tasks (based on filter settings) of the row resource.
                 * @param firstOnly If is set to true method returns first filtered task only.
                 */
                ResourceDataRow.prototype.getFilteredTasks = function (firstOnly) {
                    var filteredTasks = [];
                    var tasks = this.resource.getTasks();
                    if (tasks && (tasks.length > 0)) {
                        var predicate = function (task) {
                            return (task.getStatus().canBeRescheduled() || (Scheduler.Container.ref.settings.showCompletedAndCanceled && (task.getStatus().taskStatusType() === Scheduler.TaskStatusType.Completed)));
                        };
                        if (firstOnly) {
                            for (var i = 0; i < tasks.length; i++) {
                                var task = tasks[i];
                                if (predicate(task)) {
                                    filteredTasks.push(task);
                                    break;
                                }
                            }
                        }
                        else {
                            filteredTasks = tasks.filter(predicate);
                        }
                    }
                    return filteredTasks;
                };
                /**
                 * Returns points created from tracked way points and/or completed tasks location points.
                 */
                ResourceDataRow.prototype.getPastPolylinePoints = function (useTrackedGPSData) {
                    var polylinePoints = [];
                    if (useTrackedGPSData && this.points) {
                        var timedPoints = this.points.filter(function (point) {
                            return point.hasGPS();
                        });
                        timedPoints.sort(function (a, b) {
                            return (a.loggedOn > b.loggedOn) ? 1 : -1;
                        });
                        polylinePoints = timedPoints.map(function (timedPoint) {
                            return new MapLocation(timedPoint.lat, timedPoint.lon);
                        });
                    }
                    else {
                        if (Scheduler.Container.ref.settings.showCompletedAndCanceled) {
                            var completedTasks = this.getCompletedTasks();
                            if (completedTasks.length > 0) {
                                var tasksWithGPS = this._getTasksWithGPS(completedTasks);
                                var officeLocation = Scheduler.Container.defaultOffice.location;
                                for (var i = 0; i < tasksWithGPS.length; i++) {
                                    var task = tasksWithGPS[i];
                                    if (this._hasTravelFromOffice(task.getTravel().mode) && officeLocation.hasGPS()) {
                                        polylinePoints.push(new MapLocation(officeLocation.latitude, officeLocation.longitude));
                                    }
                                    polylinePoints.push(new MapLocation(task.location.latitude, task.location.longitude));
                                }
                            }
                        }
                    }
                    return polylinePoints;
                };
                /**
                 * Returns points created from reschedulable tasks locations.
                 */
                ResourceDataRow.prototype.getPendingVisitsPolylinePoints = function () {
                    var polylinePoints = [];
                    var reschedulableTasks = this.getReschedulableTasks();
                    var tasksWithGPS = this._getTasksWithGPS(reschedulableTasks);
                    var officeLocation = Scheduler.Container.defaultOffice.location;
                    for (var i = 0; i < tasksWithGPS.length; i++) {
                        var task = tasksWithGPS[i];
                        if (this._hasTravelFromOffice(task.getTravel().mode) && officeLocation.hasGPS()) {
                            polylinePoints.push(new MapLocation(officeLocation.latitude, officeLocation.longitude));
                        }
                        polylinePoints.push(new MapLocation(task.location.latitude, task.location.longitude));
                    }
                    if (tasksWithGPS.length > 0) {
                        var task = tasksWithGPS[tasksWithGPS.length - 1];
                        if (this._hasTravelToOffice(task.getTravel().mode) && officeLocation.hasGPS()) {
                            polylinePoints.push(new MapLocation(officeLocation.latitude, officeLocation.longitude));
                        }
                    }
                    return polylinePoints;
                };
                ResourceDataRow.prototype._getTasksWithGPS = function (tasks) {
                    return tasks.filter(function (task) {
                        return (task.location && task.location.hasGPS()) ? true : false;
                    });
                };
                ResourceDataRow.prototype._hasTravelFromOffice = function (travelMode) {
                    if (travelMode === Scheduler.TravelMode.Default || travelMode === Scheduler.TravelMode.FromOffice || travelMode === Scheduler.TravelMode.FromOfficeToNextClient || travelMode === Scheduler.TravelMode.FromOfficeToOffice) {
                        return true;
                    }
                    if (travelMode === Scheduler.TravelMode.ToOffice || travelMode === Scheduler.TravelMode.ToNextClient) {
                        return true;
                    }
                    return false;
                };
                ResourceDataRow.prototype._hasTravelToOffice = function (travelMode) {
                    if (travelMode === Scheduler.TravelMode.Default || travelMode === Scheduler.TravelMode.FromOfficeToOffice || travelMode === Scheduler.TravelMode.FromPreviousClientToOffice || travelMode === Scheduler.TravelMode.ToOffice) {
                        return true;
                    }
                    if (travelMode === Scheduler.TravelMode.FromOffice || travelMode === Scheduler.TravelMode.FromPreviousClient) {
                        return true;
                    }
                    return false;
                };
                ResourceDataRow._getResourceCheckBoxImageName = function (selected) {
                    return selected ? "resourceShown.png" : "resourceHidden.png";
                };
                ResourceDataRow._createResourceColorElement = function (selected, color) {
                    var cell = $("<div>");
                    cell.addClass("mapResourceColor");
                    cell.css({ "background-color": color });
                    cell.css({ "display": selected ? "" : "none" });
                    return cell;
                };
                ResourceDataRow._createResourceCheckBoxElement = function (selected, visible) {
                    var image = $("<div>");
                    image.addClass("mapResourceCheckBoxImage");
                    image.css({ "background-image": "url(" + Scheduler.Container.imageFolder + ResourceDataRow._getResourceCheckBoxImageName(selected) + ")" });
                    var cell = $("<div>");
                    cell.addClass("mapResourceCheckBox");
                    cell.css({ "display": visible ? "" : "none" });
                    cell.append(image);
                    return cell;
                };
                /**
                 * Creates and adds color element and "eye" checkbox element to the resource row element.
                 */
                ResourceDataRow.prototype.addResourceCheckBox = function () {
                    if ((0 <= this.rowIndex) && (this.rowIndex < Scheduler.Container.ref.listCtrl.rows.length)) {
                        var row = Scheduler.Container.ref.listCtrl.rows[this.rowIndex];
                        var alRow = row.$root.children().first();
                        alRow.append(ResourceDataRow._createResourceColorElement(this.selected, this.color));
                        alRow.append(ResourceDataRow._createResourceCheckBoxElement(this.selected, this.hasFilteredTasks));
                    }
                };
                ResourceDataRow.prototype._updateResourceCheckBoxSelection = function () {
                    if ((0 <= this.rowIndex) && (this.rowIndex < Scheduler.Container.ref.listCtrl.rows.length)) {
                        var row = Scheduler.Container.ref.listCtrl.rows[this.rowIndex];
                        row.$root.find(".mapResourceColor").css({ "display": this.selected ? "" : "none" });
                        row.$root.find(".mapResourceCheckBoxImage").css({ "background-image": "url(" + Scheduler.Container.imageFolder + ResourceDataRow._getResourceCheckBoxImageName(this.selected) + ")" });
                    }
                };
                ResourceDataRow.prototype._updateResourceCheckBoxVisibility = function () {
                    if ((0 <= this.rowIndex) && (this.rowIndex < Scheduler.Container.ref.listCtrl.rows.length)) {
                        var row = Scheduler.Container.ref.listCtrl.rows[this.rowIndex];
                        row.$root.find(".mapResourceCheckBox").css({ "display": this.hasFilteredTasks ? "" : "none" });
                    }
                };
                /**
                 * Removes color element and "eye" checkbox element from the resource row element.
                 */
                ResourceDataRow.prototype.removeResourceCheckBox = function () {
                    if ((0 <= this.rowIndex) && (this.rowIndex < Scheduler.Container.ref.listCtrl.rows.length)) {
                        var row = Scheduler.Container.ref.listCtrl.rows[this.rowIndex];
                        row.$root.find(".mapResourceColor").remove();
                        row.$root.find(".mapResourceCheckBox").remove();
                    }
                };
                ResourceDataRow.removeAllResourcesCheckBoxes = function () {
                    var row = Scheduler.Container.ref.listCtrl.rows.forEach(function (row) {
                        row.$root.find(".mapResourceColor").remove();
                        row.$root.find(".mapResourceCheckBox").remove();
                    });
                };
                return ResourceDataRow;
            }());
            var MarkerTooltip = (function (_super) {
                __extends(MarkerTooltip, _super);
                function MarkerTooltip() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                MarkerTooltip._createMapTooltipOverlay = function (position) {
                    /**
                     * The MapTooltipOverlay class could not be defined in global scope, because google.maps.OverlayView class is not defined yet there.
                     * "google.maps" classes are defined after Google Maps API script is loaded dynamically later.
                     * Therefore "google.maps" classes can be used only inside class or function scope, that is executed after the script is loaded.
                     */
                    var MapTooltipOverlay = (function (_super) {
                        __extends(MapTooltipOverlay, _super);
                        function MapTooltipOverlay(position) {
                            var _this = _super.call(this) || this;
                            _this.position = position;
                            if (MarkerTooltip._element && (MarkerTooltip._element.length > 0)) {
                                if (google.maps.OverlayView["preventMapHitsFrom"]) {
                                    google.maps.OverlayView["preventMapHitsFrom"](MarkerTooltip._element[0]);
                                }
                            }
                            return _this;
                        }
                        /**
                         * Called when the tooltip is added to the map.
                         */
                        MapTooltipOverlay.prototype.onAdd = function () {
                            if (MarkerTooltip._element && (MarkerTooltip._element.length > 0)) {
                                this.getPanes().floatPane.appendChild(MarkerTooltip._element[0]);
                            }
                        };
                        /**
                         * Called when the tooltip is removed from the map.
                         */
                        MapTooltipOverlay.prototype.onRemove = function () {
                            MarkerTooltip.removeTooltip();
                        };
                        /**
                         * Called each frame when the tooltip needs to draw itself.
                         */
                        MapTooltipOverlay.prototype.draw = function () {
                            if (MarkerTooltip._element) {
                                var divPosition = this.getProjection().fromLatLngToDivPixel(this.position);
                                MarkerTooltip._element.css({ "left": divPosition.x });
                                MarkerTooltip._element.css({ "top": divPosition.y });
                            }
                        };
                        return MapTooltipOverlay;
                    }(google.maps.OverlayView));
                    return new MapTooltipOverlay(position);
                };
                /**
                 * This method do nothing! Please use createMarkerTooltip() method to create tooltip for map marker.
                 * @param task Task to which tooltip should be created.
                 */
                MarkerTooltip.createTooltip = function (task) {
                };
                /**
                 * Creates tooltip for provided marker and task, and appends it to OverlayView pane.
                 * @param map Map where task marker is drawn.
                 * @param marker Marker that represents the task to which tooltip should be created.
                 * @param task Task to which tooltip should be created.
                 */
                MarkerTooltip.createMarkerTooltip = function (map, marker, task) {
                    MarkerTooltip.removeTooltip();
                    var instance = new MarkerTooltip();
                    instance.createMarkerTooltip(map, marker, task);
                    Scheduler.TaskTooltip._instance = instance;
                    if (!Scheduler.TaskTooltip._element) {
                        Scheduler.TaskTooltip._instance = undefined;
                    }
                };
                MarkerTooltip.prototype.createMarkerTooltip = function (map, marker, task) {
                    Scheduler.TaskTooltip._element = (task instanceof Scheduler.Task) ? MarkerTooltip._createElement(task) : this._createElement(task);
                    MarkerTooltip._mapTooltipOverlay = MarkerTooltip._createMapTooltipOverlay(marker.getPosition());
                    MarkerTooltip._mapTooltipOverlay.setMap(map);
                };
                MarkerTooltip.prototype._createElement = function (name) {
                    var content = "<div class=\"taskTooltip officeTooltip\">";
                    if (name)
                        content += "<h3>" + name + "</h3>";
                    content += "</div>";
                    return $(content);
                };
                MarkerTooltip.prototype.removeTooltip = function () {
                    if (MarkerTooltip._mapTooltipOverlay) {
                        MarkerTooltip._mapTooltipOverlay.setMap(null);
                        MarkerTooltip._mapTooltipOverlay = undefined;
                    }
                    _super.prototype.removeTooltip.call(this);
                };
                return MarkerTooltip;
            }(Scheduler.TaskTooltip));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
