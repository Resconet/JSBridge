///<reference path="../../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="stringTable.ts" />
///<reference path="interfaces.ts" />
///<reference path="geo.ts" />
///<reference path="timeRange.ts" />
///<reference path="../utilities.ts" />
///<reference path="../container.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            /**
             * Singleton represents data structure for scheduler settings.
             */
            var Constants = (function () {
                function Constants() {
                    this.debugMode = false;
                    this.componentsBackgroundColor = "#eeeeee";
                    this.componentsBorderColor = "#aaaaaa";
                    this.componentsSelectedBorderColor = "#c0c0c0";
                    this.listCtrlWidth = 320; // default width of the list for resource entities
                    this.listCtrlRowHeight = 50; // height of the row in the list for resource entities and row in the gantt grid view
                    this.separatorWidth = 5; // default width of the separator line in the splitter control
                    this.splitterTouchAreaWidth = 20; // default width of the touch area where user can handle the move of the splitter line (including splitter line width).
                    this.dialogMinMoveDistance = 10; // minimum distance (in pixels) that must be touch point (mouse/finger) moved before it is considered as move with dialog container.
                    this.quickMenuWidth = 300; // default width of the quick menu container
                    this.viewHeaderHeight = 40; // height of the gantt grid view header, where hours and/or days (or months) are shown
                    this.viewTaskMinWidth = 8; // minimal task box width in px that is used if computed width is less than this value
                    this.viewTaskMinMoveDistance = 10; // minimum distance (in pixels) that must be touch point (mouse/finger) moved before it is considered as move with task instead of possible double click/tap
                    this.viewVScrollMinEdgeSpace = this.listCtrlRowHeight / 2; // minimal space from top and bottom edge that is accepted as valid scroll position. If space is smaller than this value, content will be vertically scrolled automatically. [px]
                    this.viewVScrollSpeed = 200; // speed that gantt view automatically scrolls content vertically when edge is reached in [px/s]
                    this.viewSplitOvertimeTasks = true; // task that exceeds working hours time range will be splintered and will continue in the next working hours time range.
                    this.viewSplitMinWorkMinutes = 60; // minimal work time (in minutes) that is necessary to split overtime task into starting day working hours also. [minutes]
                    this.taskTooltipEnabled = true; // if set to true, task popup menu is shown when task is pressed at least for a time given by taskPopupMenuTimeout setting.
                    this.taskPopupMenuEnabled = true; // if set to true, task popup menu is shown when task is pressed at least for a time given by taskPopupMenuTimeout setting.
                    this.taskPopupMenuTimeout = 1000; // determines time interval that have to be task pressed until task popup menu is shown [in milliseconds]
                    this.taskVerticalMargin = 3; // space (in pixels) between top task edge and top row edge, and bottom task edge and bottom row edge.
                    this.unscheduledViewTaskSpacing = 10; // space that is added before each undefined task in the undefined tasks row to achieve space between tasks and offset before all undefined tasks.
                    this.unscheduledViewTaskWidth = 100; // width in pixels that will be used to draw undefined tasks in the row for undefined tasks. Real computed width will be used later when undefined task is hover over ganttHScroll element.
                    this.unscheduledViewMaxTasksInRow = 8;
                    this.unscheduledViewHeight = this.listCtrlRowHeight; // to enable/disable undefined tasks managing functionality use "sourceDefined" property.
                    this.unscheduledTasksEnabled = false; // enables functionality for retrieving and caching unscheduled tasks (that are not currently used)
                    this.hideUnscheduledTaskAfterScheduling = true; // if true, removes unscheduled task from horizontal list, when new task was scheduled from it.
                    this.defaultTaskDuration = 60; // task duration that is used when unscheduled task entity does not contain estimated or default duration [minutes]
                    this.daysWhenSourcesIsNotOfferedForScheduling = 14; // number of days, when scheduled source will not be offered for new schedule
                    this.enableKPIBar = true; // enables KPI Bar
                    this.enableTaskResize = false; // enables tasks resizing in the gantt chart (resizing was not fully implemented yet, because there was not need for resizing now).
                    this.enableRowSelection = true; // enables highlighting of selected (current) row in the list view and gantt chart
                    this.enableAutoSchedule = true;
                    this.enableMapView = true; // enables whole map view functionality and option to select "Map View" mode, what allows to show entities on the map
                    this.jeopardyBeforeHours = 24; // time (in hours) before "Date.now" that determines if unscheduled task (with start and end already set), that has not resource assigned yet, is count in the KPI control as task in jeopardy. [hours]
                }
                Constants.prototype.fullDateTime = function (date) {
                    var dateFormat = undefined;
                    if (this.cultureInfo && this.cultureInfo.dateTimeFormat)
                        dateFormat = this.cultureInfo.dateTimeFormat.fullDateTimePattern;
                    if (!dateFormat)
                        dateFormat = "dd MMM yyyy hh:mm";
                    return Constants.formatDateProc(date, dateFormat);
                };
                Constants.prototype.timeRangeToString = function (d1, d2) {
                    return Constants.formatDateProc(d1, "MMM d") + " - " + Constants.formatDateProc(d2, d1.getDate() > d2.getDate() ? "dd" : "d");
                };
                Constants.prototype.timeToString = function (d) {
                    return Constants.formatDateProc(d, "MMM d yyyy");
                };
                Constants.prototype.dayToString = function (d) {
                    return Constants.formatDateProc(d, "ddd d");
                };
                Constants.prototype.dayToShortString = function (d) {
                    return Constants.formatDateProc(d, "d");
                };
                Constants.prototype.monthToString = function (d) {
                    return Constants.formatDateProc(d, "MMM");
                };
                Constants.prototype.yearToString = function (d) {
                    return Constants.formatDateProc(d, "yyyy");
                };
                Constants.prototype.hourToString = function (hour) {
                    return (hour < 0 || hour > 9 ? "" : "0") + hour;
                };
                return Constants;
            }());
            Constants.disableJBridge = false;
            Constants.formatDateProc = MobileCRM.CultureInfo.formatDate;
            Scheduler.Constants = Constants;
            /**
             * Class represents image objects saved in the ImageFactory.
             */
            var Image = (function () {
                function Image(name, style, src, width, height) {
                    this.name = name;
                    this.style = style;
                    this.src = src;
                    this.width = width || 0;
                    this.height = height || 0;
                }
                return Image;
            }());
            /**
             * Singleton represents data structure for work with images that are loaded from MCRM image source.
             */
            var ImageFactory = (function () {
                function ImageFactory() {
                    this._images = new Array();
                }
                ImageFactory.getInstance = function () {
                    if (!ImageFactory.instance) {
                        ImageFactory.instance = new ImageFactory();
                    }
                    return ImageFactory.instance;
                };
                /**
                 * Adds image to the HTML element as CSS background style.
                 * @param imageName String value represents path to Resco image source.
                 * @param imageStyle String value represents name of Resco AppStyle
                 * @param element HTML element that will be set background image.
                 */
                ImageFactory.prototype.addImageToElementBackground = function (imageName, imageStyle, element) {
                    var _this = this;
                    if (!this.isImageLoaded(imageName, imageStyle)) {
                        if (Constants.disableJBridge)
                            return;
                        MobileCRM.Application.getAppImage(imageName, imageStyle, function (result) {
                            _this._images.push(new Image(imageName, imageStyle, result));
                            element.style.backgroundImage = "url(" + result + ")";
                        }, function (error) {
                            if (Scheduler.Container.debugMode)
                                console.log("Error occurred during image loading - " + imageName + "\n" + error);
                        }, null);
                    }
                    else {
                        var imageBase64 = this.getImageAsBase64string(imageName, imageStyle);
                        element.style.backgroundImage = "url(" + imageBase64 + ")";
                    }
                };
                /**
                 * Adds image to the image factory.
                 * @param imageName String value represents path to Resco image source.
                 * @param imageStyle String value represents name of Resco AppStyle
                 * @param imageWidth (optional) Number value for width of the image.
                 * @param imageHeight (optional) Number value for height of the image.
                 */
                ImageFactory.prototype.addImage = function (imageName, imageStyle, imageWidth, imageHeight) {
                    var _this = this;
                    if (!this.isImageLoaded(imageName, imageStyle)) {
                        if (Constants.disableJBridge)
                            return;
                        MobileCRM.Application.getAppImage(imageName, imageStyle, function (result) {
                            _this._images.push(new Image(imageName, imageStyle, result, imageWidth, imageHeight));
                        }, function (error) {
                            if (Scheduler.Container.debugMode)
                                console.log("Error occurred during image loading - " + imageName + "\n" + error);
                        }, null);
                    }
                };
                /**
                 * Checks if image is saved in the factory.
                 * @param imageName String value represents path to Resco image source.
                 * @param imageStyle String value represents name of Resco AppStyle.
                 */
                ImageFactory.prototype.isImageLoaded = function (imageName, imageStyle) {
                    return this._images.filter(function (i) { return i.name == imageName && i.style == imageStyle; }).length === 1;
                };
                /**
                 * Get base64 string value for image with name and style that is saved in factory.
                 * @param imageName String value represents path to Resco image source.
                 * @param imageStyle String value represents name of Resco AppStyle
                 */
                ImageFactory.prototype.getImageAsBase64string = function (imageName, imageStyle) {
                    var foundImage = this._images.filter(function (i) { return i.name == imageName && i.style == imageStyle; });
                    return foundImage.length > 0 ? foundImage[0].src : null;
                };
                return ImageFactory;
            }());
            Scheduler.ImageFactory = ImageFactory;
            var IO = (function () {
                function IO() {
                }
                IO.modifyPath = function (fileName) {
                    var inputs = Scheduler.Container.inputs;
                    if (inputs && inputs.resources && inputs.resources.entityName && inputs.scheduledTasks.entityName)
                        return inputs.resources.entityName + "_" + inputs.scheduledTasks.entityName + "_" + fileName;
                    else
                        return "empty_" + fileName;
                };
                IO.read = function (fileName, onLoad) {
                    if (!fileName)
                        return;
                    fileName = IO.modifyPath(fileName);
                    if (!Constants.disableJBridge) {
                        MobileCRM.Application.fileExists(fileName, function (exists) {
                            if (!exists)
                                onLoad(undefined);
                            else {
                                MobileCRM.Application.readFile(fileName, function (obj) {
                                    onLoad(obj ? JSON.parse(obj) : undefined);
                                }, function (err) {
                                    onLoad(undefined);
                                }, this);
                            }
                        }, function (err) { return onLoad(undefined); }, this);
                    }
                    else {
                        var xobj = new XMLHttpRequest();
                        xobj.overrideMimeType("application/json");
                        xobj.open('GET', fileName, true);
                        xobj.onreadystatechange = function () {
                            if (xobj.readyState == 4) {
                                if (xobj.status === 200) {
                                    var json = xobj.responseText;
                                    onLoad(json ? JSON.parse(json) : undefined);
                                }
                                else if (xobj.status !== 0)
                                    onLoad(undefined);
                            }
                        };
                        xobj.send(null);
                    }
                };
                IO.save = function (fileName, data, onResult) {
                    if (!Constants.disableJBridge && fileName && data)
                        fileName = IO.modifyPath(fileName);
                    MobileCRM.Application.writeFile(fileName, data, false, function () { return onResult(undefined); }, onResult, this);
                };
                return IO;
            }());
            Scheduler.IO = IO;
            /******************************** Colors ********************************/
            var ColorCache = (function () {
                function ColorCache() {
                }
                /**
                 * Converts color in RGB to HSV color model.
                 * H = {0, 360}
                 * S,V = {0, 255}
                 * @param r Red value in range {0, 255} including.
                 * @param g Green value in range {0, 255} including.
                 * @param b Blue value in range {0, 255} including.
                 */
                ColorCache.rgb2hsv = function (r, g, b) {
                    r /= 255;
                    g /= 255;
                    b /= 255;
                    var max = Math.max(r, g, b);
                    var min = Math.min(r, g, b);
                    var delta = max - min;
                    var h;
                    var s = (max === 0) ? 0 : (delta / max);
                    var v = max;
                    if (delta === 0) {
                        h = 0;
                    }
                    else if (max === r) {
                        h = (g - b) / delta;
                    }
                    else if (max === g) {
                        h = ((b - r) / delta) + 2;
                    }
                    else {
                        h = ((r - g) / delta) + 4;
                    }
                    if (h < 0) {
                        h += 6;
                    }
                    h *= 60;
                    s *= 255;
                    v *= 255;
                    return { h: h, s: s, v: v };
                };
                /**
                 * Converts color in HSV to RGB color model.
                 * R,G,B = {0, 255}
                 * @param h Hue value in range {0, 360} including.
                 * @param s Saturation value in range {0, 255} including.
                 * @param v Value value in range {0, 255} including.
                 */
                ColorCache.hsv2rgb = function (h, s, v) {
                    if (!h) {
                        h = 0;
                    }
                    h /= 60;
                    s /= 255;
                    v /= 255;
                    if (h < 0) {
                        h += 6;
                    }
                    h = h % 6;
                    var deltaH = h - Math.floor(h);
                    var alpha = v * (1 - s);
                    var beta = v * (1 - (deltaH * s));
                    var gama = v * (1 - ((1 - deltaH) * s));
                    var rgb;
                    if (0 <= h && h < 1) {
                        rgb = [v, gama, alpha];
                    }
                    else if (1 <= h && h < 2) {
                        rgb = [beta, v, alpha];
                    }
                    else if (2 <= h && h < 3) {
                        rgb = [alpha, v, gama];
                    }
                    else if (3 <= h && h < 4) {
                        rgb = [alpha, beta, v];
                    }
                    else if (4 <= h && h < 5) {
                        rgb = [gama, alpha, v];
                    }
                    else {
                        rgb = [v, alpha, beta];
                    }
                    rgb[0] *= 255;
                    rgb[1] *= 255;
                    rgb[2] *= 255;
                    return { r: Math.round(rgb[0]), g: Math.round(rgb[1]), b: Math.round(rgb[2]) };
                };
                /**
                 * Returns string in rgba(r, g, b, a) format that represents the same color as is given by "color" argument,
                 * or returns the same string as is given by "color" argument, if it is not possible to recognize the color string.
                 * Color conversion is cached to minimize the time neccesary to conversion, when the same color needs to be converted many time.
                 * @param color - String that represents color. (E.g.: "yellow", "#ffff00", "rgb(255, 255, 0)", "rgba(255, 255, 0, 0.7)")
                 * @param alpha - Channel value in interval {0, 1} including borders values.
                 */
                ColorCache.applyColorAlpha = function (color, alpha) {
                    if (0 <= alpha && alpha <= 1) {
                        var rgbaColor = ColorCache.colorToRGBA(color);
                        if (rgbaColor)
                            return "rgba(" + rgbaColor.r + ", " + rgbaColor.g + ", " + rgbaColor.b + ", " + alpha + ")";
                    }
                    return color;
                };
                /**
                 * Returns string in rgb(r, g, b) format that represents the same color as is given by "color" argument,
                 * but this color has not alpha channel (alpha is set to 100%),
                 * or returns the same string as is given by "color" argument, if it is not possible to recognize the color string.
                 * Color conversion is cached to minimize the time neccesary to conversion, when the same color needs to be converted many time.
                 * @param color - String that represents color. (E.g.: "yellow", "#ffff00", "rgb(255, 255, 0)", "rgba(255, 255, 0, 0.7)")
                 */
                ColorCache.tryGetColorWithoutAlpha = function (color) {
                    var rgbaColor = ColorCache.colorToRGBA(color);
                    return rgbaColor ? "rgb(" + rgbaColor.r + ", " + rgbaColor.g + ", " + rgbaColor.b + ")" : color;
                };
                ColorCache.tryGetRelatedColor = function (color) {
                    var rgbaColor = ColorCache.colorToRGBA(color);
                    if (rgbaColor) {
                        //let brightness = ColorCache._getColorBrightness(rgbaColor);
                        //let relatedColor = ColorCache._setColorBrightness(rgbaColor, brightness);
                        var hsv = ColorCache.rgb2hsv(rgbaColor.r, rgbaColor.g, rgbaColor.b);
                        var rgb = ColorCache.hsv2rgb(hsv.h, hsv.s, hsv.v / 2);
                        return "rgba(" + rgb.r + ", " + rgb.g + ", " + rgb.b + ", " + rgbaColor.a + ")";
                        //return relatedColor.toString();
                    }
                    return color;
                };
                /**
                 * Returns RGBAColor object that represents the same color as is given by "color" argument, but has RGBA channels values accessible as numbers throught properties,
                 * or returns undefined, if it is not possible to recognize the color string.
                 * Color conversion is cached to minimize the time neccesary to conversion, when the same color needs to be converted many time.
                 * @param color - String that represents color. (E.g.: "yellow", "#ffff00", "rgb(255, 255, 0)", "rgba(255, 255, 0, 0.7)")
                 */
                ColorCache.colorToRGBA = function (color) {
                    var rgbaColor = ColorCache._colors[color];
                    if (!rgbaColor) {
                        rgbaColor = ColorCache._convertColorToRGBA(color);
                        if (rgbaColor)
                            ColorCache._colors[color] = rgbaColor;
                    }
                    return rgbaColor;
                };
                ColorCache._convertColorToRGBA = function (color) {
                    var uniColor = ColorCache._colorToUniColor(color);
                    var rgbaColor = ColorCache._convertColorInRGBAToRGBA(uniColor);
                    if (!rgbaColor) {
                        rgbaColor = ColorCache._convertColorInHexToRGBA(color);
                        if (!rgbaColor) {
                            rgbaColor = ColorCache._convertColorInRGBAToRGBA(color);
                        }
                    }
                    return rgbaColor;
                };
                ColorCache._convertColorInHexToRGBA = function (color) {
                    if (color && color.length > 0) {
                        if (color[0] == '#' && color.length === 7) {
                            var hexToRgb = function (hex) {
                                return hex.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function (m, r, g, b) { return '#' + r + r + g + g + b + b; })
                                    .substring(1).match(/.{2}/g)
                                    .map(function (x) { return parseInt(x, 16); });
                            };
                            var rgb = hexToRgb(color);
                            return new RGBAColor(+rgb[0], +rgb[1], +rgb[2], 1);
                        }
                    }
                    return undefined;
                };
                ColorCache._convertColorInRGBAToRGBA = function (color) {
                    if (color && color.length > 0) {
                        var startIndex = 0;
                        if (color.startsWith("rgba("))
                            startIndex = 5;
                        else if (color.startsWith("rgb("))
                            startIndex = 4;
                        if (startIndex === 4 || startIndex === 5) {
                            var endIndex = color.indexOf(')');
                            if (endIndex >= 0) {
                                color = color.substring(startIndex, endIndex);
                                var rgb = color.split(',');
                                if (3 <= rgb.length && rgb.length <= 4) {
                                    var alpha = (rgb.length === 4) ? +rgb[3] : 1;
                                    return new RGBAColor(+rgb[0], +rgb[1], +rgb[2], alpha);
                                }
                            }
                        }
                    }
                    return undefined;
                };
                ColorCache._colorToUniColor = function (color) {
                    var element = document.createElement("div");
                    element.style.position = "absolute";
                    element.style.backgroundColor = color;
                    document.body.appendChild(element);
                    var style = window.getComputedStyle(element);
                    var uniColor = style.getPropertyValue("background-color");
                    document.body.removeChild(element);
                    return uniColor;
                };
                ColorCache._getColorBrightness = function (rgbaColor) {
                    //let rs = Math.pow(rgbaColor.r, 2);
                    //let gs = Math.pow(rgbaColor.g, 2);
                    //let bs = Math.pow(rgbaColor.b, 2);
                    //let brightnessSquare = (rs + gs + bs) / 3;
                    //return Math.sqrt(brightnessSquare);
                    var r = rgbaColor.r;
                    var g = rgbaColor.g;
                    var b = rgbaColor.b;
                    var rgb = r + g + b;
                    return rgb / 3;
                };
                return ColorCache;
            }());
            ColorCache._colors = {};
            Scheduler.ColorCache = ColorCache;
            var RGBAColor = (function () {
                function RGBAColor(r, g, b, a) {
                    this.r = r;
                    this.g = g;
                    this.b = b;
                    this.a = a;
                }
                Object.defineProperty(RGBAColor.prototype, "r", {
                    get: function () {
                        return this._r;
                    },
                    set: function (value) {
                        this._r = this._restrictValue(value, 0, 255);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RGBAColor.prototype, "g", {
                    get: function () {
                        return this._g;
                    },
                    set: function (value) {
                        this._g = this._restrictValue(value, 0, 255);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RGBAColor.prototype, "b", {
                    get: function () {
                        return this._b;
                    },
                    set: function (value) {
                        this._b = this._restrictValue(value, 0, 255);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(RGBAColor.prototype, "a", {
                    get: function () {
                        return this._a;
                    },
                    set: function (value) {
                        this._a = this._restrictValue(value, 0, 1);
                    },
                    enumerable: true,
                    configurable: true
                });
                RGBAColor.prototype.toString = function () {
                    return "rgba(" + this.r + ", " + this.g + ", " + this.b + ", " + this.a + ")";
                };
                RGBAColor.prototype._restrictValue = function (value, min, max) {
                    if ((value === undefined) || (value === null))
                        value = max;
                    else if (value < min)
                        value = min;
                    else if (value > max)
                        value = max;
                    return value;
                };
                return RGBAColor;
            }());
            Scheduler.RGBAColor = RGBAColor;
            var ColorGenerator = (function () {
                function ColorGenerator() {
                }
                /**
                 * This method serves to generate colors to discern objects. Returns color based on index value.
                 * Returned color (in RGB) has different Hue, Saturation and Value to be easily visible and recognizable from other colors generated by another index.
                 * @param index Index that is used to generate color that should represent the object.
                 * @param initColorAngle Initial angle set to Hue, that shifts color hue to more preferred color.
                 */
                ColorGenerator.getColor = function (index, initColorAngle) {
                    if (index < 0) {
                        index = 0;
                    }
                    // [60,30,15,7,4,2,1,1,...]
                    // angle offset per turn [degrees]
                    var angleOffsets = [0,
                        30,
                        15, 45,
                        8, 38, 22, 52,
                        4, 34, 18, 48, 12, 42, 26, 56];
                    // saturation per turn [%]
                    var saturations = [70,
                        70,
                        60, 60,
                        50, 50, 50, 50,
                        40, 40, 40, 40, 40, 40, 40, 40];
                    // value per turn [%]
                    var values = [80,
                        80,
                        70, 70,
                        80, 80, 80, 80,
                        90, 90, 90, 90, 90, 90, 90, 90];
                    var stepAngle = 60;
                    var h = index * stepAngle;
                    var turns = Math.floor(h / 360);
                    h %= 360;
                    turns %= angleOffsets.length;
                    if (initColorAngle) {
                        h += initColorAngle;
                    }
                    h += angleOffsets[turns];
                    var s = 255 * (saturations[turns] / 100);
                    var v = 255 * (values[turns] / 100);
                    var rgb = ColorCache.hsv2rgb(h, s, v);
                    return new RGBAColor(rgb.r, rgb.g, rgb.b, 1);
                };
                /**
                 * This method serves to generate colors to discern objects.
                 * Returns color from predefined array of colors, based on index value.
                 * Returned color should be easily visible and recognizable from other colors returned by another index.
                 * If index is greater than array length MOD operation is used to return appropriate color from array.
                 * @param index Index that is used to generate color that should represent the object.
                 */
                ColorGenerator.getColorFromArray = function (index) {
                    if ((index === undefined) || (index === null) || (index < 0)) {
                        index = 0;
                    }
                    index %= ColorGenerator._colors.length;
                    return ColorGenerator._colors[index];
                };
                return ColorGenerator;
            }());
            ColorGenerator._colors = [
                "dodgerblue",
                "darkorchid",
                "lightseagreen",
                "goldenrod",
                "tomato",
                "deepskyblue",
                "forestgreen",
                "mediumblue",
                "deeppink",
                "turquoise",
                "sandybrown",
                "indianred",
                "slategray",
                "lightskyblue",
                "orchid",
                "darkorange",
                "mediumpurple",
                "chocolate",
                "silver",
                "yellowgreen",
                "royalblue",
                "firebrick",
                "darkseagreen",
                "rosybrown",
                "orange",
                "darkkhaki",
                "hotpink",
                "pink",
                "cornflowerblue",
                "saddlebrown",
                "mediumseagreen",
                "violet",
                "olive",
                "greenyellow",
                "darkgoldenrod",
                "coral",
                "slateblue",
                "darkcyan",
                "purple",
                "burlywood",
                "plum",
                "green",
                "khaki",
                "palevioletred",
                "blue",
                "yellow",
                "lightsalmon",
                "skyblue",
                "darkgreen",
                "crimson",
                "sienna",
                "peachpuff",
                "mediumaquamarine",
                "mediumorchid",
                "palegoldenrod",
                "peru",
                "seagreen",
                "lightblue",
                "mediumvioletred",
                "mediumslateblue",
                "limegreen",
                "darksalmon",
                "wheat",
                "orangered",
                "cadetblue",
                "indigo",
                "lightpink",
                "lightgreen",
                "blueviolet",
                "mediumturquoise",
                "darkolivegreen",
                "tan",
                "salmon",
                "steelblue",
                "turquoise",
                "navy",
                "thistle",
                "brown",
                "teal",
                "darkviolet",
                "darkslategray",
                "powderblue",
                "lightcoral",
                "palegreen",
                "darkred",
                "lightsteelblue",
                "olivedrab",
                "darkmagenta",
                "mediumspringgreen",
                "lightslategray",
                "darkslateblue",
                "paleturquoise",
                "rebeccapurple",
                "midnightblue",
                "springgreen",
                "darkblue",
                "red",
            ];
            Scheduler.ColorGenerator = ColorGenerator;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
