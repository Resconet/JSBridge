///<reference path="../../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../../Helpers/common.ts" />
///<reference path="inputs.ts" />
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var RuleResult = (function () {
                function RuleResult(msg, srcEntity) {
                    if (msg === void 0) { msg = undefined; }
                    if (srcEntity === void 0) { srcEntity = undefined; }
                    this.errorMsg = msg;
                    this._sourceEntity = srcEntity;
                }
                Object.defineProperty(RuleResult.prototype, "sourceEntity", {
                    get: function () {
                        return this._sourceEntity;
                    },
                    enumerable: true,
                    configurable: true
                });
                ;
                RuleResult.prototype.updateSource = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            if (this._sourceEntity)
                                this._sourceEntity.saveAsync();
                            return [2 /*return*/];
                        });
                    });
                };
                return RuleResult;
            }());
            Scheduler.RuleResult = RuleResult;
            var CreateRule = (function () {
                function CreateRule(input) {
                    this.ActivityEntity = "Activity Entity";
                    this.SourceEntity = "Source Entity";
                    this.m_metaDataCache = new Resco.Dictionary();
                    this.m_createRule = input.createRule;
                    if (this.m_createRule) {
                        this.activityName = input.scheduledTasks.entityName;
                        this.activitySourceRef = input.scheduledTasks.attrSourceRef;
                        if (this.m_createRule.indexOf(this.ActivityEntity) < 0) {
                            this.activityName = null;
                        }
                        if (input.unscheduledTasks && this.activitySourceRef) {
                            this.sourceName = input.unscheduledTasks.entityName;
                            this.sourceKeyName = input.unscheduledTasks.primaryKeyName;
                            if (!this.sourceKeyName || this.m_createRule.indexOf(this.SourceEntity) < 0)
                                this.sourceName = null;
                        }
                    }
                }
                Object.defineProperty(CreateRule.prototype, "needModifyTask", {
                    get: function () {
                        return this.activityName && this.activityName.length > 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(CreateRule.prototype, "needModifySource", {
                    get: function () {
                        return this.activityName && this.activityName.length > 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                CreateRule.prototype.executeCreateRule = function (entity) {
                    return __awaiter(this, void 0, void 0, function () {
                        var activityMeta, srcMeta, srcMeta, e_1;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!this.m_createRule)
                                        return [2 /*return*/, undefined];
                                    _a.label = 1;
                                case 1:
                                    _a.trys.push([1, 9, , 10]);
                                    if (!this.activityName) return [3 /*break*/, 5];
                                    return [4 /*yield*/, this._getMetaEntity(this.activityName)];
                                case 2:
                                    activityMeta = _a.sent();
                                    if (!this.sourceName) return [3 /*break*/, 4];
                                    return [4 /*yield*/, this._getMetaEntity(this.sourceName)];
                                case 3:
                                    srcMeta = _a.sent();
                                    return [2 /*return*/, this._executeCreateRule(entity, activityMeta, srcMeta)];
                                case 4: return [2 /*return*/, this._executeCreateRule(entity, activityMeta, undefined)];
                                case 5:
                                    if (!this.sourceName) return [3 /*break*/, 7];
                                    return [4 /*yield*/, this._getMetaEntity(this.sourceName)];
                                case 6:
                                    srcMeta = _a.sent();
                                    return [2 /*return*/, this._executeCreateRule(entity, undefined, srcMeta)];
                                case 7: return [2 /*return*/, undefined];
                                case 8: return [3 /*break*/, 10];
                                case 9:
                                    e_1 = _a.sent();
                                    return [2 /*return*/, new RuleResult(e_1.message)];
                                case 10: return [2 /*return*/];
                            }
                        });
                    });
                };
                CreateRule.prototype._getMetaEntity = function (entityName) {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        return __generator(this, function (_a) {
                            return [2 /*return*/, new Promise(function (resolve, reject) {
                                    var meta = _this.m_metaDataCache.getValue(entityName);
                                    if (meta) {
                                        //var meta = MobileCRM.Metadata.getEntity(entityName);
                                        resolve(meta);
                                    }
                                    else {
                                        MobileCRM.MetaEntity.loadByName(entityName, function (meta) {
                                            _this.m_metaDataCache.set(entityName, meta);
                                            resolve(meta);
                                        }, function (error) {
                                            reject(new Resco.Exception(error));
                                        });
                                    }
                                })];
                        });
                    });
                };
                CreateRule.prototype._createDynamicEntity = function (entityName, meta, entity) {
                    if (entity === void 0) { entity = undefined; }
                    var repo = new MobileCrm.Data.DynamicRepository();
                    // initialize repository with properties obtained through JSBridge
                    meta.properties.forEach(function (prop) { return repo.add(new MobileCrm.Data.MetaProperty(prop.name, prop.type, prop.targets)); });
                    var ret = new MobileCrm.Data.DynamicEntity(entityName, repo);
                    if (entity) {
                        meta.properties.forEach(function (prop) {
                            var value = entity.properties[prop.name];
                            if (value)
                                ret.trySetValue(prop.name, value);
                        });
                    }
                    return ret;
                };
                CreateRule.prototype._updateValues = function (entity, data, variables) {
                    data.repository.properties.forEach(function (metaProp) {
                        var variable = variables.entity.tryGetValue(metaProp.name).value; // TODO: make sure that dates are formatted as required by JSBridge;
                        if (variable)
                            entity.properties[metaProp.name] = variable;
                    });
                };
                CreateRule.prototype._executeCreateRule = function (entity, activityMeta, srcMeta) {
                    var activityEntity = activityMeta ? this._createDynamicEntity(this.activityName, activityMeta, entity) : null;
                    var variables = new Resco.Dictionary();
                    var activityVar = new MobileCrm.UI.Workflow.EntityVariable(activityEntity);
                    var sourceVar = null;
                    var sourceEntity = null;
                    var sourceRef = null;
                    variables.add(this.ActivityEntity, activityVar);
                    if (srcMeta && this.activitySourceRef && entity && (sourceRef = entity.properties[this.activitySourceRef])) {
                        sourceEntity = this._createDynamicEntity(this.sourceName, srcMeta);
                        sourceEntity.trySetValue(this.sourceKeyName, sourceRef.id);
                        variables.add(this.SourceEntity, sourceVar = new MobileCrm.UI.Workflow.EntityVariable(sourceEntity));
                    }
                    var errorMessageVar = new MobileCrm.UI.Workflow.SimpleVariable("ErrorMessage", MobileCrm.Data.CrmType.String, "");
                    variables.add("ErrorMessage", errorMessageVar);
                    //variables.add("Configuration", configVar = new MobileCrm.UI.Workflow.ConfigurationVariable(/*MobileCrm.UI.Configuration.instance.constants*/));
                    //var colorVariable = new MobileCrm.UI.Workflow.SimpleVariable("Color", MobileCrm.Data.CrmType.String, false);
                    //variables.add("Color", colorVariable);
                    var r = MobileCrm.UI.Workflow.Engine.setup(this.m_createRule, this.activityName, variables);
                    this.m_createRule = r.workflow; // cache the workflow
                    if (r.context && r.context.execute()) {
                        var srcEntity = undefined;
                        if (sourceVar) {
                            srcEntity = new MobileCRM.DynamicEntity(sourceEntity.entityName, sourceRef.id, sourceRef.name);
                            this._updateValues(srcEntity, sourceEntity, sourceVar);
                            //srcEntity[this.sourceKeyName] = sourceId;
                        }
                        if (entity)
                            this._updateValues(entity, activityEntity, activityVar);
                        return new RuleResult(errorMessageVar.value, srcEntity);
                    }
                    return undefined;
                };
                return CreateRule;
            }());
            Scheduler.CreateRule = CreateRule;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
