var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var Source = (function () {
                function Source(id, name, locationRef, territory) {
                    this.id = id;
                    this.name = name;
                    this.territory = territory;
                    this.locationRef = locationRef;
                }
                return Source;
            }());
            Scheduler.Source = Source;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
