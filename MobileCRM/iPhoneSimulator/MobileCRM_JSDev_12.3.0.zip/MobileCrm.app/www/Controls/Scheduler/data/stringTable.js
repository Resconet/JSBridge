///<reference path="../../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="settings.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var StringTable = (function () {
                function StringTable() {
                }
                StringTable.load = function (regularExpression, onFinishCallback) {
                    if (!Scheduler.Constants.disableJBridge) {
                        MobileCRM.Localization.initializeEx(regularExpression, function (loc) {
                            StringTable.Msg = MobileCRM.Localization.stringTable;
                            onFinishCallback();
                        }, function (error) {
                            MobileCRM.bridge.alert(error);
                            onFinishCallback();
                        });
                    }
                    else {
                        onFinishCallback();
                    }
                };
                /**
                 * Returns localized string based on the given key, where all format items ({0}, {1}, ..., {n}) used in the localized string are replaced with the corresponding string given by args array.
                 * If format items are missing in the localized string, individual args items are ignored. If format items are used, but args are missing, format items are replaced by empty string ("").
                 * @param key - key that is used to obtain correct localized string from the string table.
                 * @param args - array of strings that replaces individual format items. ({0} is replaced by args[0], {1} by args[1] and so on).
                 */
                StringTable.get = function (key, args) {
                    var text = StringTable.Msg[key];
                    return StringTable.replaceBracketsWithArgs(text, args);
                };
                /**
                 * Returns string where all format items ({0}, {1}, ..., {n}) used in the localized (input) string are replaced with the corresponding string given by args array.
                 * If format items are missing in the localized string, individual args items are ignored. If format items are used, but args are missing, format items are replaced by empty string ("").
                 * @param text Localized string or arbitrary text
                 * @param args Array of strings that replaces individual format items. ({0} is replaced by args[0], {1} by args[1] and so on).
                 */
                StringTable.replaceBracketsWithArgs = function (text, args) {
                    if (text) {
                        if (args) {
                            for (var i = 0; i < args.length; i++) {
                                text = text.replace("{" + i.toString() + "}", args[i]);
                            }
                        }
                        var match = text.match(new RegExp("{[0-9]+}", "g"));
                        if (match) {
                            for (var i = 0; i < match.length; i++) {
                                text = text.replace(match[i], "");
                            }
                        }
                    }
                    return text;
                };
                StringTable.alert = function (error) {
                    var popup = new MobileCRM.UI.MessageBox(error);
                    popup.items = ["OK"];
                    /// If title is too long set the 'multi-line' to true
                    popup.multiLine = true;
                    popup.show(function (button) { });
                };
                StringTable.alertByKey = function (key) {
                    StringTable.alert(StringTable.Msg[key]);
                };
                /**
                 * Localizes all descendants of the element given by argument, if they have "data-localization" attribute.
                 * If descendant elements has "data-localizationvalues" attribute, individual data values (strings) for format items ({0}, {1}, ..., {n}) used in the localized text must be separated by semicolon (like "string1;string2").
                 * @param parent - element that descendants should be localized.
                 */
                StringTable.localizeElements = function (parent) {
                    var e = parent.find("[data-localization]");
                    for (var i = 0; i < e.length; i++) {
                        var element = e[i];
                        var key = element.dataset.localization;
                        var values = element.dataset.localizationvalues;
                        var valuesArray = values ? values.split(";") : null;
                        var text = StringTable.get(key, valuesArray);
                        if (text)
                            element.innerHTML = text;
                    }
                    e = parent.find("[data-tooltip]");
                    for (var i = 0; i < e.length; i++) {
                        var element = e[i];
                        /*
                        let key = element.dataset.localization;
                        let values = element.dataset.localizationvalues;
                        let valuesArray = values ? values.split(";") : null;
                        let text = StringTable.get(key, valuesArray);
        
                        if (text)
                            element.innerHTML = text;
                        */
                    }
                };
                return StringTable;
            }());
            StringTable.Msg = {};
            Scheduler.StringTable = StringTable;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
