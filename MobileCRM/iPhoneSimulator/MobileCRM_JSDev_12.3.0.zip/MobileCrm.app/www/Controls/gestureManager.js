///<reference path="../TypeScriptDefinitions/jquery.d.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var PointerEventType;
        (function (PointerEventType) {
            PointerEventType[PointerEventType["mouse"] = 0] = "mouse";
            PointerEventType[PointerEventType["touch"] = 1] = "touch";
            PointerEventType[PointerEventType["pointer"] = 2] = "pointer";
            PointerEventType[PointerEventType["mspointer"] = 3] = "mspointer";
        })(PointerEventType = Controls.PointerEventType || (Controls.PointerEventType = {}));
        var EventNameType;
        (function (EventNameType) {
            EventNameType[EventNameType["Down"] = 0] = "Down";
            EventNameType[EventNameType["Move"] = 1] = "Move";
            EventNameType[EventNameType["Up"] = 2] = "Up";
            EventNameType[EventNameType["Cancel"] = 3] = "Cancel";
            EventNameType[EventNameType["Leave"] = 4] = "Leave";
        })(EventNameType || (EventNameType = {}));
        var MouseTouchPointerManager = (function () {
            function MouseTouchPointerManager() {
                this._mouseEventsNames = ["mousedown", "mousemove", "mouseup", "", "mouseleave"];
                this._touchEventsNames = ["touchstart", "touchmove", "touchend", "touchcancel", ""];
                this._pointerEventsNames = ["pointerdown", "pointermove", "pointerup", "pointercancel", "pointerleave"]; // pointerleave event name can be changed to pointerleavespecial event name, in order to ensures that pointerleave event will be really used by JQuery
                this._msPointerEventsNames = ["MSPointerDown", "MSPointerMove", "MSPointerUp", "MSPointerCancel", "MSPointerLeave"];
                this._pointerEventType = this._getPointerEventType();
                if (this._pointerEventType === PointerEventType.pointer) {
                    this._useCustomEventForPointerLeave(); // Use pointerleavespecial custom event, that ensures that pointerleave event will be really used by JQuery.
                }
                this._setEventsNames(this._pointerEventType);
            }
            Object.defineProperty(MouseTouchPointerManager, "instance", {
                get: function () {
                    if (!MouseTouchPointerManager._instance)
                        MouseTouchPointerManager._instance = new MouseTouchPointerManager();
                    return MouseTouchPointerManager._instance;
                },
                enumerable: true,
                configurable: true
            });
            /**
             * If pointerleave event is registered by JQuery, JQuery registers and uses pointerout event instead, due to built in rule defined in special event hooks.
             * Therefore, we need to add a new rule (custom event) into special event hooks, that ensures that pointerleave event will be really registered and used by JQuery.
             */
            MouseTouchPointerManager.prototype._useCustomEventForPointerLeave = function () {
                if (jQuery && jQuery["event"] && jQuery["event"].special) {
                    var customEventName = "pointerleavespecial";
                    var originalEventName = "pointerleave";
                    var index = this._pointerEventsNames.indexOf(originalEventName);
                    if (index >= 0) {
                        this._pointerEventsNames[index] = customEventName;
                        jQuery["event"].special[customEventName] = {
                            delegateType: originalEventName,
                            bindType: originalEventName
                        };
                    }
                }
            };
            MouseTouchPointerManager.prototype._getPointerEventType = function () {
                //Desktop[onmousedown] - iOS[onmousedown, ontouchstart] - Surface[onmousedown, onpointerdown] - Android[onmousedown, ontouchstart, onpointerdown]
                if ((navigator.maxTouchPoints === undefined) || (navigator.maxTouchPoints > 0)) {
                    if ("onpointerdown" in window) {
                        return PointerEventType.pointer;
                    }
                    else if (("onmspointerdown" in window)) {
                        return PointerEventType.mspointer;
                    }
                    else if ("ontouchstart" in window) {
                        return PointerEventType.touch;
                    }
                }
                return PointerEventType.mouse;
            };
            MouseTouchPointerManager.prototype._setEventsNames = function (pointerEventType) {
                if (pointerEventType === PointerEventType.mouse) {
                    this._eventsNames = this._mouseEventsNames;
                }
                else if (pointerEventType === PointerEventType.touch) {
                    this._eventsNames = this._touchEventsNames;
                }
                else if (pointerEventType === PointerEventType.pointer) {
                    this._eventsNames = this._pointerEventsNames;
                }
                else {
                    this._eventsNames = this._msPointerEventsNames;
                }
            };
            Object.defineProperty(MouseTouchPointerManager, "pointerEventType", {
                get: function () {
                    return MouseTouchPointerManager.instance._pointerEventType;
                },
                enumerable: true,
                configurable: true
            });
            MouseTouchPointerManager.eventName = function (eventNameType) {
                return MouseTouchPointerManager.instance._eventsNames[eventNameType];
            };
            /**
             * Returns X coordinate of mouse, pointer or touch point (from event arguments), relative to the left edge of the document.
             * @param eventArgs - event arguments
             */
            MouseTouchPointerManager.getPointerX = function (eventArgs, identifier) {
                var originalEvent = eventArgs.originalEvent;
                if (originalEvent) {
                    if (originalEvent.pageX || originalEvent.pageX === 0) {
                        return originalEvent.pageX; // for mouse or pointer
                    }
                    else if (originalEvent.touches) {
                        if ((identifier === undefined) || (identifier === null)) {
                            if (originalEvent.touches.length > 0)
                                return originalEvent.touches[0].pageX;
                            else if (originalEvent.changedTouches.length > 0)
                                return originalEvent.changedTouches[0].pageX;
                        }
                        else {
                            if (originalEvent.touches.length > 0) {
                                for (var i = 0; i < originalEvent.touches.length; i++) {
                                    if (originalEvent.touches[i].identifier === identifier)
                                        return originalEvent.touches[i].pageX;
                                }
                            }
                            else if (originalEvent.changedTouches.length > 0) {
                                for (var i = 0; i < originalEvent.changedTouches.length; i++) {
                                    if (originalEvent.changedTouches[i].identifier === identifier)
                                        return originalEvent.changedTouches[i].pageX;
                                }
                            }
                        }
                    }
                }
                return 0;
            };
            /**
             * Returns Y coordinate of mouse, pointer or touch point (from event arguments), relative to the top edge of the document.
             * @param eventArgs - event arguments
             */
            MouseTouchPointerManager.getPointerY = function (eventArgs, identifier) {
                var originalEvent = eventArgs.originalEvent;
                if (originalEvent) {
                    if (originalEvent.pageY || originalEvent.pageY === 0) {
                        return originalEvent.pageY; // for mouse or pointer
                    }
                    else if (originalEvent.touches) {
                        if ((identifier === undefined) || (identifier === null)) {
                            if (originalEvent.touches.length > 0)
                                return originalEvent.touches[0].pageY;
                            else if (originalEvent.changedTouches.length > 0)
                                return originalEvent.changedTouches[0].pageY;
                        }
                        else {
                            if (originalEvent.touches.length > 0) {
                                for (var i = 0; i < originalEvent.touches.length; i++) {
                                    if (originalEvent.touches[i].identifier === identifier)
                                        return originalEvent.touches[i].pageY;
                                }
                            }
                            else if (originalEvent.changedTouches.length > 0) {
                                for (var i = 0; i < originalEvent.changedTouches.length; i++) {
                                    if (originalEvent.changedTouches[i].identifier === identifier)
                                        return originalEvent.changedTouches[i].pageY;
                                }
                            }
                        }
                    }
                }
                return 0;
            };
            /**
             * Returns string "mouse", "touch" or "pen" indicating the device type that caused the event.
             * @param eventArgs - event arguments
             */
            MouseTouchPointerManager.getPointerType = function (eventArgs) {
                if (MouseTouchPointerManager.pointerEventType === PointerEventType.mouse) {
                    return "mouse";
                }
                else if (MouseTouchPointerManager.pointerEventType === PointerEventType.touch) {
                    return "touch";
                }
                else {
                    return eventArgs.originalEvent.pointerType;
                }
            };
            /**
             * Returns ID of first touch point, pointer or -1 for mouse.
             * @param eventArgs - event arguments
             */
            MouseTouchPointerManager.getPointerId = function (eventArgs) {
                var changedTouches = MouseTouchPointerManager._getChangedTouchesIdentifiers(eventArgs);
                if (changedTouches.length > 0)
                    return changedTouches[0];
                var originalEvent = eventArgs.originalEvent;
                if (originalEvent) {
                    if ((originalEvent["pointerId"] !== undefined) && (originalEvent["pointerId"] !== null))
                        return originalEvent["pointerId"];
                }
                return -1;
            };
            /**
             * Checks if eventArgs contains the pointerId given by argument. (Checks if event of given eventArgs was raised by the same touch point, pointer or mouse, like event of given pointerId.
             * @param eventArgs - event arguments
             * @param pointerId - that is compared with pointerId given by eventArgs.
             */
            MouseTouchPointerManager.containPointerId = function (eventArgs, pointerId) {
                if (MouseTouchPointerManager._containTouchIdentifier(eventArgs, pointerId))
                    return true;
                var originalEvent = eventArgs.originalEvent;
                if (originalEvent) {
                    if ((originalEvent["pointerId"] !== undefined) && (originalEvent["pointerId"] !== null)) {
                        if (originalEvent["pointerId"] === pointerId)
                            return true;
                    }
                    else {
                        if (pointerId === -1)
                            return true;
                    }
                }
                return false;
            };
            /**
             * Returns array of changedTouches identifiers or empty array, if touches are not find or supported.
             * @param eventArgs - event arguments
             */
            MouseTouchPointerManager._getChangedTouchesIdentifiers = function (eventArgs) {
                var identifiers = [];
                var originalEvent = eventArgs.originalEvent;
                if (originalEvent && originalEvent.changedTouches) {
                    for (var i = 0; i < originalEvent.changedTouches.length; i++) {
                        identifiers.push(originalEvent.changedTouches[i].identifier);
                    }
                }
                return identifiers;
            };
            /**
             * Checks if array of changedTouches identifiers contains touch identifier given by argument.
             * @param eventArgs - event arguments
             * @param identifier - that is compared with changedTouches identifiers.
             */
            MouseTouchPointerManager._containTouchIdentifier = function (eventArgs, identifier) {
                var identifiers = MouseTouchPointerManager._getChangedTouchesIdentifiers(eventArgs);
                for (var i = 0; i < identifiers.length; i++) {
                    if (identifiers[i] === identifier)
                        return true;
                }
                return false;
            };
            MouseTouchPointerManager._addContainer = function () {
                if (this.getContainer().length <= 0) {
                    var container = $("<div>");
                    container.attr("id", "MTPContainer");
                    container.css({ position: "absolute", left: "0px", right: "0px", top: "0px", bottom: "0px", overflow: "hidden", "z-Index": "10000" });
                    $(document.body).append(container);
                }
            };
            MouseTouchPointerManager._removeContainer = function () {
                this.getContainer().remove();
            };
            MouseTouchPointerManager.getContainer = function () {
                return $("#MTPContainer");
            };
            return MouseTouchPointerManager;
        }());
        var GestureManager = (function () {
            function GestureManager() {
                //private _downManager: DownManager = new DownManager();
                //private _moveManager: MoveManager = new MoveManager();
                //private _upManager: UpManager = new UpManager();
                //private _cancelManager: CancelManager = new CancelManager();
                this._downMoveUpCancelManager = new DownMoveUpCancelManager();
                this._clickManager = new ClickManager();
                this._swipeLeftManager = new SwipeLeftManager();
                this._swipeRightManager = new SwipeRightManager();
                this._swipeUpManager = new SwipeUpManager();
                this._swipeDownManager = new SwipeDownManager();
            }
            //public onDown(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._downManager.add(element, handler);
            //}
            //public offDown(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._downManager.remove(element, handler);
            //}
            //public onMove(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._moveManager.add(element, handler);
            //}
            //public offMove(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._moveManager.remove(element, handler);
            //}
            //public onUp(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._upManager.add(element, handler);
            //}
            //public offUp(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._upManager.remove(element, handler);
            //}
            //public onCancel(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._cancelManager.add(element, handler);
            //}
            //public offCancel(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //	this._cancelManager.remove(element, handler);
            //}
            GestureManager.prototype.onDownMoveUpCancel = function (downElement, downHandler, moveHandler, upHandler, cancelHandler, doNotPreventDefault) {
                this._downMoveUpCancelManager.add(downElement, downHandler, moveHandler, upHandler, cancelHandler, !doNotPreventDefault);
            };
            GestureManager.prototype.offDownMoveUpCancel = function (downElement, downHandler, moveHandler, upHandler, cancelHandler) {
                this._downMoveUpCancelManager.remove(downElement, downHandler, moveHandler, upHandler, cancelHandler);
            };
            GestureManager.prototype.onClick = function (element, handler) {
                this._clickManager.add(element, handler);
            };
            GestureManager.prototype.offClick = function (element, handler) {
                this._clickManager.remove(element, handler);
            };
            //public static onDblClick(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //}
            //public static offDblClick(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //}
            //public static onPressAndHold(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //}
            //public static offPressAndHold(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
            //}
            GestureManager.prototype.onSwipeLeft = function (element, handler) {
                this._swipeLeftManager.add(element, handler);
            };
            GestureManager.prototype.offSwipeLeft = function (element, handler) {
                this._swipeLeftManager.remove(element, handler);
            };
            GestureManager.prototype.onSwipeRight = function (element, handler) {
                this._swipeRightManager.add(element, handler);
            };
            GestureManager.prototype.offSwipeRight = function (element, handler) {
                this._swipeRightManager.remove(element, handler);
            };
            GestureManager.prototype.onSwipeUp = function (element, handler) {
                this._swipeUpManager.add(element, handler);
            };
            GestureManager.prototype.offSwipeUp = function (element, handler) {
                this._swipeUpManager.remove(element, handler);
            };
            GestureManager.prototype.onSwipeDown = function (element, handler) {
                this._swipeDownManager.add(element, handler);
            };
            GestureManager.prototype.offSwipeDown = function (element, handler) {
                this._swipeDownManager.remove(element, handler);
            };
            Object.defineProperty(GestureManager, "pointerEventType", {
                get: function () {
                    return MouseTouchPointerManager.pointerEventType;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GestureManager, "DOWN", {
                get: function () {
                    return MouseTouchPointerManager.eventName(EventNameType.Down);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GestureManager, "MOVE", {
                get: function () {
                    return MouseTouchPointerManager.eventName(EventNameType.Move);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GestureManager, "UP", {
                get: function () {
                    return MouseTouchPointerManager.eventName(EventNameType.Up);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GestureManager, "CANCEL", {
                get: function () {
                    return MouseTouchPointerManager.eventName(EventNameType.Cancel);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(GestureManager, "LEAVE", {
                get: function () {
                    return MouseTouchPointerManager.eventName(EventNameType.Leave);
                },
                enumerable: true,
                configurable: true
            });
            /**
             * Returns X coordinate of mouse, pointer or touch point (from event arguments), relative to the left edge of the document.
             * @param eventArgs - event arguments
             */
            GestureManager.getPointerX = function (eventArgs, identifier) {
                return MouseTouchPointerManager.getPointerX(eventArgs, identifier);
            };
            /**
             * Returns Y coordinate of mouse, pointer or touch point (from event arguments), relative to the top edge of the document.
             * @param eventArgs - event arguments
             */
            GestureManager.getPointerY = function (eventArgs, identifier) {
                return MouseTouchPointerManager.getPointerY(eventArgs, identifier);
            };
            /**
             * Returns ID of first touch point, pointer or -1 for mouse.
             * @param eventArgs - event arguments
             */
            GestureManager.getPointerId = function (eventArgs) {
                return MouseTouchPointerManager.getPointerId(eventArgs);
            };
            /**
             * Checks if eventArgs contains the pointerId given by argument. (Checks if event of given eventArgs was raised by the same touch point, pointer or mouse, like event of given pointerId.
             * @param eventArgs - event arguments
             * @param pointerId - that is compared with pointerId given by eventArgs.
             */
            GestureManager.containPointerId = function (eventArgs, pointerId) {
                return MouseTouchPointerManager.containPointerId(eventArgs, pointerId);
            };
            return GestureManager;
        }());
        GestureManager.minMoveDistance = 10; // minimum distance (in pixels) that must be touch point (mouse/finger) moved before it is considered as move
        GestureManager.swipeTimeout = 1000; // time in milliseconds when gesture is not recognized more as swipe
        Controls.GestureManager = GestureManager;
        var GestureEventObject = (function () {
            function GestureEventObject(jQueryEventObject, pointerId, pointerType, pageX, pageY) {
                this.jQueryEventObject = jQueryEventObject;
                this.pointerId = pointerId;
                this.pointerType = pointerType;
                this.pageX = pageX;
                this.pageY = pageY;
                this.cancelDown = false;
            }
            return GestureEventObject;
        }());
        Controls.GestureEventObject = GestureEventObject;
        var ElementHandlerPair = (function () {
            function ElementHandlerPair(element, handler) {
                this.element = element;
                this.handler = handler;
            }
            ElementHandlerPair.prototype.equals = function (elementHandlerPair) {
                return (elementHandlerPair.element === this.element) && (elementHandlerPair.handler === this.handler);
            };
            return ElementHandlerPair;
        }());
        var DMUCElementHandlerPair = (function () {
            function DMUCElementHandlerPair(downElement, downHandler, moveHandler, upHandler, cancelHandler) {
                this.downElement = downElement;
                this.downHandler = downHandler;
                this.moveHandler = moveHandler;
                this.upHandler = upHandler;
                this.cancelHandler = cancelHandler;
            }
            DMUCElementHandlerPair.prototype.equals = function (elementHandlerPair) {
                return (elementHandlerPair.downElement === this.downElement) &&
                    (elementHandlerPair.downHandler === this.downHandler) &&
                    (elementHandlerPair.moveHandler === this.moveHandler) &&
                    (elementHandlerPair.upHandler === this.upHandler) &&
                    (elementHandlerPair.cancelHandler === this.cancelHandler);
            };
            return DMUCElementHandlerPair;
        }());
        //abstract class BaseGestureHandler implements IGestureHandler<ElementHandlerPair> {
        //	public elementHandlerPair: ElementHandlerPair;
        //	private _touchAction: string;
        //	constructor(elementHandlerPair: ElementHandlerPair, touchAction: string) {
        //		this.elementHandlerPair = elementHandlerPair;
        //		this._touchAction = touchAction;
        //	}
        //	public get touchAction(): string {
        //		return this._touchAction;
        //	}
        //	// EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
        //	public abstract eventHandler = (eventObject: GestureEventObject): void => {
        //	}
        //}
        //class SimpleGestureHandler extends BaseGestureHandler {
        //	constructor(elementHandlerPair: ElementHandlerPair, touchAction: string) {
        //		super(elementHandlerPair, touchAction);
        //	}
        //	// EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
        //	public eventHandler = (e: JQueryEventObject): void => {
        //		let pointerId = MouseTouchPointerManager.getPointerId(e);
        //		let pointerType = MouseTouchPointerManager.getPointerType(e);
        //		let pageX = MouseTouchPointerManager.getPointerX(e, pointerId);
        //		let pageY = MouseTouchPointerManager.getPointerY(e, pointerId);
        //		let geo = new GestureEventObject(e, pointerId, pointerType, pageX, pageY);
        //		this.elementHandlerPair.handler(geo);
        //	};
        //}
        var DMUCGestureHandler = (function () {
            function DMUCGestureHandler(elementHandlerPair, touchAction, preventDefault) {
                var _this = this;
                this._isProcessing = false;
                this._preventDefault = true;
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this.downEventHandler = function (e) {
                    if ((e.which !== undefined) && (e.which !== 0) && (e.which !== 1))
                        return;
                    if (_this._isProcessing)
                        return;
                    var pointerId = MouseTouchPointerManager.getPointerId(e);
                    var pointerType = MouseTouchPointerManager.getPointerType(e);
                    var pageX = MouseTouchPointerManager.getPointerX(e, pointerId);
                    var pageY = MouseTouchPointerManager.getPointerY(e, pointerId);
                    var geo = new GestureEventObject(e, pointerId, pointerType, pageX, pageY);
                    _this.elementHandlerPair.downHandler(geo);
                    if (geo.cancelDown) {
                        return;
                    }
                    if (_this._preventDefault)
                        e.preventDefault(); // Prevents scrollable parent containers from scrolling when nested element is moving during touch gesture. Style "touch-action: none" must be set to the nested element (that will be moved) before the touch gestue started, if pointer events are used, because preventDefault function does not prevent scrolling.
                    _this._isProcessing = true;
                    _this._downPointerId = pointerId;
                    var body = $(document.body);
                    body.on(MouseTouchPointerManager.eventName(EventNameType.Move), null, _this.moveEventHandler);
                    body.on(MouseTouchPointerManager.eventName(EventNameType.Up), null, _this.upEventHandler);
                    var cancelName = MouseTouchPointerManager.eventName(EventNameType.Cancel);
                    if (cancelName)
                        body.on(cancelName, null, _this.cancelEventHandler);
                    var leaveName = MouseTouchPointerManager.eventName(EventNameType.Leave);
                    if (leaveName)
                        body.on(leaveName, null, _this.cancelEventHandler);
                };
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this.moveEventHandler = function (e) {
                    if (!_this._isProcessing)
                        return;
                    if (!MouseTouchPointerManager.containPointerId(e, _this._downPointerId))
                        return;
                    if (_this._preventDefault)
                        e.preventDefault(); // Prevents scrollable parent containers from scrolling when nested element is moving during touch gesture. Style "touch-action: none" must be set to the nested element (that will be moved) before the touch gestue started, if pointer events are used, because preventDefault function does not prevent scrolling.
                    var pointerType = MouseTouchPointerManager.getPointerType(e);
                    var pageX = MouseTouchPointerManager.getPointerX(e, _this._downPointerId);
                    var pageY = MouseTouchPointerManager.getPointerY(e, _this._downPointerId);
                    var geo = new GestureEventObject(e, _this._downPointerId, pointerType, pageX, pageY);
                    _this.elementHandlerPair.moveHandler(geo);
                };
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this.upEventHandler = function (e) {
                    if ((e.which !== undefined) && (e.which !== 0) && (e.which !== 1))
                        return;
                    var geo = _this._onUpCancel(e);
                    if (!geo)
                        return;
                    _this.elementHandlerPair.upHandler(geo);
                };
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this.cancelEventHandler = function (e) {
                    var geo = _this._onUpCancel(e);
                    if (!geo)
                        return;
                    _this.elementHandlerPair.cancelHandler(geo);
                };
                this.elementHandlerPair = elementHandlerPair;
                this._touchAction = touchAction;
                this._preventDefault = preventDefault;
            }
            Object.defineProperty(DMUCGestureHandler.prototype, "touchAction", {
                get: function () {
                    return this._touchAction;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DMUCGestureHandler.prototype, "preventDefault", {
                get: function () {
                    return this._preventDefault;
                },
                enumerable: true,
                configurable: true
            });
            DMUCGestureHandler.prototype._onUpCancel = function (e) {
                if (!this._isProcessing)
                    return null;
                if (!MouseTouchPointerManager.containPointerId(e, this._downPointerId))
                    return null;
                if (this._preventDefault)
                    e.preventDefault(); // Prevents scrollable parent containers from scrolling when nested element is moving during touch gesture. Style "touch-action: none" must be set to the nested element (that will be moved) before the touch gestue started, if pointer events are used, because preventDefault function does not prevent scrolling.
                var body = $(document.body);
                body.off(MouseTouchPointerManager.eventName(EventNameType.Move), this.moveEventHandler);
                body.off(MouseTouchPointerManager.eventName(EventNameType.Up), this.upEventHandler);
                var cancelName = MouseTouchPointerManager.eventName(EventNameType.Cancel);
                if (cancelName)
                    body.off(cancelName, this.cancelEventHandler);
                var leaveName = MouseTouchPointerManager.eventName(EventNameType.Leave);
                if (leaveName)
                    body.off(leaveName, this.cancelEventHandler);
                var pointerType = MouseTouchPointerManager.getPointerType(e);
                var pageX = MouseTouchPointerManager.getPointerX(e, this._downPointerId);
                var pageY = MouseTouchPointerManager.getPointerY(e, this._downPointerId);
                var geo = new GestureEventObject(e, this._downPointerId, pointerType, pageX, pageY);
                this._downPointerId = undefined;
                this._isProcessing = false;
                return geo;
            };
            return DMUCGestureHandler;
        }());
        var BaseGestureHandler = (function () {
            function BaseGestureHandler(elementHandlerPair) {
                var _this = this;
                this._downMoveUpCancelManager = new DownMoveUpCancelManager();
                this._downX = null;
                this._downY = null;
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this._downEventHandler = function (e) {
                    _this._downX = e.pageX;
                    _this._downY = e.pageY;
                    _this._timeStamp = e.jQueryEventObject.timeStamp;
                };
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this._moveEventHandler = function (e) {
                };
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this._upEventHandler = function (e) {
                    if (_this._downX === null || _this._downY === null) {
                        return;
                    }
                    var deltaX = e.pageX - _this._downX;
                    var deltaY = e.pageY - _this._downY;
                    var deltaTimeStamp = e.jQueryEventObject.timeStamp - _this._timeStamp;
                    if (_this.predicate(deltaX, deltaY, deltaTimeStamp)) {
                        _this.elementHandlerPair.handler(e);
                    }
                    _this._onUpCancel();
                };
                // EventHandler methods need to be declared using arrow function to force TypeScript compiler to create local _this variable for correct function scope.
                this._cancelEventHandler = function (e) {
                    _this._onUpCancel();
                };
                this.elementHandlerPair = elementHandlerPair;
                this._downMoveUpCancelManager.add($(elementHandlerPair.element), this._downEventHandler, this._moveEventHandler, this._upEventHandler, this._cancelEventHandler, false);
            }
            BaseGestureHandler.prototype._onUpCancel = function () {
                this._downX = null;
                this._downY = null;
            };
            return BaseGestureHandler;
        }());
        var ClickGestureHandler = (function (_super) {
            __extends(ClickGestureHandler, _super);
            function ClickGestureHandler() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            ClickGestureHandler.prototype.predicate = function (deltaX, deltaY, deltaTimeStamp) {
                if ((deltaX < GestureManager.minMoveDistance) && (deltaY < GestureManager.minMoveDistance)) {
                    return true;
                }
                return false;
            };
            return ClickGestureHandler;
        }(BaseGestureHandler));
        var SwipeGestureHandler = (function (_super) {
            __extends(SwipeGestureHandler, _super);
            function SwipeGestureHandler() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeGestureHandler.prototype.predicate = function (deltaX, deltaY, deltaTimeStamp) {
                if (deltaTimeStamp < GestureManager.swipeTimeout) {
                    if (this.directionPredicate(deltaX, deltaY)) {
                        return true;
                    }
                }
                return false;
            };
            return SwipeGestureHandler;
        }(BaseGestureHandler));
        var SwipeLeftGestureHandler = (function (_super) {
            __extends(SwipeLeftGestureHandler, _super);
            function SwipeLeftGestureHandler() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeLeftGestureHandler.prototype.directionPredicate = function (deltaX, deltaY) {
                return ((Math.abs(deltaX) > Math.abs(deltaY)) && (deltaX < -GestureManager.minMoveDistance)) ? true : false;
            };
            return SwipeLeftGestureHandler;
        }(SwipeGestureHandler));
        var SwipeRightGestureHandler = (function (_super) {
            __extends(SwipeRightGestureHandler, _super);
            function SwipeRightGestureHandler() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeRightGestureHandler.prototype.directionPredicate = function (deltaX, deltaY) {
                return ((Math.abs(deltaX) > Math.abs(deltaY)) && (deltaX > GestureManager.minMoveDistance)) ? true : false;
            };
            return SwipeRightGestureHandler;
        }(SwipeGestureHandler));
        var SwipeUpGestureHandler = (function (_super) {
            __extends(SwipeUpGestureHandler, _super);
            function SwipeUpGestureHandler() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeUpGestureHandler.prototype.directionPredicate = function (deltaX, deltaY) {
                return ((Math.abs(deltaX) < Math.abs(deltaY)) && (deltaY < -GestureManager.minMoveDistance)) ? true : false;
            };
            return SwipeUpGestureHandler;
        }(SwipeGestureHandler));
        var SwipeDownGestureHandler = (function (_super) {
            __extends(SwipeDownGestureHandler, _super);
            function SwipeDownGestureHandler() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeDownGestureHandler.prototype.directionPredicate = function (deltaX, deltaY) {
                return ((Math.abs(deltaX) < Math.abs(deltaY)) && (deltaY > GestureManager.minMoveDistance)) ? true : false;
            };
            return SwipeDownGestureHandler;
        }(SwipeGestureHandler));
        // optimize gestureCache to store elements in one array and handlers for each element in array bound to the each element for faster search
        var GestureHandlerCache = (function () {
            function GestureHandlerCache() {
                this._gestureHandlers = new Array();
            }
            GestureHandlerCache.prototype.add = function (gestureHandler) {
                if (this._getIndex(gestureHandler.elementHandlerPair) === -1)
                    this._gestureHandlers.push(gestureHandler);
            };
            GestureHandlerCache.prototype.getAndRemove = function (elementHandlerPair) {
                var index = this._getIndex(elementHandlerPair);
                if ((0 <= index) && (index < this._gestureHandlers.length)) {
                    var cachedGestureHandler = this._gestureHandlers[index];
                    this._gestureHandlers.splice(index, 1);
                    return cachedGestureHandler;
                }
                return null;
            };
            GestureHandlerCache.prototype._getIndex = function (elementHandlerPair) {
                for (var i = 0; i < this._gestureHandlers.length; i++) {
                    if (elementHandlerPair.equals(this._gestureHandlers[i].elementHandlerPair))
                        return i;
                }
                return -1;
            };
            return GestureHandlerCache;
        }());
        //abstract class BaseManager<T extends BaseGestureHandler> {
        //	protected _gestureCache: GestureHandlerCache<T, ElementHandlerPair> = new GestureHandlerCache<T, ElementHandlerPair>();
        //	public abstract add(element: JQuery, handler: (eventObject: GestureEventObject) => void): void;
        //	public abstract remove(element: JQuery, handler: (eventObject: GestureEventObject) => void): void;
        //	protected _add(c: new (elementHandlerPair: ElementHandlerPair, touchAction: string) => T, eventsName: string, element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		for (let i = 0; i < element.length; i++) {
        //			let htmlElement = element[i];
        //			let $htmlElement = $(htmlElement);
        //			let elementHandlerPair = new ElementHandlerPair(htmlElement, handler);
        //			let gestureHandler = new c(elementHandlerPair, htmlElement.style.touchAction);
        //			this._gestureCache.add(gestureHandler);
        //			htmlElement.style.touchAction = "none"; // Prevents scrollable parent containers from scrolling when nested element is moving during touch gesture. Style "touch-action: none" must be set to the nested element (that will be moved) before the touch gestue started, if pointer events are used, because preventDefault function does not prevent scrolling.
        //			htmlElement.style.msTouchAction = htmlElement.style.touchAction;
        //			$htmlElement.on(eventsName, null, gestureHandler.eventHandler);
        //		}
        //	}
        //	protected _remove(eventsName: string, element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		for (let i = 0; i < element.length; i++) {
        //			let htmlElement = element[i];
        //			let $htmlElement = $(htmlElement);
        //			let elementHandlerPair = new ElementHandlerPair(htmlElement, handler);
        //			let gestureHandler = this._gestureCache.getAndRemove(elementHandlerPair);
        //			if (gestureHandler) {
        //				htmlElement.style.touchAction = gestureHandler.touchAction;
        //				htmlElement.style.msTouchAction = htmlElement.style.touchAction;
        //				$(htmlElement).off(eventsName, gestureHandler.eventHandler);
        //			}
        //		}
        //	}
        //}
        //class DownManager extends BaseManager {
        //	public add(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._add(MouseTouchPointerManager.DOWN, element, handler);
        //	}
        //	public remove(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._remove(MouseTouchPointerManager.DOWN, element, handler);
        //	}
        //}
        //class MoveManager extends BaseManager {
        //	public add(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._add(MouseTouchPointerManager.MOVE, element, handler);
        //	}
        //	public remove(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._remove(MouseTouchPointerManager.MOVE, element, handler);
        //	}
        //}
        //class UpManager extends BaseManager {
        //	public add(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._add(MouseTouchPointerManager.UP, element, handler);
        //	}
        //	public remove(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._remove(MouseTouchPointerManager.UP, element, handler);
        //	}
        //}
        //class CancelManager extends BaseManager {
        //	public add(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._add(MouseTouchPointerManager.CANCEL, element, handler);
        //	}
        //	public remove(element: JQuery, handler: (eventObject: GestureEventObject) => void): void {
        //		this._remove(MouseTouchPointerManager.CANCEL, element, handler);
        //	}
        //}
        var DownMoveUpCancelManager = (function () {
            function DownMoveUpCancelManager() {
                this._gestureCache = new GestureHandlerCache();
            }
            DownMoveUpCancelManager.prototype.add = function (downElement, downHandler, moveHandler, upHandler, cancelHandler, preventDefault) {
                for (var i = 0; i < downElement.length; i++) {
                    var htmlDownElement = downElement[i];
                    var $htmlDownElement = $(htmlDownElement);
                    var elementHandlerPair = new DMUCElementHandlerPair(htmlDownElement, downHandler, moveHandler, upHandler, cancelHandler);
                    var gestureHandler = new DMUCGestureHandler(elementHandlerPair, htmlDownElement.style.touchAction, preventDefault);
                    this._gestureCache.add(gestureHandler);
                    if (gestureHandler.preventDefault) {
                        htmlDownElement.style.touchAction = "none"; // Prevents scrollable parent containers from scrolling when nested element is moving during touch gesture. Style "touch-action: none" must be set to the nested element (that will be moved) before the touch gestue started, if pointer events are used, because preventDefault function does not prevent scrolling.
                        htmlDownElement.style.msTouchAction = htmlDownElement.style.touchAction;
                    }
                    $htmlDownElement.on(MouseTouchPointerManager.eventName(EventNameType.Down), null, gestureHandler.downEventHandler);
                }
            };
            DownMoveUpCancelManager.prototype.remove = function (downElement, downHandler, moveHandler, upHandler, cancelHandler) {
                for (var i = 0; i < downElement.length; i++) {
                    var htmlDownElement = downElement[i];
                    var $htmlDownElement = $(htmlDownElement);
                    var elementHandlerPair = new DMUCElementHandlerPair(htmlDownElement, downHandler, moveHandler, upHandler, cancelHandler);
                    var gestureHandler = this._gestureCache.getAndRemove(elementHandlerPair);
                    if (gestureHandler) {
                        if (gestureHandler.preventDefault) {
                            htmlDownElement.style.touchAction = gestureHandler.touchAction;
                            htmlDownElement.style.msTouchAction = htmlDownElement.style.touchAction;
                        }
                        $htmlDownElement.off(MouseTouchPointerManager.eventName(EventNameType.Down), gestureHandler.downEventHandler);
                    }
                }
            };
            return DownMoveUpCancelManager;
        }());
        var BaseManager = (function () {
            function BaseManager() {
                this._gestureCache = new GestureHandlerCache();
            }
            BaseManager.prototype._add = function (c, element, handler) {
                for (var i = 0; i < element.length; i++) {
                    var htmlElement = element[i];
                    var elementHandlerPair = new ElementHandlerPair(htmlElement, handler);
                    var gestureHandler = new c(elementHandlerPair);
                    this._gestureCache.add(gestureHandler);
                }
            };
            BaseManager.prototype.remove = function (element, handler) {
                for (var i = 0; i < element.length; i++) {
                    var htmlElement = element[i];
                    var elementHandlerPair = new ElementHandlerPair(htmlElement, handler);
                    var gestureHandler = this._gestureCache.getAndRemove(elementHandlerPair);
                }
            };
            return BaseManager;
        }());
        var ClickManager = (function (_super) {
            __extends(ClickManager, _super);
            function ClickManager() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            ClickManager.prototype.add = function (element, handler) {
                this._add(ClickGestureHandler, element, handler);
            };
            return ClickManager;
        }(BaseManager));
        var SwipeManager = (function (_super) {
            __extends(SwipeManager, _super);
            function SwipeManager() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            return SwipeManager;
        }(BaseManager));
        var SwipeLeftManager = (function (_super) {
            __extends(SwipeLeftManager, _super);
            function SwipeLeftManager() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeLeftManager.prototype.add = function (element, handler) {
                this._add(SwipeLeftGestureHandler, element, handler);
            };
            return SwipeLeftManager;
        }(SwipeManager));
        var SwipeRightManager = (function (_super) {
            __extends(SwipeRightManager, _super);
            function SwipeRightManager() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeRightManager.prototype.add = function (element, handler) {
                this._add(SwipeRightGestureHandler, element, handler);
            };
            return SwipeRightManager;
        }(SwipeManager));
        var SwipeUpManager = (function (_super) {
            __extends(SwipeUpManager, _super);
            function SwipeUpManager() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeUpManager.prototype.add = function (element, handler) {
                this._add(SwipeUpGestureHandler, element, handler);
            };
            return SwipeUpManager;
        }(SwipeManager));
        var SwipeDownManager = (function (_super) {
            __extends(SwipeDownManager, _super);
            function SwipeDownManager() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SwipeDownManager.prototype.add = function (element, handler) {
                this._add(SwipeDownGestureHandler, element, handler);
            };
            return SwipeDownManager;
        }(SwipeManager));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
