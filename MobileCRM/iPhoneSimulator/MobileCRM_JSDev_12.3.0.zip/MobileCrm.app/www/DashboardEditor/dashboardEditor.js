/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path='../Controls/controls.ts' />
/// <reference path='../Controls/comboBox.ts' />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var DashboardEditor;
(function (DashboardEditor) {
    /**
     * Bacis class represents view | chart
     */
    var ViewBase = (function () {
        function ViewBase() {
            this.selected = ko.observable();
            this.enabled = ko.observable();
        }
        return ViewBase;
    }());
    DashboardEditor.ViewBase = ViewBase;
    /**
     * Class represents size of the actual window.
     */
    var DashboardEditorSizeMonitor = (function (_super) {
        __extends(DashboardEditorSizeMonitor, _super);
        function DashboardEditorSizeMonitor(initialized) {
            var _this = _super.call(this) || this;
            _this.m_topSpace = 72; // height of the space in the top of window
            _this.m_bottombarSpace = 50;
            _this.dashboardEntityViewModelHeight = ko.computed(function () {
                return (_this.height() ? _this.height() - _this.m_topSpace - _this.m_bottombarSpace : 0);
            }, _this);
            _this.dashboardContentHeight = ko.computed(function () {
                return (_this.height() ? _this.height() - _this.m_bottombarSpace : 0);
            });
            if (initialized) {
                _this.width(0);
                _this.height(0);
            }
            else {
                _this.changeSize();
            }
            return _this;
        }
        return DashboardEditorSizeMonitor;
    }(Resco.Controls.WindowSizeMonitor));
    DashboardEditor.DashboardEditorSizeMonitor = DashboardEditorSizeMonitor;
    /**
     * Class represents dashboard entity with its properties.
     */
    var DashboardEntity = (function () {
        function DashboardEntity(commonNamesValue) {
            var _this = this;
            /**
             * @property it is used for handle loading views only one.
             */
            this.viewsLoaded = false;
            /*
             * @property it is used for handle loading charts only one
             */
            this.chartsLoaded = false;
            try {
                if (commonNamesValue && commonNamesValue.indexOf(";") > 0) {
                    var splittedNames = commonNamesValue.split(";");
                    this.logicalName = splittedNames[0];
                    this.displayName = splittedNames[1];
                    this.commonNamesValue = commonNamesValue;
                }
                this.views = ko.observableArray();
                this.charts = ko.observableArray();
                this.displayRecordsAsListView = ko.observable();
                this.displayRecordsAsChart = ko.observable();
                this.displayRecordsAsMap = ko.observable();
                this.createNewRecords = ko.observable();
                this.search = ko.observable();
                this.allowedCharts = new Array();
                this.allowedViews = new Array();
                this.initialType = ["List", "Map", "Chart"];
                this.additionalText = ko.observable();
                this.initialViewTypeSelected = ko.observable(this.initialType[0]);
                this.selectedView = ko.observable();
                this.selectedChart = ko.observable();
                this.updateInitialViewType = function (args) {
                    _this.initialViewTypeSelected(args.changedItem);
                };
                this.updateSelectedView = function (args) {
                    _this.views().forEach(function (v) { return v.selected(false); });
                    var view = args.changedItem;
                    view.selected(true);
                    _this.selectedView(view);
                };
                this.updateSelectedChart = function (args) {
                    _this.charts().forEach(function (v) { return v.selected(false); });
                    var chart = args.changedItem;
                    chart.selected(true);
                    _this.selectedChart(chart);
                };
            }
            catch (error) {
                console.log(error);
            }
        }
        /**
         * A public method that refresh addition text of dashboard entity obj
         * @return {string} return string value with serialized all labels of the views if exist some views that are disabled oterwise result is text 'all views'
         */
        DashboardEntity.prototype.updateAdditionalText = function () {
            var enabledViews = this.views().filter(function (v) { return v.enabled(); });
            var result = "";
            if (enabledViews.length == 0) {
            }
            else if (enabledViews.length == this.views().length) {
                result = "All Views";
            }
            else {
                for (var _i = 0, enabledViews_1 = enabledViews; _i < enabledViews_1.length; _i++) {
                    var v = enabledViews_1[_i];
                    result += v.label;
                    if (v.selected()) {
                        result += "*";
                    }
                    result += ",";
                }
            }
            return result;
        };
        return DashboardEntity;
    }());
    DashboardEditor.DashboardEntity = DashboardEntity;
    /**
     * Main class of the dashboard editor. It is main form
     */
    var Editor = (function () {
        function Editor() {
            var _this = this;
            this.editorSizeMonitor = new DashboardEditorSizeMonitor();
            this.contextMenu = new ContextMenu();
            this.columnCount = ko.observable();
            this.rowCount = ko.observable();
            this.isEntityEdit = ko.observable(false);
            this.m_newEntityAdded = false;
            this.selectedEntity = ko.observable();
            this.entities = new Array();
            this.selectedEntities = ko.observableArray();
            this.isEntityListShow = ko.observable(false);
            this.isDirty = ko.observable(false);
            //colors
            this.titleBackgroundColor = ko.observable("#0066CC");
            this.titleForegroundColor = ko.observable("FFFFFF");
            this.formBackgroundColor = ko.observable();
            this.formItemBackgroundColor = ko.observable();
            this.formItemLabelForegroundColor = ko.observable();
            this.tabBackgroundColor = ko.observable();
            this.tabSelForegroundColor = ko.observable();
            this.tabForegroundColor = ko.observable();
            this.formItemLinkColor = ko.observable();
            this.formItemForegroundColor = ko.observable();
            this.formItemDisabledColor = ko.observable();
            this.listBackgroundColor = ko.observable();
            this.listForegroundColor = ko.observable();
            this.listSelBackgroundColor = ko.observable();
            this.listSelForegroundColor = ko.observable();
            this.listSeparatorColor = ko.observable();
            this.backArrowImg = ko.observable();
            this.sortDownArrowImg = ko.observable();
            this.sortUpArrowImg = ko.observable();
            this.editButtonImg = ko.observable();
            this.selectedCheckMarkImg = ko.observable();
            this.addButtonImg = ko.observable();
            this.saveButtonImg = ko.observable();
            this.deleteButtonImg = ko.observable();
            this.actionButtonImg = ko.observable();
            this.editorLabel = ko.observable();
            this.noData = ko.observable();
            var bottomBarLabels = ["Options", "List View", "Chart", "Map"];
            this.bottomBarDisplayLabels = this._initializeLabelsArray(4, bottomBarLabels);
            this.optionViewCommands = this._initializeLabelsArray(2);
            this.sectionLabels = this._initializeLabelsArray(5);
            this.chartViewNoData = ko.observable();
            this.mapViewMessage = ko.observable();
            this.onBackCmdLabels = this._initializeLabelsArray(3);
            MobileCRM.bridge.command("getDashboardViewsConfig", {}, function (result) {
                var configDashboard = result[0];
                var key = "columns";
                _this.columnCount(JSON.parse(configDashboard[key]));
                key = "rows";
                _this.rowCount(JSON.parse(configDashboard[key]));
                for (var j = 1; j < result.length; j++) {
                    var dashboardComponent = result[j];
                    var dashboardComponetOptions = dashboardComponent.options ? dashboardComponent.options.split("|") : new Array();
                    var entity = new DashboardEntity(dashboardComponent.entityName);
                    for (var i = 0; i < dashboardComponetOptions.length; i++) {
                        var property = dashboardComponetOptions[i].replace("[", "").replace("]", "").split(",");
                        switch (property[0]) {
                            case "createNew":
                                entity.createNewRecords(JSON.parse(property[1].toLocaleLowerCase()));
                                break;
                            case "allowSearch":
                                entity.search(JSON.parse(property[1].toLocaleLowerCase()));
                                break;
                            case "disableMap":
                                entity.displayRecordsAsMap(JSON.parse(property[1].toLocaleLowerCase()));
                                break;
                            case "disableChart":
                                entity.displayRecordsAsChart(JSON.parse(property[1].toLocaleLowerCase()));
                                break;
                            case "disableList":
                                entity.displayRecordsAsListView(JSON.parse(property[1].toLocaleLowerCase()));
                                break;
                            case "initialChart":
                                if (JSON.parse(property[1].toLocaleLowerCase()))
                                    entity.initialViewTypeSelected(entity.initialType[2]);
                                break;
                            case "initialMap":
                                if (JSON.parse(property[1].toLocaleLowerCase()))
                                    entity.initialViewTypeSelected(entity.initialType[1]);
                                break;
                            case "initialListViews":
                                entity.initialView = property[1].trim();
                                break;
                            case "allowedListViews":
                                entity.allowedViews = property[1].trim().split(";");
                                break;
                            case "allowedChartsViews":
                                entity.allowedCharts = property[1].trim().split(";");
                                break;
                            case "initialChartViews":
                                entity.initialChart = property[1].trim();
                                break;
                            default:
                                break;
                        }
                    }
                    _this._loadViews(entity);
                    _this._loadCharts(entity);
                    _this.selectedEntities.push(entity);
                }
            }, function (error) { console.log(error); }, this);
            MobileCRM.bridge.command("getEntityList", {}, function (result) {
                var entitiesNames = result;
                for (var e in entitiesNames) {
                    var de = {
                        logicalName: e,
                        displayName: entitiesNames[e],
                        charts: undefined,
                        views: undefined,
                    };
                    _this.entities.push(de);
                }
            }, function (error) {
                console.log(error);
            }, this);
            MobileCRM.bridge.command("getLocalizedEditorLabels", {}, function (result) {
                var localizedLabels = result;
                _this.editorLabel(localizedLabels[0]);
                _this.contextMenu.labelMoveUp(localizedLabels[1]);
                _this.contextMenu.labelMoveDown(localizedLabels[2]);
                _this.contextMenu.labelDelete(localizedLabels[3]);
                _this.noData(localizedLabels[4]);
                _this.bottomBarDisplayLabels[0](localizedLabels[5]);
                _this.bottomBarDisplayLabels[1](localizedLabels[6]);
                _this.bottomBarDisplayLabels[2](localizedLabels[7]);
                _this.bottomBarDisplayLabels[3](localizedLabels[8]);
                _this.optionViewCommands[0](localizedLabels[9]);
                _this.optionViewCommands[1](localizedLabels[10]);
                _this.sectionLabels[0](localizedLabels[11]);
                _this.sectionLabels[1](localizedLabels[12]);
                _this.sectionLabels[2](localizedLabels[13]);
                _this.sectionLabels[3](localizedLabels[14]);
                _this.sectionLabels[4](localizedLabels[15]);
                _this.chartViewNoData(localizedLabels[16]);
                _this.mapViewMessage(localizedLabels[17]);
                var cmdLabels = localizedLabels[18].split(";");
                _this.onBackCmdLabels = cmdLabels.map(function (cmdLabel) { return ko.observable(cmdLabel); });
            }, function (error) { }, this);
            this._loadImages();
            this._loadColors();
            this.updateSelectedEntity = function (data) {
                _this.isEntityListShow(false);
                var iEntityData = data;
                var dashboardEntity = new DashboardEntity();
                dashboardEntity.logicalName = iEntityData.logicalName;
                dashboardEntity.displayName = iEntityData.displayName;
                _this._addSelectedEntity(dashboardEntity);
            };
        }
        Editor.prototype.closeContext = function () {
            if (this.contextMenu.enabled()) {
                this.contextMenu.enabled(false);
                this.selectedEntity(null);
            }
        };
        /**
         * A private method that load images through JSBridge.
         */
        Editor.prototype._loadImages = function () {
            var _this = this;
            this._loadImage("Cmd.Back.png", "TitleForeground", function (r) { _this.backArrowImg(r); });
            this._loadImage("Now.RowClose.png", "", function (r) { _this.sortUpArrowImg(r); });
            this._loadImage("Now.RowOpen.png", "", function (r) { _this.sortDownArrowImg(r); });
            this._loadImage("Controls.CheckMark.png", "", function (r) { _this.selectedCheckMarkImg(r); });
            this._loadImage("Cmd.Edit.png", "", function (r) { _this.editButtonImg(r); });
            this._loadImage("Cmd.Save.png", "TitleForeground", function (r) { _this.saveButtonImg(r); });
            this._loadImage("Cmd.New.png", "TitleForeground", function (r) { _this.addButtonImg(r); });
            this._loadImage("Cmd.Delete.png", "", function (r) { _this.deleteButtonImg(r); });
            this._loadImage("Cmd.Action.png", "", function (r) { _this.actionButtonImg(r); });
        };
        Editor.prototype._loadImage = function (imageName, color, callback) {
            MobileCRM.Application.getAppImage(imageName, color, function (result) {
                callback("url('" + result + "')");
            }, function (err) {
                console.log(err);
            }, null);
        };
        /**
         * A private method that load colors through JSBridge.
         */
        Editor.prototype._loadColors = function () {
            var _this = this;
            this._loadColor("FormBackground", function (r) { _this.formBackgroundColor(r); });
            this._loadColor("TitleBackground", function (r) { _this.titleBackgroundColor(r); });
            this._loadColor("TitleForeground", function (r) { _this.titleForegroundColor(r); });
            this._loadColor("FormItemBackground", function (r) { _this.formItemBackgroundColor(r); });
            this._loadColor("FormItemLabelForeground", function (r) { _this.formItemLabelForegroundColor(r); });
            this._loadColor("FormItemLink", function (r) { _this.formItemLinkColor(r); });
            this._loadColor("ListBackground", function (r) { _this.listBackgroundColor(r); });
            this._loadColor("ListForeground", function (r) { _this.listForegroundColor(r); });
            this._loadColor("ListSelBackground", function (r) { _this.listSelBackgroundColor(r); });
            this._loadColor("ListSelForeground", function (r) { _this.listSelForegroundColor(r); });
            this._loadColor("ListSeparator", function (r) { _this.listSeparatorColor(r); });
            this._loadColor("TabBackground", function (r) { _this.tabBackgroundColor(r); });
            this._loadColor("TabForeground", function (r) { _this.tabForegroundColor(r); });
            this._loadColor("TabSelForeground", function (r) { _this.tabSelForegroundColor(r); });
            this._loadColor("FormItemForeground", function (r) { _this.formItemForegroundColor(r); });
            this._loadColor("FormItemDisabled", function (r) { _this.formItemDisabledColor(r); });
        };
        Editor.prototype._loadColor = function (color, callback) {
            MobileCRM.Application.getAppColor(color, function (result) {
                callback(result);
            }, function (err) {
                console.log(err);
            });
        };
        /**
         * A public method that handle move of the component to down.
         */
        Editor.prototype.moveDownComponent = function (sender, e) {
            var index = this.selectedEntities().indexOf(this.selectedEntity());
            if (index < this.selectedEntities().length - 1) {
                var rawEntities = this.selectedEntities();
                this.selectedEntities().splice(index, 2, rawEntities[index + 1], rawEntities[index]);
                this.selectedEntities.valueHasMutated();
                this.selectedEntity(null);
                this.contextMenu.enabled(false);
                this.isDirty(true);
            }
        };
        /**
         * A public method that handle move of the component to he higher.
         */
        Editor.prototype.moveUpComponent = function (sender, e) {
            var index = this.selectedEntities().indexOf(this.selectedEntity());
            if (index >= 1) {
                var rawEntities = this.selectedEntities();
                this.selectedEntities().splice(index - 1, 2, rawEntities[index], rawEntities[index - 1]);
                this.selectedEntities.valueHasMutated();
                this.selectedEntity(null);
                this.contextMenu.enabled(false);
                this.isDirty(true);
            }
        };
        /**
         * A public method that handle opening contex menu.
         * @param {any} sender Object that calls this method.
         * @param e Html on click event
         */
        Editor.prototype.openContextMenu = function (sender, e) {
            var item = sender;
            var parentOffsetTop = e.target.offsetParent.offsetTop;
            this.contextMenu.topPosition(e.currentTarget.offsetTop + e.currentTarget.offsetHeight + +parentOffsetTop);
            var w = 150;
            var leftPosition = e.currentTarget.offsetLeft + e.currentTarget.offsetWidth - w; /// TODO: detect bottom!!!
            this.selectedEntity(item);
            this.contextMenu.leftPosition(leftPosition);
            this.contextMenu.enabled(true);
        };
        /**
         * A send command to MCRM for close editor.
         */
        Editor.prototype.onBackButtonClick = function (sender, e) {
            var _this = this;
            if (this.isEntityListShow()) {
                this.isEntityListShow(false);
            }
            else {
                if (this.isDirty()) {
                    var message = this.editorLabel();
                    var items_1 = this.onBackCmdLabels.map(function (i) { return i(); });
                    var messageBox = new MobileCRM.UI.MessageBox(message, "");
                    messageBox.multiLine = true;
                    messageBox.items = items_1;
                    messageBox.show(function (result) {
                        switch (result) {
                            case items_1[0]:
                                _this.saveEditor(null, null);
                                break;
                            case items_1[1]:
                                _this._closeEditorWithoutSave();
                                break;
                            case items_1[2]:
                                break;
                        }
                    }, function (failure) { }, this);
                }
                else {
                    this._closeEditorWithoutSave();
                }
            }
        };
        /**
         * Save and close editor after click to the save button.
         */
        Editor.prototype.saveEditor = function (sender, e) {
            var serializeData = this._serializeData();
            MobileCRM.bridge.command("deserializeDashboardSettings", serializeData, function (result) { }, function (error) { }, this);
        };
        /**
         * Serialize data and send their to the MCRM.
         */
        Editor.prototype._serializeData = function () {
            var result = [];
            function _generateStringFormat(items) {
                if (items) {
                    var enabledViews = items.filter(function (v) { return v.enabled(); });
                    if (enabledViews.length == items.length) {
                        var initialView = items.filter(function (v) { return v.selected(); });
                        if (initialView && initialView.length == 1) {
                            return entity.logicalName + ".*:" + entity.logicalName + ".@" + initialView[0].name;
                        }
                        return "";
                    }
                    var resultSerializedItems = "";
                    for (var _i = 0, enabledViews_2 = enabledViews; _i < enabledViews_2.length; _i++) {
                        var view = enabledViews_2[_i];
                        resultSerializedItems += entity.logicalName + ".";
                        if (view.selected()) {
                            resultSerializedItems += "@";
                        }
                        resultSerializedItems += view.name + ":";
                    }
                    if (resultSerializedItems.length > 0 && resultSerializedItems.lastIndexOf(":") > -1) {
                        resultSerializedItems = resultSerializedItems.slice(0, resultSerializedItems.lastIndexOf(":"));
                    }
                    return resultSerializedItems;
                }
                return "";
            }
            for (var _i = 0, _a = this.selectedEntities(); _i < _a.length; _i++) {
                var entity = _a[_i];
                var entityInitType = entity.initialType.map(function (i) { return i === entity.initialViewTypeSelected(); }); //[false, false];
                result.push({
                    name: entity.logicalName,
                    allowedViews: _generateStringFormat(entity.views()),
                    allowedCharts: _generateStringFormat(entity.charts()),
                    options: entity.createNewRecords() + ";" + entity.search() + ";" + entity.displayRecordsAsChart() + ";" + entity.displayRecordsAsMap() + ";" + entity.displayRecordsAsListView() + ";" + entityInitType[1] + ";" + entityInitType[2],
                });
            }
            return JSON.stringify(result);
        };
        /**
         * Handle click on button to add new entity.
         */
        Editor.prototype.addNewEntityToDashboard = function () {
            this.isEntityListShow(true);
            this.contextMenu.enabled(false);
            // todo: go to new form with selection of entity
        };
        Editor.prototype._loadViews = function (entity) {
            if (!entity.viewsLoaded) {
                MobileCRM.bridge.command("getEntityViews", entity.logicalName, function (result) {
                    var loadedViews = new Array();
                    for (var v in result) {
                        var view = new ViewBase();
                        view.name = v;
                        view.label = result[v];
                        var allowedAll = (entity.allowedViews.filter(function (i) { return i == "*"; }))[0] || entity.allowedViews.length == 0 || entity.allowedViews == null ? true : false;
                        if (allowedAll) {
                            view.enabled(true);
                        }
                        else {
                            if (entity.allowedViews) {
                                view.enabled(entity.allowedViews.filter(function (av) { return av == v; }).length !== 0 ? true : false);
                            }
                            else {
                                view.enabled(false);
                            }
                        }
                        var defaultSelection = (entity.initialView && entity.initialView == v) ? true : false;
                        view.selected(defaultSelection);
                        if (defaultSelection) {
                            entity.selectedView(view);
                        }
                        loadedViews.push(view);
                    }
                    if (entity.selectedView() === undefined) {
                        loadedViews[0].selected(true);
                        entity.selectedView(loadedViews[0]);
                    }
                    entity.views(loadedViews);
                    entity.additionalText(entity.updateAdditionalText());
                    entity.viewsLoaded = true;
                }, function (error) {
                    console.log(error);
                }, this);
            }
        };
        Editor.prototype._loadCharts = function (entity) {
            if (!entity.chartsLoaded) {
                MobileCRM.bridge.command("getEntityCharts", entity.logicalName, function (result) {
                    var charts = result;
                    if (Object.keys(charts).length > 0 && charts.constructor === Object) {
                        var loadedCharts = new Array();
                        for (var ch in result) {
                            var chart = new ViewBase();
                            chart.name = ch;
                            chart.label = result[ch];
                            var allowedAll = (entity.allowedCharts.filter(function (i) { return i == "*"; }))[0] || entity.allowedCharts.length == 0 || entity.allowedCharts == null ? true : false;
                            if (allowedAll) {
                                chart.enabled(true);
                            }
                            else {
                                if (entity.allowedCharts) {
                                    chart.enabled(entity.allowedCharts.filter(function (ach) { return ach == ch; }).length !== 0 ? true : false);
                                }
                                else {
                                    chart.enabled(false);
                                }
                            }
                            var defaultSelection = (entity.initialChart && entity.initialChart == ch) ? true : false;
                            chart.selected(defaultSelection);
                            if (defaultSelection) {
                                entity.selectedChart(chart);
                            }
                            loadedCharts.push(chart);
                        }
                        if (entity.selectedChart() === undefined) {
                            loadedCharts[0].selected(true);
                            entity.selectedChart(loadedCharts[0]);
                        }
                        entity.charts(loadedCharts);
                    }
                    else {
                        entity.displayRecordsAsChart(false); ///TODO make unavailable 
                    }
                    entity.chartsLoaded = true;
                }, function (error) {
                    console.log(error);
                }, this);
            }
        };
        /**
         * Click on the button to edit selected dashboard entity.
         */
        Editor.prototype.editSelectedEntity = function (sender, e) {
            var entity = sender;
            if (!entity.viewsLoaded) {
                this._loadViews(entity);
            }
            if (!entity.chartsLoaded) {
                this._loadCharts(entity);
            }
            this.isEntityEdit(true);
            this.contextMenu.enabled(false);
            this.selectedEntity(entity);
            this.isDirty(true);
        };
        /**
         * Click to return button from lower part of dashboard editor.
         */
        Editor.prototype.returnBackToMainScreen = function (sender, e) {
            var entity = sender;
            if (this.isEntityEdit() && !this.m_newEntityAdded) {
                entity.additionalText(entity.updateAdditionalText());
                this.selectedEntities().splice(this.selectedEntities().indexOf(this.selectedEntity()), 1, entity);
            }
            else {
                entity.additionalText(entity.updateAdditionalText());
                this.selectedEntities.push(entity);
                this.isEntityListShow(false);
            }
            this.isEntityEdit(false);
            this.m_newEntityAdded = false;
            this.selectedEntity(undefined);
            this.contextMenu.enabled(false);
        };
        /**
         * Handle click to the remove button.
         */
        Editor.prototype.removeSelectedItem = function (sender, e) {
            this.contextMenu.enabled(false);
            var dashboardEntity = this.selectedEntity();
            this.selectedEntities.remove(dashboardEntity);
            this.selectedEntity(null);
            this.isDirty(true);
        };
        Editor.prototype._addSelectedEntity = function (selectedDashboardEntity) {
            this.isEntityEdit(true);
            this.m_newEntityAdded = true;
            var dashboardEntity = selectedDashboardEntity;
            dashboardEntity.search(true);
            dashboardEntity.createNewRecords(true);
            dashboardEntity.displayRecordsAsChart(true);
            dashboardEntity.displayRecordsAsMap(true);
            dashboardEntity.displayRecordsAsListView(true);
            dashboardEntity.initialViewTypeSelected(dashboardEntity.initialType[0]);
            this._loadViews(dashboardEntity);
            this._loadCharts(dashboardEntity);
            dashboardEntity.viewsLoaded = true;
            dashboardEntity.chartsLoaded = true;
            this.selectedEntity(dashboardEntity);
            this.isDirty(true);
        };
        Editor.prototype._initializeLabelsArray = function (count, defaultNames) {
            var labelsArray = new Array();
            for (var i = 0; i < count; i++) {
                labelsArray.push(ko.observable());
            }
            return labelsArray;
        };
        Editor.prototype._closeEditorWithoutSave = function () {
            MobileCRM.bridge.command("deserializeDashboardSettings", "", function (result) { }, function (error) { }, this);
        };
        return Editor;
    }());
    DashboardEditor.Editor = Editor;
    /**
     * ViewModel extents dashboardEntity class about some of visual components.
     */
    var DashboardEntityViewModel = (function (_super) {
        __extends(DashboardEntityViewModel, _super);
        function DashboardEntityViewModel(params) {
            var _this = _super.call(this) || this;
            _this.editorSizeMonitor = params.size;
            var dashboardEntity = params.dashboardEnity();
            _this.logicalName = dashboardEntity.logicalName;
            _this.displayName = dashboardEntity.displayName;
            _this.views = dashboardEntity.views;
            _this.charts = dashboardEntity.charts;
            _this.createNewRecords = dashboardEntity.createNewRecords;
            _this.search = dashboardEntity.search;
            _this.displayRecordsAsChart = dashboardEntity.displayRecordsAsChart;
            _this.displayRecordsAsListView = dashboardEntity.displayRecordsAsListView;
            _this.displayRecordsAsMap = dashboardEntity.displayRecordsAsMap;
            _this.allowedCharts = dashboardEntity.allowedCharts;
            _this.allowedViews = dashboardEntity.allowedViews;
            _this.viewsLoaded = dashboardEntity.viewsLoaded;
            _this.chartsLoaded = dashboardEntity.chartsLoaded;
            _this.initialType = dashboardEntity.initialType;
            _this.initialViewTypeSelected = dashboardEntity.initialViewTypeSelected;
            _this.initialView = dashboardEntity.initialView;
            _this.initialChart = dashboardEntity.initialChart;
            _this.selectedView = dashboardEntity.selectedView;
            _this.selectedChart = dashboardEntity.selectedChart;
            _this.localizedLabels = new Array();
            _this.localizedLabels = params.localizedLabels;
            _this._initBottomBarButton(params.localizedLabels, params.tabColors);
            _this.displayRecordsAsListView.subscribe(function (value) {
                _this.bottomBarButtons[1].enabled(value);
            });
            _this.displayRecordsAsChart.subscribe(function (value) {
                _this.bottomBarButtons[2].enabled(value);
            });
            _this.displayRecordsAsMap.subscribe(function (value) {
                _this.bottomBarButtons[3].enabled(value);
            });
            return _this;
        }
        /**
         * A public method handle click on the bottom bar. Last selected button deselects nad selects sender obj.
         * @param {any} sender bottomBarButton obj that was cliked.
         * @param {any} e event
         */
        DashboardEntityViewModel.prototype.bottomMenuBarClick = function (sender, e) {
            var bottomBarButton = sender;
            this._changeSelectedBottomBarButton(bottomBarButton);
        };
        /**
         * A public method that handle clicks on the different buttons in the template. By the command string detect on which button was clicked.
         * @param {string} command a string value that is unique value of html tag attribute and identify which button was clicked.
         * @param {any} sender sender object
         * @param {any} e JS event
         */
        DashboardEntityViewModel.prototype.changeOptionsButtonStatus = function (command, sender, e) {
            switch (command) {
                case "createNewRecors":
                    this.createNewRecords(!this.createNewRecords());
                    $(e.target).children().addClass("animation");
                    break;
                case "search":
                    this.search(!this.search());
                    $(e.target).children().addClass("animation");
                    break;
                case "listView":
                    this.displayRecordsAsListView(!this.displayRecordsAsListView());
                    $(e.target).children().addClass("animation");
                    break;
                case "map":
                    this.displayRecordsAsMap(!this.displayRecordsAsMap());
                    $(e.target).children().addClass("animation");
                    break;
                case "chart":
                    this.displayRecordsAsChart(!this.displayRecordsAsChart());
                    $(e.target).children().addClass("animation");
                    break;
            }
        };
        /**
         * This method change status of button where was clicked with help of the jquery add class.
         * @param {any} sender object that in usual case of ViewBase type.
         * @param {any} e JS event.
         */
        DashboardEntityViewModel.prototype.changeButtonStatus = function (sender, e) {
            var vb = sender;
            if (!vb.selected()) {
                $(e.target).children().addClass("animation");
                vb.enabled(!vb.enabled());
            }
        };
        /**
         * A private method that initialize bottom bar.
         */
        DashboardEntityViewModel.prototype._initBottomBarButton = function (localizedLabels, tabColors) {
            this.bottomBarButtons = new Array();
            var bottomBarButtonsDisplayNames = localizedLabels;
            var bottomBarButtonsLogicalNames = ["options", "listView", "chart", "map"];
            var bottomBarButtonsImagesNames = ["options", "view", "chart", "Map"];
            var bottomBarButtonsEnabled = [true, this.displayRecordsAsListView(), this.displayRecordsAsChart(), this.displayRecordsAsMap()];
            for (var i = 0; i < 4; i++) {
                var button = new BottomBarButton(bottomBarButtonsDisplayNames[i], bottomBarButtonsLogicalNames[i], bottomBarButtonsEnabled[i], false, bottomBarButtonsImagesNames[i], tabColors);
                this.bottomBarButtons.push(button);
            }
            this._changeSelectedBottomBarButton(this.bottomBarButtons[0]);
        };
        /**
         * A private method changes selection of the bottomBarButton
         */
        DashboardEntityViewModel.prototype._changeSelectedBottomBarButton = function (selectedButton) {
            for (var _i = 0, _a = this.bottomBarButtons; _i < _a.length; _i++) {
                var b = _a[_i];
                if (b === selectedButton) {
                    selectedButton.selected(true);
                }
                else {
                    b.selected(false);
                }
            }
        };
        return DashboardEntityViewModel;
    }(DashboardEntity));
    DashboardEditor.DashboardEntityViewModel = DashboardEntityViewModel;
    /**
     * ViewModel for bottom bar button shows during edit selected Entity
     */
    var BottomBarButton = (function () {
        function BottomBarButton(name, id, enabled, selected, imageName, colors) {
            var _this = this;
            this.displayName = name;
            this.logicalName = id;
            this.enabled = ko.observable(enabled);
            this.selected = ko.observable(null);
            this.base = ko.observable();
            this.imageName = imageName;
            this.colors = colors;
            this.selected.subscribe(function (value) {
                if (value)
                    _this._colorizeImage(colors[0]);
                else
                    _this._colorizeImage(colors[1]);
            });
        }
        BottomBarButton.prototype._colorizeImage = function (color) {
            var _this = this;
            var path = "img/" + this.imageName + ".png";
            var mask = document.createElement("img");
            mask.src = path;
            mask.onload = function () {
                var canvas = document.createElement("canvas");
                var canvascontext = canvas.getContext("2d");
                canvas.width = mask.width ? mask.width : 30;
                canvas.height = mask.height ? mask.height : 30;
                canvascontext.drawImage(mask, 0, 0, canvas.width, canvas.height);
                canvascontext.globalCompositeOperation = 'source-atop';
                canvascontext.fillStyle = color;
                canvascontext.fillRect(0, 0, canvas.width, canvas.height);
                _this.base("url('" + canvas.toDataURL() + "')");
            };
        };
        return BottomBarButton;
    }());
    /**
     * A public class that represents context menu with additional buttons menu.
     */
    var ContextMenu = (function () {
        function ContextMenu() {
            this.topPosition = ko.observable();
            this.leftPosition = ko.observable();
            this.labelMoveUp = ko.observable();
            this.labelMoveDown = ko.observable();
            this.labelDelete = ko.observable();
            this.enabled = ko.observable();
        }
        return ContextMenu;
    }());
})(DashboardEditor || (DashboardEditor = {}));
