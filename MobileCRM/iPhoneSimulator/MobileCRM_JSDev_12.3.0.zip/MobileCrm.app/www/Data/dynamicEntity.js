/// <reference path="../Controls/IView.ts" />
/// <reference path="metaEntity.ts" />
/// <reference path="metaData.ts" />
var MobileCrm;
(function (MobileCrm) {
    var Data;
    (function (Data) {
        var DynamicEntity = (function () {
            function DynamicEntity(entityName, repo) {
                this.m_entityName = entityName;
                this.m_data = [];
                this.repository = repo;
            }
            Object.defineProperty(DynamicEntity.prototype, "meta", {
                get: function () {
                    return Data.MetaData.instance.entities.getValue(this.m_entityName);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DynamicEntity.prototype, "id", {
                get: function () {
                    return this._getRowGuid();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DynamicEntity.prototype, "entityName", {
                get: function () {
                    return this.m_entityName;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DynamicEntity.prototype, "primaryKeyValue", {
                get: function () {
                    return this.id;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DynamicEntity.prototype, "primaryName", {
                get: function () {
                    if (this.meta && this.meta.primaryFieldName) {
                        var getResult = this.tryGetValue(this.meta.primaryFieldName);
                        if (getResult.result) {
                            return getResult.value;
                        }
                    }
                    return "";
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DynamicEntity.prototype, "isNew", {
                get: function () {
                    // TODO:
                    return false;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DynamicEntity.prototype, "repository", {
                get: function () {
                    return this.m_repository;
                },
                set: function (value) {
                    if (!this.m_repository) {
                        this.m_repository = value;
                        this.m_data = new Array(value.properties.length);
                    }
                },
                enumerable: true,
                configurable: true
            });
            DynamicEntity.prototype.getTextValue = function (binding, formatted) {
                if (formatted === void 0) { formatted = true; }
                var result = "";
                var index = Resco.strictParseInt(binding);
                if (isNaN(index)) {
                    if (binding == "PrimaryName") {
                        var metaEntity = MobileCrm.Data.MetaData.instance.tryGetEntity(this.m_entityName);
                        if (metaEntity) {
                            binding = metaEntity.primaryFieldName;
                        }
                    }
                    result = this.getDynamicPropertyOrOwn(binding, true);
                }
                if (!result) {
                    result = this.getPropertyValue(index, formatted);
                }
                return result ? result : ""; // do not return 'null' or 'undefined' if result === null or result === undefined (return "" instead)
            };
            DynamicEntity.prototype._getRowGuid = function () {
                if (this.meta) {
                    var r = this.tryGetValue(this.meta.primaryKeyName);
                    if (r.result) {
                        return r.value;
                    }
                }
                return "";
            };
            DynamicEntity.prototype.trySetValue = function (propertyName, value) {
                var index = this.tryGetPropertyIndex(propertyName);
                if (index >= 0) {
                    this.m_data[index] = value;
                    return true;
                }
                return false;
            };
            DynamicEntity.prototype.tryGetValue = function (propertyName) {
                var index = this.tryGetPropertyIndex(propertyName);
                if (index >= 0) {
                    return { result: true, value: this.getPropertyValue(index, false) };
                }
                return { result: false, value: null };
            };
            DynamicEntity.prototype.getImageValue = function (binding) {
                return { imageData: this.getTextValue(binding), placeHolder: "" };
            };
            DynamicEntity.prototype.getPropertyValue = function (index, formatted) {
                if (index >= DynamicEntity.formattedMagicStart) {
                    index -= DynamicEntity.formattedMagicStart;
                    formatted = true;
                }
                // TODO: CustomProperties
                var value;
                if (index >= this.m_data.length) {
                    //var ci = index - this.m_data.length;
                    //if (ci < this.m_customProperties.length) {
                    //	value = this.m_customProperties.getValue(ci);
                    //}
                    //else {
                    //throw new Resco.IndexOutOfRangeException("Invalid entity property index: " + index); // This case occurs when variables or shared variables are used on view template, since rules are not supported by this version yet.
                    //}
                }
                else {
                    value = this.m_data[index];
                    // TODO: Formatted List properties
                    //if (value !== null && value !== undefined && formatted) {
                    //	if (!this.m_formatedData) {
                    //		this.m_formatedData = new Array<any>(this.m_data.length);
                    //	}
                    //	var f = this.m_formatedData[index];
                    //	if (f === null || f === undefined) {
                    //		var desc = this.m_repository.properties[index];
                    //		var propMeta = desc.metaProperty;
                    //		var propType = propMeta.type;
                    //		if (propType == MobileCrm.Data.CrmType.Picklist || propType == MobileCrm.Data.CrmType.Status || propType == MobileCrm.Data.CrmType.State) {
                    //			value = this._getOptionLabel(propMeta, value, "");
                    //		}
                    //		else if (propType == MobileCrm.Data.CrmType.Boolean) {
                    //			value = this._getOptionLabel(propMeta, value ? 1 : 0, value ? "True" : "False");
                    //		}
                    //		else if (propType == MobileCrm.Data.CrmType.DateTime) {
                    //			// TODO: moment.js formatting
                    //			//value = $.datepicker.formatDate(propMeta.format == MobileCrm.Data.CrmDisplayFormat.DateOnly ? "D, M d. yy" : "D, M d. yy - HH:II:ss", value);
                    //		}
                    //		else if (propType == MobileCrm.Data.CrmType.Decimal || propType == MobileCrm.Data.CrmType.Float) {
                    //			value = Resco.formatString("{0:N" + propMeta.precision + "}", [value]);
                    //		}
                    //		else if (propType == MobileCrm.Data.CrmType.Money) {
                    //			// TODO: Format Currency
                    //			//var currency = this.tryGetValue("transactioncurrencyid");
                    //			//if (currency.result) {
                    //			//	value = CurrencyManager.format(currency.value, propMeta, value);
                    //			//}
                    //		}
                    //		this.m_formatedData[index] = value.toString();
                    //	}
                    //	value = this.m_formatedData[index];
                    //}
                }
                // TODO: value converter
                return value;
            };
            DynamicEntity.prototype.getDynamicPropertyOrOwn = function (propName, formatted) {
                var index = this.tryGetPropertyIndex(propName);
                if (index >= 0) {
                    return this.getPropertyValue(index, formatted);
                }
                return this[propName];
            };
            DynamicEntity.prototype.tryGetPropertyIndex = function (propertyName) {
                var index = this.m_repository.getPropertyIndex(propertyName);
                // TODO: CustomProperties
                //if (index < 0 && this.m_customProperties) {
                //	var fnres = this.m_customProperties.tryGetIndex(propertyName);
                //	if (fnres.result) {
                //		index = fnres.index + this.m_data.length;
                //	}
                //}
                return index;
            };
            DynamicEntity.prototype._getOptionLabel = function (propMeta, value, defaultText) {
                // TODO: Localize
                //return Localization.instance.getTextOrDefault(propMeta.entity.name + "." + propMeta.name + "." + value, defaultText);
                return defaultText;
            };
            DynamicEntity.as = function (obj) {
                if (obj instanceof DynamicEntity) {
                    return obj;
                }
                return null;
            };
            return DynamicEntity;
        }());
        DynamicEntity.formattedMagicStart = 1000;
        Data.DynamicEntity = DynamicEntity;
        var DynamicRepository = (function () {
            function DynamicRepository() {
                this.properties = [];
            }
            DynamicRepository.prototype.add = function (property) {
                this.properties.push(property);
            };
            DynamicRepository.prototype.getPropertyIndex = function (name) {
                for (var i = 0; i < this.properties.length; i++) {
                    if (this.properties[i].name === name) {
                        return i;
                    }
                }
                return -1;
            };
            return DynamicRepository;
        }());
        Data.DynamicRepository = DynamicRepository;
    })(Data = MobileCrm.Data || (MobileCrm.Data = {}));
})(MobileCrm || (MobileCrm = {}));
