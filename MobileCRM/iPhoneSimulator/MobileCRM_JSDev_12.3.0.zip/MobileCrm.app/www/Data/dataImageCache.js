/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="dynamicEntity.ts" />
var MobileCrm;
(function (MobileCrm) {
    var Data;
    (function (Data) {
        var DataImageCache = (function () {
            function DataImageCache() {
                this.m_cache = new Array();
            }
            Object.defineProperty(DataImageCache, "instance", {
                get: function () {
                    if (!DataImageCache.s_instance) {
                        DataImageCache.s_instance = new DataImageCache();
                    }
                    return DataImageCache.s_instance;
                },
                enumerable: true,
                configurable: true
            });
            DataImageCache.clear = function () {
                if (DataImageCache.s_instance) {
                    DataImageCache.s_instance._clearCache(0);
                }
            };
            //private _refresh(entity: IReference) {
            //    var entityId = entity.id;
            //    var items: Array<CacheItem> = null;
            //    for (var i = 0; i < this.m_cache.length; i++) {
            //        var item = this.m_cache[i];
            //        var itemEntityId = item.entityId;
            //        if (item.isLoaded && !item.canceled && itemEntityId == entityId) {
            //            this.m_cache.splice(i, 1);
            //            if (!items) {
            //                items = new Array<CacheItem>();
            //            }
            //            items.splice(0, 0, item);
            //            item.isLoaded = false;
            //            item.imageData = null;
            //            i--;
            //        }
            //    }
            //    if (items) {
            //        items.forEach((item) => {
            //            this._loadItem(item);
            //        }, this);
            //    } 
            //}
            DataImageCache.loadImage = function (entity, imageQuery, renderWidth, renderHeight, onLoaded, element) {
                if (entity) {
                    return DataImageCache.instance.loadImage(entity, imageQuery, renderWidth, renderHeight, onLoaded, element);
                }
                return null;
            };
            DataImageCache.prototype.loadImage = function (entity, imageQuery, renderWidth, renderHeight, onLoaded, element) {
                for (var i = 0; i < this.m_cache.length; i++) {
                    var item = this.m_cache[i];
                    var itemEntity = item.entity;
                    if (!itemEntity) {
                        DataImageCache._clearCacheItem(item);
                    }
                    else if (item.imageQuery == imageQuery && item.width == renderWidth && item.height == renderHeight && item.tryAddEntity(entity)) {
                        item.timeStamp = Date.now();
                        if (i > 0) {
                            var j = this._getItemInsertIndex(i);
                            if (j < i) {
                                this.m_cache.splice(i, 1);
                                this.m_cache.splice(j, 0, item);
                            }
                        }
                        if (item.imageData) {
                            return { data: item.imageData, isLocal: false };
                        }
                        else {
                            return { data: item.defaultImage, isLocal: true };
                        }
                    }
                }
                if (this.m_cache.length >= DataImageCache.MaxCacheSize) {
                    this._clearCache(DataImageCache.MaxCacheSize / 2);
                }
                var item = new CacheItem();
                item.imageQuery = imageQuery;
                item.width = renderWidth;
                item.height = renderHeight;
                item.loadComplete = onLoaded;
                item.element = element;
                item.tryAddEntity(entity);
                this._loadImage(item, entity);
                if (item.imageData) {
                    return { data: item.imageData, isLocal: false };
                }
                else {
                    return { data: item.defaultImage, isLocal: true };
                }
            };
            DataImageCache.prototype._clearCache = function (from) {
                for (var i = from; i < this.m_cache.length; i++) {
                    DataImageCache._clearCacheItem(this.m_cache[i]);
                }
            };
            DataImageCache._clearCacheItem = function (item) {
                item.canceled = true;
                item.imageData = null;
                item.clearEntity();
            };
            DataImageCache.prototype._parseImageQuery = function (query) {
                var parts = query.split("|");
                var defaultImage = "";
                if (parts.length > 1) {
                    defaultImage = parts[1];
                }
                return { imageQuery: parts[0], defaultImage: defaultImage };
            };
            DataImageCache.prototype._loadImage = function (item, entity) {
                var loader = null;
                var parsedQuery = this._parseImageQuery(item.imageQuery);
                var imageQuery = parsedQuery.imageQuery;
                var defaultImage = parsedQuery.defaultImage;
                if (imageQuery.indexOf(";") < 0) {
                    var imageProperty = imageQuery;
                    //if (entity.isOnline) {
                    var imageIndex = entity.tryGetPropertyIndex(imageProperty);
                    if (imageIndex >= 0) {
                        var data = entity.getPropertyValue(imageIndex, false);
                        item.imageData = data;
                        if (!item.imageData) {
                            item.isLoaded = true;
                        }
                    }
                    else {
                        return;
                    }
                    //}
                    imageQuery = entity.entityName + ";" + imageProperty + ";" + entity.meta.primaryKeyName + ";{id}";
                }
                item.loader = DataImageCache.getImageLoader ? DataImageCache.getImageLoader(imageQuery) : null; // new OnlineImageLoader(imageQuery);
                item.defaultImage = defaultImage;
                this._loadItem(item);
            };
            DataImageCache.prototype._getItemInsertIndex = function (max) {
                var j = 0;
                var now = Date.now();
                for (j = 0; j < max; j++) {
                    if ((now - this.m_cache[j].timeStamp) > 1000) {
                        break;
                    }
                }
                return j;
            };
            DataImageCache.prototype._loadItem = function (item) {
                item.timeStamp = Date.now();
                var index = this._getItemInsertIndex(this.m_cache.length);
                this.m_cache.splice(index, 0, item);
                if (!item.isLoaded && !item.canceled && item.loader) {
                    item.loader.load(item.entity, function (data) {
                        item.imageData = "data:image/png;base64," + data; // TODO: handle better
                        if (item.loadComplete) {
                            item.loadComplete(item.imageData);
                        }
                        if (item.element) {
                            $(item.element).attr("src", item.imageData);
                        }
                    });
                }
            };
            return DataImageCache;
        }());
        DataImageCache.MaxCacheSize = 100;
        Data.DataImageCache = DataImageCache;
        var CacheItem = (function () {
            function CacheItem() {
            }
            Object.defineProperty(CacheItem.prototype, "entity", {
                get: function () {
                    return this.m_entity;
                },
                enumerable: true,
                configurable: true
            });
            CacheItem.prototype.tryAddEntity = function (value) {
                if (this.entityId && this.entityId != Data.GuidEmpty && value.id != this.entityId) {
                    return false;
                }
                this.m_entity = value;
                this.entityId = value.id;
                return true;
            };
            //public tryNotify() {
            //    if (this.m_entity) {
            //        this.m_entity.onPropertyChanged("Item[]");
            //        return true;
            //    }
            //    return false;
            //}
            CacheItem.prototype.clearEntity = function () {
                this.m_entity = null;
                this.entityId = Data.GuidEmpty;
            };
            return CacheItem;
        }());
        Data.CacheItem = CacheItem;
        Data.GuidEmpty = "00000000-0000-0000-0000-000000000000";
        // export class OnlineImageLoader implements Online.IOnlineRequest {
        //     public inProgress: boolean;
        //     public cancel: boolean;
        //     public exception: any;
        //     public pleaseWaitText: string;
        //     public delay: number;
        //     private m_onLoaded: (data: string) => void;
        //     private m_imageQuery: string[];
        //     private m_imageProperty: string;
        //     private m_fetch: Fetch.Fetch;
        //     constructor(imageQuery: string) {
        //         this.m_imageQuery = imageQuery.split(";");
        //         this.m_imageProperty = this.m_imageQuery[1];
        //         this.m_fetch = new Fetch.Fetch(null, this.m_imageQuery[0]);
        //         this.m_fetch.entity.addAttribute(this.m_imageProperty, false);
        //     }
        //     public load(entity: DynamicEntity, onLoaded: (data: string) => void) {
        //         this.m_onLoaded = onLoaded;
        //         this.m_fetch.entity.filter.clear();
        //         for (var i = 2; i < this.m_imageQuery.length - 1; i += 2) {
        //             var valueName = this.m_imageQuery[i + 1];
        //             if (valueName.startsWith("{")) {
        //                 var r = OnlineImageLoader._tryGetEntityValue(entity, valueName);
        //                 if (r.result) {
        //                     this.m_fetch.entity.filter.where(this.m_imageQuery[i], r.value);
        //                 }
        //             }
        //             else {
        //                 this.m_fetch.entity.filter.where(this.m_imageQuery[i], valueName);
        //             }
        //         }
        //         Online.OnlineRepository.addRequest(this);
        //     }
        //     public completed() {
        //         // do nothing
        //     }
        //     public async execute(service: WebService.ICrmService, onFinished?: (req: Online.IOnlineRequest) => void) {
        //var result = await service.executeFetch(this.m_fetch);
        //         if (result.length > 0) {
        //             this.m_onLoaded(result[0][this.m_imageProperty]);
        //         }
        //     }
        //     public dispose() {
        //         // do nothing
        //     }
        //     static _tryGetEntityValue(entity: DynamicEntity, valueName: string) {
        //         if (valueName == "{id}") {
        //             return { result: true, value: entity.primaryKeyValue };
        //         }
        //         else if (valueName.startsWith("{")) {
        //             var result = entity.tryGetValue(valueName.substring(1, valueName.length - 2));
        //             if (result.result) {
        //                 var value = result.value;
        //                 if (isReference(value)) {
        //                     value = (<IReference>value).id;
        //                 }
        //                 return { result: true, value: value };
        //             }
        //         }
        //         return { result: false, value: null };
        //     }
        // }
    })(Data = MobileCrm.Data || (MobileCrm.Data = {}));
})(MobileCrm || (MobileCrm = {}));
