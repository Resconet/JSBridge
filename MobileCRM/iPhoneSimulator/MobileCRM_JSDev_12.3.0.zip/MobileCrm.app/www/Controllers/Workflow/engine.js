/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../../Helpers/common.ts" />
/// <reference path="../../Data/metaEntity.ts" />
/// <reference path="executionContext.ts" />
/// <reference path="externalActions.ts" />
/// <reference path="sharedVariables.ts" />
/// <reference path="workflow.ts" />
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var Engine = (function () {
                function Engine() {
                }
                Engine.execute = function (workflow, entityName, variables, externalActions) {
                    var result = { result: false, workflow: null };
                    var r = Engine.setup(workflow, entityName, variables, externalActions);
                    if (r.context) {
                        result.result = r.context.execute();
                        result.workflow = r.workflow;
                    }
                    return result; // result contains resutl of workflow execution + compiled workflow
                };
                Engine.setup = function (workflow, entityName, variables, externalActions, onCompleted, onCompeltedSource) {
                    var result = { context: null, workflow: null };
                    try {
                        result.workflow = Engine._parseWorkflow(workflow);
                        if (result.workflow) {
                            result.context = new Workflow.ExecutionContext(entityName);
                            result.context.setInputVariables(variables);
                            result.context.externalActions = externalActions;
                            result.context.program = result.workflow.program;
                            result.context.completedCallback = onCompleted;
                            result.context.completedCallbackSource = onCompeltedSource;
                        }
                    }
                    catch (ex) {
                        Engine.log(ex, "SetupError", null);
                    }
                    return result;
                };
                Engine.parseSharedVariables = function (sharedVariables) {
                    if (sharedVariables) {
                        var sv = new Workflow.SharedVariables();
                        sv.variables = new Array();
                        var parsed = $.parseXML(sharedVariables);
                        var parsedVars = $("SharedVariable", parsed);
                        parsedVars.each(function (index, elem) {
                            var v = new Workflow.SharedVariable();
                            v.name = $("Name", elem).text();
                            var strCrmType = $("CrmType", elem).text();
                            switch (strCrmType) {
                                case "String":
                                    v.crmType = MobileCrm.Data.CrmType.String;
                                    break;
                                case "Boolean":
                                    v.crmType = MobileCrm.Data.CrmType.Boolean;
                                    break;
                                case "Integer":
                                    v.crmType = MobileCrm.Data.CrmType.Integer;
                                    break;
                                case "Decimal":
                                    v.crmType = MobileCrm.Data.CrmType.Decimal;
                                    break;
                                case "DateTime":
                                    v.crmType = MobileCrm.Data.CrmType.DateTime;
                                    break;
                                case "Entity":
                                    v.crmType = MobileCrm.Data.CrmType.Entity;
                                    v.innerType = $("InnerType", elem).text();
                                    break;
                                case "Lookup":
                                    v.crmType = MobileCrm.Data.CrmType.Lookup;
                                    break;
                                case "StringList":
                                    v.crmType = MobileCrm.Data.CrmType.StringList;
                                    break;
                            }
                            sv.variables.push(v);
                        });
                    }
                    return sv;
                };
                Engine._parseWorkflow = function (workflow) {
                    var w = Workflow.Workflow.as(workflow);
                    if (!w) {
                        var xmlText = workflow.replace(/\\n/g, "\n");
                        w = Workflow.Workflow.deserializeXML($("Workflow", $.parseXML(xmlText)));
                        if (w.version > 1) {
                            Engine.log(null, "VersionError: " + w.version, null);
                            return null;
                        }
                        else {
                            w.decode();
                        }
                    }
                    return w;
                };
                Engine.log = function (ex, msg, context) {
                    var result;
                    result = this._getFormatedDateTime(new Date()) + ": " + msg + "\r\n--------------------------------------";
                    if (context) {
                        result += "\r\nLine " + context.instructionPointer + ": " + context.callStack.map(function (s) { return s.fullName; }).join("\n") + "\r\n--------------------------------------";
                    }
                    if (ex) {
                        result += "\r\n" + ex.message;
                    }
                    result += "\r\n";
                    if (context) {
                        context.messageLog += result;
                    }
                    console.log(result);
                };
                Engine._getFormatedDateTime = function (date) {
                    return date.getFullYear() + "-" + this._to2Digits(date.getMonth()) + "-" + this._to2Digits(date.getDate()) + " " + this._to2Digits(date.getHours()) + ":" + this._to2Digits(date.getMinutes()) + ":" + this._to2Digits(date.getSeconds());
                };
                Engine._to2Digits = function (value) {
                    var s = value.toString();
                    if (s.length === 1) {
                        s = "0" + s;
                    }
                    return s;
                };
                return Engine;
            }());
            Workflow.Engine = Engine;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
