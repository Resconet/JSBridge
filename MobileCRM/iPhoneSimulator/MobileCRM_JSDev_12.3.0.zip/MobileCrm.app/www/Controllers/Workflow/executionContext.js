/// <reference path="../../Data/metaEntity.ts" />
/// <reference path="step.ts" />
/// <reference path="engine.ts" />
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var ExecutionContext = (function () {
                function ExecutionContext(entityName) {
                    this.callStack = new Array();
                    this.entityName = entityName;
                    this.tempVariable = new Resco.Dictionary();
                    this.instructionPointer = 0;
                }
                ExecutionContext.prototype.addTempVariable = function (name, variable) {
                    this.tempVariable.set(name, variable);
                };
                ExecutionContext.prototype.setInputVariables = function (inputVariables) {
                    this.m_variable = inputVariables;
                };
                Object.defineProperty(ExecutionContext.prototype, "isComplete", {
                    get: function () {
                        return this.instructionPointer >= this.program.length;
                    },
                    enumerable: true,
                    configurable: true
                });
                ExecutionContext.prototype.execute = function () {
                    var result = true;
                    try {
                        while (this.instructionPointer < this.program.length) {
                            var instr = this.program[this.instructionPointer++];
                            var ret = instr.execute(this);
                            if (ret === ExecutionContext.asyncResult) {
                                this.isAsync = true;
                                return null;
                            }
                        }
                    }
                    catch (ex) {
                        result = false;
                        Workflow.Engine.log(ex, "ExecutionError", this);
                    }
                    if (this.completedCallback) {
                        this.completedCallback.call(this.completedCallbackSource ? this.completedCallbackSource : this, this, result);
                    }
                    return result;
                };
                ExecutionContext.prototype.getVariable = function (path) {
                    var r = this._findVariable(path);
                    return r.variable.getValue(r.s);
                };
                ExecutionContext.prototype.setVariable = function (path, value) {
                    var r = this._findVariable(path);
                    return r.variable.setValue(r.s, value);
                };
                ExecutionContext.prototype.getVariableType = function (path) {
                    var r = this._findVariable(path);
                    return r.variable.getValueType(r.s);
                };
                ExecutionContext.prototype.getOriginalVariable = function (path) {
                    var result = this._findVariable(path);
                    return result.variable;
                };
                ExecutionContext.prototype._findVariable = function (path) {
                    var result = { s: null, variable: null };
                    if (!path) {
                        throw new Resco.Exception("Invalid variable path.");
                    }
                    result.s = ExecutionContext._splitVariable(path);
                    var name = result.s[0];
                    var v;
                    if (this.m_variable.containsKey(name)) {
                        v = this.m_variable.getValue(name);
                    }
                    else if (this.tempVariable.containsKey(name)) {
                        v = this.tempVariable.getValue(name);
                    }
                    else {
                        throw new Resco.Exception("Variable not found '" + path + "'");
                    }
                    if (!v) {
                        throw new Resco.Exception("Variable '" + name + "' is null, when referencing path '" + path + "'");
                    }
                    result.variable = v;
                    return result;
                };
                ExecutionContext._splitVariable = function (path) {
                    var pp = new Array();
                    var propBuffer = "";
                    var l = 0;
                    for (var i = 0; i < path.length; i++) {
                        var c = path[i];
                        if (c == '(' && propBuffer.length == 0) {
                            l++;
                            continue;
                        }
                        else if (l > 0 && c == ')') {
                            l--;
                            continue;
                        }
                        if (l === 0 && c == '.') {
                            pp.push(propBuffer);
                            propBuffer = "";
                        }
                        else {
                            propBuffer += c;
                        }
                    }
                    if (propBuffer.length > 0) {
                        pp.push(propBuffer);
                    }
                    return pp;
                };
                ExecutionContext.as = function (obj) {
                    if (obj instanceof ExecutionContext)
                        return obj;
                    return null;
                };
                return ExecutionContext;
            }());
            ExecutionContext.asyncResult = new Object();
            Workflow.ExecutionContext = ExecutionContext;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
