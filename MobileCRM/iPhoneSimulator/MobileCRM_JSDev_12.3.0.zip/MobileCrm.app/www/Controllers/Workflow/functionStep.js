/// <reference path="../../TypeScriptDefinitions/decimaljs.d.ts" />
/// <reference path="expressionStep.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var FunctionStep = (function (_super) {
                __extends(FunctionStep, _super);
                function FunctionStep() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                FunctionStep.prototype._getName = function () {
                    return "FunctionStep";
                };
                FunctionStep.prototype.execute = function (context) {
                    context.callStack.push(this);
                    var varType;
                    var functionName = this.serializedFunction;
                    var date;
                    switch (functionName) {
                        case Function.Assign:
                            var argValue = null;
                            varType = this.getVariableType(context);
                            if (varType == MobileCrm.Data.CrmType.Entity) {
                                return this._loadReference(context, false);
                            }
                            if (varType == MobileCrm.Data.CrmType.String || varType == MobileCrm.Data.CrmType.Memo) {
                                argValue = this.getArgumentValueAsText(context, 0);
                            }
                            else {
                                argValue = this.getArgumentValue(context, 0);
                            }
                            if ((varType == MobileCrm.Data.CrmType.Integer || varType == MobileCrm.Data.CrmType.Decimal || varType == MobileCrm.Data.CrmType.Float || varType == MobileCrm.Data.CrmType.Money) && argValue !== null) {
                                argValue = this._castResult(argValue, this.getVariableType(context));
                            }
                            context.setVariable(this.serializedVariable, argValue);
                            break;
                        case Function.Convert:
                            var result = this._conversion(this.getVariableType(context), this.getArgumentValue(context, 0));
                            context.setVariable(this.serializedVariable, result);
                            break;
                        case Function.Clear:
                            varType = this.getVariableType(context);
                            if (varType == MobileCrm.Data.CrmType.PartyList) {
                                var clearedVariable = this.getVariableValue(context);
                                clearedVariable.splice(0);
                            }
                            else if (varType == MobileCrm.Data.CrmType.Entity) {
                            }
                            else {
                                context.setVariable(this.serializedVariable, null);
                            }
                            break;
                        case Function.AddPrefix:
                            this._append(context, true);
                            break;
                        case Function.AddSufix:
                            this._append(context, false);
                            break;
                        case Function.Concat:
                            this._concat(context, 2);
                            break;
                        case Function.Concat3:
                            this._concat(context, 3);
                            break;
                        case Function.Addition:
                        case Function.Difference:
                        case Function.Multiplication:
                        case Function.Division:
                            this._mathFunction(context, functionName);
                            break;
                        case Function.GetUnixTime:
                            date = new Date(this.getArgumentValue(context, 0));
                            context.setVariable(this.serializedVariable, Math.floor(date.valueOf() / 1000));
                            break;
                        case Function.SetNow:
                            context.setVariable(this.serializedVariable, new Date());
                            break;
                        case Function.SetToday:
                            date = new Date();
                            context.setVariable(this.serializedVariable, new Date(date.getFullYear(), date.getMonth(), date.getDate()));
                            break;
                        case Function.SetTomorrow:
                            date = new Date();
                            context.setVariable(this.serializedVariable, new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1));
                            break;
                        case Function.AddMinutes:
                        case Function.AddHours:
                        case Function.AddDays:
                        case Function.AddWeeks:
                        case Function.AddMonths:
                        case Function.AddYears:
                            this._dateTimeFunction(context, functionName);
                            break;
                        case Function.TimeDifference:
                            this._calculateTimeDifference(context);
                            break;
                        case Function.Negate:
                            var argBoolValue = this.getArgumentValue(context, 0);
                            context.setVariable(this.serializedVariable, argBoolValue === true ? false : true);
                            break;
                        case Function.AddParty:
                            this._addParty(context);
                            break;
                        case Function.RemoveParty:
                            this._removeParty(context);
                            break;
                        case Function.AddItem:
                            this._addItem(context, false);
                            break;
                        case Function.InsertItem:
                            this._addItem(context, true);
                            break;
                        case Function.RemoveItem:
                            this._removeItem(context);
                            break;
                        case Function.ClearItems:
                            this._clearItems(context);
                            break;
                        case Function.IncludeFilter:
                            context.setVariable(this.serializedVariable, this.getArgumentValue(context, 0));
                            break;
                        case Function.Format:
                            this._format(context);
                            break;
                        case Function.FormatSpecial:
                            this._formatSpecial(context);
                            break;
                        case Function.IndexOf:
                            this._patternIndexOf(context);
                            break;
                        case Function.SubString:
                            this._subString(context);
                            break;
                        case Function.LoadReference:
                            return this._loadReference(context, true);
                        case Function.NewInstance:
                        case Function.AssignNew:
                        case Function.LoadFetch:
                            // TODO: Workflow
                            /*var newEntityName: string;
                            var vp = this.serializedVariable;
                            if (functionName != Function.AssignNew) {
                                newEntityName = this.getArgumentValue(context, 0);
                                this._addTempEntityVariable(context, newEntityName);
                                vp += ".@this";
                            }
                            else {
                                newEntityName = this._getEntityName(context);
                            }
                            var newRepo = Data.DynamicRepository.getInstance(newEntityName, null);
        
                            if (this.serializedArguments.length > 1) {
                                var fetchText = this.getArgumentValue(context, 1);
                                var fetchXml = Data.Fetch.Fetch.deserializeXML(fetchText);
                                fetchXml.entity.attributes = newRepo.fetch.entity.attributes;
                                fetchXml.entity.applyMacros(null, context.getVariable);
                                var ea = context.externalActions;
                                var req = newRepo.loadSingle((entity, ex) => {
                                    if (ex) {
                                        ea.sayError(ex);
                                    }
                                    context.setVariable(vp, entity);
                                    context.execute();
                                });
                                context.callStack.pop();
                                return ExecutionContext.asyncResult;
                            }
                            else {
                                var newEntity = newRepo.createNewInstance();
                                context.setVariable(vp, newEntity);
                            }*/
                            break;
                        case Function.LengthOf:
                            var len = 0;
                            var arg = this.getArgumentValue(context, 0);
                            var strList = void 0;
                            if (Object.prototype.toString.call(arg) === '[object Array]') {
                                if (arg.every(function (item) { return typeof item === "string"; }))
                                    strList = arg;
                            }
                            if (strList) {
                                len = strList.length;
                            }
                            else {
                                var z = this.getArgumentValueAsText(context, 0);
                                len = z ? z.length : 0;
                            }
                            varType = this.getVariableValue(context);
                            context.setVariable(this.serializedVariable, this._castResult(len, varType));
                            break;
                        case Function.ElementAt: {
                            var listElement = null;
                            var listIndex = this.getArgumentValue(context, 1);
                            var listObject = this.getArgumentValue(context, 0);
                            if (Object.prototype.toString.call(listObject) === '[object Array]')
                                listElement = (listIndex >= 0 && listIndex < listObject.length) ? listObject[listIndex] : null;
                            context.setVariable(this.serializedVariable, listElement);
                            break;
                        }
                    }
                    context.callStack.pop();
                    return null;
                };
                FunctionStep.prototype._loadReference = function (context, bGetFromArgument) {
                    // TODO: Workflow
                    /*var variablePath = this.serializedVariable;
                    var entityName: string;
        
                    if (bGetFromArgument) {
                        entityName = this.getArgumentValue(context, 1);
                        this._addTempEntityVariable(context, entityName);
                        variablePath += ".@this";
        
                    }
                    else {
                        entityName = this._getEntityName(context);
                    }
                    var lookup = <Data.IReference>this.getArgumentValue(context, 0);
        
                    if (!lookup || lookup.entityName != entityName) {
                        // Trying to load an entity of different type (e.g. loading appointment.regarding as contact when it is in fact an account.)
                        context.setVariable(variablePath, null);
                    }
                    else {
                        var ea = context.externalActions;
                        var repo = Data.DynamicRepository.getInstance(entityName, null);
                        var copy = repo.tryCopy(lookup);
                        if (copy) {
                            // The lookup is in fact a full entity so just make a copy.
                            context.setVariable(variablePath, copy);
                        }
                        else {
                            // We need to load. In the online case we need to return Async.
                            repo.loadInstanceById(lookup.id,(entity, ex) => {
                                if (ex) {
                                    ea.sayError(ex);
                                }
        
                                context.setVariable(variablePath, entity);
                                context.execute();
                            });
                            context.callStack.pop();
                            return ExecutionContext.asyncResult;
                        }
                    }*/
                };
                FunctionStep.prototype._getEntityName = function (context) {
                    return context.getVariable(this.serializedVariable.replace(/.@this/g, ".EntityName"));
                };
                // TODO: Workflow
                //private _addTempEntityVariable(context: ExecutionContext, entityName: string): void {
                //    var repo = Data.DynamicRepository.getInstance(entityName, null);
                //    var ev = new EntityVariable(null);
                //    ev.entityName = entityName;
                //    context.addTempVariable(this.serializedVariable, ev); 
                //}
                FunctionStep.prototype._addParty = function (context) {
                    // TODO: Workflow
                    /*var partyList = <Data.IReference[]>this.getVariableValue(context);
        
                    var ref = this._getReferenceFromArgument(this.getArgumentValue(context, 0));
                    for (var i = 0; i < partyList.length; i++) {
                        if (partyList[i].equals(ref)) {
                            return;
                        }
                    }
                    partyList.push(ref);
                    context.setVariable(this.serializedVariable, partyList);*/
                };
                FunctionStep.prototype._removeParty = function (context) {
                    // TODO: Workflow
                    /*var partyList = <Data.IReference[]>this.getVariableValue(context);
        
                    var ref = this._getReferenceFromArgument(this.getArgumentValue(context, 0));
                    for (var i = 0; i < partyList.length; i++) {
                        if (partyList[i].equals(ref)) {
                            partyList.splice(i, 1);
                            context.setVariable(this.serializedVariable, partyList);
                            return;
                        }
                    }*/
                };
                // TODO: Workflow
                FunctionStep.prototype._getReferenceFromArgument = function (arg) {
                    /*var ref = Data.Reference.as(arg);
                    if (!ref) {
                        var entity = <EntityVariable>arg;
                        ref = new Data.Reference(entity.primaryKey, entity.entityName, entity.primaryName);
                    }
                    return ref;*/
                };
                FunctionStep.prototype._addItem = function (context, isIndexSet) {
                    var listVar = this.getVariableValue(context);
                    var argValue = this.getArgumentValueAsText(context, 0);
                    var index = listVar.length;
                    if (isIndexSet) {
                        index = this.getArgumentValue(context, 1);
                        if (!isNaN(index)) {
                            if (index > listVar.length) {
                                index = listVar.length;
                            }
                            else if (index < 0) {
                                index = 0;
                            }
                        }
                        else {
                            index = listVar.length;
                        }
                    }
                    listVar.splice(index, 0, argValue ? argValue : "");
                    context.setVariable(this.serializedVariable, listVar);
                };
                FunctionStep.prototype._removeItem = function (context) {
                    var listVar = this.getVariableValue(context);
                    var index = this.getArgumentValue(context, 0);
                    if (!isNaN(index) && index >= 0 && index < listVar.length) {
                        listVar.splice(index, 1);
                        context.setVariable(this.serializedVariable, listVar);
                    }
                };
                FunctionStep.prototype._clearItems = function (context) {
                    var listVar = this.getVariableValue(context);
                    listVar.splice(0);
                    context.setVariable(this.serializedVariable, listVar);
                };
                FunctionStep.prototype._format = function (context) {
                    var format = this.getArgumentValue(context, 0);
                    var list = this.getArgumentValue(context, 1);
                    var result = Resco.formatString(format, list);
                    context.setVariable(this.serializedVariable, result);
                };
                FunctionStep.prototype._formatSpecial = function (context) {
                    // TODO:
                };
                FunctionStep.prototype._patternIndexOf = function (context) {
                    var source = this.getArgumentValueAsText(context, 0);
                    var pattern = this.getArgumentValueAsText(context, 1);
                    var caseSensitive = this.getArgumentValue(context, 2);
                    var result = -1;
                    if (source) {
                        result = source.indexOf(pattern); // TODO: check and handle case sensitivity
                    }
                    context.setVariable(this.serializedVariable, result);
                };
                FunctionStep.prototype._subString = function (context) {
                    var source = this.getArgumentValueAsText(context, 0);
                    var fromIndex = this.getArgumentValue(context, 1);
                    var length = this.getArgumentValue(context, 2);
                    var result = null;
                    if (source && fromIndex >= 0) {
                        var max = source.length - fromIndex;
                        if (length < 0 || length > max) {
                            length = max;
                        }
                        result = source.substr(fromIndex, length);
                    }
                    context.setVariable(this.serializedVariable, result);
                };
                FunctionStep.getLocalizedText = function (text) {
                    // TODO: Localization
                    /*var localized: string;
                    if (text && text[0] == '@' && Localization.instance.stringTable.containsKey(text.substr(1))) {
                        return Localization.instance.get(text.substr(1));
                    }*/
                    return text;
                };
                FunctionStep.prototype._dateTimeFunction = function (context, func) {
                    var result = 0;
                    var argValue1 = this.getArgumentValue(context, 0);
                    var argValue2 = this.getArgumentValue(context, 1);
                    var part;
                    var date = new Date(argValue1);
                    var addedDate;
                    switch (func) {
                        case Function.AddMinutes:
                            addedDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes() + argValue2, date.getSeconds(), date.getMilliseconds());
                            break;
                        case Function.AddHours:
                            addedDate = new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours() + argValue2, date.getMinutes(), date.getSeconds(), date.getMilliseconds());
                            break;
                        case Function.AddDays:
                            addedDate = new Date(date.getFullYear(), date.getMonth(), date.getDate() + argValue2, date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
                            break;
                        case Function.AddWeeks:
                            addedDate = new Date(date.getFullYear(), date.getMonth(), date.getDate() + (argValue2 * 7), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
                            break;
                        case Function.AddMonths:
                            addedDate = new Date(date.getFullYear(), date.getMonth() + argValue2, date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
                            break;
                        case Function.AddYears:
                            addedDate = new Date(date.getFullYear() + argValue2, date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds(), date.getMilliseconds());
                            break;
                    }
                    context.setVariable(this.serializedVariable, addedDate);
                };
                FunctionStep.prototype._calculateTimeDifference = function (context) {
                    var varType = context.getVariableType(this.serializedVariable);
                    var date1 = this.getArgumentValue(context, 0);
                    var date2 = this.getArgumentValue(context, 1);
                    var seconds = (date2.valueOf() - date1.valueOf()) / 1000;
                    var units = this.getArgumentValue(context, 2); //0 - minutes, 1 - hours, 2 - days
                    switch (units) {
                        case "m":
                        case "minutes":
                        case "0": {
                            var val = seconds / 60;
                            if (varType == MobileCrm.Data.CrmType.Integer || varType == MobileCrm.Data.CrmType.String) {
                                context.setVariable(this.serializedVariable, Math.floor(val));
                            }
                            else {
                                context.setVariable(this.serializedVariable, val);
                            }
                            break;
                        }
                        case "h":
                        case "hours":
                        case "1": {
                            var val = seconds / 3600;
                            if (varType == MobileCrm.Data.CrmType.Integer || varType == MobileCrm.Data.CrmType.String) {
                                context.setVariable(this.serializedVariable, Math.floor(val));
                            }
                            else {
                                context.setVariable(this.serializedVariable, val);
                            }
                            break;
                        }
                        case "d":
                        case "days":
                        case "2": {
                            var val = seconds / 86400;
                            if (varType == MobileCrm.Data.CrmType.Integer || varType == MobileCrm.Data.CrmType.String) {
                                context.setVariable(this.serializedVariable, Math.floor(val));
                            }
                            else {
                                context.setVariable(this.serializedVariable, val);
                            }
                            break;
                        }
                    }
                };
                FunctionStep.prototype._mathFunction = function (context, func) {
                    var result = new Decimal(0);
                    var value1 = this.getArgumentValue(context, 0);
                    var argValue1 = new Decimal(value1 ? value1 : 0); // treat null or undefined as 0 (as implemented in mobile app)
                    var value2 = this.getArgumentValue(context, 1);
                    var argValue2 = new Decimal(value2 ? value2 : 0); // treat null or undefined as 0 (as implemented in mobile app)
                    switch (func) {
                        case Function.Addition:
                            result = argValue1.plus(argValue2);
                            break;
                        case Function.Difference:
                            result = argValue1.minus(argValue2);
                            break;
                        case Function.Multiplication:
                            result = argValue1.times(argValue2);
                            break;
                        case Function.Division:
                            result = argValue1.div(argValue2);
                            break;
                    }
                    context.setVariable(this.serializedVariable, result.toNumber());
                };
                FunctionStep.prototype._castResult = function (value, varType) {
                    if (varType == MobileCrm.Data.CrmType.Decimal || varType == MobileCrm.Data.CrmType.Money || varType == MobileCrm.Data.CrmType.Float) {
                        return Resco.strictParseFloat(value);
                    }
                    return Resco.strictParseInt(value);
                };
                FunctionStep.prototype._append = function (context, toStart) {
                    var varValue = this.getVariableValue(context);
                    var argValue = this.getArgumentValueAsText(context, 0);
                    var result = toStart ? argValue + varValue : varValue + argValue;
                    context.setVariable(this.serializedVariable, result);
                };
                FunctionStep.prototype._concat = function (context, argCount) {
                    var argValue1 = this.getArgumentValueAsText(context, 0);
                    var argValue2 = this.getArgumentValueAsText(context, 1);
                    var argValue3 = argCount == 3 ? this.getArgumentValueAsText(context, 2) : "";
                    var result = argValue1 + argValue2 + argValue3;
                    context.setVariable(this.serializedVariable, result);
                };
                FunctionStep.prototype._conversion = function (varType, argValue) {
                    var result = null;
                    switch (varType) {
                        case MobileCrm.Data.CrmType.Boolean:
                            if (argValue === "1" || argValue === "true" || argValue == "True") {
                                result = true;
                            }
                            else {
                                result = false;
                            }
                            break;
                    }
                    return result;
                };
                FunctionStep.deserializeXML = function ($step) {
                    var s = new FunctionStep();
                    s._deserializeXML($step);
                    return s;
                };
                FunctionStep.prototype._deserializeXML = function ($step) {
                    this.serializedFunction = Function[$step.children("func")[0].textContent];
                    _super.prototype._deserializeXML.call(this, $step);
                };
                return FunctionStep;
            }(Workflow.ExpressionStep));
            Workflow.FunctionStep = FunctionStep;
            var Function;
            (function (Function) {
                // Default functions for every type
                /// <remarks />
                Function[Function["Assign"] = 0] = "Assign";
                /// <remarks />
                Function[Function["Convert"] = 1] = "Convert";
                /// <remarks />
                Function[Function["SetDefualtValue"] = 2] = "SetDefualtValue";
                /// <remarks />
                Function[Function["Clear"] = 3] = "Clear";
                /// <remarks />
                Function[Function["AddPrefix"] = 4] = "AddPrefix";
                /// <remarks />
                Function[Function["AddSufix"] = 5] = "AddSufix";
                /// <remarks />
                Function[Function["Concat"] = 6] = "Concat";
                /// <remarks />
                Function[Function["Concat3"] = 7] = "Concat3";
                /// <remarks />
                Function[Function["Format"] = 8] = "Format";
                //---------- Number Functions
                /// <remarks>Calculates a sum of two Arguments</remarks>
                Function[Function["Addition"] = 9] = "Addition";
                /// <remarks>Calculates a difference of two Arguments, (firstArg - secondArg)</remarks>
                Function[Function["Difference"] = 10] = "Difference";
                /// <remarks>Calculates a product of division of two Arguments, (firstArg / secondArg)</remarks>
                Function[Function["Division"] = 11] = "Division";
                /// <remarks>Calculates a product of multiplication of two Arguments</remarks>
                Function[Function["Multiplication"] = 12] = "Multiplication";
                // --------- Date Functions
                /// <remarks />
                Function[Function["SetNow"] = 13] = "SetNow";
                /// <remarks />
                Function[Function["SetToday"] = 14] = "SetToday";
                /// <remarks />
                Function[Function["SetTomorrow"] = 15] = "SetTomorrow";
                /// <remarks />
                Function[Function["AddMinutes"] = 16] = "AddMinutes";
                /// <remarks />
                Function[Function["AddHours"] = 17] = "AddHours";
                /// <remarks />
                Function[Function["AddDays"] = 18] = "AddDays";
                /// <remarks />
                Function[Function["AddWeeks"] = 19] = "AddWeeks";
                /// <remarks />
                Function[Function["AddMonths"] = 20] = "AddMonths";
                /// <remarks />
                Function[Function["AddYears"] = 21] = "AddYears";
                ///<remarks /> 
                Function[Function["TimeDifference"] = 22] = "TimeDifference";
                ///<remarks /> 
                Function[Function["GetUnixTime"] = 23] = "GetUnixTime";
                // --------- Boolean Functions
                /// <remarks />
                Function[Function["Negate"] = 24] = "Negate";
                // --------- PartyList Function
                /// <remarks />
                Function[Function["AddParty"] = 25] = "AddParty";
                /// <remarks />
                Function[Function["RemoveParty"] = 26] = "RemoveParty";
                // --------- TempVariable functions
                /// <remarks />
                Function[Function["AddItem"] = 27] = "AddItem";
                /// <remarks />
                Function[Function["InsertItem"] = 28] = "InsertItem";
                /// <remarks />
                Function[Function["GetItem"] = 29] = "GetItem";
                /// <remarks />
                Function[Function["RemoveItem"] = 30] = "RemoveItem";
                /// <remarks />
                Function[Function["ClearItems"] = 31] = "ClearItems";
                /// <remarks />
                Function[Function["CreateListVariable"] = 32] = "CreateListVariable";
                /// <remarks />
                Function[Function["IncludeFilter"] = 33] = "IncludeFilter";
                /// <remarks />
                Function[Function["SetGpsPosition"] = 34] = "SetGpsPosition";
                /// <remarks />
                Function[Function["LoadReference"] = 35] = "LoadReference";
                /// <remarks />
                Function[Function["NewInstance"] = 36] = "NewInstance";
                /// <remarks />
                Function[Function["LoadFetch"] = 37] = "LoadFetch";
                /// <remarks />
                Function[Function["AssignNew"] = 38] = "AssignNew";
                /// <remarks />
                Function[Function["LengthOf"] = 39] = "LengthOf";
                /// <remarks />
                Function[Function["IndexOf"] = 40] = "IndexOf";
                /// <remarks />
                Function[Function["SubString"] = 41] = "SubString";
                /// <remarks />
                Function[Function["ElementAt"] = 42] = "ElementAt";
                /// <remarks />
                Function[Function["FormatSpecial"] = 43] = "FormatSpecial";
            })(Function = Workflow.Function || (Workflow.Function = {}));
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
