///<reference path="dialogs/basePickersPage.ts" />
///<reference path="data/inputs.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var InspectionsPage = /** @class */ (function (_super) {
                __extends(InspectionsPage, _super);
                function InspectionsPage(dialog, inspections) {
                    var _this = _super.call(this, "INSPECTIONS", "Scheduler.Msg.INSPECTIONS", "INSPECTIONS", "Scheduler.Msg.TaskInspections", "Inspections.") || this;
                    //private readonly _emptyID: string = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx";
                    _this._provider = new InspectionsDataProvider();
                    _this._propertyDlg = dialog;
                    _this._inspections = inspections;
                    //let typesList: FilterListItem[] = [];
                    //let selectedTypeId: string = this._emptyID;
                    var templatesList = [];
                    var selectedTemplatesIds = [];
                    //if (inspections) {
                    //	let provider = new InspectionsDataProvider();
                    //	let promises: Promise<void>[] = [];
                    //	promises.push(provider.loadTypes(inspections.types).then((value: FilterListItem[]) => {
                    //		typesList = value;
                    //		return;
                    //	}));
                    //	promises.push(provider.loadTaskTypeFieldValue(Container.inputs, inspections.activityTypeField, this._propertyDlg.task.id).then((value: string) => {
                    //		selectedTypeId = (value === undefined) ? this._emptyID : value;
                    //		return;
                    //	}));
                    //	promises.push(provider.loadTemplates(inspections.templates).then((value: FilterListItem[]) => {
                    //		templatesList = value;
                    //		return;
                    //	}));
                    //	Promise.all(promises).then((values: void[]) => {
                    //		this.addBodyContent('<p data-localization="Scheduler.Msg.InspectionsType">Appointment type</p>');
                    //		this.addBodyContent(this._createTypePicker(typesList, selectedTypeId));
                    //		this.addBodyContent('<p data-localization="Scheduler.Msg.InspectionsTemplate">Appointment template</p>');
                    //		this.addBodyContent(this._createTemplatePicker(templatesList, selectedItems));
                    //	});
                    //}
                    if (inspections) {
                        var promises = [];
                        promises.push(_this._provider.loadTemplates(inspections.templates).then(function (values) {
                            templatesList = values;
                        }));
                        promises.push(_this._provider.loadAppointmentTemplates(inspections, _this._propertyDlg.task).then(function (values) {
                            selectedTemplatesIds = values.map(function (item) {
                                return item.id;
                            });
                        }));
                        Promise.all(promises).then(function (values) {
                            _this.addBodyContent('<p data-localization="Scheduler.Msg.InspectionsTemplate">Appointment template</p>');
                            _this.addBodyContent(_this._createTemplatePicker(templatesList, selectedTemplatesIds));
                        });
                    }
                    return _this;
                }
                //private _createTypePicker(typesList: FilterListItem[], selectedTypeId: string): JQuery {
                //	let inspectionsTypeListElement = $("<select>").addClass("inspectionsType").css("width", "100%");
                //	if (!this._propertyDlg.canSave) {
                //		inspectionsTypeListElement.attr("disabled", "disabled");
                //	}
                //	else {
                //		inspectionsTypeListElement.removeAttr("disabled");
                //		typesList.sort((a: FilterListItem, b: FilterListItem) => {
                //			return a.name.localeCompare(b.name);
                //		});
                //		if (selectedTypeId === this._emptyID) {
                //			let option = document.createElement('option');
                //			option.text = "";
                //			option.value = this._emptyID;
                //			inspectionsTypeListElement.append(option);
                //		}
                //		for (let i = 0; i < typesList.length; i++) {
                //			let inspectionsType: FilterListItem = typesList[i];
                //			let option = document.createElement('option');
                //			option.text = inspectionsType.name;
                //			option.value = inspectionsType.id;
                //			if (selectedTypeId === inspectionsType.id) {
                //				option.selected = true;
                //			}
                //			inspectionsTypeListElement.append(option);
                //		}
                //		inspectionsTypeListElement.change((e: any) => {
                //			let item = e.target;
                //			if (item.selectedIndex >= 0) {
                //				let typeId = item[item.selectedIndex].value;
                //				this._propertyDlg.onChange("inspectionsTypeID", typeId);
                //			}
                //		});
                //	}
                //	return inspectionsTypeListElement;
                //}
                InspectionsPage.prototype._createTemplatePicker = function (templatesList, selectedTemplatesIds) {
                    var _this = this;
                    var pickerSettings = {
                        minHeight: 27,
                        arrowImage: Scheduler.Container.imageFolder + "arrow_down.png",
                        arrowWidth: 27,
                        imageContainerSize: { width: 22, height: 22 },
                        appColors: Scheduler.Container.appColors,
                        dataSource: templatesList,
                        displayMember: "name",
                        valueMember: "id",
                        separator: "; "
                    };
                    var simpleListMultiPicker = new Controls.SimpleListMultiPicker(pickerSettings);
                    if (!this._propertyDlg.canSave) {
                        //inspectionsTypeListElement.attr("disabled", "disabled");
                    }
                    else {
                        simpleListMultiPicker.suspendUpdate();
                        if (selectedTemplatesIds) {
                            for (var i = 0; i < simpleListMultiPicker.items.length; i++) {
                                var listItem = simpleListMultiPicker.items[i];
                                if (selectedTemplatesIds.indexOf(listItem.data) >= 0) {
                                    listItem.isSelected = true;
                                }
                            }
                        }
                        simpleListMultiPicker.resumeUpdate();
                        simpleListMultiPicker.selectionChanged.add(this, function (sender, e) {
                            var selectedItems = e.selectedItems.map(function (item) {
                                return new Scheduler.FilterListItem(item.data, item.label);
                            });
                            _this._propertyDlg.onChange(InspectionsDataProvider.inspectionsSelectedTemplatesIDs, selectedItems);
                        });
                    }
                    return simpleListMultiPicker.element;
                };
                /**
                 * Saves inspection templates set in the taskChanges argument.
                 * @param taskChanges Object where selected templates were saved by InspectionPage in task edit dialog.
                 */
                InspectionsPage.prototype.onSave = function (taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            return [2 /*return*/, this._provider.updateTemplateNNEntity(this._inspections, this._propertyDlg.task, taskChanges)];
                        });
                    });
                };
                return InspectionsPage;
            }(Scheduler.BasePage));
            Scheduler.InspectionsPage = InspectionsPage;
            var InspectionsDataProvider = /** @class */ (function () {
                function InspectionsDataProvider() {
                }
                //public async loadTypes(types: EntityBase): Promise<FilterListItem[]> {
                //	return this._loadTypesData(types).then((typesResults: MobileCRM.DynamicEntity[]) => {
                //		return this._toTypesList(types, typesResults);
                //	}).catch((error: any) => {
                //		let msg = (error instanceof Resco.Exception) ? error.message : error.toString();
                //		StringTable.alert((StringTable.get("Err.CantFetchEntity") || "Can't fetch entity") + " " + types.entityName + " " + msg);
                //		return [];
                //	});
                //}
                //private async _loadTypesData(types: EntityBase): Promise<MobileCRM.DynamicEntity[]> {
                //	if (types && types.entityName) {
                //		let entity = new MobileCRM.FetchXml.Entity(types.entityName);
                //		entity.addAttribute(types.primaryKeyName);
                //		entity.addAttribute(types.primaryFieldName);
                //		let fetch = new MobileCRM.FetchXml.Fetch(entity);
                //		return await fetch.executeAsync("DynamicEntities");
                //	}
                //	return undefined;
                //}
                //private _toTypesList(types: EntityBase, typesResults: MobileCRM.DynamicEntity[]): FilterListItem[] {
                //	let typesList: FilterListItem[] = [];
                //	if (typesResults && (typesResults.length > 0)) {
                //		for (let i = 0; i < typesResults.length; i++) {
                //			let prop = typesResults[i].properties;
                //			typesList.push(new FilterListItem(prop[types.primaryKeyName], prop[types.primaryFieldName]));
                //		}
                //	}
                //	return typesList;
                //}
                //public async loadTaskTypeFieldValue(input: ConfigData, typeFieldName: string, taskId: string): Promise<string> {
                //	if (input && input.scheduledTasks) {
                //		let entity = new MobileCRM.FetchXml.Entity(input.scheduledTasks.entityName);
                //		entity.addAttribute(input.scheduledTasks.primaryKeyName);
                //		entity.addAttribute(input.scheduledTasks.primaryFieldName);
                //		entity.addAttribute(typeFieldName);
                //		entity.addFilter().where(input.scheduledTasks.primaryKeyName, "eq", taskId);
                //		let fetch = new MobileCRM.FetchXml.Fetch(entity);
                //		let results: MobileCRM.DynamicEntity[] = await fetch.executeAsync("DynamicEntities");
                //		if (results && (results.length > 0)) {
                //			let typeRef: MobileCRM.Reference = typeFieldName ? results[0].properties[typeFieldName] : undefined;
                //			if (typeRef && typeRef.id) {
                //				return typeRef.id;
                //			}
                //		}
                //	}
                //	return undefined;
                //}
                //public async saveTypes(types: EntityBase): Promise<FilterListItem[]> {
                //	return this._loadTypesData(types).then((typesResults: MobileCRM.DynamicEntity[]) => {
                //		return this._toTypesList(types, typesResults);
                //	}).catch((error: any) => {
                //		let msg = (error instanceof Resco.Exception) ? error.message : error.toString();
                //		StringTable.alert((StringTable.get("Err.CantFetchEntity") || "Can't fetch entity") + " " + types.entityName + " " + msg);
                //		return [];
                //	});
                //}
                /**
                 * Loads all templates.
                 * @param templates Input configuration for templates from Inspections object.
                 */
                InspectionsDataProvider.prototype.loadTemplates = function (templates) {
                    return __awaiter(this, void 0, void 0, function () {
                        var _this = this;
                        return __generator(this, function (_a) {
                            // (statusReason[active or published]) and istemplate
                            return [2 /*return*/, this._loadTemplatesData(templates).then(function (templatesResults) {
                                    return _this._toTemplatesList(templates, templatesResults);
                                }).catch(function (error) {
                                    var msg = (error instanceof Resco.Exception) ? error.message : error.toString();
                                    Scheduler.StringTable.alert((Scheduler.StringTable.get("Err.CantFetchEntity") || "Can't fetch entity") + " " + templates.entityName + " " + msg);
                                    return [];
                                })];
                        });
                    });
                };
                InspectionsDataProvider.prototype._loadTemplatesData = function (templates) {
                    return __awaiter(this, void 0, void 0, function () {
                        var entity, filters, statusFilter, resourceFilter, fetch_1;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    if (!(templates && templates.entityName)) return [3 /*break*/, 2];
                                    entity = new MobileCRM.FetchXml.Entity(templates.entityName);
                                    entity.addAttribute(templates.primaryKeyName);
                                    entity.addAttribute(templates.primaryFieldName);
                                    entity.addAttribute(templates.attrStatusReason);
                                    entity.addAttribute(templates.attrIsTemplate);
                                    filters = [];
                                    statusFilter = new MobileCRM.FetchXml.Filter();
                                    statusFilter.isIn(templates.attrStatusReason, InspectionsDataProvider.templatesAllowedStatuses);
                                    filters.push(statusFilter);
                                    resourceFilter = new MobileCRM.FetchXml.Filter();
                                    resourceFilter.where(templates.attrIsTemplate, "eq", true);
                                    filters.push(resourceFilter);
                                    entity.addFilter().filters = filters;
                                    fetch_1 = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch_1.executeAsync("DynamicEntities")];
                                case 1: return [2 /*return*/, _a.sent()];
                                case 2: return [2 /*return*/, undefined];
                            }
                        });
                    });
                };
                InspectionsDataProvider.prototype._toTemplatesList = function (templates, templatesResults) {
                    var templatesList = [];
                    if (templatesResults && (templatesResults.length > 0)) {
                        for (var i = 0; i < templatesResults.length; i++) {
                            var prop = templatesResults[i].properties;
                            templatesList.push(new Scheduler.FilterListItem(prop[templates.primaryKeyName], prop[templates.primaryFieldName]));
                        }
                    }
                    return templatesList;
                };
                /**
                 * Loads all templates that are associated with the activity.
                 * @param inspections Input configuration Inspections object.
                 * @param task Activity for which we want to load associated templates.
                 */
                InspectionsDataProvider.prototype.loadAppointmentTemplates = function (inspections, task) {
                    return __awaiter(this, void 0, void 0, function () {
                        var templates, entity, linkEntity, fetch, result, i, prop;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    templates = [];
                                    entity = new MobileCRM.FetchXml.Entity(inspections.templates.entityName);
                                    entity.addAttribute(inspections.templates.primaryKeyName);
                                    entity.addAttribute(inspections.templates.primaryFieldName);
                                    linkEntity = entity.addLink(inspections.activitiesTemplates.entityName, inspections.activitiesTemplates.linkFromAttr, inspections.activitiesTemplates.linkToAttr, inspections.activitiesTemplates.linkType);
                                    linkEntity.addAttribute(inspections.activitiesTemplates.linkFromAttr);
                                    linkEntity.addAttribute(inspections.activitiesTemplates.attrToFilterBy);
                                    linkEntity.addFilter().where(inspections.activitiesTemplates.attrToFilterBy, "eq", task.id);
                                    fetch = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch.executeAsync("DynamicEntities")];
                                case 1:
                                    result = _a.sent();
                                    if (result) {
                                        for (i = 0; i < result.length; i++) {
                                            prop = result[i].properties;
                                            templates.push(new Scheduler.FilterListItem(prop[inspections.templates.primaryKeyName], prop[inspections.templates.primaryFieldName]));
                                        }
                                    }
                                    return [2 /*return*/, templates];
                            }
                        });
                    });
                };
                /**
                 * Saves inspection templates set in the taskChanges argument to the respective N:N entity.
                 * @param inspections Input configuration Inspections object.
                 * @param task Activity to which the emplates were selected.
                 * @param taskChanges Object where selected templates were saved by InspectionPage in task edit dialog.
                 */
                InspectionsDataProvider.prototype.updateTemplateNNEntity = function (inspections, task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var selectedTemplates, loadedTemplates, result;
                        var _this = this;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    selectedTemplates = taskChanges[InspectionsDataProvider.inspectionsSelectedTemplatesIDs];
                                    return [4 /*yield*/, this.loadAppointmentTemplates(inspections, task)];
                                case 1:
                                    loadedTemplates = _a.sent();
                                    result = this._separateTemplates(selectedTemplates, loadedTemplates);
                                    return [2 /*return*/, new Promise(function (resolve, reject) {
                                            var promises = [];
                                            for (var i = 0; i < result.toCreate.length; i++) {
                                                promises.push(_this._createAppointmentTemplate(inspections, task, result.toCreate[i]));
                                            }
                                            for (var i = 0; i < result.toDelete.length; i++) {
                                                promises.push(_this._deleteAppointmentTemplate(inspections, task, result.toDelete[i]));
                                            }
                                            Scheduler.PromiseEx.allEx(promises)
                                                .then(function (values) {
                                                resolve();
                                            })
                                                .catch(function (errors) {
                                                var error = (Scheduler.StringTable.get("Scheduler.Err.InspectionsNotAllTemplatesWereSaved") || "Not all activity templates were saved") + ":\r\n";
                                                for (var i = 0; i < errors.length; i++)
                                                    error += " - " + errors[i] + "\r\n";
                                                reject(new Resco.Exception(error));
                                            });
                                        })];
                            }
                        });
                    });
                };
                InspectionsDataProvider.prototype._separateTemplates = function (selectedTemplates, loadedTemplates) {
                    var toCreate = [];
                    var toDelete = [];
                    if (selectedTemplates && loadedTemplates) {
                        var _loop_1 = function (i) {
                            var selectedTemplate = selectedTemplates[i];
                            if (!loadedTemplates.find(function (item) {
                                return item.id === selectedTemplate.id;
                            })) {
                                toCreate.push(selectedTemplate);
                            }
                        };
                        for (var i = 0; i < selectedTemplates.length; i++) {
                            _loop_1(i);
                        }
                        var _loop_2 = function (i) {
                            var loadedTemplate = loadedTemplates[i];
                            if (!selectedTemplates.find(function (item) {
                                return item.id === loadedTemplate.id;
                            })) {
                                toDelete.push(loadedTemplate);
                            }
                        };
                        for (var i = 0; i < loadedTemplates.length; i++) {
                            _loop_2(i);
                        }
                    }
                    return { toCreate: toCreate, toDelete: toDelete };
                };
                InspectionsDataProvider.prototype._createAppointmentTemplate = function (inspections, task, template) {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        var activityReference = new MobileCRM.Reference(Scheduler.Container.inputs.scheduledTasks.entityName, task.id, task.name);
                        var templateReference = new MobileCRM.Reference(inspections.templates.entityName, template.id, template.name);
                        MobileCRM.ManyToManyReference.create(inspections.activitiesTemplates.entityName, activityReference, templateReference, resolve, reject, _this);
                    });
                };
                InspectionsDataProvider.prototype._deleteAppointmentTemplate = function (inspections, task, template) {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        var activityReference = new MobileCRM.Reference(Scheduler.Container.inputs.scheduledTasks.entityName, task.id, task.name);
                        var templateReference = new MobileCRM.Reference(inspections.templates.entityName, template.id, template.name);
                        MobileCRM.ManyToManyReference.remove(inspections.activitiesTemplates.entityName, activityReference, templateReference, resolve, reject, _this);
                    });
                };
                InspectionsDataProvider.inspectionsSelectedTemplatesIDs = "inspectionsSelectedTemplatesIDs"; // Property name of the taskChanges object, where selected templates are saved.
                InspectionsDataProvider.templatesAllowedStatuses = [1, 473220002]; // Active=[1], Published=[473220002] // StatusReason values that template can have to be loaded.
                return InspectionsDataProvider;
            }());
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
;
//# sourceMappingURL=inspections.js.map