///<reference path="data/resource.ts" />
///<reference path="data/constants.ts" />
///<reference path="task.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            // items of StatisticType enum are ascendingly ordered base on their priority (Idle has the lowest priority)
            var StatisticType;
            (function (StatisticType) {
                StatisticType[StatisticType["Idle"] = 0] = "Idle";
                StatisticType[StatisticType["Other"] = 1] = "Other";
                StatisticType[StatisticType["Completed"] = 2] = "Completed";
                StatisticType[StatisticType["Scheduled"] = 3] = "Scheduled";
                StatisticType[StatisticType["TimeOff"] = 4] = "TimeOff";
            })(StatisticType = Scheduler.StatisticType || (Scheduler.StatisticType = {}));
            var TaskStatisticHelper = /** @class */ (function () {
                function TaskStatisticHelper(statisticType, timeRange) {
                    this.statisticType = statisticType;
                    this.timeRange = timeRange;
                }
                TaskStatisticHelper.prototype.createDeepCopy = function () {
                    var copy = new TaskStatisticHelper(this.statisticType, new Scheduler.TimeRange(this.timeRange.start, this.timeRange.end));
                    return copy;
                };
                return TaskStatisticHelper;
            }());
            var Statistic = /** @class */ (function () {
                function Statistic(resource, timeRange, workingDays) {
                    this.resource = resource;
                    this.timeRange = timeRange;
                    this._workingDays = workingDays;
                    this.idle = 0;
                    this.completed = 0;
                    this.scheduled = 0;
                    this.timeOff = 0;
                }
                /**
                 * Computes and sets statistic data
                 */
                Statistic.prototype.updateStatistics = function () {
                    var workingTime = this._workingDays * (Scheduler.Container.defaultOffice.workingDayDuration * Scheduler.minuteInMiliseconds);
                    var statistics = this._computeStatistics();
                    var usedTime = statistics[StatisticType.Other];
                    usedTime += statistics[StatisticType.Completed];
                    usedTime += statistics[StatisticType.Scheduled];
                    usedTime += statistics[StatisticType.TimeOff];
                    var idle = workingTime - usedTime;
                    idle = idle < 0 ? 0 : idle;
                    statistics[StatisticType.Idle] = idle;
                    var pureTime = statistics[StatisticType.Idle];
                    pureTime += statistics[StatisticType.Completed];
                    pureTime += statistics[StatisticType.Scheduled];
                    pureTime += statistics[StatisticType.TimeOff];
                    if (pureTime > 0) {
                        this.idle = statistics[StatisticType.Idle] / pureTime;
                        this.completed = statistics[StatisticType.Completed] / pureTime;
                        this.scheduled = statistics[StatisticType.Scheduled] / pureTime;
                        this.timeOff = statistics[StatisticType.TimeOff] / pureTime;
                    }
                    else {
                        this.idle = 1;
                        this.completed = this.scheduled = this.timeOff = 0;
                    }
                };
                Statistic.prototype._computeStatistics = function () {
                    var tasks = this.resource.getTasks();
                    var sortedTaskStatisticHelpers = [];
                    var statistics = [0, 0, 0, 0, 0];
                    var workingDayStatistics = [0, 0, 0, 0, 0];
                    if (tasks) {
                        // prepares sorted list of all tasks timeRange intervals in the statistic timeRange interval, based on task.start time
                        sortedTaskStatisticHelpers = this._prepareSortedStatisticHelpers(tasks);
                        // moves through each task timeRange interval and fills statistics time counters. Restricts tasks time ranges to max day working range.
                        var currentWorkingDayRange = void 0;
                        for (var i = 0; i < sortedTaskStatisticHelpers.length; i++) {
                            var currentTask = sortedTaskStatisticHelpers[i];
                            var workingDayRange = Scheduler.Container.defaultOffice.getWorkingDayRange(currentTask.timeRange.start);
                            if (!currentWorkingDayRange) {
                                currentWorkingDayRange = workingDayRange;
                            }
                            else if ((currentWorkingDayRange.start !== workingDayRange.start)) {
                                // go to next working day
                                this._restrictIncludeAndResetDayStatistics(statistics, workingDayStatistics);
                                currentWorkingDayRange = workingDayRange;
                            }
                            if (currentTask.timeRange.end > currentWorkingDayRange.end) {
                                var subRange = new Scheduler.TimeRange(currentTask.timeRange.start, currentWorkingDayRange.end);
                                workingDayStatistics[currentTask.statisticType] += subRange.duration();
                                do {
                                    // go to next working day
                                    this._restrictIncludeAndResetDayStatistics(statistics, workingDayStatistics);
                                    subRange = new Scheduler.TimeRange(subRange.end, currentTask.timeRange.end);
                                    currentWorkingDayRange = Scheduler.Container.defaultOffice.getWorkingDayRange(subRange.start);
                                    subRange.restrict(currentWorkingDayRange);
                                    workingDayStatistics[currentTask.statisticType] += subRange.duration();
                                } while (currentTask.timeRange.end > currentWorkingDayRange.end);
                            }
                            else {
                                workingDayStatistics[currentTask.statisticType] += currentTask.timeRange.duration();
                            }
                        }
                        if (sortedTaskStatisticHelpers.length > 0) {
                            this._restrictIncludeAndResetDayStatistics(statistics, workingDayStatistics);
                        }
                    }
                    return statistics;
                };
                Statistic.prototype._prepareSortedStatisticHelpers = function (tasks) {
                    // prepares sorted list of all tasks timeRange intervals in the statistic timeRange interval, based on task.start time
                    var sortedTaskStatisticHelpers = this._restrictToStatisticTimeRange(tasks);
                    sortedTaskStatisticHelpers.sort(function (a, b) { return a.timeRange.start - b.timeRange.start; });
                    this._resolveOccupancyConflicts(sortedTaskStatisticHelpers);
                    this._resolveWorkingRangeConflicts(sortedTaskStatisticHelpers);
                    return sortedTaskStatisticHelpers;
                };
                Statistic.prototype._restrictToStatisticTimeRange = function (tasks) {
                    var taskHelpers = [];
                    for (var i = 0; i < tasks.length; i++) {
                        var task = tasks[i];
                        var taskTimeRange = new Scheduler.TimeRange(task.getStart(), task.getEnd());
                        if (taskTimeRange.isValid() && this.timeRange.contain(taskTimeRange)) {
                            taskTimeRange.restrict(this.timeRange);
                            var statisticType = StatisticType.Other;
                            if (task.isTimeOff()) {
                                statisticType = StatisticType.TimeOff;
                            }
                            else if (task.getStatus().taskStatusType() === Scheduler.TaskStatusType.Completed) {
                                statisticType = StatisticType.Completed;
                            }
                            else if (task.getStatus().isScheduled()) {
                                statisticType = StatisticType.Scheduled;
                            }
                            taskHelpers.push(new TaskStatisticHelper(statisticType, taskTimeRange));
                        }
                    }
                    return taskHelpers;
                };
                Statistic.prototype._resolveOccupancyConflicts = function (sortedTaskHelpersWithConflicts) {
                    // moves through each task timeRange interval and resolves conflicts (regarding multiple tasks scheduled during the same period) if necessary
                    // !!!sortedTaskHelpersWithConflicts must be sorted and retricted to statistic range!!!
                    if (sortedTaskHelpersWithConflicts.length > 0) {
                        var currentTask = sortedTaskHelpersWithConflicts[0];
                        for (var nextIndex = 1; nextIndex < sortedTaskHelpersWithConflicts.length; nextIndex++) {
                            var nextTask = sortedTaskHelpersWithConflicts[nextIndex];
                            if (nextTask.timeRange.start < currentTask.timeRange.end) {
                                //is in conflict
                                // conflict resolve priority order [TimeOff > Scheduled > Completed > Other > Idle]
                                if (currentTask.statisticType === StatisticType.TimeOff) {
                                    //currentTask fist
                                    if (nextTask.timeRange.end > currentTask.timeRange.end) {
                                        this._restrictNext(currentTask, nextTask);
                                    }
                                    else {
                                        sortedTaskHelpersWithConflicts.splice(nextIndex, 1);
                                        nextIndex--;
                                        continue;
                                    }
                                }
                                else if (currentTask.statisticType === StatisticType.Scheduled) {
                                    if (nextTask.timeRange.end > currentTask.timeRange.end) {
                                        if (nextTask.statisticType >= StatisticType.TimeOff) {
                                            this._restrictCurrent(currentTask, nextTask);
                                        }
                                        else {
                                            this._restrictNext(currentTask, nextTask);
                                        }
                                    }
                                    else {
                                        if (nextTask.statisticType >= StatisticType.TimeOff) {
                                            this._splitAndRestrictCurrent(currentTask, nextTask, nextIndex, sortedTaskHelpersWithConflicts);
                                        }
                                        else {
                                            sortedTaskHelpersWithConflicts.splice(nextIndex, 1);
                                            nextIndex--;
                                            continue;
                                        }
                                    }
                                }
                                else if (currentTask.statisticType === StatisticType.Completed) {
                                    if (nextTask.timeRange.end > currentTask.timeRange.end) {
                                        if (nextTask.statisticType >= StatisticType.Scheduled) {
                                            this._restrictCurrent(currentTask, nextTask);
                                        }
                                        else {
                                            this._restrictNext(currentTask, nextTask);
                                        }
                                    }
                                    else {
                                        if (nextTask.statisticType >= StatisticType.Scheduled) {
                                            this._splitAndRestrictCurrent(currentTask, nextTask, nextIndex, sortedTaskHelpersWithConflicts);
                                        }
                                        else {
                                            sortedTaskHelpersWithConflicts.splice(nextIndex, 1);
                                            nextIndex--;
                                            continue;
                                        }
                                    }
                                }
                                else {
                                    if (nextTask.timeRange.end > currentTask.timeRange.end) {
                                        if (nextTask.statisticType >= StatisticType.Completed) {
                                            this._restrictCurrent(currentTask, nextTask);
                                        }
                                        else {
                                            this._restrictNext(currentTask, nextTask);
                                        }
                                    }
                                    else {
                                        if (nextTask.statisticType >= StatisticType.Completed) {
                                            this._splitAndRestrictCurrent(currentTask, nextTask, nextIndex, sortedTaskHelpersWithConflicts);
                                        }
                                        else {
                                            sortedTaskHelpersWithConflicts.splice(nextIndex, 1);
                                            nextIndex--;
                                            continue;
                                        }
                                    }
                                }
                            }
                            currentTask = nextTask;
                        }
                    }
                };
                Statistic.prototype._restrictCurrent = function (current, next) {
                    current.timeRange.end = next.timeRange.start;
                };
                Statistic.prototype._restrictNext = function (current, next) {
                    next.timeRange.start = current.timeRange.end;
                };
                Statistic.prototype._removeNextAndLoadNewNext = function (newNext, nextIndex, taskHelpersWithConflicts) {
                    taskHelpersWithConflicts.splice(nextIndex, 1);
                    newNext = nextIndex < taskHelpersWithConflicts.length ? taskHelpersWithConflicts[nextIndex] : null; // if null is assigned, this is the last loop
                };
                Statistic.prototype._splitAndRestrictCurrent = function (current, next, nextIndex, taskHelpersWithConflicts) {
                    // splits and restricts current task range
                    var currentTaskCopy = current.createDeepCopy();
                    this._restrictCurrent(current, next);
                    this._restrictNext(next, currentTaskCopy);
                    // add splitted rest of the current task in proper order back to the array
                    for (var j = nextIndex; j < taskHelpersWithConflicts.length; j++) {
                        if ((j + 1) < taskHelpersWithConflicts.length) {
                            var nextNextTask = taskHelpersWithConflicts[j + 1];
                            if (currentTaskCopy.timeRange.start < nextNextTask.timeRange.start) {
                                taskHelpersWithConflicts.splice(j + 1, 0, currentTaskCopy);
                                break;
                            }
                        }
                        else {
                            taskHelpersWithConflicts.push(currentTaskCopy);
                            break;
                        }
                    }
                };
                Statistic.prototype._resolveWorkingRangeConflicts = function (sortedTaskHelpers) {
                    // splits and restricts timeRange of each task according to working hours to resolve conflicts (regarding task timeRange exceeding working hours) if necessary
                    // !!!sortedTaskHelpers must be sorted, retricted to statistic range and must be without occupancy conflicts!!!
                    for (var i = 0; i < sortedTaskHelpers.length; i++) {
                        var currentTask = sortedTaskHelpers[i];
                        var taskDuration = currentTask.timeRange.duration();
                        if (taskDuration > 0) {
                            var earliestWorkingHoursRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(currentTask.timeRange.start, this.timeRange);
                            var lastWorkingHoursRange = Scheduler.Container.defaultOffice.getLastWorkingHoursRange(currentTask.timeRange.end, this.timeRange);
                            if ((earliestWorkingHoursRange === null) || (lastWorkingHoursRange === null)) {
                                sortedTaskHelpers.splice(i, 1);
                                i--;
                                continue;
                            }
                            if (lastWorkingHoursRange.start > earliestWorkingHoursRange.start) {
                                // task is located in more than 1 working hours ranges
                                if (currentTask.statisticType === StatisticType.TimeOff) {
                                    currentTask.timeRange.restrict(new Scheduler.TimeRange(earliestWorkingHoursRange.start, lastWorkingHoursRange.end));
                                }
                                do {
                                    // splits and restricts task range according to working hours in each day, if task is located in more days
                                    var currentTaskCopy = currentTask.createDeepCopy();
                                    currentTask.timeRange.end = earliestWorkingHoursRange.end;
                                    currentTaskCopy.timeRange.start = currentTask.timeRange.end;
                                    earliestWorkingHoursRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(currentTaskCopy.timeRange.start, this.timeRange);
                                    if ((earliestWorkingHoursRange === null) || !earliestWorkingHoursRange.contain(currentTaskCopy.timeRange))
                                        break; // continue to next task
                                    currentTaskCopy.timeRange.start = earliestWorkingHoursRange.start;
                                    // add currentTaskCopy in sorted position (after the current task)
                                    i++;
                                    sortedTaskHelpers.splice(i, 0, currentTaskCopy);
                                    currentTask = currentTaskCopy;
                                } while (lastWorkingHoursRange.start > earliestWorkingHoursRange.start);
                            }
                            else if (lastWorkingHoursRange.start === earliestWorkingHoursRange.start) {
                                // task is located in 1 working hours range only
                                if (currentTask.statisticType === StatisticType.TimeOff) {
                                    // restricts task timeRange to workingTimeDuration for every day where task is fully scheduled
                                    currentTask.timeRange.restrict(earliestWorkingHoursRange);
                                }
                                else {
                                    // keep the task as it is (do nothing)
                                }
                            }
                            else {
                                // task is located outside working hours ranges
                                if (currentTask.statisticType === StatisticType.TimeOff) {
                                    sortedTaskHelpers.splice(i, 1);
                                    i--;
                                    continue;
                                }
                                else {
                                    // keep the task as it is (do nothing)
                                }
                            }
                        }
                        else {
                            sortedTaskHelpers.splice(i, 1);
                            i--;
                            continue;
                        }
                    }
                };
                Statistic.prototype._restrictIncludeAndResetDayStatistics = function (statistics, workingDayStatistics) {
                    var workingTimeDuration = Scheduler.Container.defaultOffice.workingDayDuration * Scheduler.minuteInMiliseconds;
                    var maxWorkingTimeDuration = workingTimeDuration * 2;
                    for (var i = 0; i < workingDayStatistics.length; i++) {
                        var statisticValue = workingDayStatistics[i];
                        if (i === StatisticType.TimeOff) {
                            if (statisticValue > workingTimeDuration) {
                                statisticValue = workingTimeDuration;
                            }
                        }
                        else {
                            if (statisticValue > maxWorkingTimeDuration) {
                                statisticValue = maxWorkingTimeDuration;
                            }
                        }
                        statistics[i] += statisticValue;
                        workingDayStatistics[i] = 0;
                    }
                };
                /**
                 * Creates and appends statistic element that is drawn based on the statistic data
                 * @param view is scheduler View object where statistic is draw and that contains fields and methods necessary to compute statistic element dimension rectangle
                 */
                Statistic.prototype.draw = function (view) {
                    if (view.viewBody.vScrollContentElement && view.viewBody.vScrollContentElement.length > 0) {
                        var container = view.viewBody.vScrollContentElement[0];
                        var statisticDiv = this._createStatisticDiv(view);
                        var statisticContentDiv = this._createStatisticContent();
                        statisticDiv.appendChild(statisticContentDiv);
                        container.appendChild(statisticDiv);
                        this._updateLabelsPosition(statisticDiv);
                    }
                };
                Statistic.prototype._createStatisticDiv = function (view) {
                    var statisticDiv = document.createElement("div");
                    statisticDiv.classList.add("statistic");
                    statisticDiv.style.padding = "5px";
                    //statisticDiv.style.backgroundColor = "#00ff00";
                    var dimensions = this.getTaskBoxDimensions(view);
                    statisticDiv.style.position = "absolute";
                    statisticDiv.style.width = dimensions.width + "px";
                    statisticDiv.style.height = dimensions.height + "px";
                    statisticDiv.style.left = dimensions.x + "px";
                    statisticDiv.style.top = dimensions.y + "px";
                    return statisticDiv;
                };
                Statistic.prototype._createStatisticContent = function () {
                    var statisticContentDiv = document.createElement("div");
                    statisticContentDiv.classList.add("statisticContent");
                    var statisticContentLabelsDiv = this._createStatisticContentLabels();
                    var statisticContentChartDiv = this._createStatisticContentChart();
                    statisticContentDiv.appendChild(statisticContentLabelsDiv);
                    statisticContentDiv.appendChild(statisticContentChartDiv);
                    return statisticContentDiv;
                };
                Statistic.prototype._createStatisticContentLabels = function () {
                    var statisticContentLabelsDiv = document.createElement("div");
                    statisticContentLabelsDiv.classList.add("statisticContentLabels");
                    var completedValue = this.completed * 100;
                    if ((completedValue > 0) && Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Completed)) {
                        var completedLabel = document.createElement("label");
                        completedLabel.classList.add("statisticCompletedLabel");
                        completedLabel.innerHTML = Math.round(completedValue) + "%";
                        completedLabel.style.textAlign = "center";
                        completedLabel.style.color = Scheduler.ColorCache.tryGetColorWithoutAlpha(Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Completed].color()); //"#3498DB";
                        statisticContentLabelsDiv.appendChild(completedLabel);
                    }
                    var scheduledValue = this.scheduled * 100;
                    if ((scheduledValue > 0) && Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Scheduled)) {
                        var scheduledLabel = document.createElement("label");
                        scheduledLabel.classList.add("statisticScheduledLabel");
                        scheduledLabel.innerHTML = Math.round(scheduledValue) + "%";
                        scheduledLabel.style.textAlign = "center";
                        scheduledLabel.style.color = Scheduler.ColorCache.tryGetColorWithoutAlpha(Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Scheduled].color()); //"#EC7063";
                        statisticContentLabelsDiv.appendChild(scheduledLabel);
                    }
                    return statisticContentLabelsDiv;
                };
                Statistic.prototype._createStatisticContentChart = function () {
                    var statisticContentChartDiv = document.createElement("div");
                    statisticContentChartDiv.classList.add("statisticContentChart");
                    var hasChart = false;
                    var completedValue = this.completed * 100;
                    if ((completedValue > 0) && Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Completed)) {
                        var completedDiv = document.createElement("div");
                        completedDiv.classList.add("statisticCompleted");
                        completedDiv.style.width = Math.round(completedValue) + "%";
                        completedDiv.style.backgroundColor = Scheduler.ColorCache.tryGetColorWithoutAlpha(Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Completed].color()); //"#71B7E6"; // #71B7E6 - #3498DB
                        statisticContentChartDiv.appendChild(completedDiv);
                        hasChart = true;
                    }
                    // temporary unused
                    //let timeOffValue = this.timeOff * 100;
                    //if ((timeOffValue > 0) && Container.statusCodeTable.isSupported(TaskStatusType.TimeOff)) {
                    //	let timeOffDiv = <HTMLDivElement>document.createElement("div");
                    //	timeOffDiv.classList.add("statisticTimeOff");
                    //	timeOffDiv.style.width = Math.round(timeOffValue) + "%";
                    //	timeOffDiv.style.backgroundColor = ColorCache.tryGetColorWithoutAlpha(Container.statusCodeTable.primaryStatuses[TaskStatusType.TimeOff].color()); //"#606060";
                    //	statisticContentChartDiv.appendChild(timeOffDiv);
                    //	hasChart = true;
                    //}
                    var scheduledValue = this.scheduled * 100;
                    if ((scheduledValue > 0) && Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Scheduled)) {
                        var scheduledDiv = document.createElement("div");
                        scheduledDiv.classList.add("statisticScheduled");
                        scheduledDiv.style.width = Math.round(scheduledValue) + "%";
                        scheduledDiv.style.backgroundColor = Scheduler.ColorCache.tryGetColorWithoutAlpha(Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Scheduled].color()); //"#F29B91"; // #F29B91 - #EC7063
                        statisticContentChartDiv.appendChild(scheduledDiv);
                        hasChart = true;
                    }
                    if (hasChart) {
                        var idleDiv = document.createElement("div");
                        idleDiv.style.flexGrow = "1";
                        idleDiv.style.webkitFlexGrow = "1";
                        //idleDiv.style.width = Math.round(this.idle * 100) + "%"; // flexGrow is used instead to fill rest space
                        idleDiv.style.backgroundColor = "#f0f0f0";
                        statisticContentChartDiv.appendChild(idleDiv);
                    }
                    return statisticContentChartDiv;
                };
                Statistic.prototype._updateLabelsPosition = function (statisticDiv) {
                    var statisticContentLabelsDiv = statisticDiv.firstChild.firstChild;
                    var statisticContentChartDiv = statisticDiv.firstChild.lastChild;
                    if (statisticContentLabelsDiv.children.length === 1) {
                        var label = statisticContentLabelsDiv.firstChild;
                        var bar = void 0;
                        if (label.classList.contains("statisticCompletedLabel")) {
                            bar = statisticContentChartDiv.children.item(0);
                        }
                        else if (label.classList.contains("statisticScheduledLabel")) {
                            bar = statisticContentChartDiv.children.item(1);
                        }
                        if (bar) {
                            var barWidth = bar.clientWidth > statisticContentLabelsDiv.clientWidth ? statisticContentLabelsDiv.clientWidth : bar.clientWidth;
                            var labelWidth = label.getBoundingClientRect().width;
                            label.style.width = (barWidth > labelWidth) ? (barWidth + "px") : "";
                        }
                    }
                    else if (statisticContentLabelsDiv.children.length === 2) {
                        var labelsDivWidth = statisticContentLabelsDiv.clientWidth;
                        var completedLabel = statisticContentLabelsDiv.children.item(0);
                        var scheduledLabel = statisticContentLabelsDiv.children.item(1);
                        var completedBar = statisticContentChartDiv.children.item(0);
                        var scheduledBar = statisticContentChartDiv.children.item(1);
                        var completedLabelWidth = completedLabel.getBoundingClientRect().width;
                        var scheduledLabelWidth = scheduledLabel.getBoundingClientRect().width;
                        var completedBarWidth = completedBar.clientWidth;
                        var scheduledBarWidth = scheduledBar.clientWidth;
                        if (statisticContentChartDiv.children.length > 2) {
                            var idleBar = statisticContentChartDiv.children.item(2);
                            var idleBarWidth = idleBar.clientWidth;
                            if ((completedBarWidth > completedLabelWidth) && (scheduledBarWidth > scheduledLabelWidth)) {
                                var csw = labelsDivWidth - idleBarWidth;
                                var w = csw - completedBarWidth;
                                completedLabel.style.width = completedBarWidth + "px";
                                scheduledLabel.style.width = w + "px";
                            }
                            else if ((completedBarWidth > completedLabelWidth) && (scheduledBarWidth <= scheduledLabelWidth)) {
                                if ((completedLabelWidth + scheduledLabelWidth) > (completedBarWidth + scheduledBarWidth)) {
                                    // do nothing (keep labels width as it is set by default)
                                }
                                else {
                                    var w = (completedBarWidth + scheduledBarWidth) - scheduledLabelWidth;
                                    if ((scheduledBarWidth + idleBarWidth) > scheduledLabelWidth) {
                                        w = completedBarWidth;
                                    }
                                    completedLabel.style.width = w + "px";
                                }
                            }
                            else if ((completedBarWidth <= completedLabelWidth) && (scheduledBarWidth > scheduledLabelWidth)) {
                                if ((completedLabelWidth + scheduledLabelWidth) > (completedBarWidth + scheduledBarWidth)) {
                                    // do nothing (keep labels width as it is set by default)
                                }
                                else {
                                    var w = (completedBarWidth + scheduledBarWidth) - completedLabelWidth;
                                    scheduledLabel.style.width = w + "px";
                                }
                            }
                            else {
                                // do nothing (keep labels width as it is set by default)
                            }
                        }
                        else {
                            if ((completedBarWidth > completedLabelWidth) && (scheduledBarWidth > scheduledLabelWidth)) {
                                var w = labelsDivWidth - completedBarWidth;
                                completedLabel.style.width = completedBarWidth + "px";
                                scheduledLabel.style.width = w + "px";
                            }
                            else if ((completedBarWidth > completedLabelWidth) && (scheduledBarWidth <= scheduledLabelWidth)) {
                                var w = labelsDivWidth - scheduledLabelWidth;
                                completedLabel.style.width = w + "px";
                            }
                            else if ((completedBarWidth <= completedLabelWidth) && (scheduledBarWidth > scheduledLabelWidth)) {
                                var w = labelsDivWidth - completedLabelWidth;
                                scheduledLabel.style.width = w + "px";
                            }
                            else {
                                // do nothing (keep labels width as it is set by default)
                            }
                        }
                    }
                };
                /**
                 * Calculates dimension rectangle (size and position) for statistic DOM element box
                 * @param view is scheduler View object where statistic is draw and that contains fields and methods necessary to compute statistic element dimension rectangle
                 */
                Statistic.prototype.getTaskBoxDimensions = function (view) {
                    var month = new Date(this.timeRange.start).getMonth();
                    var x = view.columnWidth * (view.zoom.inMonthsMode6() ? (month % 6) : month);
                    var width = view.columnWidth;
                    var rowIndex = this.resource.rowIndex;
                    var y = view.getRowPosition(rowIndex);
                    var height = view.rowHeight;
                    return { x: x, y: y, width: width, height: height };
                };
                return Statistic;
            }());
            Scheduler.Statistic = Statistic;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=statistic.js.map