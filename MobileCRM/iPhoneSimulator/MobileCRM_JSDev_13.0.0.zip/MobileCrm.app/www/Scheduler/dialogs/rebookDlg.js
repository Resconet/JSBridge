///<reference path="../../../../MobileCrm/www/TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../../../MobileCrm/www/Controls/appColors.ts" />
///<reference path="../../../../MobileCrm/www/Controls/listBox.ts" />
///<reference path="../container.ts" />
///<reference path="baseDlg.ts" />
///<reference path="basePickersPage.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var RebookDlg = /** @class */ (function (_super) {
                __extends(RebookDlg, _super);
                function RebookDlg(container, task, onRebookCallback) {
                    var _this = _super.call(this) || this;
                    _this._rebookPage = undefined;
                    _this._task = task;
                    _this._container = container;
                    _this._onRebookCallback = onRebookCallback;
                    _this.onShowDialog();
                    return _this;
                }
                RebookDlg.show = function (container, task, onRebookCallback) {
                    if (RebookDlg._dialogInstance)
                        RebookDlg._dialogInstance.destroy();
                    RebookDlg._dialogInstance = new RebookDlg(container, task, onRebookCallback);
                };
                RebookDlg.prototype.onShowDialog = function () {
                    var _this = this;
                    if (this._container.dataLoadEnabed(true) === false)
                        return;
                    this.dialog = this._createRebookDlgElement();
                    var rescoTabCtrl = this.dialog.find(".rescoTabCtrl");
                    var dialogControlContainer = this.dialog.find(".dialogControlContainer");
                    var rebookPage = new RebookPage(this._container, this._task, this.zIndex);
                    rescoTabCtrl.append(rebookPage.tabElement);
                    dialogControlContainer.before(rebookPage.tabContentElement);
                    this._rebookPage = rebookPage;
                    this.initializeTabDialog(this.dialog);
                    Scheduler.StringTable.localizeElements(this.dialog);
                    this.dialog.find(".rebookButton").click(function (e) {
                        _this._onRebook();
                    });
                    _super.prototype.create.call(this, this.dialog, 400, 500);
                };
                RebookDlg.prototype._onRebook = function () {
                    var viewTimeRange = this._container.viewCtrl.zoom.getTimeRange();
                    var window = this._rebookPage.rebookWindow(this._container);
                    if (window.end <= window.start) {
                        Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.WindowEndBeforeStart") || "End of defined schedule window is before its start.");
                        return;
                    }
                    if (!(viewTimeRange.start <= window.start && window.start <= viewTimeRange.end) ||
                        !(viewTimeRange.start <= window.end && window.end <= viewTimeRange.end)) {
                        Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.WindowNotInInterval") || "Rebook window must be in displayed time interval.");
                        return;
                    }
                    if (!this._onRebookCallback(window))
                        return;
                    this.destroy();
                };
                RebookDlg.prototype.destroy = function () {
                    this._rebookPage.removeRescoComponents();
                    RebookDlg._dialogInstance = null;
                    _super.prototype.destroy.call(this);
                };
                RebookDlg.prototype._createRebookDlgElement = function () {
                    var element = Scheduler.Utilities.createFromTemplate(RebookDlg._template);
                    element.find("ul.rescoTabCtrl").css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    return element;
                };
                RebookDlg._dialogInstance = null;
                RebookDlg._template = '\
			<div class="rescoDialog">\
				<ul class="rescoTabCtrl">\
				</ul>\
				<div class="dialogControlContainer">\
				  <button class="closeButton" data-localization="Msg.Cancel">Cancel</button>&nbsp;\
				  <button class="rebookButton" data-localization="Msg.Rebook">Rebook</button>&nbsp;\
				</div>\
			</div>\
		';
                return RebookDlg;
            }(Scheduler.BaseDlg));
            Scheduler.RebookDlg = RebookDlg;
            var RebookPage = /** @class */ (function (_super) {
                __extends(RebookPage, _super);
                function RebookPage(container, task, zIndex) {
                    var _this = _super.call(this, "REBOOK", "Scheduler.Msg.REBOOK_TASK", "REBOOK TASK", "Scheduler.Msg.REBOOKTitle", "Define time window for task rebook and press button 'Rebook'.") || this;
                    _this.template = '\
			<div>\
				<p data-localization="Scheduler.Msg.RebookScheduleStart">Rebook schedule (start)</p>\
				<div class="flexPart">\
					<div data-datevalue="To" class="startDate"></div>\
					<div data-timeField="To" class="startTime" style="margin-left: 30px;"></div>\
				</div>\
			</div>\
			<br>\
			<div>\
				<p>\
					<label class="checkboxLabel">\
						<input type="checkbox" class="endInterval">\
						<span data-localization="Scheduler.Msg.RebookScheduleFinish">Rebook schedule (finish)</span>\
					</label>\
				</p>\
				<div class="endDateTime">\
					<p data-localization="Scheduler.Msg.DefineLastPossibleTime">Define the last possible time for rebooked task</p>\
					<div class="flexPart">\
						<div data-datevalue="To" class="endDate"></div>\
						<div data-timeField="To" class="endTime" style="margin-left: 30px;"></div>\
					</div>\
				</div>\
			</div>\
		';
                    _this.addBodyContent(_this.template);
                    var start = task.getStart() + Scheduler.dayInMiliseconds;
                    var startDate = new Date(start);
                    var now = Date.now();
                    if (startDate.valueOf() < now)
                        startDate = new Date(Date.now());
                    start = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).valueOf();
                    start = Scheduler.Container.defaultOffice.findNextWorkingTimeBegin(start);
                    _this._container = container;
                    _this._zIndex = zIndex;
                    _this._timeRange = new Scheduler.TimeRange(start, start + Scheduler.weekInMiliseconds);
                    _this._start = new Date(_this._timeRange.start);
                    _this._end = new Date(_this._timeRange.end);
                    _this._initDateFields();
                    return _this;
                }
                RebookPage.prototype.rebookWindow = function (container) {
                    var start = this._start.valueOf();
                    var end = this._end.valueOf();
                    if (!RebookPage._useEnd) {
                        var viewTimeRange = container.viewCtrl.zoom.getTimeRange();
                        end = viewTimeRange.end;
                    }
                    return new Scheduler.TimeRange(start, end);
                };
                RebookPage.prototype.removeRescoComponents = function () {
                    this.disposeRescoDateControls(this._startDatePicker);
                    this.disposeRescoDateControls(this._endDatePicker);
                    this.disposeRescoTimeControls(this._startTimePicker);
                    this.disposeRescoTimeControls(this._endTimePicker);
                };
                RebookPage.prototype._initDateFields = function () {
                    var minRange = this._container.settings.roundMinutes;
                    var content = this.tabContentElement;
                    var element;
                    var self = this;
                    if ((element = content.find(".startDate")) && element.length === 1) {
                        this._startDatePicker = this.createRescoInputDatePicker(element, this._start, { width: 190, height: 27, left: 0, top: 0 }, true, this._zIndex + 10);
                        this._startDatePicker.valueChanged.add(this, this._startDateChanged);
                    }
                    if ((element = content.find(".startTime")) && element.length === 1) {
                        this._startTimePicker = this.createRescoInputTimePicker(element, minRange, this._start, { width: 100, height: 27, left: 0, top: 0 }, true, this._zIndex + 10);
                        this._startTimePicker.valueChanged.add(this, this._startTimeChanged);
                    }
                    if ((element = content.find(".endDate")) && element.length === 1) {
                        this._endDatePicker = this.createRescoInputDatePicker(element, this._end, { width: 190, height: 27, left: 0, top: 0 }, true, this._zIndex + 10);
                        this._endDatePicker.valueChanged.add(this, this._endDateChanged);
                    }
                    if ((element = content.find(".endTime")) && element.length === 1) {
                        this._endTimePicker = this.createRescoInputTimePicker(element, minRange, this._end, { width: 100, height: 27, left: 0, top: 0 }, true, this._zIndex + 10);
                        this._endTimePicker.valueChanged.add(this, this._endTimeChanged);
                    }
                    var div = content.find(".endDateTime");
                    content.find(".endInterval")
                        .change(function (e) {
                        RebookPage._useEnd = e.target.checked;
                        self.onEndClicked();
                    })
                        .prop('checked', RebookPage._useEnd);
                    this.onEndClicked();
                };
                RebookPage.prototype.onEndClicked = function () {
                    var div = this.tabContentElement.find(".endDateTime");
                    if (RebookPage._useEnd)
                        div.show();
                    else
                        div.hide();
                };
                RebookPage.prototype._startDateChanged = function (sender, e) {
                    var value = e.value;
                    this._start.setFullYear(value.getFullYear(), value.getMonth(), value.getDate());
                };
                RebookPage.prototype._endDateChanged = function (sender, e) {
                    var value = e.value;
                    this._end.setFullYear(value.getFullYear(), value.getMonth(), value.getDate());
                };
                RebookPage.prototype._startTimeChanged = function (sender, e) {
                    var value = e.value;
                    this._start.setHours(value.hour);
                    this._start.setMinutes(value.minute);
                    this._start.setSeconds(0);
                    this._start.setMilliseconds(0);
                };
                RebookPage.prototype._endTimeChanged = function (sender, e) {
                    var value = e.value;
                    this._end.setHours(value.hour);
                    this._end.setMinutes(value.minute);
                    this._end.setSeconds(0);
                    this._end.setMilliseconds(0);
                };
                RebookPage._useEnd = false;
                return RebookPage;
            }(Scheduler.BasePickersPage));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=rebookDlg.js.map