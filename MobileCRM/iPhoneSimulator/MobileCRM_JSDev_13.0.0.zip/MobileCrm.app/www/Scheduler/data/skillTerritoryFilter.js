///<reference path="../task.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var AllowedResources = /** @class */ (function () {
                function AllowedResources(resourceId) {
                    //public static Source = new Dictionary<AllowedResources>();
                    this.ResourceId = [];
                    this.ResourceId = resourceId;
                }
                //		public static Reset(): void {
                //			AllowedResources.Source = new Dictionary<AllowedResources>();
                //		}
                // Load skill/territory dependencies for listed tasks
                AllowedResources.Load = function (tasks, onFinishCallback) {
                    var sourcesToUpdate = AllowedResources._sourcesToUpdate(tasks);
                    var sourcesToLoad = AllowedResources._sourcesToLoad(sourcesToUpdate);
                    var loaders = new Array();
                    var sourceLoader = new Scheduler.SourceDependenceLoader();
                    var resourceLoader = new Scheduler.ResourceDependenceLoader();
                    resourceLoader.addLoaders(loaders, Scheduler.Container.ref.resourceList);
                    if (sourcesToLoad.length > 0)
                        sourceLoader.addLoaders(loaders, sourcesToLoad);
                    Scheduler.PromiseEx.allEx(loaders)
                        .then(function (results) {
                        AllowedResources._updateAllowedResources(sourcesToUpdate, tasks, onFinishCallback);
                        AllowedResources._setLinkedResources(tasks);
                        onFinishCallback(null);
                    })
                        .catch(function (errors) {
                        var messages = errors.map(function (error) {
                            return (error instanceof Resco.Exception) ? error.message : error.toString();
                        });
                        onFinishCallback(Scheduler.aggregateErrors(messages));
                    });
                };
                AllowedResources._updateAllowedResources = function (sources, tasks, onFinishCallback) {
                    var resources = Scheduler.Container.ref.resourceList;
                    for (var i = 0; i < sources.length; i++) {
                        var source = sources[i];
                        var allowedRes = source.allowedResources;
                        if (!allowedRes) {
                            var resIds = [];
                            if (!source.territoryId && (!source.skillIds || !source.skillIds.length)) {
                                for (var j = 0; j < resources.length; j++) {
                                    if (resources[j].canProcessSourcesTasks(source))
                                        resIds.push(resources[j].getID());
                                }
                            }
                            else {
                                for (var j = 0; j < resources.length; j++) {
                                    if (resources[j].canProcessSourcesTasks(source))
                                        resIds.push(resources[j].getID());
                                }
                            }
                            source.allowedResources = new AllowedResources(resIds);
                        }
                    }
                };
                AllowedResources._sourcesToUpdate = function (tasks) {
                    var sourceMap = {};
                    for (var i = 0; i < tasks.length; i++) {
                        var task = tasks[i];
                        var source = task.group;
                        if (task.getLinkedResources() == undefined && source) {
                            var allowedRes = source.allowedResources;
                            if (allowedRes === undefined)
                                sourceMap[source.id] = source;
                            else
                                task.setLinkedResources(allowedRes.ResourceId);
                        }
                    }
                    var keySet = [];
                    for (var prop in sourceMap) {
                        if (sourceMap.hasOwnProperty(prop))
                            keySet.push(sourceMap[prop]);
                    }
                    return keySet;
                };
                AllowedResources._sourcesToLoad = function (sources) {
                    return sources.filter(function (s) { return s.skillIds === undefined || s.territoryId === undefined; });
                };
                AllowedResources._setLinkedResources = function (tasks) {
                    for (var i = tasks.length - 1; i >= 0; i--) {
                        var task = tasks[i];
                        if (task.getLinkedResources() == undefined && task.group) {
                            var resources = task.group.allowedResources;
                            task.setLinkedResources(resources ? resources.ResourceId : null);
                        }
                    }
                };
                return AllowedResources;
            }());
            Scheduler.AllowedResources = AllowedResources;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=skillTerritoryFilter.js.map