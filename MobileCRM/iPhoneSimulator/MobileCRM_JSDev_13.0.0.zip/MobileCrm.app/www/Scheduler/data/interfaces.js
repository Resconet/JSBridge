///<reference path="timeRange.ts" />
///<reference path="geo.ts" />
///<reference path="resource.ts" />
///<reference path="statusCodeTable.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            //export interface ICustomizationProvider {
            //	loadStatusList(statusList: StatusList): void;
            //	loadPrimaryStatuses(primaryStatuses: { taskStatusType: TaskStatusType, statusName: string }[]): void;
            //loadPlannerSettings(plannerSettings: PlannerSettings): void;
            //}
            //export interface IStatusList {
            //	getStatusByName(name: string): IStatus;
            //	getStatusByValue(value: number): IStatus;
            //}
            var StatusCSS;
            (function (StatusCSS) {
                StatusCSS[StatusCSS["Default"] = 0] = "Default";
                StatusCSS[StatusCSS["PastTask"] = 1] = "PastTask";
            })(StatusCSS = Scheduler.StatusCSS || (Scheduler.StatusCSS = {}));
            var Dictionary = /** @class */ (function () {
                function Dictionary() {
                    this.items = {};
                }
                Dictionary.prototype.ContainsKey = function (key) {
                    return this.items.hasOwnProperty(key);
                };
                Dictionary.prototype.IsEmpty = function () {
                    for (var prop in this.items) {
                        return false;
                    }
                    return true;
                };
                Dictionary.prototype.Add = function (key, value) {
                    this.items[key] = value;
                };
                Dictionary.prototype.Remove = function (key) {
                    var val = this.items[key];
                    delete this.items[key];
                    return val;
                };
                Dictionary.prototype.Item = function (key) {
                    return this.items[key];
                };
                Dictionary.prototype.ForEach = function (callback) {
                    for (var prop in this.items) {
                        if (this.items.hasOwnProperty(prop)) {
                            callback(this.items[prop]);
                        }
                    }
                };
                Dictionary.prototype.CopyTo = function (dst) {
                    var counter = 0;
                    for (var prop in this.items) {
                        if (this.items.hasOwnProperty(prop)) {
                            dst.Add(prop, this.items[prop]);
                            counter++;
                        }
                    }
                    return counter;
                };
                Dictionary.prototype.Keys = function () {
                    var keySet = [];
                    for (var prop in this.items) {
                        if (this.items.hasOwnProperty(prop)) {
                            keySet.push(prop);
                        }
                    }
                    return keySet;
                };
                Dictionary.prototype.Values = function () {
                    var values = [];
                    for (var prop in this.items) {
                        if (this.items.hasOwnProperty(prop)) {
                            values.push(this.items[prop]);
                        }
                    }
                    return values;
                };
                return Dictionary;
            }());
            Scheduler.Dictionary = Dictionary;
            function mergeArrays(dst, src) {
                if (!src)
                    return;
                for (var i = 0; i < src.length; i++)
                    dst.push(src[i]);
                return dst;
            }
            Scheduler.mergeArrays = mergeArrays;
            function arraysAreEqual(a, b) {
                if (!a)
                    return !b;
                if (!b)
                    return false;
                if (a.length != b.length)
                    return false;
                for (var i = 0, l = a.length; i < l; i++) {
                    if (a[i] != b[i])
                        return false;
                }
                return true;
            }
            Scheduler.arraysAreEqual = arraysAreEqual;
            ;
            function arrayFindIndex(arr, fnc) {
                for (var i = 0; i < arr.length; i++)
                    if (fnc(arr[i]))
                        return i;
                return -1;
            }
            Scheduler.arrayFindIndex = arrayFindIndex;
            function aggregateErrors(errors) {
                var error = null;
                for (var i = 0; i < errors.length; i++) {
                    if (errors[i]) {
                        if (error)
                            error += "\r\n" + errors[i];
                        else
                            error = errors[i];
                    }
                }
                return error;
            }
            Scheduler.aggregateErrors = aggregateErrors;
            var SettingsChangeRequest;
            (function (SettingsChangeRequest) {
                SettingsChangeRequest[SettingsChangeRequest["None"] = 0] = "None";
                SettingsChangeRequest[SettingsChangeRequest["RedrawNeeded"] = 1] = "RedrawNeeded";
                SettingsChangeRequest[SettingsChangeRequest["ReloadNeeded"] = 2] = "ReloadNeeded";
                SettingsChangeRequest[SettingsChangeRequest["ReinitializationNeeded"] = 3] = "ReinitializationNeeded";
            })(SettingsChangeRequest = Scheduler.SettingsChangeRequest || (Scheduler.SettingsChangeRequest = {}));
            var MultipageFetch = /** @class */ (function () {
                function MultipageFetch() {
                    this._pageCount = 500;
                    this._requiredCount = -1;
                }
                MultipageFetch.prototype.execute = function (entity, entityResultCallback) {
                    var _this = this;
                    if (entity) {
                        this._requiredCount = ((this.count === undefined) || (this.count === null) || (this.count < 0)) ? -1 : this.count;
                        this._rows = new Array();
                        this._fetch = new MobileCRM.FetchXml.Fetch(entity);
                        this._fetch.page = 1;
                    }
                    else
                        this._fetch.page++;
                    this._fetch.count = ((0 <= this._requiredCount) && (this._requiredCount < this._pageCount)) ? this._requiredCount : this._pageCount;
                    this._fetch.execute("DynamicEntities", function (entityResult) {
                        if (_this._requiredCount > 0) {
                            _this._requiredCount = _this._requiredCount - entityResult.length;
                            if (_this._requiredCount < 0)
                                _this._requiredCount = 0;
                        }
                        if ((_this._requiredCount !== 0) && (entityResult.length === _this._fetch.count)) {
                            mergeArrays(_this._rows, entityResult);
                            _this.execute(null, entityResultCallback);
                        }
                        else if (_this._rows.length > 0) {
                            mergeArrays(_this._rows, entityResult);
                            entityResultCallback(_this._rows);
                        }
                        else
                            entityResultCallback(entityResult);
                    }, function (err) {
                        Scheduler.StringTable.alert(err);
                        entityResultCallback(_this._rows);
                    }, this);
                };
                return MultipageFetch;
            }());
            Scheduler.MultipageFetch = MultipageFetch;
            function defineMissingProperties() {
                if (!Array.prototype.findIndex) {
                    Object.defineProperty(Array.prototype, 'findIndex', {
                        value: function (predicate) {
                            // 1. Let O be ? ToObject(this value).
                            if (this == null) {
                                throw new TypeError('"this" is null or not defined');
                            }
                            var o = Object(this);
                            // 2. Let len be ? ToLength(? Get(O, "length")).
                            var len = o.length >>> 0;
                            // 3. If IsCallable(predicate) is false, throw a TypeError exception.
                            if (typeof predicate !== 'function') {
                                throw new TypeError('predicate must be a function');
                            }
                            // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
                            var thisArg = arguments[1];
                            // 5. Let k be 0.
                            var k = 0;
                            // 6. Repeat, while k < len
                            while (k < len) {
                                // a. Let Pk be ! ToString(k).
                                // b. Let kValue be ? Get(O, Pk).
                                // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
                                // d. If testResult is true, return k.
                                var kValue = o[k];
                                if (predicate.call(thisArg, kValue, k, o)) {
                                    return k;
                                }
                                // e. Increase k by 1.
                                k++;
                            }
                            // 7. Return -1.
                            return -1;
                        },
                        configurable: true,
                        writable: true
                    });
                }
            }
            Scheduler.defineMissingProperties = defineMissingProperties;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=interfaces.js.map