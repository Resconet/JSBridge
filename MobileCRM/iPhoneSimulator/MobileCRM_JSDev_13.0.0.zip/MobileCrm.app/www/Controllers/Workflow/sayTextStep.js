/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="step.ts" />
/// <reference path="executionContext.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var SayTextStep = /** @class */ (function (_super) {
                __extends(SayTextStep, _super);
                function SayTextStep() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                SayTextStep.prototype._getName = function () {
                    return "SayTextStep";
                };
                SayTextStep.deserializeXML = function ($step) {
                    var s = new SayTextStep();
                    s._deserializeXML($step);
                    return s;
                };
                SayTextStep.prototype._deserializeXML = function ($step) {
                    this.text = $step.children("text").text();
                    this.serializedVariable = $step.children("var")[0].textContent;
                    _super.prototype._deserializeXML.call(this, $step);
                };
                SayTextStep.prototype.execute = function (context) {
                    var text = this.text;
                    if (text && text[0] == '@') {
                        // TODO: Localize
                        text = text.substr(1); //Localization.instance.get(text.substr(1));
                    }
                    if (this.serializedVariable) {
                        text = text + " " + context.getVariable(this.serializedVariable);
                    }
                    context.externalActions.sayText(text);
                    return null;
                };
                return SayTextStep;
            }(Workflow.Step));
            Workflow.SayTextStep = SayTextStep;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=sayTextStep.js.map