/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="executionContext.ts" />
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var Step = /** @class */ (function () {
                function Step() {
                }
                Object.defineProperty(Step.prototype, "fullName", {
                    get: function () {
                        return this._getName() + ":" + this.description;
                    },
                    enumerable: true,
                    configurable: true
                });
                Step.prototype._getName = function () {
                    return "Step";
                };
                Step.prototype.decode = function (steps) {
                    steps.push(this);
                };
                Step.deserializeXML = function ($step) {
                    var s = new Step();
                    s._deserializeXML($step);
                    return s;
                };
                Step.prototype._deserializeXML = function ($step) {
                    this.description = $step.attr("info");
                };
                // virtual
                Step.prototype.execute = function (context) {
                    return null;
                };
                return Step;
            }());
            Workflow.Step = Step;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=step.js.map