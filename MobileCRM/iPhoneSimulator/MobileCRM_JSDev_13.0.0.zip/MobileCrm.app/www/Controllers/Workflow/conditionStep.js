/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../../Data/metaEntity.ts" />
/// <reference path="expressionStep.ts" />
/// <reference path="executionContext.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var ConditionStep = /** @class */ (function (_super) {
                __extends(ConditionStep, _super);
                function ConditionStep() {
                    return _super.call(this) || this;
                }
                ConditionStep.prototype._getName = function () {
                    return "ConditionStep";
                };
                ConditionStep.deserializeXML = function ($step) {
                    var s = new ConditionStep();
                    s._deserializeXML($step);
                    return s;
                };
                ConditionStep.prototype._deserializeXML = function ($step) {
                    this.serializedOperator = ConditionOperator[$step.children("op")[0].textContent];
                    _super.prototype._deserializeXML.call(this, $step);
                };
                ConditionStep.prototype.execute = function (context) {
                    context.callStack.push(this);
                    var result = this._eval(context);
                    context.callStack.pop();
                    return result;
                };
                ConditionStep._isLogicalNull = function (obj) {
                    return obj === null || obj === undefined || obj === ""; // TODO: add datetime
                };
                ConditionStep._isVariableNull = function (type, variableValue) {
                    if (ConditionStep._isLogicalNull(variableValue)) {
                        return true;
                    }
                    if (type == MobileCrm.Data.CrmType.PartyList) {
                        var list = variableValue;
                        if (list.length === 0) {
                            return true;
                        }
                    }
                    if (type == MobileCrm.Data.CrmType.Picklist || type == MobileCrm.Data.CrmType.Status || type == MobileCrm.Data.CrmType.State) {
                        return variableValue === -1;
                    }
                    return false;
                };
                ConditionStep.prototype._eval = function (context) {
                    var variableValue = this.getVariableValue(context);
                    var variableType = this.getVariableType(context);
                    var stringVariable = ConditionStep._stringValue(variableValue);
                    switch (this.serializedOperator) {
                        case ConditionOperator.ContainsData:
                            return !ConditionStep._isVariableNull(variableType, variableValue);
                        case ConditionOperator.DoesNotContainData:
                            return ConditionStep._isVariableNull(variableType, variableValue);
                        case ConditionOperator.EqualUser:
                            return ConditionStep._isCurrentUser(variableValue);
                        case ConditionOperator.NotEqualUser:
                            return !ConditionStep._isCurrentUser(variableValue);
                        case ConditionOperator.EqualUserTeam:
                            return ConditionStep._isCurrentUserTeam(variableValue);
                        case ConditionOperator.EqualUserOrUserTeam:
                            return ConditionStep._isCurrentUser(variableValue) || ConditionStep._isCurrentUserTeam(variableValue);
                        case ConditionOperator.EqualBusinessUnit:
                            return ConditionStep._equalsCurrentBusinessUnit(variableValue);
                        case ConditionOperator.NotEqualBusinessUnit:
                            return !ConditionStep._equalsCurrentBusinessUnit(variableValue);
                    }
                    var argumentValue = this.getArgumentValue(context, 0);
                    var argumentType = this.getArgumentType(context, 0);
                    var stringArgument = ConditionStep._stringValue(argumentValue);
                    // TODO: get broadest number?
                    switch (this.serializedOperator) {
                        case ConditionOperator.Equal:
                            return ConditionStep._objectEquals(variableValue, argumentValue);
                        case ConditionOperator.NotEqual:
                            return !ConditionStep._objectEquals(variableValue, argumentValue);
                        case ConditionOperator.LessThan:
                            return ConditionStep._objectCompare(variableValue, argumentValue) < 0;
                        case ConditionOperator.LessEqual:
                            return ConditionStep._objectCompare(variableValue, argumentValue) <= 0;
                        case ConditionOperator.GreaterThan:
                            return ConditionStep._objectCompare(variableValue, argumentValue) > 0;
                        case ConditionOperator.GreaterEqual:
                            return ConditionStep._objectCompare(variableValue, argumentValue) >= 0;
                        case ConditionOperator.In:
                            return ConditionStep._checkIn(argumentValue, variableValue);
                        case ConditionOperator.NotIn:
                            return !ConditionStep._checkIn(argumentValue, variableValue);
                        case ConditionOperator.StartsWith:
                            return stringVariable.toLowerCase().startsWith(stringArgument.toLowerCase());
                        case ConditionOperator.DoesNotStartsWith:
                            return !stringVariable.toLowerCase().startsWith(stringArgument.toLowerCase());
                        case ConditionOperator.EndsWith:
                            return stringVariable.toLowerCase().endsWith(stringArgument.toLowerCase());
                        case ConditionOperator.DoesNotEndsWith:
                            return !stringVariable.toLowerCase().endsWith(stringArgument.toLowerCase());
                        case ConditionOperator.Contains:
                            /*if (variableType === Data.CrmType.PartyList)
                                return ConditionStep._partyListContains(variableValue, argumentValue);
                            else */ if (variableType === MobileCrm.Data.CrmType.StringList)
                                return ConditionStep._stringListContains(variableValue, argumentValue);
                            return stringVariable.toLowerCase().indexOf(stringArgument.toLowerCase()) >= 0;
                        case ConditionOperator.DoesNotContain:
                            /*if (variableType === Data.CrmType.PartyList)
                                return !ConditionStep._partyListContains(variableValue, argumentValue);
                            else */ if (variableType === MobileCrm.Data.CrmType.StringList)
                                return !ConditionStep._stringListContains(variableValue, argumentValue);
                            return stringVariable.toLowerCase().indexOf(stringArgument.toLowerCase()) < 0;
                        case ConditionOperator.RegexMatches:
                            var regExp = new RegExp(stringArgument);
                            return regExp.test(stringVariable);
                        case ConditionOperator.RegexDoesNotMatch:
                            var regExp = new RegExp(stringArgument);
                            return !regExp.test(stringVariable);
                        case ConditionOperator.On: {
                            if (!argumentValue || !variableValue) {
                                return false;
                            }
                            return this._isSameDay(new Date(variableValue), new Date(argumentValue));
                        }
                        case ConditionOperator.OnOrAfter: {
                            if (!argumentValue || !variableValue) {
                                return false;
                            }
                            return this._isSameOrAfterDay(new Date(variableValue), new Date(argumentValue));
                        }
                        case ConditionOperator.OnOrBefore: {
                            if (!argumentValue || !variableValue) {
                                return false;
                            }
                            return this._isSameOrBeforeDay(new Date(variableValue), new Date(argumentValue));
                        }
                        case ConditionOperator.NextXHours: {
                            if (!argumentValue || !variableValue) {
                                return false;
                            }
                            return this._isNextXHours(new Date(variableValue), argumentValue);
                        }
                        case ConditionOperator.LastXHours: {
                            if (!argumentValue || !variableValue) {
                                return false;
                            }
                            return this._isLastXHours(new Date(variableValue), argumentValue);
                        }
                        //case ConditionOperator.LastXDays:
                        //case ConditionOperator.NextXDays:
                        //case ConditionOperator.LastXWeeks:
                        //case ConditionOperator.NextXWeeks:
                        //case ConditionOperator.LastXMonths:
                        //case ConditionOperator.NextXMonths:
                        //case ConditionOperator.LastXYears:
                        //case ConditionOperator.NextXYears:
                        //	{
                        //		if (!argumentValue || !variableValue)
                        //			return false;
                        //		return this._checkDateInRange(context, this.serializedOperator);
                        //	}
                        case ConditionOperator.TypeOf: {
                            if (!argumentValue || !variableValue) {
                                return false;
                            }
                            //TODO: Workflow
                            //var reference = Data.Reference.as(variableValue);
                            //return (reference && (reference.entityName === argumentValue));
                        }
                    }
                    return false;
                };
                //static _partyListContains(variableValue: any, argumentValue: any): boolean {
                //	var list = Data.asReferenceArray(variableValue);
                //	if (list) {
                //		if (typeof argumentValue === "string") {
                //			let s = <string>argumentValue.toLocaleLowerCase();
                //			for (let i = 0; i < list.length; i++) {
                //				let a = list[i];
                //				var party = Data.ActivityParty.as(a);
                //				if (party && party.addressUsed.toLocaleLowerCase().localeCompare(s) === 0)
                //					return true;
                //			}
                //			return false;
                //		}
                //		if (list.contains(argumentValue))
                //			return true;
                //	}
                //	return false;
                //}
                ConditionStep._stringListContains = function (variableValue, argumentValue) {
                    if (Object.prototype.toString.call(variableValue) === '[object Array]') {
                        var arr = variableValue;
                        for (var i = 0; i < arr.length; i++) {
                            if (typeof arr[i] !== "string")
                                return false;
                        }
                        var list = variableValue;
                        if (typeof argumentValue === "string") {
                            var s = argumentValue.toLocaleLowerCase();
                            for (var i = 0; i < list.length; i++) {
                                if (s.localeCompare(list[i].toLocaleLowerCase()) === 0)
                                    return true;
                            }
                        }
                    }
                    return false;
                };
                //private _checkDateInRange(context: ExecutionContext, op: ConditionOperator): boolean {
                //	let variableValue = moment(this.getVariableValue(context));
                //	let range = <number>this.getArgumentValue(context, 0);
                //	let start = moment();
                //	let today = moment(new Date(start.year(), start.month(), start.date()));
                //	let end = moment(today);
                //	if (op === ConditionOperator.LastXDays || op === ConditionOperator.LastXWeeks || op === ConditionOperator.LastXMonths || op === ConditionOperator.LastXYears)
                //		range = -range;
                //	if (op === ConditionOperator.LastXDays || op === ConditionOperator.NextXDays)
                //		end.add("day", range);
                //	else if (op === ConditionOperator.LastXWeeks || op === ConditionOperator.NextXWeeks)
                //		end.add("day", (range * 7));
                //	else if (op === ConditionOperator.LastXMonths || op === ConditionOperator.NextXMonths)
                //		end.add("month", range);
                //	else if (op === ConditionOperator.LastXYears || op === ConditionOperator.NextXYears)
                //		end.add("year", range);
                //	if (range < 0) {
                //		let t = start;
                //		start = end;
                //		end = t;
                //	}
                //	else {
                //		end = end.add("day", 1);
                //	}
                //	return (variableValue.isAfter(start) || variableValue.isSame(start)) && (variableValue.isBefore(end) || variableValue.isSame(end));
                //}
                ConditionStep.prototype._isSameDay = function (date1, date2) {
                    return (date1.getFullYear() === date2.getFullYear()) && (date1.getMonth() === date2.getMonth()) && (date1.getDate() === date2.getDate());
                };
                ConditionStep.prototype._isSameOrBeforeDay = function (date1, date2) {
                    var date1m = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate());
                    return date1m.valueOf() <= date2.valueOf();
                };
                ConditionStep.prototype._isSameOrAfterDay = function (date1, date2) {
                    var date2m = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate());
                    return date1.valueOf() >= date2m.valueOf();
                };
                ConditionStep.prototype._isLastXHours = function (date, hours) {
                    var dateValue = date.valueOf();
                    var nowValue = Date.now();
                    var nowValueMinusX = nowValue - (hours * 60 * 60 * 1000);
                    return (dateValue < nowValue) && (dateValue >= nowValueMinusX);
                };
                ConditionStep.prototype._isNextXHours = function (date, hours) {
                    var dateValue = date.valueOf();
                    var nowValue = Date.now();
                    var nowValuePlusX = nowValue + (hours * 60 * 60 * 1000);
                    return (dateValue > nowValue) && (dateValue <= nowValuePlusX);
                };
                ConditionStep._objectEquals = function (a, b) {
                    if (a !== null && a !== undefined && b !== null && b !== undefined) {
                        if ((typeof a === "string") || (typeof b === "string")) {
                            return (a.toString().localeCompare(b.toString()) == 0);
                        }
                    }
                    if (ConditionStep._isLogicalNull(a) && ConditionStep._isLogicalNull(b)) {
                        return true;
                    }
                    if (Resco.hasFunction(a, "equals")) {
                        return a.equals(b);
                    }
                    return (a === b);
                };
                ConditionStep._objectCompare = function (a, b) {
                    var nullA = ConditionStep._isLogicalNull(a);
                    var nullB = ConditionStep._isLogicalNull(b);
                    if (nullA || nullB) {
                        if (nullA && nullB) {
                            return 0;
                        }
                        return nullA ? -1 : 1;
                    }
                    if (typeof a === "string") {
                        return a.localeCompare(b.toString());
                    }
                    else if (Resco.isIComparable(a)) {
                        return a.compareTo(b);
                    }
                    if (a === b) {
                        return 0;
                    }
                    return a > b ? 1 : -1;
                };
                ConditionStep._checkIn = function (array, value) {
                    if ((Object.prototype.toString.call(array) === '[object Array]')) {
                        var seq = array;
                        for (var i = 0; i < seq.length; i++) {
                            if (seq[i] === value) {
                                return true;
                            }
                        }
                    }
                    return false;
                };
                ConditionStep._isCurrentUser = function (value) {
                    // TODO: Configuration
                    /*var r = Data.Reference.as(value);
                    if (r) {
                        return r.id == Configuration.instance.settings.systemUserId;
                    }*/
                    return false;
                };
                ConditionStep._isCurrentUserTeam = function (value) {
                    return false;
                    /*var r = Data.Reference.as(value);
                    if (!r) {
                        return false;
                    }
                    for (var i = 0; i < Configuration.instance.settings.teamMate.length; i++) {
                        var tm = Configuration.instance.settings.teamMate[i];
                        if (r.id == tm) {
                            return true;
                        }
                    }
                    return false;*/
                };
                ConditionStep._equalsCurrentBusinessUnit = function (value) {
                    /*if (value) {
                        var r = Data.Reference.as(value);
                        if (r && r.id === Configuration.instance.settings.businessUnitId) {
                            return true;
                        }
                    }*/
                    return false;
                };
                ConditionStep._stringValue = function (value) {
                    return value ? value.toString() : "";
                };
                return ConditionStep;
            }(Workflow.ExpressionStep));
            Workflow.ConditionStep = ConditionStep;
            var ConditionOperator;
            (function (ConditionOperator) {
                /// <remarks/>
                ConditionOperator[ConditionOperator["Equal"] = 0] = "Equal";
                /// <remarks/>
                ConditionOperator[ConditionOperator["NotEqual"] = 1] = "NotEqual";
                /// <remarks/>
                ConditionOperator[ConditionOperator["GreaterThan"] = 2] = "GreaterThan";
                /// <remarks/>
                ConditionOperator[ConditionOperator["LessThan"] = 3] = "LessThan";
                /// <summary>GreaterEqual</summary>
                ConditionOperator[ConditionOperator["GreaterEqual"] = 4] = "GreaterEqual";
                /// <summary>LessEqual</summary>
                ConditionOperator[ConditionOperator["LessEqual"] = 5] = "LessEqual";
                /// <remarks/>
                ConditionOperator[ConditionOperator["StartsWith"] = 6] = "StartsWith";
                /// <remarks/>
                ConditionOperator[ConditionOperator["DoesNotStartsWith"] = 7] = "DoesNotStartsWith";
                /// <remarks/>
                ConditionOperator[ConditionOperator["EndsWith"] = 8] = "EndsWith";
                /// <remarks/>
                ConditionOperator[ConditionOperator["DoesNotEndsWith"] = 9] = "DoesNotEndsWith";
                /// <remarks/>
                ConditionOperator[ConditionOperator["In"] = 10] = "In";
                /// <remarks/>
                ConditionOperator[ConditionOperator["NotIn"] = 11] = "NotIn";
                /// <remarks/>
                ConditionOperator[ConditionOperator["ContainsData"] = 12] = "ContainsData";
                /// <remarks/>
                ConditionOperator[ConditionOperator["DoesNotContainData"] = 13] = "DoesNotContainData";
                /// <remarks/>
                ConditionOperator[ConditionOperator["On"] = 14] = "On";
                /// <remarks/>
                ConditionOperator[ConditionOperator["OnOrBefore"] = 15] = "OnOrBefore";
                /// <remarks/>
                ConditionOperator[ConditionOperator["OnOrAfter"] = 16] = "OnOrAfter";
                /// <remarks/>
                ConditionOperator[ConditionOperator["Contains"] = 17] = "Contains";
                /// <remarks/>
                ConditionOperator[ConditionOperator["DoesNotContain"] = 18] = "DoesNotContain";
                /// <remarks/>
                ConditionOperator[ConditionOperator["NextXHours"] = 19] = "NextXHours";
                /// <remarks/>
                ConditionOperator[ConditionOperator["LastXHours"] = 20] = "LastXHours";
                /// <remarks/>
                ConditionOperator[ConditionOperator["TypeOf"] = 21] = "TypeOf";
                /// <remarks/>
                ConditionOperator[ConditionOperator["RegexMatches"] = 22] = "RegexMatches";
                /// <remarks/>
                ConditionOperator[ConditionOperator["RegexDoesNotMatch"] = 23] = "RegexDoesNotMatch";
                /// <remarks/>
                ConditionOperator[ConditionOperator["EqualUser"] = 24] = "EqualUser";
                /// <remarks/>
                ConditionOperator[ConditionOperator["NotEqualUser"] = 25] = "NotEqualUser";
                /// <remarks/>
                ConditionOperator[ConditionOperator["EqualUserTeam"] = 26] = "EqualUserTeam";
                /// <remarks/>
                ConditionOperator[ConditionOperator["EqualUserOrUserTeam"] = 27] = "EqualUserOrUserTeam";
                /// <remarks/>
                ConditionOperator[ConditionOperator["EqualBusinessUnit"] = 28] = "EqualBusinessUnit";
                /// <remarks/>
                ConditionOperator[ConditionOperator["NotEqualBusinessUnit"] = 29] = "NotEqualBusinessUnit";
                ///// <remarks/>
                //NextXDays,
                ///// <remarks/>
                //LastXDays,
                ///// <remarks/>
                //NextXWeeks,
                ///// <remarks/>
                //LastXWeeks,
                ///// <remarks/>
                //NextXMonths,
                ///// <remarks/>
                //LastXMonths,
                ///// <remarks/>
                //NextXYears,
                ///// <remarks/>
                //LastXYears,
            })(ConditionOperator = Workflow.ConditionOperator || (Workflow.ConditionOperator = {}));
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
//# sourceMappingURL=conditionStep.js.map