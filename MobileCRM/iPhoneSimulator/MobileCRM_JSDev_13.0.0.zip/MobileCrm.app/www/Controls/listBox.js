///<reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="event.ts" />
/// <reference path="appColors.ts" />
///<reference path="datePicker.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        /**
         * Event arguments with information about which item has been changed.
         */
        var ListItemChangedEventArgs = /** @class */ (function (_super) {
            __extends(ListItemChangedEventArgs, _super);
            function ListItemChangedEventArgs(item) {
                var _this = _super.call(this) || this;
                _this._item = item;
                return _this;
            }
            Object.defineProperty(ListItemChangedEventArgs.prototype, "item", {
                get: function () {
                    return this._item;
                },
                enumerable: true,
                configurable: true
            });
            return ListItemChangedEventArgs;
        }(Resco.EventArgs));
        Controls.ListItemChangedEventArgs = ListItemChangedEventArgs;
        /**
         * Event arguments with information about all selected items.
         */
        var MultiSelectionChangedEventArgs = /** @class */ (function (_super) {
            __extends(MultiSelectionChangedEventArgs, _super);
            function MultiSelectionChangedEventArgs(selectedItems) {
                var _this = _super.call(this) || this;
                _this._selectedItems = selectedItems;
                return _this;
            }
            Object.defineProperty(MultiSelectionChangedEventArgs.prototype, "selectedItems", {
                get: function () {
                    return this._selectedItems;
                },
                enumerable: true,
                configurable: true
            });
            return MultiSelectionChangedEventArgs;
        }(Resco.EventArgs));
        Controls.MultiSelectionChangedEventArgs = MultiSelectionChangedEventArgs;
        /**
         * Class represents one item in the SimpleListBox component
         */
        var SimpleListItem = /** @class */ (function () {
            /**
             * Public constructor of the SimpleListItem with label for this item.
             * @param parent
             * @param data
             * @param label
             * @param isSelected
             */
            function SimpleListItem(parent, data, label, isSelected) {
                var _this = this;
                this.selectionChanged = new Resco.Event(this);
                this.itemClicked = new Resco.Event(this);
                this._parent = parent;
                this._element = $("<div>").addClass("simpleListItem");
                this._labelElement = $("<span>").addClass("text");
                this.element.append(this.labelElement);
                this._data = data;
                this._label = label;
                this.labelElement.text(this.label);
                this.isSelected = isSelected;
                this.element.click(function (e) {
                    _this._listBoxItemClicked(e);
                });
            }
            Object.defineProperty(SimpleListItem.prototype, "parent", {
                //*** PROPERTIES ***//
                get: function () {
                    return this._parent;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListItem.prototype, "element", {
                get: function () {
                    return this._element;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListItem.prototype, "labelElement", {
                get: function () {
                    return this._labelElement;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListItem.prototype, "data", {
                get: function () {
                    return this._data;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListItem.prototype, "label", {
                get: function () {
                    return this._label;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListItem.prototype, "isSelected", {
                get: function () {
                    return this._isSelected;
                },
                set: function (value) {
                    if (value !== this.isSelected) {
                        this._isSelected = value;
                        if (value) {
                            this.element.addClass("selected");
                        }
                        else {
                            this.element.removeClass("selected");
                        }
                        this.updateColors();
                        this.selectionChanged.raise(new ListItemChangedEventArgs(this), this); // Change of selection of any item in the selectionChanged handler leads to cyclic selectionChanged event raising!!!
                    }
                },
                enumerable: true,
                configurable: true
            });
            //*** METHODS ***//
            /**
             * Handles color updating based on the appColors object from parent SimpleListBox.
             */
            SimpleListItem.prototype.updateColors = function () {
                if (this.isSelected) {
                    this.element.css("background-color", this.parent.appColors.listSelBackgroundColor ? this.parent.appColors.listSelBackgroundColor : "");
                    this.labelElement.css("color", this.parent.appColors.listSelForegroundColor ? this.parent.appColors.listSelForegroundColor : "");
                }
                else {
                    this.element.css("background-color", this.parent.appColors.listBackgroundColor ? this.parent.appColors.listBackgroundColor : "");
                    this.labelElement.css("color", this.parent.appColors.listForegroundColor ? this.parent.appColors.listForegroundColor : "");
                }
            };
            /**
             * Handles click on the one SimpleListItem in the SimpleListBox.
             */
            SimpleListItem.prototype._listBoxItemClicked = function (e) {
                this.isSelected = !this.isSelected;
                this.itemClicked.raise(new ListItemChangedEventArgs(this), this);
            };
            return SimpleListItem;
        }());
        Controls.SimpleListItem = SimpleListItem;
        /**
         * Public class represents list box component with lines of ListBoxItems.
         */
        var SimpleListBox = /** @class */ (function () {
            function SimpleListBox(settings) {
                /** Array of ListBoxItems is collection of items displayed on SimpleListBox. Adding or removing items is not reflected (set new dataSource in such case). Only changing items selection is reflected. */
                this._items = [];
                /** Width of the SimpleListBox component. */
                this._width = -1;
                /** Height of the SimpleListBox component. */
                this._height = -1;
                this.selectionChanged = new Resco.Event(this);
                this.itemClicked = new Resco.Event(this);
                this._settings = settings;
                this._initSettings();
                this._element = $("<div>").addClass("simpleListBox");
                if (this.appColors)
                    this.appColors.propertyChanged.add(this, this._onPropertyChanged);
                this._reloadItems();
            }
            Object.defineProperty(SimpleListBox.prototype, "element", {
                /* PROPERTIES */
                get: function () {
                    return this._element;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListBox.prototype, "appColors", {
                get: function () {
                    return this._settings.appColors;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListBox.prototype, "items", {
                /** Array of ListBoxItems is collection of items displayed on SimpleListBox. Adding or removing items is not reflected (set new dataSource in such case). Only changing items selection is reflected. */
                get: function () {
                    return this._items;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListBox.prototype, "width", {
                get: function () {
                    return this._width;
                },
                set: function (value) {
                    if (value !== this.width) {
                        this._width = value;
                        this.element.css("width", (value > -1) ? (value + "px") : "");
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListBox.prototype, "height", {
                get: function () {
                    return this._height;
                },
                set: function (value) {
                    if (value !== this.height) {
                        this._height = value;
                        this.element.css("height", (value > -1) ? (value + "px") : "");
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListBox.prototype, "dataSource", {
                get: function () {
                    return this._settings.dataSource;
                },
                set: function (value) {
                    if (Array.isArray(value)) {
                        this._settings.dataSource = value;
                        this._reloadItems();
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListBox.prototype, "valueMember", {
                get: function () {
                    return this._settings.valueMember;
                },
                set: function (value) {
                    if (value && value !== this.valueMember) {
                        this._settings.valueMember = value;
                        this._reloadItems();
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListBox.prototype, "displayMember", {
                get: function () {
                    return this._settings.displayMember;
                },
                set: function (value) {
                    if (value && value !== this.displayMember) {
                        this._settings.displayMember = value;
                        this._reloadItems();
                    }
                },
                enumerable: true,
                configurable: true
            });
            //*** METHODS ***//
            SimpleListBox.prototype._initSettings = function () {
                if (!Array.isArray(this._settings.dataSource)) {
                    this._settings.dataSource = [];
                }
                if (!this._settings.valueMember) {
                    this._settings.valueMember = "0";
                }
                if (!this._settings.displayMember) {
                    this._settings.displayMember = "1";
                }
            };
            SimpleListBox.prototype._createItemsElements = function () {
                for (var i = 0; i < this.items.length; i++) {
                    var item = this.items[i];
                    this.element.append(item.element);
                    if (i < (this.items.length - 1)) {
                        var separator = $("<div>").addClass("separator");
                        this.element.append(separator);
                    }
                }
            };
            SimpleListBox.prototype._reloadItems = function () {
                var _this = this;
                if (Array.isArray(this.dataSource)) {
                    this._items = this.dataSource.map(function (item) {
                        var listBoxItem = new SimpleListItem(_this, item[_this.valueMember], item[_this.displayMember], false);
                        listBoxItem.selectionChanged.add(_this, _this._onItemSelectionChanged);
                        listBoxItem.itemClicked.add(_this, _this._onItemClicked);
                        return listBoxItem;
                    });
                    this.element.empty();
                    this._createItemsElements();
                    this.updateColors();
                }
            };
            /**
             * Handles color updating based on the appColors object.
             */
            SimpleListBox.prototype.updateColors = function () {
                this.element.css("background-color", this.appColors.listBackgroundColor ? this.appColors.listBackgroundColor : "");
                this.element.css("border-color", this.appColors.listSeparatorColor ? this.appColors.listSeparatorColor : "");
                this.element.find(".separator").css("background-color", this.appColors.listSeparatorColor ? this.appColors.listSeparatorColor : "");
                for (var i = 0; i < this.items.length; i++) {
                    var item = this.items[i];
                    item.updateColors();
                }
            };
            SimpleListBox.prototype._onPropertyChanged = function (sender, e) {
                this.updateColors();
            };
            SimpleListBox.prototype._onItemSelectionChanged = function (sender, e) {
                this.selectionChanged.raise(e, this);
            };
            SimpleListBox.prototype._onItemClicked = function (sender, e) {
                this.itemClicked.raise(e, this);
            };
            return SimpleListBox;
        }());
        Controls.SimpleListBox = SimpleListBox;
        /**
         * Public class represents list picker (combo box) with multi-selectable simple list box component.
         */
        var SimpleListMultiPicker = /** @class */ (function () {
            function SimpleListMultiPicker(settings) {
                var _this = this;
                /** Width of the SimpleListMultiPicker component. */
                this._width = -1;
                /** Determines whether picker dropdown is open (SimpleListBox is visible) or closed (SimpleListBox is hidden) */
                this._isListBoxVisible = false;
                /** Determines whether SimpleListMultiPicker should update itself every time when items selection is changed. */
                this._isSuspendedUpdate = false;
                /** Cached selection of every item. This is used to check if any item was change. */
                this._cachedItemsSelection = [];
                this.itemClicked = new Resco.Event(this);
                this.selectionChanged = new Resco.Event(this);
                this._settings = settings;
                this._initListBox();
                this._backgroundElement = this._createBackgroundElement(this._listBox.element);
                this._element = this._createElement();
                this.updateColors();
                if (this.appColors)
                    this.appColors.propertyChanged.add(this, this._onPropertyChanged);
                window.addEventListener("resize", function (e) {
                    _this._closeListBox();
                });
            }
            Object.defineProperty(SimpleListMultiPicker.prototype, "element", {
                get: function () {
                    return this._element;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListMultiPicker.prototype, "appColors", {
                get: function () {
                    return this._listBox.appColors;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListMultiPicker.prototype, "items", {
                /** Array of ListBoxItems is collection of items displayed on SimpleListBox. Adding or removing items is not reflected (set new dataSource in such case). Only changing items selection is reflected. */
                get: function () {
                    return this._listBox.items;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListMultiPicker.prototype, "selectedItems", {
                get: function () {
                    return this._listBox.items.filter(function (item) {
                        return item.isSelected;
                    });
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListMultiPicker.prototype, "dataSource", {
                get: function () {
                    return this._listBox.dataSource;
                },
                set: function (value) {
                    this._listBox.dataSource = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListMultiPicker.prototype, "valueMember", {
                get: function () {
                    return this._listBox.valueMember;
                },
                set: function (value) {
                    this._listBox.valueMember = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListMultiPicker.prototype, "displayMember", {
                get: function () {
                    return this._listBox.displayMember;
                },
                set: function (value) {
                    this._listBox.displayMember = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SimpleListMultiPicker.prototype, "width", {
                get: function () {
                    return this._width;
                },
                set: function (value) {
                    if (value !== this.width) {
                        this._width = value;
                        this.element.css("width", (value > -1) ? (value + "px") : "");
                    }
                },
                enumerable: true,
                configurable: true
            });
            SimpleListMultiPicker.prototype.suspendUpdate = function () {
                if (!this._isSuspendedUpdate) {
                    this._isSuspendedUpdate = true;
                    this._cachedItemsSelection = this.items.map(function (item) {
                        return item.isSelected;
                    });
                }
            };
            SimpleListMultiPicker.prototype.resumeUpdate = function () {
                if (this._isSuspendedUpdate) {
                    this._isSuspendedUpdate = false;
                    if (this.items.length === this._cachedItemsSelection.length) {
                        for (var i = 0; i < this.items.length; i++) {
                            if (this.items[i].isSelected !== this._cachedItemsSelection[i]) {
                                this._onSelectionChanged();
                                break;
                            }
                        }
                    }
                    else {
                        this._onSelectionChanged();
                    }
                    this._cachedItemsSelection = [];
                }
            };
            SimpleListMultiPicker.prototype._createElement = function () {
                var _this = this;
                var element = $("<div>").addClass("simpleListMultiPicker");
                var label = $("<div>").addClass("label");
                var arrow = $("<div>").addClass("arrow");
                arrow.css("min-width", (this._settings.arrowWidth ? this._settings.arrowWidth : this._settings.minHeight));
                arrow.css("min-height", this._settings.minHeight);
                var image = $("<div>").addClass("image");
                image.css("background-image", "url(" + this._settings.arrowImage + ")");
                if (this._settings.imageContainerSize) {
                    image.css({ "width": this._settings.imageContainerSize.width, "height": this._settings.imageContainerSize.height });
                }
                else {
                    image.css("height", this._settings.minHeight);
                }
                element.append(label);
                arrow.append(image);
                element.append(arrow);
                element.click(function (e) {
                    _this._onArrowClicked(e);
                });
                return element;
            };
            SimpleListMultiPicker.prototype._createBackgroundElement = function (dropDownElement) {
                var _this = this;
                var element = $("<div>").addClass("simpleListMultiPickerBackground");
                dropDownElement.click(function (e) {
                    e.stopPropagation();
                });
                element.click(function (e) {
                    _this._onBackgroundClicked(e);
                    e.stopPropagation(); // prevents click on underlay elements if dropdown background is shown over them
                });
                element.append(dropDownElement);
                return element;
            };
            SimpleListMultiPicker.prototype._initListBox = function () {
                this._listBox = new SimpleListBox(this._settings);
                this._listBox.itemClicked.add(this, this._onListItemClicked);
                this._listBox.selectionChanged.add(this, this._onListItemSelectionChanged);
            };
            SimpleListMultiPicker.prototype._onListItemSelectionChanged = function (sender, e) {
                if (!this._isSuspendedUpdate) {
                    this._onSelectionChanged();
                }
            };
            SimpleListMultiPicker.prototype._onListItemClicked = function (sender, e) {
                this.itemClicked.raise(e, sender);
            };
            SimpleListMultiPicker.prototype._onArrowClicked = function (e) {
                if (this._isListBoxVisible) {
                    this._closeListBox();
                }
                else {
                    this._openListBox();
                }
            };
            SimpleListMultiPicker.prototype._onBackgroundClicked = function (e) {
                this._closeListBox();
            };
            SimpleListMultiPicker.prototype._openListBox = function () {
                this._isListBoxVisible = true;
                this._backgroundElement.css("zIndex", Controls.Core.findMaxZIndexInDocument() + 10);
                $("body").append(this._backgroundElement);
                this._updateDropDown(); // We update styles after element is attached in DOM tree in this case, because we need to know computed heigh and width of the dropdown list.
                this.suspendUpdate();
            };
            SimpleListMultiPicker.prototype._closeListBox = function () {
                this._isListBoxVisible = false;
                this._backgroundElement.css("zIndex", "");
                this._backgroundElement.detach();
                this.resumeUpdate();
            };
            /**
             * Checks and modify dropdown list position and size according to available space and screen size.
             */
            SimpleListMultiPicker.prototype._updateDropDown = function () {
                this._listBox.element.css("min-width", this.element.outerWidth());
                var backOffset = this._backgroundElement.offset();
                var insideRectangle = { x: backOffset.left, y: backOffset.top, width: this._backgroundElement.width(), height: this._backgroundElement.height() };
                var pickerOffset = this.element.offset();
                var listRectangle = { x: pickerOffset.left, y: pickerOffset.top + this.element.height(), width: this._listBox.element.outerWidth(), height: this._listBox.element.outerHeight() };
                if ((listRectangle.x + listRectangle.width) > (insideRectangle.x + insideRectangle.width))
                    listRectangle.x = (insideRectangle.x + insideRectangle.width) - listRectangle.width;
                if ((listRectangle.y + listRectangle.height) > (insideRectangle.y + insideRectangle.height))
                    listRectangle.y = (insideRectangle.y + insideRectangle.height) - listRectangle.height;
                if (listRectangle.x < insideRectangle.x)
                    listRectangle.x = insideRectangle.x;
                if (listRectangle.y < insideRectangle.y)
                    listRectangle.y = insideRectangle.y;
                var maxHeight = Math.round(insideRectangle.height * 0.9);
                if (listRectangle.height >= maxHeight) {
                    listRectangle.height = maxHeight;
                    listRectangle.y = insideRectangle.y + Math.round((insideRectangle.height - listRectangle.height) / 2);
                    this._listBox.element.css("height", listRectangle.height);
                }
                else {
                    this._listBox.element.css("height", "");
                }
                this._listBox.element.css("left", listRectangle.x);
                this._listBox.element.css("top", listRectangle.y);
                this._deactivatePerfectScrollbar();
                this._activatePerfectScrollbar();
            };
            SimpleListMultiPicker.prototype._updateLabel = function (selectedItems) {
                var separator = this._settings.separator ? this._settings.separator : ", ";
                var text = "";
                if (selectedItems.length > 0) {
                    text = selectedItems[0].label;
                    for (var i = 1; i < selectedItems.length; i++) {
                        text += separator + selectedItems[i].label;
                    }
                }
                this.element.find(".label").text(text);
            };
            SimpleListMultiPicker.prototype._onSelectionChanged = function () {
                var selectedItems = this.selectedItems;
                this._updateLabel(selectedItems);
                this.selectionChanged.raise(new MultiSelectionChangedEventArgs(selectedItems), this);
            };
            SimpleListMultiPicker.prototype._onPropertyChanged = function (sender, e) {
                this.updateColors();
            };
            /**
             * Handles color updating based on the appColors object.
             */
            SimpleListMultiPicker.prototype.updateColors = function () {
                this.element.css("background-color", this.appColors.listBackgroundColor ? this.appColors.listBackgroundColor : "");
                this.element.css("border-color", this.appColors.listSeparatorColor ? this.appColors.listSeparatorColor : "");
            };
            SimpleListMultiPicker.prototype._activatePerfectScrollbar = function () {
                if (this._listBox.element.length > 0) {
                    this._perfectScrollbar = new PerfectScrollbar(this._listBox.element[0], { suppressScrollX: true });
                }
            };
            SimpleListMultiPicker.prototype._deactivatePerfectScrollbar = function () {
                if (this._perfectScrollbar) {
                    this._perfectScrollbar.destroy();
                    this._perfectScrollbar = undefined;
                }
            };
            return SimpleListMultiPicker;
        }());
        Controls.SimpleListMultiPicker = SimpleListMultiPicker;
        //export interface IRescoComboBoxSettings {
        //	dataSource: Array<Object>;
        //	displayMember: string;
        //	valueMember: string;
        //	selectedValue: string;
        //	showLabel: boolean;
        //	parentElement: HTMLElement;
        //	useParentDimensions: boolean;
        //	arrowImage: string;
        //	dimension?: Dimension;
        //}
        //export class RescoComboBox {
        //	public rescoComboBoxElement: HTMLElement;
        //	public valueChanged: Resco.Event<Resco.EventArgs>;
        //	public id: string;
        //	private _listBox: SimpleListBox;
        //	private _listBoxElement: HTMLElement;
        //	private _labelElement: HTMLElement;
        //	private _settings: IRescoComboBoxSettings;
        //	private _isListBoxVisible: boolean = false;
        //	constructor(settings: IRescoComboBoxSettings) {
        //		this.valueChanged = new Resco.Event<Resco.EventArgs>(this);
        //		this._generateID(this._generateUniqueIdentifier());
        //		this._initSettings(settings);
        //		this._initComboBox();
        //	}
        //	public openRescoComboBox(): void {
        //		this._isListBoxVisible = true;
        //		this._changedClassesInListBox();
        //		//@DM: Add invisible layer for handle click out of the rescoDatePicker element
        //		document.body.insertAdjacentHTML("afterbegin", "<div id='rescoInvisibleControlLayer" + this.id + "' class='rescoInvisibleControlLayer' style= 'width: " + document.body.offsetWidth + "px; height: " + document.body.offsetHeight + "px' > </div>");
        //		this._addEventListenerToInvisibleLayer();
        //	}
        //	public closeRescoComboBox(): void {
        //		this._isListBoxVisible = false;
        //		this._changedClassesInListBox();
        //		this._removeEventListenerFromInvisibleLayer();
        //	}
        //	private _initSettings(settings: IRescoComboBoxSettings): void {
        //		this._settings = settings;
        //		if (this._settings.dimension) {
        //			this._computeDimensions(this._settings.parentElement, this._settings.useParentDimensions);
        //		}
        //	}
        //	private _computeDimensions(parentElement: HTMLElement, useParentDimentions: boolean): void {
        //		this._settings.dimension = {
        //			width: parentElement.offsetWidth > 0 ? parentElement.offsetWidth : 20,
        //			height: parentElement.offsetHeight > 0 ? parentElement.offsetHeight : 40,
        //			top: parentElement.offsetTop + parentElement.offsetHeight,
        //			left: parentElement.offsetLeft,
        //		}
        //	}
        //	private _initComboBox(): void {
        //		let template: string =
        //			"<div id='" + this.id + "' class='rescoComboBox' style='width:" + this._settings.dimension.width + "px; height:" + this._settings.dimension.height + "px;'>\
        //				<div class='comboBoxHeader'>\
        //					<div class='selectedItem'>" + this.selectedValue + "</div>\
        //					<div class='arrow' style='height:"+ this._settings.dimension.height + "px;'>\
        //						<div class='icon' style='background-image: url(" + this._settings.arrowImage + ")'></div>\
        //					</div>\
        //				</div>\
        //				<div class='listBoxContainer hidden'></div>\
        //			</div>";
        //		this._settings.parentElement.insertAdjacentHTML("beforeend", template);
        //		this._initListBox();
        //		this.rescoComboBoxElement = <HTMLElement>this._settings.parentElement.getElementsByClassName("rescoComboBox")[0];
        //		this._labelElement = <HTMLElement>this.rescoComboBoxElement.getElementsByClassName("selectedItem")[0];
        //		if (!this._settings.showLabel) {
        //			this._labelElement.style.display = "none";
        //		}
        //		this._addEventListenerToRescoComboBox();
        //	}
        //	private _initListBox(): void {
        //		let appColors = new AppColors(); ///#FIXME remove from initialization use as setting or use default template
        //		this._listBox = new SimpleListBox(appColors);
        //		this._listBox.dataSource = this._settings.dataSource;
        //		this._listBox.displayMember = this._settings.displayMember;
        //		this._listBox.valueMember = this._settings.valueMember;
        //		this._listBoxElement = <HTMLElement>this._settings.parentElement.getElementsByClassName("listBoxContainer")[0];
        //		this._listBoxElement.appendChild(this._listBox.element[0]);
        //		this._listBox.selectionChanged.add(this, this._onListBoxSelectionChanged);
        //		this._changedClassesInListBox();
        //		this._listBoxMakeNewSelection();
        //	}
        //	private _listBoxMakeNewSelection(): void {
        //		for (let i = 0; i < this._listBox.items.length; i++) {
        //			if (this._listBox.items[i].label === this.selectedValue) {
        //				this._listBox.items[i].isSelected = true;
        //			}
        //			else {
        //				this._listBox.items[i].isSelected = false;
        //			}
        //		}
        //	}
        //	private _addEventListenerToRescoComboBox(): void {
        //		this.rescoComboBoxElement.addEventListener("click", (e) => {
        //			if (this._isListBoxVisible) {
        //				this.closeRescoComboBox();
        //			}
        //			else {
        //				this.openRescoComboBox();
        //			}
        //		});
        //	}
        //	private _addEventListenerToInvisibleLayer(): void {
        //		let invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
        //		invisibleDatePickerLayer.addEventListener("click", (e) => {
        //			this.closeRescoComboBox();
        //		});
        //	}
        //	private _removeEventListenerFromInvisibleLayer(): void {
        //		let invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
        //		document.body.removeChild(invisibleDatePickerLayer);
        //	}
        //	private _onListBoxSelectionChanged(sender: any, e: SelectionChangedEventArgs): void {
        //		let item = <SimpleListItem>e.changedItem;
        //		this._updateLabel(item.label);
        //		this._listBoxMakeNewSelection();
        //		this.valueChanged.raise(new ValueChangedEventArgs(item.label), this);
        //	} 
        //	private get selectedValue(): string {
        //		return this._settings.selectedValue;
        //	}
        //	private _changedClassesInListBox(): void {
        //		if (this._isListBoxVisible) {
        //			if (this._listBoxElement.classList.contains("hidden"))
        //				this._listBoxElement.classList.remove("hidden");
        //			this._listBoxElement.classList.add("visible");
        //		}
        //		else {
        //			if (this._listBoxElement.classList.contains("visible"))
        //				this._listBoxElement.classList.remove("visible");
        //			this._listBoxElement.classList.add("hidden");
        //		}
        //	}
        //	private _updateLabel(label: string): void {
        //		this._settings.selectedValue = label;
        //		this._labelElement.textContent = this.selectedValue;
        //	}
        //	////#FIXME move to another Utilities class
        //	private _generateID(id: string): void {
        //		let e = document.getElementById(id);
        //		if (e === null)
        //			this.id = id;
        //		else
        //			this._generateID(this._generateUniqueIdentifier());
        //	}
        //	////#FIXME move to another Utilities class
        //	private _generateUniqueIdentifier(): string {
        //		let identifier = Math.random().toString(16).slice(-5).toLowerCase();
        //		return identifier;
        //	}
        //}
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=listBox.js.map