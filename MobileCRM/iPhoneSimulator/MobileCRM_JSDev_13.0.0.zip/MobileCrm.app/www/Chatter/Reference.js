/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
var Chatter;
(function (Chatter) {
    var Reference = /** @class */ (function () {
        function Reference(id, name, entityname) {
            this.id = id;
            this.name = name;
            this.entityname = entityname;
        }
        return Reference;
    }());
    Chatter.Reference = Reference;
})(Chatter || (Chatter = {}));
//# sourceMappingURL=Reference.js.map