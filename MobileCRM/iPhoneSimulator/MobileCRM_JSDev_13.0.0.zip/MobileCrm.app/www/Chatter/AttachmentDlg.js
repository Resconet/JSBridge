/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="Localization.ts" />
var Chatter;
(function (Chatter) {
    var AttachmentDlg = /** @class */ (function () {
        function AttachmentDlg() {
            this.title = ko.observable();
            this.comment = ko.observable();
            this.imageUrl = ko.observable();
            this.visible = ko.observable();
        }
        AttachmentDlg.show = function (fileUrl, fileName, mimeType, title, comment, callback) {
            var dlg = AttachmentDlg.instance;
            dlg.imageUrl(fileUrl);
            dlg.fileName = fileName;
            dlg.mimeType = mimeType;
            dlg.title(title);
            dlg.comment(comment);
            dlg.callback = callback;
            dlg.visible(true);
        };
        AttachmentDlg.prototype.onClose = function () {
            this.visible(false);
        };
        AttachmentDlg.prototype.onSubmit = function () {
            this.visible(false);
            if (this.callback) {
                this.callback(this.title(), this.comment());
                this.callback = null;
            }
        };
        AttachmentDlg.prototype.onKeyPress = function (instance, event) {
            switch (event.charCode) {
                case 27:
                    this.onClose();
                    event.preventDefault();
                    break;
                case 13:
                    this.onSubmit();
                    event.preventDefault();
                    break;
            }
            return true;
        };
        AttachmentDlg.instance = new AttachmentDlg();
        return AttachmentDlg;
    }());
    Chatter.AttachmentDlg = AttachmentDlg;
})(Chatter || (Chatter = {}));
//# sourceMappingURL=AttachmentDlg.js.map