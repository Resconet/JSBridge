/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
var Chatter;
(function (Chatter) {
    var Localization = /** @class */ (function () {
        function Localization() {
        }
        Localization.init = function (table, options) {
            Localization._table = table;
            if (options) {
                if (options.time24hours)
                    Localization._time24hours = options.time24hours;
                if (options.timeDesignators)
                    Localization._timeDesignators = options.timeDesignators;
                if (options.monthNames)
                    Localization._monthNames = options.monthNames;
                if (options.dateOperators)
                    Localization._dateOperators = options.dateOperators;
            }
        };
        Localization.get = function (key) {
            return Localization._table[key] || key;
        };
        Localization.printTime = function (date) {
            if (date) {
                var h = date.getHours();
                var m = date.getMinutes();
                return Localization._time24hours ?
                    (h < 10 ? '0' : '') + h + ':' + (m < 10 ? '0' : '') + m :
                    ((h + 11) % 12 + 1) + ':' + (m < 10 ? '0' : '') + m + ' ' + Localization._timeDesignators[h >= 12 ? 1 : 0];
            }
            return '';
        };
        Localization.printDate = function (date) {
            return date ? date.toDateString() : ''; // TODO Localize format
        };
        Localization.printFriendlyDay = function (date) {
            if (date) {
                var dateMS = date.getTime();
                var now = new Date();
                var nowMS = now.getTime();
                if (now.getFullYear() != date.getFullYear())
                    return Localization.printDate(date); // print full date
                var todayMS = nowMS - nowMS % Localization.OneDayMS;
                var tomorrowMS = todayMS + Localization.OneDayMS;
                if (dateMS < todayMS - Localization.OneDayMS || dateMS > tomorrowMS + Localization.OneDayMS)
                    return Localization._monthNames[date.getMonth()] + " " + date.getDate(); // print month and day
                return Localization._dateOperators[dateMS < todayMS ? "Yesterday" : (dateMS < tomorrowMS ? "Today" : "Tomorrow")];
            }
            return '';
        };
        Localization.toLower = function (text) {
            return text ? text.toLocaleLowerCase() : text;
        };
        Localization._time24hours = false;
        Localization._timeDesignators = ["AM", "PM"];
        Localization._monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        Localization._dateOperators = { Today: "Today", Tomorrow: "Tomorrow", Yesterday: "Yesterday" };
        Localization.OneDayMS = 24 * 60 * 60 * 1000;
        return Localization;
    }());
    Chatter.Localization = Localization;
})(Chatter || (Chatter = {}));
//# sourceMappingURL=Localization.js.map