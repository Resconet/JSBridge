/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="Localization.ts" />
/// <reference path="MyRoute.ts" />
/// <reference path="RouteItem.ts" />
var RoutePlanner;
(function (RoutePlanner) {
    var ItemEditor = /** @class */ (function () {
        function ItemEditor() {
            this.titleBarCmdClick = null;
            this.footerCommandClick = null;
            this.buttonPopupItems = ko.observable();
            this.selectedValue = ko.observable();
            this.titleBarCmdImg = ko.observable("");
            this.titleBarCmdAlt = ko.observable("");
            this.footerCommand = ko.observable("");
            this.mode = ko.observable();
            this.mode.subscribe(function (newVal) {
                return setTimeout(function () {
                    return MobileCRM.bridge.invokeMethodAsync("RoutePlanView", "SetEditMode", [newVal ? true : false, $(document.body).height().toFixed()]);
                });
            });
        }
        ItemEditor.prototype.editItem = function (item) {
            var _this = this;
            if (this.mode())
                this.close();
            if (RoutePlanner.Configuration.instance.viewingMode)
                return;
            this.id = item.id;
            this.name = item.name;
            this.startDate = item.startDate;
            this.endDate = item.endDate;
            if (item.entity.isNew) {
                this.titleBarCmdImg("Cmd.Delete.png");
                this.titleBarCmdClick = item.delete.bind(item);
            }
            else
                this.createStatusMenu(item);
            var dirtyHandler = function (isDirty) {
                if (isDirty) {
                    _this.footerCommand(RoutePlanner.Localization.get("Cmd.Save"));
                    _this.footerCommandClick = item.save.bind(item);
                }
                else {
                    _this.footerCommand(RoutePlanner.Localization.get("Cmd.Edit"));
                    _this.footerCommandClick = item.showEntityForm.bind(item);
                    if (_this.titleBarCmdImg() == "Cmd.Delete.png")
                        _this.createStatusMenu(item);
                }
            };
            this._tmpSubscription = item.isDirty.subscribe(dirtyHandler, this);
            dirtyHandler(item.isDirty());
            this.mode("RouteItem");
        };
        ItemEditor.prototype.createStatusMenu = function (item) {
            var _this = this;
            var statusList = RoutePlanner.Configuration.instance.completionStatuses;
            if (statusList) {
                this.titleBarCmdImg("Cmd.Action.png");
                var items = new Array();
                var _loop_1 = function (status_1) {
                    items.push(new PopupItem(statusList[status_1], function () {
                        item.changeStatus(status_1);
                        _this.showMenu(null);
                    }));
                };
                for (var status_1 in statusList) {
                    _loop_1(status_1);
                }
                this.titleBarCmdClick = this.showMenu.bind(this, items);
            }
            else
                this.titleBarCmdImg("");
        };
        ItemEditor.prototype.editStartEnd = function (item) {
            var _this = this;
            if (this.mode())
                this.close();
            this.name = ko.observable(item.title);
            this.startDate = item.time;
            this.itemsSource = [0, 1, 2].map(function (id) { return { id: id, title: RoutePlanner.Localization.get(RoutePlanner.StartEndItem.keys[id]) }; });
            this.selectedValue(this.itemsSource[item.locationType()]);
            this.footerCommand(RoutePlanner.Localization.get("RoutePlanner.Set" + item.name + "Point"));
            this.footerCommandClick = function () {
                var type = _this.selectedValue().id;
                if (type != item.locationType()) {
                    item.locationType(type);
                    MobileCRM.bridge.command(item.itemType ? "endLocationChanged" : "startLocationChanged", type);
                }
                _this.close();
            };
            this._tmpSubscription = this.selectedValue.subscribe(function (newVal) { return _this.titleBarCmdAlt(newVal.id == 0 ? "" : RoutePlanner.Localization.get("RoutePlanner.Relocate")); });
            this.selectedValue.notifySubscribers(this.selectedValue());
            this.titleBarCmdImg("");
            this.titleBarCmdClick = function () {
                var type = _this.selectedValue().id;
                item.locationType(type);
                RoutePlanner.MyRoute.instance.grabLocation(item.itemType);
            };
            this.mode("StartEndItem");
        };
        ItemEditor.prototype.close = function () {
            if (this._tmpSubscription) {
                this._tmpSubscription.dispose();
                this._tmpSubscription = null;
            }
            if (ItemEditor._popupCloseHandler)
                this.showMenu(null);
            this.id = null;
            this.mode(null);
            this.titleBarCmdImg("");
            this.titleBarCmdAlt("");
            this.titleBarCmdClick = null;
            this.footerCommand("");
            this.footerCommandClick = null;
        };
        ItemEditor.prototype.showMenu = function (items) {
            var _this = this;
            this.buttonPopupItems(items);
            if (items) {
                ItemEditor._popupCloseHandler = function (e) {
                    if (!$(e.target).hasClass("buttonpopuplistitem"))
                        _this.showMenu(null);
                };
                document.addEventListener(RoutePlanner.DragHandler.startEvent, ItemEditor._popupCloseHandler);
            }
            else if (ItemEditor._popupCloseHandler) {
                document.removeEventListener(RoutePlanner.DragHandler.startEvent, ItemEditor._popupCloseHandler);
                ItemEditor._popupCloseHandler = null;
            }
        };
        return ItemEditor;
    }());
    RoutePlanner.ItemEditor = ItemEditor;
    var PopupItem = /** @class */ (function () {
        function PopupItem(text, onClick) {
            this.text = text;
            this.onClick = onClick;
        }
        return PopupItem;
    }());
})(RoutePlanner || (RoutePlanner = {}));
//# sourceMappingURL=ItemEditor.js.map