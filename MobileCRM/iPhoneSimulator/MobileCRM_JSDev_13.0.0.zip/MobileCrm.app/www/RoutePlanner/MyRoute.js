/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../Controls/datePicker.ts" />
/// <reference path="DragHandler.ts" />
/// <reference path="Localization.ts" />
/// <reference path="RouteItem.ts" />
/// <reference path="OtherItems.ts" />
/// <reference path="ItemEditor.ts" />
var RoutePlanner;
(function (RoutePlanner) {
    /**
     * Singleton instance implementing the RoutePlan root class
     */
    var MyRoute = /** @class */ (function () {
        function MyRoute() {
            var _this = this;
            this.editor = new RoutePlanner.ItemEditor();
            // Observables
            this.showFixAll = ko.observable(false);
            this.items = ko.observableArray().extend({ rateLimit: { timeout: 100, method: "notifyWhenChangesStop" } });
            this.totalTime = ko.observable();
            this.totalDistance = ko.observable();
            this.routeDate = ko.observable();
            this.editingRouteDay = ko.observable();
            this.canOptimize = function () {
                return this.totalDistance() && !Configuration.instance.viewingMode && this.items().length > 1;
            };
            this.startTime = ko.observable();
            this.startItem = new RoutePlanner.StartEndItem();
            this.endItem = new RoutePlanner.StartEndItem();
            this.dragHandler = new RoutePlanner.DragHandler(function (element, delta) { return MobileCRM.bridge.command('dragEntity', ko.dataFor(element[0]).id + "," + delta); });
            if (MobileCRM.bridge.platform == "Windows") {
                this.editingRouteDay.subscribe(function (editing) {
                    if (editing)
                        _this.showDatePicker(document.getElementById("dateCell").parentElement);
                }, this);
            }
        }
        MyRoute.Run = function () {
            RoutePlanner.Localization.load();
            Configuration.load(function () {
                var myRoute = MyRoute.instance;
                myRoute.init();
                ko.applyBindings(myRoute);
                MobileCRM.bridge.invokeMethodAsync("WebController", "Reload", []);
            });
        };
        MyRoute.prototype.init = function () {
            var _this = this;
            /// <summary>Initial entry point for specifying the start/end entity fields</summary>
            var config = Configuration.instance;
            this.startItem.init(0, this.startTime);
            this.endItem.init(1, ko.computed(function () {
                var endRoute = _this.endItem.routeStep();
                var items = _this.items();
                if (endRoute && items && items.length) {
                    var lastItem = items[items.length - 1];
                    var lastEnd = lastItem.endDate();
                    return new Date(lastEnd.getTime() + (endRoute.travelTime + 59) * 1000);
                }
            }, this));
            this.endItem.timeText.subscribe(this.updateOverview, this);
            this.startItem.locationType(config.startType);
            this.endItem.locationType(config.endType);
        };
        /******* Interface methods (called from native app) ********/
        MyRoute.prototype.reload = function (routeDay, entityToSelect) {
            var _this = this;
            /// <summary>Entry point initiating the data reload.</summary>
            this.totalDistance(null);
            this.totalTime(null);
            this.routeDate(RoutePlanner.Localization.dateToInputString(routeDay));
            routeDay.setMinutes(Configuration.instance.startTime);
            this.startTime(routeDay);
            this.endItem.routeStep(new RouteStep(Number.NaN, Number.NaN));
            MobileCRM.bridge.command("getData", "", function (entities) { return _this.onGotData(entities, entityToSelect); }, RoutePlanner.Localization.onError, this);
            if (!this.routeDateSbscr)
                this.routeDateSbscr = this.routeDate.subscribe(function (newDate) { return MobileCRM.bridge.command("changeStartTime", newDate + "T" + _this.getStartTime()); }, this);
            ;
        };
        MyRoute.prototype.onGotData = function (entities, idToSelect) {
            var _this = this;
            var nEntities = entities.length;
            var items = new Array();
            var prevEnd = this.startTime;
            var itemToEdit = null;
            for (var i = 0; i < nEntities; i++) {
                var e = entities[i];
                var newItem = new RoutePlanner.RouteItem(e, prevEnd);
                if (e.id == idToSelect)
                    itemToEdit = newItem;
                items.push(newItem);
                newItem.hasConflict.subscribe(function (newVal) { return _this.showFixAll(newVal || _this.items().some(function (item) { return item.hasConflict(); })); }, this);
                prevEnd = newItem.endDate;
            }
            this.items(items);
            this.updateOverview();
            if (itemToEdit)
                itemToEdit.onClick();
        };
        MyRoute.prototype.updateItinerary = function (itinerary, start) {
            this.totalTime(RoutePlanner.Localization.secondsToText(itinerary.totalTime));
            this.totalSeconds = itinerary.totalTime;
            this.totalDistance(RoutePlanner.Localization.metersToText(itinerary.totalDistance));
            var items = this.items();
            var updateStart = this.items.length > 1;
            var steps = itinerary.steps;
            for (var i = 0; i < steps.length; i++) {
                var it = steps[i];
                if (!it)
                    break;
                var itIndex = i + start;
                if (itIndex < items.length) {
                    var itItem = items[itIndex];
                    itItem.routeDistance(it.distance);
                    itItem.routeTravelTime(it.travelTime);
                }
                else if (items.length > 0) {
                    this.endItem.routeStep(it);
                }
            }
            this.updateOverview();
        };
        MyRoute.prototype.updateOverview = function (endTime) {
            var nAppts = this.items().length;
            var text = nAppts.toString() + " " + (nAppts == 1 ? Configuration.instance.routeEntityName : Configuration.instance.routeEntityPlural);
            var start = this.startItem.timeText();
            var end = this.endItem.timeText();
            if (start && end)
                text += " (" + start + " - " + end + ")";
            if (this.totalDistance())
                text += "\n" + RoutePlanner.Localization.get('RoutePlanner.TotalDistance') + ": " + this.totalDistance() + " / " + RoutePlanner.Localization.get('RoutePlanner.DrivingTime') + ": " + this.totalTime();
            MobileCRM.bridge.invokeMethodAsync("RoutePlanView", "set_OverviewText", [text]);
        };
        MyRoute.prototype.getStartTime = function () {
            return RoutePlanner.Localization.formatDate(this.startTime(), 24); //$("#startTimeInput").val();
        };
        MyRoute.prototype.editEntity = function (id) {
            if (id) {
                if (this.editor.id != id) {
                    var items = this.items();
                    for (var i = 0; i < items.length; i++) {
                        var item = items[i];
                        if (item.id == id) {
                            this.editor.editItem(item);
                        }
                    }
                }
            }
            else if (this.editor.id)
                this.editor.close();
        };
        MyRoute.prototype.updateTimeField = function (index, start, time) {
            var item = this.items()[index];
            var observable = start ? item.startDate : item.endDate;
            if (observable().getTime() != time.getTime())
                observable(time);
        };
        MyRoute.prototype.updateNameField = function (index, name) {
            var item = this.items()[index];
            if (item.name() != name)
                item.name(name);
        };
        MyRoute.prototype.resetDirtyFlags = function () {
            this.items().forEach(function (item, index, arr) {
                item.entity.isNew = false;
                item.isDirty(false);
            });
        };
        MyRoute.prototype.onOptimize = function () {
            MobileCRM.bridge.command("onOptimize", this.totalSeconds, this.onOptimizationFinished, MobileCRM.bridge.alert, this);
        };
        MyRoute.prototype.onOptimizationFinished = function (data) {
            //this.startTime = data;
        };
        MyRoute.prototype.showDatePicker = function (parent) {
            var _this = this;
            if (!this._datePicker) {
                var settings = {
                    firstWeekDay: 0,
                    actualDate: new Date(),
                    dayNames: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                    images: [window['_imageCache']['Controls.arrow_left.png'], window['_imageCache']['Controls.arrow_right.png']],
                    platform: MobileCRM.bridge.platform
                };
                this._datePicker = new Resco.Controls.RescoDatePicker(settings, parent, false);
            }
            this._datePicker.parentElement = parent;
            this._datePicker.updateDefaultValue(new Date(this.routeDate()));
            this._datePicker.showRescoDatePicker();
            this._datePicker.updatePosition(parent.offsetTop + parent.offsetHeight, (document.body.clientWidth - this._datePicker.getDimension().width) / 2, undefined, true);
            this._datePicker.datePickerClicked.add(this, function (sender, e) {
                _this.routeDate(RoutePlanner.Localization.dateToInputString(e.item.date));
                _this.hideDatePicker();
            });
            this._datePicker.datePickerBlur.add(this, function (e) { return _this.hideDatePicker(); });
        };
        MyRoute.prototype.hideDatePicker = function () {
            this._datePicker.hideRescoDatePicker();
            this._datePicker.datePickerClicked.clear();
            this._datePicker.datePickerBlur.clear();
        };
        /******* Helper methods ********/
        /**
         * Calls the native code to change Home/Work location on the map (user will choose it).
         * @param type 1=Home; 2=Work
         */
        MyRoute.prototype.grabLocation = function (type) {
            MobileCRM.bridge.command("grabLocation", type + "," + this.startItem.locationType() + "," + this.endItem.locationType());
        };
        /**
         * FixAll button click handler. Calls the native code to solve all time conflicts (it moves items' start/end values).
         */
        MyRoute.prototype.fixAll = function () {
            MobileCRM.bridge.command('fixall', this.getStartTime(), function (data) {
                for (var i = 0; i < data.length; i++) {
                    var rec = data[i];
                    var index = rec[0];
                    var items = this.items();
                    if (index < items.length) {
                        var item = items[index];
                        item.startDate(rec[1]);
                        item.endDate(rec[2]);
                    }
                }
            }, null, this);
        };
        MyRoute.instance = new MyRoute();
        return MyRoute;
    }());
    RoutePlanner.MyRoute = MyRoute;
    /**
     * Represents the configuration class. Singleton carries the default values and settings from the RoutePlan setup.
     */
    var Configuration = /** @class */ (function () {
        function Configuration() {
        }
        Configuration.load = function (onLoaded) {
            MobileCRM.bridge.command("getConfig", null, function (config) {
                Configuration.instance = config;
                if (Configuration.instance.dpiCoef) {
                    /// <summary>Entry point for fixing the custom Android DPI.</summary>
                    var coef = Configuration.instance.dpiCoef;
                    var fontSize = coef.toString() + "em";
                    $(document.body).css("font-size", fontSize);
                    fontSize = (coef * 0.8).toString() + "em";
                    $('input').css("font-size", fontSize);
                    $('select').css("font-size", fontSize);
                    $('button').css("font-size", fontSize);
                }
                if (onLoaded)
                    onLoaded();
            }, MobileCRM.bridge.alert);
        };
        return Configuration;
    }());
    RoutePlanner.Configuration = Configuration;
    var Itinerary = /** @class */ (function () {
        function Itinerary() {
        }
        return Itinerary;
    }());
    RoutePlanner.Itinerary = Itinerary;
    var RouteStep = /** @class */ (function () {
        function RouteStep(travelTime, distance) {
            this.travelTime = travelTime;
            this.distance = distance;
        }
        return RouteStep;
    }());
    RoutePlanner.RouteStep = RouteStep;
})(RoutePlanner || (RoutePlanner = {}));
//# sourceMappingURL=MyRoute.js.map