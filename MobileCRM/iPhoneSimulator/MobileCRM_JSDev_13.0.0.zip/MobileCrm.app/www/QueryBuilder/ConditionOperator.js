var FetchQueryBuilder;
(function (FetchQueryBuilder) {
    var ConditionOperator = /** @class */ (function () {
        function ConditionOperator() {
        }
        /**
         * Gets the value of the condition according to the passed in key
         * @param key The key to look for
         */
        ConditionOperator.getValue = function (key) {
            var rVal = null;
            for (var cond in ConditionOperator.operators) {
                if (ConditionOperator.operators[cond].Key === key) {
                    rVal = ConditionOperator.operators[cond].Value;
                    break;
                }
            }
            return rVal;
        };
        /**
         * Gets the condition according to the operator
         * @param operator Name of the key or value of the condition
         */
        ConditionOperator.getOperator = function (operator) {
            for (var cond in ConditionOperator.operators) {
                if (ConditionOperator.operators[cond].Key === operator || ConditionOperator.operators[cond].Value == operator) {
                    return ConditionOperator.operators[cond];
                }
            }
            return null;
        };
        /**
         * Gets the group operators
         * @param group Name of the group
         */
        ConditionOperator.getOperators = function (group) {
            var list = [];
            for (var prop in ConditionOperator.operators) {
                if (ConditionOperator.operators.hasOwnProperty(prop)) {
                    var op = ConditionOperator.operators[prop];
                    if (op.Group === group) {
                        list.push(op);
                    }
                }
                else {
                    console.log("");
                }
            }
            return list;
        };
        ConditionOperator.getArity = function (operator) {
            for (var prop in ConditionOperator.operators) {
                if (ConditionOperator.operators.hasOwnProperty(prop)) {
                    var op = ConditionOperator.operators[prop];
                    if (op && (op.Value === operator || op.Key === operator) && op.Arity === 0) {
                        return 0;
                    }
                }
            }
            return 1;
        };
        /**
         * Gets the wildcards for the string conditions
         * @param operator Name of the key or value
         */
        ConditionOperator.getWildcards = function (operator) {
            var wildcards = {
                WildcardStart: "",
                WildcardEnd: ""
            };
            for (var prop in ConditionOperator.operators) {
                if (ConditionOperator.operators.hasOwnProperty(prop)) {
                    var op = ConditionOperator.operators[prop];
                    if (op && (op.Value === operator || op.Key === operator)) {
                        if (op.WildcardStart) {
                            wildcards.WildcardStart = op.WildcardStart;
                        }
                        if (op.WildcardEnd) {
                            wildcards.WildcardEnd = op.WildcardEnd;
                        }
                        return wildcards;
                    }
                }
            }
            return wildcards;
        };
        ConditionOperator.operators = {
            Equal: { Key: "Equals", Value: "eq", Group: "EqOps" },
            NotEqual: { Key: "Does Not Equal", Value: "ne", Group: "EqOps" },
            GreaterThan: { Key: "Is Greater Than", Value: "gt", Group: "NumberOps" },
            LessThan: { Key: "Is Less Than", Value: "lt", Group: "NumberOps" },
            GreaterEqual: { Key: "Is Greater Than or Equal To", Value: "ge", Group: "NumberOps" },
            LessEqual: { Key: "Is Less Than or Equal To", Value: "le", Group: "NumberOps" },
            BeginWith: { Key: "Begins With", Value: "like", Group: "TextOps", WildcardEnd: "%" },
            NotBeginWith: { Key: "Does Not Begin With", Value: "not-like", Group: "TextOps", WildcardEnd: "%" },
            EndWith: { Key: "Ends With", Value: "like", Group: "TextOps", WildcardStart: "%" },
            NotEndWith: { Key: "Does Not End With", Value: "not-like", Group: "TextOps", WildcardStart: "%" },
            Contain: { Key: "Contains", Value: "like", Group: "TextOps", WildcardStart: "%", WildcardEnd: "%" },
            NotContain: { Key: "Does Not Contain", Value: "not-like", Group: "TextOps", WildcardStart: "%", WildcardEnd: "%" },
            Null: { Key: "Does Not Contain Data", Value: "null", Arity: 0 },
            NotNull: { Key: "Contains Data", Value: "not-null", Arity: 0 },
            DateOn: { Key: "On", Value: "on", Group: "DateOps" },
            DateOnOrAfter: { Key: "On or After", Value: "on-or-after", Group: "DateOps" },
            DateOnOrBefore: { Key: "On or Before", Value: "on-or-before", Group: "DateOps" },
            DateToday: { Key: "Today", Value: "today", Group: "DateOps", Arity: 0 },
            DateYesterday: { Key: "Yesterday", Value: "yesterday", Group: "DateOps", Arity: 0 },
            DateTomorrow: { Key: "Tomorrow", Value: "tomorrow", Group: "DateOps", Arity: 0 },
            DateThisMonth: { Key: "This Month", Value: "this-month", Group: "DateOps", Arity: 0 },
            DateLastMonth: { Key: "Last Month", Value: "last-month", Group: "DateOps", Arity: 0 },
            DateNextMonth: { Key: "Next Month", Value: "next-month", Group: "DateOps", Arity: 0 },
            DateThisWeek: { Key: "This Week", Value: "this-week", Group: "DateOps", Arity: 0 },
            DateLastWeek: { Key: "Last Week", Value: "last-week", Group: "DateOps", Arity: 0 },
            DateNextWeek: { Key: "Next Week", Value: "next-week", Group: "DateOps", Arity: 0 },
            DateThisYear: { Key: "This Year", Value: "this-year", Group: "DateOps", Arity: 0 },
            DateLastYear: { Key: "Last Year", Value: "last-year", Group: "DateOps", Arity: 0 },
            DateNextYear: { Key: "Next Year", Value: "next-year", Group: "DateOps", Arity: 0 },
            OlderThanXHours: { Key: "Older Than X Hours", Value: "olderthan-x-hours", Group: "DateOps" },
            OlderThanXDays: { Key: "Older Than X Days", Value: "olderthan-x-days", Group: "DateOps" },
            OlderThanXWeeks: { Key: "Older Than X Weeks", Value: "olderthan-x-weeks", Group: "DateOps" },
            OlderThanXMonths: { Key: "Older Than X Months", Value: "olderthan-x-months", Group: "DateOps" },
            OlderThanXYears: { Key: "Older Than X Years", Value: "olderthan-x-years", Group: "DateOps" },
            LastXDays: { Key: "Last X Days", Value: "last-x-days", Group: "DateOps" },
            NextXDays: { Key: "Next X Days", Value: "next-x-days", Group: "DateOps" },
            LastXWeeks: { Key: "Last X Weeks", Value: "last-x-weeks", Group: "DateOps" },
            NextXWeeks: { Key: "Next X Weeks", Value: "next-x-weeks", Group: "DateOps" },
            LastXMonths: { Key: "Last X Months", Value: "last-x-months", Group: "DateOps" },
            NextXMonths: { Key: "Next X Months", Value: "lext-x-months", Group: "DateOps" },
            LastXYears: { Key: "Last X Years", Value: "last-x-years", Group: "DateOps" },
            NextXYears: { Key: "Next X Years", Value: "next-x-years", Group: "DateOps" },
            LastXHours: { Key: "Last X Hours", Value: "last-x-hours", Group: "DateOps" },
            NextXHours: { Key: "Next X Hours", Value: "next-x-hours", Group: "DateOps" },
            EqualCustomer: { Key: "Equals Current Customer", Value: "eq-customerid", Arity: 0 },
            EqualCustomerUser: { Key: "Equals Customer User", Value: "eq-customeruserid", Arity: 0 },
            In: { Key: "In", Value: "in", Group: "InOps" },
            NotIn: { Key: "Not In", Value: "not-in", Group: "InOps" },
            EqualUser: { Key: "Equals Current User", Value: "eq-userid", Arity: 0 },
            NotEqualUser: { Key: "Does Not Equal Current User", Value: "ne-userid", Arity: 0 },
            EqualUserTeam: { Key: "Equals Current Team", Value: "eq-userteams", Arity: 0 },
            EqualUserOrUserTeam: { Key: "Equals Current User Or Team", Value: "eq-useroruserteams", Arity: 0 },
            EqualBusinessUnit: { Key: "Equals Current Business Unit", Value: "eq-businessid", Arity: 0 },
            NotEqualBusinessUnit: { Key: "Does Not Equal Current Business Unit", Value: "ne-businessid", Arity: 0 }
        };
        return ConditionOperator;
    }());
    FetchQueryBuilder.ConditionOperator = ConditionOperator;
})(FetchQueryBuilder || (FetchQueryBuilder = {}));
//# sourceMappingURL=ConditionOperator.js.map