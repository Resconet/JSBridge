﻿///<reference path="../TypeScriptDefinitions/knockout.d.ts" />

function writeTemplates() {
    var addTemplate = function (templateName, templateMarkup) {
        document.write("<script type='text/html' id='" + templateName + "'>" + templateMarkup + "<" + "/script>");
    };

    addTemplate("dashboardsDesigner",
	"<div class='designer' data-bind='style: { height: size.height() + \"px\", backgroundColor: formBackgroundColor  }' >\
		<div class='header' data-bind='style: { backgroundColor: titleBackgroundColor, color: $root.titleForegroundColor }' >\
			<div class='backButton backArrow' data-bind='click: closeDesigner, style: { backgroundImage: backArrowImg }'></div>\
			<div class='designerName'><span data-bind='text: designerLabel'></span></div>\
            <div class='addDashboardButton' data-bind='click: $root.addNewDashboard, style: {backgroundImage: addButtonImg }'></div>\
		</div>\
		<div id='content' class='content' data-bind='style: { height: size.contentHeight() + \"px\"}'>\
			<!-- ko if: dashboards().length == 0 -->\
				<div class='emptyDesigner' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForeground }'>\
					<div data-bind='text: noData'></div>\
				</div>\
			<!-- /ko -->\
			<!-- ko foreach: dashboards -->\
                <div class='separator' data-bind='style: {backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='dashboardItem' data-bind='style: { backgroundColor: $parent.formItemBackgroundColor }'>\
					<!-- ko ifnot: $data.isEdited() -->\
						<div class='name text' data-bind='text: $data.name, click: function(data, event){ $root.openSelectedDashboard(data, event) }, style: { color: $root.formItemLabelForeground }'></div>\
                        <div class='contextMenuButton' data-bind='click: $root.openContextMenu.bind($root), style: { backgroundImage: $root.actionButtonImg }'></div>\
					<!-- /ko -->\
					<!-- ko if: $data.isEdited() -->\
						<input id='dashboardInputField' class='editedName' data-bind='value: $data.name, style: { color:$root.formItemLabelForeground, borderColor: $root.formItemLabelForeground }' type='text' placeholder='Add new dashboard name.' />\
						<div class='editButton' data-bind='click: function(data, event){ $root.saveEditedDashboardList($index(), data, event)}, style: {backgroundImage: $root.finishEditButtonImg }'></div>\
					<!-- /ko -->\
				</div>\
			<!-- /ko -->\
		</div>\
        <!-- ko if: $root.contextMenu.enabled() -->\
            <!-- ko template: { name: \"contextMenu\", data: contextMenu } --><!-- /ko -->\
            <div class='backend' data-bind='style: { height: $root.size.contentHeight() + \"px\", width: $root.size.width() + \"px\" }, click:$root.closeContext.bind($root) '></div>\
        <!-- /ko-->\
	</div>\
	");

    addTemplate("contextMenu",
	"<div class='contextMenu' data-bind='style: { top: topPosition() + \"px\", left: leftPosition() + \"px\" , borderColor: $root.formBackgroundColor }'>\
        <div class='contextMenuItem' data-bind='style: {backgroundColor: $root.formItemBackgroundColor }, click: function(data, event){$root.editDashboardItem()}' >\
            <div class='imageMenuItem' data-bind='style: {backgroundImage: $root.editButtonImg }' ></div>\
            <div class='labelMenuItem text' data-bind='text: labelRename, style: { color: $root.formItemLabelForeground } '></div>\
        </div>\
        <div class='separator' data-bind='style: {backgroundColor: $root.formBackgroundColor }'></div>\
        <div class='contextMenuItem' data-bind='style: {backgroundColor: $root.formItemBackgroundColor }, , click: function(selectedItem, data, event) { $root.removeDashboard() } ' >\
            <div class='imageMenuItem' data-bind='style: {backgroundImage: $root.deleteButtonImg }' ></div>\
            <div class='labelMenuItem text' data-bind='text: labelDelete, style: { color: $root.formItemLabelForeground }'></div>\
        </div>\
    </div>\
    ");
}


/**Main function that loads templates*/
(function () {
    writeTemplates();

    var templateEngine = ko.nativeTemplateEngine.instance;

    ko.bindingHandlers.row = {
        update: function (element, valueAccessor) {
            ko.renderTemplate("dashboardsDesigner", valueAccessor(), { templateEngine: ko.nativeTemplateEngine.instance }, element, "replaceNode");
        }
    }
}());