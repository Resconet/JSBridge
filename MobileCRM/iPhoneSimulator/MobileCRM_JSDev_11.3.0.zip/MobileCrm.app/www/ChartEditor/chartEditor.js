/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path='../Controls/event.ts' />
/// <reference path='../Controls/comboBox.ts' />
/// <reference path='../Controls/controls.ts' />
var ChartEditor;
(function (ChartEditor) {
    "use strict";
    /**
     * Class for representation of series, with all fields which series has.
     */
    var Series = (function () {
        function Series(seriesData, serializedAggregators) {
            var _this = this;
            this.seriesColor = ko.observable();
            this.seriesColor(seriesData.color);
            this.seriesColor.subscribe(function (value) {
                if (seriesData.color !== value)
                    Chart.isDirty(true);
            }, this, "beforeChange");
            this.id = seriesData.id;
            this.isNumeric = ko.observable(false);
            this.seriesField = seriesData.attribute;
            this.aggregation = ko.observable();
            this.aggregation({
                label: "",
                id: seriesData.aggregation.toString(),
            });
            this.allAggregators = ko.observableArray();
            this.countAggregators = ko.observableArray();
            this._initLimits();
            this.limitValue = ko.observable(seriesData.limit); // TODO : fix loading from saved data.
            this.limitCountEnabled = ko.computed(function () {
                return _this.limitValue() !== ChartLimit.None;
            });
            this.updateAggregation = function (args) {
                var item = args.changedItem;
                _this.aggregation(item);
                if (args.status)
                    Chart.isDirty(true);
            };
            this.updateSeriesField = function (args) {
                if (args.changedItems.length === 1) {
                    for (var _i = 0, _a = args.changedItems; _i < _a.length; _i++) {
                        var item = _a[_i];
                        var field = item.changedItem;
                        _this.isNumeric(_this._isNumeric(field.type));
                        if (!item.status)
                            _this._makeInitAggregators(serializedAggregators);
                        else
                            Chart.isDirty(true);
                        _this.seriesField = field.id;
                        // update aggregation to correct index
                        _this._changeAggregationAfterChangeField();
                    }
                }
                else if (args.changedItems.length > 1) {
                    var seriesItems = new Array();
                    var statusChanged = false;
                    for (var _b = 0, _c = args.changedItems; _b < _c.length; _b++) {
                        var item = _c[_b];
                        var field = item.changedItem;
                        if (field.target === "") {
                            _this.isNumeric(_this._isNumeric(field.type));
                            seriesItems.push(field.id);
                            statusChanged = item.status;
                        }
                        else {
                            seriesItems.push(field.id);
                            seriesItems.push(field.target);
                        }
                    }
                    _this.seriesField = seriesItems.join(".");
                    if (statusChanged)
                        Chart.isDirty(true);
                    else
                        _this._makeInitAggregators(serializedAggregators);
                    _this._changeAggregationAfterChangeField();
                }
            };
        }
        Series.prototype._changeAggregationAfterChangeField = function () {
            if (!this.isNumeric()) {
                var indexFound = false;
                for (var _i = 0, _a = this.countAggregators(); _i < _a.length; _i++) {
                    var agg = _a[_i];
                    indexFound = this.aggregation().id === agg.id;
                }
                if (!indexFound)
                    this.aggregation(this.countAggregators()[0]);
            }
        };
        Series.prototype._makeInitAggregators = function (serializedAggregators) {
            this.allAggregators(this._initAggregators(serializedAggregators[0]));
            this.countAggregators(this._initAggregators(serializedAggregators[1]));
        };
        /**
         * Public static method to serialize input series parameter to array of the strings.
         * @param series object that will be serialized to array of the strings.
         */
        Series.serialize = function (serie) {
            var serieProperites = Array();
            serieProperites.push(serie.seriesField);
            serieProperites.push(serie.seriesColor());
            serieProperites.push(serie.limitValue().toString());
            serieProperites.push(serie.aggregation().id);
            return serieProperites;
        };
        Series.prototype._initAggregators = function (serializedAggregators) {
            var result = new Array();
            for (var agg in serializedAggregators) {
                var cb = {
                    label: agg,
                    id: serializedAggregators[agg].toString(),
                };
                result.push(cb);
                if (cb.id === this.aggregation().id)
                    this.aggregation().label = agg;
            }
            return result;
        };
        Series.prototype._initLimits = function () {
            this.limits = new Array();
            var count = 3;
            for (var i = 0; i < count; i++) {
                this.limits.push({ label: ChartLimit[i], id: this.id, });
            }
        };
        Series.prototype._isNumeric = function (fieldType) {
            if (fieldType == Resco.Controls.CrmType.Integer || fieldType == Resco.Controls.CrmType.Decimal || fieldType == Resco.Controls.CrmType.Double || fieldType == Resco.Controls.CrmType.Money
                || fieldType == Resco.Controls.CrmType.Float || fieldType == Resco.Controls.CrmType.BigInt)
                return true;
            return false;
        };
        return Series;
    }());
    ChartEditor.Series = Series;
    /**
     * Editor field type used for chart axis.
     */
    var FieldType = (function () {
        /**
         * Constructor of field type.
         */
        function FieldType() {
            this.fieldType = ko.observable();
        }
        return FieldType;
    }());
    /**
     * Class represents special properties of the Gauge chart kind.
     */
    var GaugeValueEntity = (function () {
        /**
         * A public constructor for object of the chart gauge special field.
         * @param hasColor Boolean value enables color picker for this field.
         * @param aggregation Default value for aggregation comboBox.
         * @param serializedAggregators
         */
        function GaugeValueEntity(hasColor, serializedAggregators, aggregation) {
            var _this = this;
            this.hasColor = hasColor;
            this.isNumeric = ko.observable();
            this.constantValue = ko.observable(0);
            this.aggregation = ko.observable();
            this.aggregation({
                label: "",
                id: aggregation !== undefined ? aggregation.toString() : "0",
            });
            this.allAggregators = ko.observableArray();
            this.countAggregators = ko.observableArray();
            this.targetColor = ko.observable();
            this.targetColor("");
            this.targetValue = "";
            this.updateTargetValue = function (args) {
                if (args.changedItems.length === 1) {
                    for (var _i = 0, _a = args.changedItems; _i < _a.length; _i++) {
                        var item = _a[_i];
                        var field = item.changedItem;
                        _this.isNumeric(_this._isNumeric(field.type));
                        if (!item.status) {
                            _this.allAggregators(_this._initAggregators(serializedAggregators[0]));
                            _this.countAggregators(_this._initAggregators(serializedAggregators[1]));
                        }
                        else {
                            Chart.isDirty(true);
                        }
                        _this.targetValue = field.id;
                        // update aggregation to correct index
                        _this._changeAggregationAfterChangeField();
                    }
                }
                else if (args.changedItems.length > 1) {
                    var targetValues = new Array();
                    var statusChanged = false;
                    for (var _b = 0, _c = args.changedItems; _b < _c.length; _b++) {
                        var item = _c[_b];
                        var field = item.changedItem;
                        if (field.target === "") {
                            _this.isNumeric(_this._isNumeric(field.type));
                            targetValues.push(field.id);
                            statusChanged = item.status;
                        }
                        else {
                            targetValues.push(field.id);
                            targetValues.push(field.target);
                        }
                    }
                    _this.targetValue = targetValues.join(".");
                    if (statusChanged)
                        Chart.isDirty(true);
                    else {
                        _this.allAggregators(_this._initAggregators(serializedAggregators[0]));
                        _this.countAggregators(_this._initAggregators(serializedAggregators[1]));
                    }
                    _this._changeAggregationAfterChangeField();
                }
            };
            this.type = new Array();
            var labels = ["Entity", "Constant"];
            this.type = labels;
            this.selectedType = ko.observable();
            this.selectedType(this.type[0]);
            this.isConstant = ko.computed(function () {
                return _this.selectedType() === _this.type[1];
            });
            this.updateType = function (args) {
                _this.selectedType(args.changedItem);
                if (args.status)
                    Chart.isDirty(true);
            };
            this.updateAggregation = function (args) {
                var item = args.changedItem;
                _this.aggregation(item);
                if (args.status)
                    Chart.isDirty(true);
            };
        }
        /**
         * Public method serializes the gauge field value into array of the string.
         */
        GaugeValueEntity.prototype.serialize = function () {
            var data = new Array();
            if (this.isConstant()) {
                data.push(this.constantValue().toString());
            }
            else {
                data.push(this.targetValue);
                data.push(this.aggregation().id);
            }
            if (this.hasColor) {
                data.push(this.targetColor());
            }
            return data;
        };
        GaugeValueEntity.prototype._changeAggregationAfterChangeField = function () {
            if (!this.isNumeric()) {
                var indexFounded = false;
                for (var _i = 0, _a = this.countAggregators(); _i < _a.length; _i++) {
                    var agg = _a[_i];
                    indexFounded = this.aggregation().id === agg.id;
                }
                if (!indexFounded)
                    this.aggregation(this.countAggregators()[0]);
            }
        };
        GaugeValueEntity.prototype._initAggregators = function (serializedAggregators) {
            var result = new Array();
            for (var agg in serializedAggregators) {
                var cb = {
                    label: agg,
                    id: serializedAggregators[agg].toString(),
                };
                result.push(cb);
                if (cb.id === this.aggregation().id)
                    this.aggregation().label = agg;
            }
            return result;
        };
        GaugeValueEntity.prototype._isNumeric = function (fieldType) {
            if (fieldType == Resco.Controls.CrmType.Integer || fieldType == Resco.Controls.CrmType.Decimal || fieldType == Resco.Controls.CrmType.Double || fieldType == Resco.Controls.CrmType.Money
                || fieldType == Resco.Controls.CrmType.Float || fieldType == Resco.Controls.CrmType.BigInt)
                return true;
            return false;
        };
        return GaugeValueEntity;
    }());
    ChartEditor.GaugeValueEntity = GaugeValueEntity;
    /**
     * Class represents chart item.
     */
    var Chart = (function () {
        /**
         * A public constructor for Chart object.
         */
        function Chart() {
            var _this = this;
            this.chartId = '';
            Chart.isDirty = ko.observable(false);
            this.entityName = ko.observable();
            this.name = ko.observable();
            this.name.subscribe(function (value) {
                if (value !== undefined)
                    Chart.isDirty(true);
            }, this, "beforeChange");
            this.axisField = new FieldType();
            this.updateAxisField = function (args) {
                if (args.changedItems.length === 1) {
                    for (var _i = 0, _a = args.changedItems; _i < _a.length; _i++) {
                        var item = _a[_i];
                        var field_1 = item.changedItem;
                        if (item.status)
                            Chart.isDirty(true);
                        _this.axisField.displayName = field_1.label;
                        _this.axisField.logicalName = field_1.id;
                        _this.axisField.fieldType(field_1.type);
                        if (_this.axisField.fieldType() !== Resco.Controls.CrmType['DateTime'])
                            _this.dateGroupItem = { label: DateGroupingKind[0], id: DateGroupingKind[0], };
                    }
                }
                else if (args.changedItems.length > 1) {
                    var items = new Array();
                    var statusChanged = false;
                    for (var _b = 0, _c = args.changedItems; _b < _c.length; _b++) {
                        var item = _c[_b];
                        var field = item.changedItem;
                        if (field.target === "") {
                            items.push(field.id);
                            _this.axisField.displayName = field.label;
                            _this.axisField.fieldType(field.type);
                            statusChanged = item.status;
                        }
                        else {
                            items.push(field.id);
                            items.push(field.target);
                        }
                    }
                    _this.axisField.logicalName = items.join(".");
                    if (statusChanged)
                        Chart.isDirty(true);
                    if (_this.axisField.fieldType() !== Resco.Controls.CrmType['DateTime'])
                        _this.dateGroupItem = { label: DateGroupingKind[0], id: DateGroupingKind[0], };
                }
            };
            this.limitCount = ko.observable(3);
            this.limitCount.subscribe(function (value) {
                if (value !== 3 || (_this.originalChartData && value !== _this.originalChartData[5])) {
                    Chart.isDirty(true);
                }
            }, this, "beforeChange");
            this.updateSeriesLimits = function (args) {
                var chartLimitItem = args.changedItem;
                for (var _i = 0, _a = _this.series(); _i < _a.length; _i++) {
                    var series = _a[_i];
                    if (series.id === chartLimitItem.id) {
                        series.limitValue(ChartLimit[chartLimitItem.label]);
                        Chart.isDirty(true);
                    }
                    else
                        series.limitValue(ChartLimit.None);
                }
            };
            this.drillDownFields = new Array();
            this.drillDownAvailableItems = new Array();
            this.updateDrillDownField = function (args) {
                _this.drillDownFields = args.changedItems.map(function (i) { var item = i.changedItem; return item.id; });
                Chart.isDirty(true);
            };
            this.updateDateGroupItems = function (args) {
                var item = args.changedItem;
                _this.dateGroupItem = item;
                if (args.status)
                    Chart.isDirty(true);
            };
            this.chartStyle = ko.observableArray();
            this.chartDonutRatioEnabled = ko.observable();
            this.chartDonutRatio = ko.observable(0);
            this.visibleStyle = ko.observable();
            this.updateKindsSelection = function (data) {
                var icon = _this.kinds.filter(function (i) { return i.name === data.name; });
                icon[0].selected(true);
                _this._changeChartSettingsProperties(EntityChartKind[icon[0].name]);
                _this.isGauge(EntityChartKind[icon[0].name] === EntityChartKind.Gauge);
                Chart.isDirty(true);
            };
            this.series = ko.observableArray();
            this._loadAggregators();
            this.kinds = new Array();
            this.dateGroupItems = new Array();
            this.canAddSeries = ko.computed(function () {
                var seriesCount = _this.series().length;
                _this._updateKinds();
                if (_this.kinds.length > 0) {
                    var s = _this.kinds.filter(function (k) { return k.selected() && k.enabled(); });
                    if (s.length == 1) {
                        var selectedKind = EntityChartKind[s[0].name];
                        var k = (selectedKind != EntityChartKind.Donut && selectedKind != EntityChartKind.Pie && selectedKind !== EntityChartKind.Funnel && selectedKind != EntityChartKind.Gauge);
                        return k && seriesCount <= 4;
                    }
                }
                return true;
            });
            this.isGauge = ko.observable();
            this.updateChartStyle = function (args) {
                _this.chartStyleSelected(args.changedItem);
                var chartStyleChanged = _this.chartStyles.filter(function (ch) { return ch.values === _this.chartStyle(); });
                if (chartStyleChanged.length > 0) {
                    chartStyleChanged[0].selectedValue = _this.chartStyleSelected();
                    if (args.status)
                        Chart.isDirty(true);
                }
            };
            this.chartStyleSelected = ko.observable();
        }
        Chart.prototype._loadChildren = function (object) {
            var bindingEntity = object;
            var items = this.bindingEntitiesAll.filter(function (i) { return i.id === bindingEntity.target; });
            return items.length > 0 ? items[0].children : items;
        };
        Chart.prototype._updateKinds = function () {
            var _this = this;
            var oneSeriesKinds = this.kinds.filter(function (k) { return EntityChartKind[k.name] === EntityChartKind.Donut ||
                EntityChartKind[k.name] === EntityChartKind.Pie ||
                EntityChartKind[k.name] === EntityChartKind.Funnel ||
                EntityChartKind[k.name] === EntityChartKind.Gauge; });
            oneSeriesKinds.forEach(function (k) { return k.enabled(_this.series().length === 1); });
        };
        /**
         * Adds new series to series list of the chart.
         * @param sender sender
         * @param e event
         */
        Chart.prototype.addNewSeries = function (sender, e) {
            var s = new Series({ attribute: "", attributeLabel: "", color: "#FF0000", aggregation: AggregationKind.Count, limit: ChartLimit.None, id: "chartseries" + this.series().length }, this.serializedAggregators);
            this.series.push(s);
            Chart.isDirty(true);
        };
        /**
         * Removes series from the series list.
         * @param sender Sender is series object which will be removed.
         * @param e event
         */
        Chart.prototype.removeSeries = function (sender, e) {
            var s = sender;
            if (this.series().length > 1) {
                this.series.remove(s);
                Chart.isDirty(true);
            }
        };
        /**
         * Reconstructs drill-down fields from serialized value to value used in ComboBox component used for drillDown fields.
         * @param drillDown
         */
        Chart.prototype.deserializeDrillDown = function (drillDown) {
            var result = new Array();
            switch (drillDown) {
                case "!":
                    break;
                case "":
                    result = this.drillDownAvailableItems.map(function (i) { return i.id; });
                    break;
                default:
                    result = drillDown.split(";");
                    break;
            }
            return result;
        };
        Chart.prototype.serializeDrillDownData = function () {
            var serializedDrillDownFields = "";
            var maxLength = this.drillDownAvailableItems.length;
            switch (this.drillDownFields.length) {
                case 0:
                    serializedDrillDownFields = "!";
                    break;
                case maxLength:
                    break;
                default:
                    serializedDrillDownFields = this.drillDownFields.join(";");
                    break;
            }
            return serializedDrillDownFields;
        };
        /**
         * A public method calls JSBridge command for loads all entities with their fields which are necessary for creation of TreeViewComboBox.
         */
        Chart.prototype.loadEntitiesData = function () {
            var _this = this;
            MobileCRM.bridge.command("getEntitiesList", this.entityName(), function (result) {
                var bindings = new Array();
                bindings = result;
                _this.bindingEntitiesAll = new Array();
                for (var names in bindings) {
                    var n = names.split(";"); // data sends from our code no check validation
                    var item = { id: n[0], label: n[1], children: new Array() };
                    var children = result[names];
                    for (var _i = 0, children_1 = children; _i < children_1.length; _i++) {
                        var field = children_1[_i];
                        var treeItemData = {
                            id: field[1],
                            label: field[0],
                            type: Resco.Controls.CrmType[field[2]],
                            target: "",
                            childrenMember: undefined,
                        };
                        item.children.push(treeItemData);
                        var target = field[3];
                        if (target) {
                            var targetItems = target.split(";");
                            for (var _a = 0, targetItems_1 = targetItems; _a < targetItems_1.length; _a++) {
                                var t = targetItems_1[_a];
                                var g = {
                                    id: field[1],
                                    label: field[0],
                                    type: Resco.Controls.CrmType[field[2]],
                                    target: t,
                                    childrenMember: function (g) { return _this._loadChildren(g); },
                                };
                                item.children.push(g);
                            }
                        }
                    }
                    _this.bindingEntitiesAll.push(item);
                }
                var defaultItems = _this.bindingEntitiesAll.filter(function (entity) { return entity.id === _this.entityName(); });
                if (defaultItems.length > 0) {
                    _this.rootEntities = defaultItems[0].children;
                    _this.drillDownAvailableItems = _this.rootEntities.filter(function (i) { return (i.target === ""); });
                }
            }, function (err) { Editor.showMessageBox(err, ["OK"]); }, this);
        };
        Chart.prototype._loadAggregators = function () {
            var _this = this;
            MobileCRM.bridge.command("getLocalizedAggregators", "", function (result) {
                _this.serializedAggregators = new Array();
                _this.serializedAggregators.push(result[0]);
                _this.serializedAggregators.push(result[1]);
            }, function (err) { Editor.showMessageBox(err, ["OK"]); }, this);
        };
        /**
         * First initialization of some comboBox items in the chart editor after loading default selected data for this comboBoxes.
         * @param selectedKind String value represents name of kind which will be selected by default.
         * @param barOrAreaChartStyle Default selection of the chart style in the chart settings section for bar or area chart kind.
         * @param pieLabelStyle Default selection of pie label style used for pie or donut chart kind
         * @param dateGroup Selected value of the axis date group combo-box.
         */
        Chart.prototype.initChartComboBoxItems = function (selectedKind, barOrAreaChartStyle, pieLabelStyle, dateGroup) {
            this._initChartSettings(barOrAreaChartStyle, pieLabelStyle);
            this._initializeDateGroupOptions(dateGroup);
            var chartIcons = ["ColumnChart", "BarChart", "LineChart", "PieChart", "FunnelChart", "DonutChart", "GaugeChart", "AreaChart"]; //@DM: hack names are in same order as EntityChartKind enumerator
            var length = chartIcons.length;
            for (var i = 0; i < length; i++) {
                var k = new Resco.Controls.ImageBarItem();
                k.name = EntityChartKind[i];
                k.path = "url(\"../Charts/ChartImages/" + chartIcons[i] + ".png\")";
                k.selected(k.name == selectedKind);
                k.enabled(true);
                this.kinds.push(k);
                if (k.selected()) {
                    this._changeChartSettingsProperties(EntityChartKind[k.name]);
                    this.isGauge(EntityChartKind[k.name] === EntityChartKind.Gauge);
                }
            }
        };
        Chart.prototype._changeChartSettingsProperties = function (kind) {
            this.visibleStyle(true);
            this.chartDonutRatioEnabled(kind == EntityChartKind.Donut);
            if (kind == EntityChartKind.Column || kind == EntityChartKind.Bar) {
                this.chartStyle(this.chartStyles[0].values);
                this.chartStyleSelected(this.chartStyles[0].selectedValue);
            }
            else if (kind == EntityChartKind.Pie || kind == EntityChartKind.Donut) {
                this.chartStyle(this.chartStyles[1].values);
                this.chartStyleSelected(this.chartStyles[1].selectedValue);
            }
            else if (kind == EntityChartKind.Area) {
                this.chartStyle(this.chartStyles[2].values);
                this.chartStyleSelected(this.chartStyles[2].selectedValue);
            }
            else {
                this.visibleStyle(false);
            }
        };
        Chart.prototype._initChartSettings = function (barOrAreaChartStyle, pieLabelStyle) {
            this.chartStyles = new Array();
            var labels = [["Default", "Stacked", "Grouped"], ["Inside", "Outside", "Disabled"], ["Default", "Stacked", "Expanded"]];
            for (var i = 0; i < 3; i++) {
                var chartStylesArray = { values: new Array(), selectedValue: { label: "", id: "" } };
                for (var j = 0; j < 3; j++) {
                    var chartStyle = { label: labels[i][j], id: j.toString() };
                    if (((i === 0 || i === 2) && j === barOrAreaChartStyle) || ((i === 1) && j === pieLabelStyle))
                        chartStylesArray.selectedValue = chartStyle;
                    chartStylesArray.values.push(chartStyle);
                }
                if (chartStylesArray.selectedValue.id === "") {
                    chartStylesArray.selectedValue = chartStylesArray.values[0];
                }
                this.chartStyles.push(chartStylesArray);
            }
        };
        Chart.prototype._initializeDateGroupOptions = function (defaultDateGroup) {
            var count = 6; // DM: count of the items from DateGroupingKind enumerator
            for (var i = 0; i < count; i++) {
                var k = { label: DateGroupingKind[i], id: DateGroupingKind[i], };
                this.dateGroupItems.push(k);
                if (defaultDateGroup == k.id) {
                    this.dateGroupItem = k;
                }
            }
        };
        return Chart;
    }());
    ChartEditor.Chart = Chart;
    /**
     * Main class of private chart editor.
     */
    var Editor = (function () {
        /**
         * A public constructor for class Editor.
         */
        function Editor() {
            var _this = this;
            this._isAddedNewChart = false;
            this.editorSizeMonitor = new Resco.Controls.WindowSizeMonitor();
            this.charts = ko.observableArray();
            this.selectedChart = ko.observable(null);
            this.updateSelectedEntity = function (data) {
                _this.isEntityListShow(false);
                var e = data;
                _this._addNewChart(e);
            };
            this.isEntityListShow = ko.observable(false);
            this.entities = new Array();
            //colors
            this.formBackgroundColor = ko.observable();
            this.titleBackgroundColor = ko.observable();
            this.titleForegroundColor = ko.observable();
            this.formItemBackgroundColor = ko.observable();
            this.formItemLabelForegroundColor = ko.observable();
            this.formItemLinkColor = ko.observable();
            this.listBackgroundColor = ko.observable();
            this.listForegroundColor = ko.observable();
            this.listSelBackgroundColor = ko.observable();
            this.listSelForegroundColor = ko.observable();
            this.listSeparatorColor = ko.observable();
            //images
            this.backArrowImg = ko.observable();
            this.addButtonImg = ko.observable();
            this.addSeriesButtonImg = ko.observable();
            this.removeButtonImg = ko.observable();
            this.saveButtonImg = ko.observable();
            this.selectedCheckMarkImg = ko.observable();
            //labels
            this.localization = ko.observable({});
            this._loadLocalizedLabels();
            this._loadColors();
            this._loadImages();
            this._loadCharts();
        }
        Editor.prototype._loadCharts = function () {
            var _this = this;
            MobileCRM.bridge.command("getCharts", "", function (result) {
                var charts = result;
                for (var _i = 0, charts_1 = charts; _i < charts_1.length; _i++) {
                    var ch = charts_1[_i];
                    var chart = new Chart();
                    var chartParams = ch.split(";");
                    chart.name(chartParams[0]);
                    chart.chartId = chartParams[1];
                    chart.entityName(chartParams[1].split("|")[0]);
                    chart.loadEntitiesData();
                    _this.charts.push(chart);
                }
            }, function (err) {
                Editor.showMessageBox(err, ["OK"]);
            }, this);
        };
        /**
         * Handles all clicks to back arrow in the editor.
         * @param sender sender
         * @param e event
         */
        Editor.prototype.backArrowClick = function (sender, e) {
            var _this = this;
            if (this.isEntityListShow()) {
                this.isEntityListShow(false);
            }
            else {
                if (this.selectedChart()) {
                    if (Chart.isDirty()) {
                        var mb = new MobileCRM.UI.MessageBox(this.localization()["EditorMainLabel"]);
                        var items = [this.localization()["Cmd.SaveClose"], this.localization()["Cmd.Discard"], this.localization()["Cmd.ContinueEdit"]];
                        mb.multiLine = true;
                        mb.items = items;
                        mb.show(function (result) {
                            switch (result) {
                                case items[0]:
                                    _this.savePrivateChart(null, null);
                                    break;
                                case items[1]:
                                    if (_this._isAddedNewChart) {
                                        _this.charts.remove(_this.selectedChart());
                                        Chart.isDirty(false);
                                    }
                                    else {
                                        _this._undoChanges();
                                    }
                                    _this.selectedChart(null);
                                    break;
                                case items[2]:
                                    break;
                            }
                        }, function (failure) { }, this);
                    }
                    else {
                        this.selectedChart(null);
                    }
                }
                else {
                    MobileCRM.bridge.command("closeChartEditor", "close");
                }
            }
        };
        Editor.prototype._undoChanges = function () {
            var _this = this;
            var foundChartItem = this.charts().filter(function (item) { return item === _this.selectedChart(); });
            if (foundChartItem.length > 0) {
                var chartItem = foundChartItem[0];
                var backupedChartItem = chartItem;
                var index = this.charts.indexOf(chartItem);
                chartItem = null;
                chartItem = new Chart();
                chartItem.chartId = backupedChartItem.chartId;
                chartItem.entityName(backupedChartItem.entityName());
                chartItem.rootEntities = backupedChartItem.rootEntities;
                chartItem.serializedAggregators = backupedChartItem.serializedAggregators;
                chartItem.name(backupedChartItem.originalChartData[1]);
                chartItem.drillDownAvailableItems = backupedChartItem.drillDownAvailableItems;
                this.charts.splice(index, 1, chartItem);
                Chart.isDirty(false);
            }
        };
        Editor.prototype._addNewChart = function (entity) {
            function generateName(newChartName, charts, iteration) {
                var sameNameCharts = charts.filter(function (ch) { return ch.name() === newChartName; });
                if (sameNameCharts.length === 0) {
                    return newChartName;
                }
                else {
                    var newName = entity.displayName + " - private - Copy(" + iteration + ")";
                    return generateName(newName, charts, ++iteration);
                }
            }
            var chart = new Chart();
            chart.entityName(entity.logicalName);
            var sameEntityCharts = this.charts().filter(function (ch) { return ch.entityName() === entity.logicalName; });
            var name = entity.displayName + " - private";
            chart.name(generateName(name, sameEntityCharts, 1));
            chart.loadEntitiesData();
            this.charts.push(chart);
            this._isAddedNewChart = true;
            this._loadChartDefinitionData(chart);
            Chart.isDirty(true);
        };
        /**
         * Shows list of entities for selection one of them during the creation of private new chart. Using JSBridge command to EntityChart
         * @param sender sender
         * @param e event
         */
        Editor.prototype.showEntityList = function (sender, e) {
            var _this = this;
            if (this.entities.length === 0) {
                MobileCRM.bridge.command("getEntityList", {}, function (result) {
                    var entitiesNames = result;
                    for (var e in entitiesNames) {
                        var de = new Resco.Controls.SelectionListItem(e, entitiesNames[e]);
                        _this.entities.push(de);
                    }
                    _this.isEntityListShow(true);
                }, function (error) {
                    Editor.showMessageBox(error, ["OK"]);
                }, this);
            }
            else {
                this.isEntityListShow(true);
            }
        };
        /**
         * Method calls after click on delete button in editor. Removes selected chart from chart list.
         * @param sender represents chart object which will be remove.
         * @param e event
         */
        Editor.prototype.removeChart = function (sender, e) {
            var _this = this;
            var chart = sender;
            var popup = new MobileCRM.UI.MessageBox("Are you sure you want to delete " + chart.name() + " chart?", "");
            popup.items = ["Yes", "No"];
            popup.multiLine = true;
            popup.show(function (result) {
                if (result == "Yes") {
                    MobileCRM.bridge.command("removeChart", chart.name() + ";" + chart.entityName(), function (result) {
                        if (result == "OK") {
                            _this.selectedChart(null);
                            _this.charts.remove(chart);
                            Chart.isDirty(false);
                        }
                    }, function (error) {
                        Editor.showMessageBox(error, ["OK"]);
                    }, _this);
                }
            }, function (error) {
                Editor.showMessageBox(error, ["OK"]);
            }, this);
        };
        /**
         * Opens chart with its properties for editation.
         * @param sender object represents chart which will be open.
         * @param e
         */
        Editor.prototype.openSelectedChart = function (sender, e) {
            var chart = sender;
            this._loadChartDefinitionData(chart);
            this._isAddedNewChart = false;
        };
        //// result [0] - entityName, [1] - name, [2] - kind, [3] - drilldown
        /**
         * Load chart serialized data from MCRM through JSBrigde
         * @param chart Object of Chart type which will be configured.
         * command result: [0] - entityName, [1] - chartName, [2] - chart kind, [3] - drillDownFields, [4] - Axis fields data array or if gauge array of gauge properties,
         * [5] - chart series limit, [6] - axis date group, [7] - chart series data array, [8] - donut chart field donut ratio, [9] - pie or donut chart settings for label style, [10] - bar, column or stackArea chart style setting,
         */
        Editor.prototype._loadChartDefinitionData = function (chart) {
            var _this = this;
            var existedChart = this.charts().filter(function (ch) { return ch.name() === chart.name() && ch.entityName() === chart.entityName() && ch.series().length > 0; });
            if (existedChart.length > 0) {
                this.selectedChart(chart);
                return; // @DM: chart loaded in the past.
            }
            var json = chart.name() + ";" + (chart.chartId === '' ? chart.entityName() : chart.chartId);
            MobileCRM.bridge.command("getChartDefinitionData", json, function (result) {
                if (result) {
                    _this._deserializeChartDefinition(result, chart);
                    _this.selectedChart(chart);
                }
            }, function (err) {
                Editor.showMessageBox(err, ["OK"]);
            }, this);
        };
        Editor.prototype._deserializeChartDefinition = function (chartDefinition, chart) {
            chart.entityName(chartDefinition[0]);
            chart.name(chartDefinition[1]);
            var kind = chartDefinition[2];
            var dateGroup = DateGroupingKind[chartDefinition[6]];
            chart.initChartComboBoxItems(kind, +chartDefinition[10], +chartDefinition[9], dateGroup);
            chart.drillDownFields = chart.deserializeDrillDown(chartDefinition[3] || "");
            chart.axisField = new FieldType();
            if (kind === EntityChartKind[EntityChartKind.Gauge]) {
                chart.gaugeMinimalValue = this._deserializeGaugeData(chart, chartDefinition[4][0], 0);
                chart.gaugeMaximalValue = this._deserializeGaugeData(chart, chartDefinition[4][1], 1);
                chart.gaugeTargetValue = this._deserializeGaugeData(chart, chartDefinition[4][2], 2);
            }
            else {
                chart.axisField.displayName = chartDefinition[4][0];
                chart.axisField.logicalName = chartDefinition[4][1];
                chart.axisField.fieldType = chartDefinition[4][2] != null ? ko.observable(chartDefinition[4][2]) : ko.observable(Resco.Controls.CrmType.Integer);
                chart.gaugeMinimalValue = new GaugeValueEntity(false, chart.serializedAggregators);
                chart.gaugeMaximalValue = new GaugeValueEntity(false, chart.serializedAggregators);
                chart.gaugeTargetValue = new GaugeValueEntity(true, chart.serializedAggregators);
            }
            chart.limitCount(chartDefinition[5]);
            if (chart.serializedAggregators) {
                for (var _i = 0, _a = chartDefinition[7]; _i < _a.length; _i++) {
                    var serie = _a[_i];
                    var s = new Series({
                        attribute: serie[0],
                        attributeLabel: serie[1],
                        color: serie[2],
                        aggregation: serie[3],
                        limit: serie[4],
                        id: "chartseries" + chart.series().length,
                    }, chart.serializedAggregators);
                    chart.series.push(s);
                }
            }
            chart.chartDonutRatio(chartDefinition[8]);
            chart.originalChartData = chartDefinition;
        };
        Editor.prototype._deserializeGaugeData = function (chart, data, index) {
            var hasColor = index == 2;
            if (typeof data === "string") {
                var gaugeValueEntity = new GaugeValueEntity(hasColor, chart.serializedAggregators);
                gaugeValueEntity.selectedType(gaugeValueEntity.type[1]);
                gaugeValueEntity.constantValue(+data);
                return gaugeValueEntity;
            }
            else {
                var aggreegationKind = data[1];
                var gaugeValueEntity = new GaugeValueEntity(hasColor, chart.serializedAggregators, aggreegationKind);
                gaugeValueEntity.selectedType(gaugeValueEntity.type[0]);
                gaugeValueEntity.targetValue = data[0];
                return gaugeValueEntity;
            }
        };
        /**
         * Method calls after click on save button in the editor. Makes validation of fields and if everything is correct sends data to save.
         * @param sender
         * @param e
         */
        Editor.prototype.savePrivateChart = function (sender, e) {
            var _this = this;
            var validationStatus = this._validateChartData(this.selectedChart());
            if (validationStatus.status) {
                MobileCRM.bridge.command("savePrivateChartData", this._serializeChartData(this.selectedChart()), function (result) {
                    if (result === 0) {
                        _this.charts.removeAll();
                        _this._loadCharts();
                        _this.selectedChart(null);
                        Chart.isDirty(false);
                    }
                }, function (err) { }, this);
            }
            else {
                Editor.showMessageBox(validationStatus.message, ["OK"]);
            }
        };
        /**
         * A public static method gets selected value from array of items which are type of ComboBox or Icon.
         * @param items Array of items where is finding selected item.
         */
        Editor.getSelectedValue = function (items) {
            var item = items.filter(function (i) { return i.selected() && i.enabled(); });
            if (item && item.length == 1) {
                return item[0].name;
            }
        };
        /**
         * A public static method gets index of selected item from array of objects type of ComboBoxItems or Icons.
         * Return index number or -1 if array has no one item selected.
         * @param items Array of ComboBoxItem or Icon.
         */
        Editor.getSelectedValueIndex = function (items) {
            var item = items.filter(function (i) { return i.selected() && i.enabled(); });
            if (item.length > 0)
                return items.indexOf(item[0]);
            return -1;
        };
        Editor.prototype._serializeChartData = function (chart) {
            var result = {};
            var kind = EntityChartKind[Editor.getSelectedValue(chart.kinds)];
            result = {
                name: chart.name().trim(),
                kind: kind,
                series: this._serializeSeries(),
                limit: chart.limitCount(),
                axisField: kind == EntityChartKind.Gauge ? this._serializeGauge(chart) : chart.axisField.logicalName,
                dateGrouping: DateGroupingKind[chart.dateGroupItem.id],
                drillDown: chart.serializeDrillDownData(),
                chartRatio: chart.chartDonutRatioEnabled() ? chart.chartDonutRatio() : 50,
                pieLabelStyle: kind === EntityChartKind.Pie || kind === EntityChartKind.Donut ? chart.chartStyleSelected().id : 0,
                chartStyle: kind == EntityChartKind.Column || kind == EntityChartKind.Bar || kind == EntityChartKind.Area ? chart.chartStyleSelected().id : 0,
            };
            return JSON.stringify(result);
        };
        Editor.prototype._serializeSeries = function () {
            var serializedSeries = Array();
            for (var i = 0; i < this.selectedChart().series().length; i++) {
                var serie = this.selectedChart().series()[i];
                serializedSeries.push(Series.serialize(serie));
            }
            return serializedSeries;
        };
        Editor.prototype._serializeGauge = function (chart) {
            var data = new Array();
            data.push(chart.gaugeMinimalValue.serialize());
            data.push(chart.gaugeMaximalValue.serialize());
            data.push(chart.gaugeTargetValue.serialize());
            return data;
        };
        Editor.prototype._validateChartData = function (chart) {
            var vStatus = new ValidationStatus();
            vStatus.status = true;
            if (chart.name() === "") {
                vStatus.status = false;
                vStatus.message += "\n" + this.localization()["ErrorChartName"];
            }
            var sameNameCharts = this.charts().filter(function (ch) { return ch.name() === chart.name(); });
            if (sameNameCharts.length > 1) {
                vStatus.status = false;
                vStatus.message += "\n" + this.localization()["ErrorChartExist"];
            }
            if (Editor.getSelectedValueIndex(chart.kinds) !== EntityChartKind.Gauge && (chart.axisField.logicalName === undefined || chart.axisField.logicalName === "")) {
                vStatus.status = false;
                vStatus.message += "\n" + this.localization()["ErrorAxisIsEmpty"];
            }
            if (Editor.getSelectedValueIndex(chart.kinds) === EntityChartKind.Gauge) {
                if (chart.gaugeTargetValue.targetValue === undefined && !chart.gaugeTargetValue.isConstant()) {
                    vStatus.status = false;
                    vStatus.message += "\n" + this.localization()["ErrorGaugeTarget"];
                }
                if (chart.gaugeMaximalValue.targetValue === undefined && !chart.gaugeMaximalValue.isConstant()) {
                    vStatus.status = false;
                    vStatus.message += "\n" + this.localization()["ErrorGaugeMaximal"];
                }
                if (chart.gaugeMinimalValue.targetValue === undefined && !chart.gaugeMinimalValue.isConstant()) {
                    vStatus.status = false;
                    vStatus.message += "\n" + this.localization()["ErrorGaugeMinimal"];
                }
            }
            if (chart.limitCount() < 0 || typeof +chart.limitCount() !== "number") {
                vStatus.message += "\n" + this.localization()["ErrorLimitCount"];
                vStatus.status = false;
            }
            var selectedSeriesFields = chart.series().filter(function (s) {
                return (s.seriesField !== "" && s.seriesField !== Resco.Controls.TreeView.defaultEmptyLabel);
            });
            if (selectedSeriesFields.length != chart.series().length) {
                vStatus.message += "\n" + this.localization()["ErrorSeriesField"];
                vStatus.status = false;
            }
            if (chart.chartDonutRatioEnabled() && (chart.chartDonutRatio() < 1 || chart.chartDonutRatio() > 99)) {
                vStatus.message += "\n" + this.localization()["ErrorChartStyleDonut"];
                vStatus.status = false;
            }
            return vStatus;
        };
        /**
        * Static method for show message box with specific message.
        * @param message string message to show
        * @param items string array as button labels in the message.
        */
        Editor.showMessageBox = function (message, items) {
            var mb = new MobileCRM.UI.MessageBox(message, "");
            mb.multiLine = true;
            mb.items = items;
            mb.show(function (result) { }, function (failure) { }, this);
        };
        Editor.prototype._loadColor = function (color, callback) {
            MobileCRM.Application.getAppColor(color, function (result) {
                callback(result);
            }, function (err) {
                Editor.showMessageBox(err, ["OK"]);
            });
        };
        Editor.prototype._loadImage = function (imageName, color, callback) {
            MobileCRM.Application.getAppImage(imageName, color, function (result) {
                callback("url('" + result + "')");
            }, function (err) {
                Editor.showMessageBox(err, ["OK"]);
            }, null);
        };
        Editor.prototype._loadColors = function () {
            var _this = this;
            this._loadColor("FormBackground", function (r) { _this.formBackgroundColor(r); });
            this._loadColor("TitleBackground", function (r) { _this.titleBackgroundColor(r); });
            this._loadColor("TitleForeground", function (r) { _this.titleForegroundColor(r); });
            this._loadColor("FormItemBackground", function (r) { _this.formItemBackgroundColor(r); });
            this._loadColor("FormItemLabelForeground", function (r) { _this.formItemLabelForegroundColor(r); });
            this._loadColor("FormItemLink", function (r) { _this.formItemLinkColor(r); });
            this._loadColor("ListBackground", function (r) { _this.listBackgroundColor(r); });
            this._loadColor("ListForeground", function (r) { _this.listForegroundColor(r); });
            this._loadColor("ListSelBackground", function (r) { _this.listSelBackgroundColor(r); });
            this._loadColor("ListSelForeground", function (r) { _this.listSelForegroundColor(r); });
            this._loadColor("ListSeparator", function (r) { _this.listSeparatorColor(r); });
        };
        Editor.prototype._loadImages = function () {
            var _this = this;
            this._loadImage("Cmd.Back.png", "TitleForeground", function (r) { _this.backArrowImg(r); });
            this._loadImage("Cmd.New.png", "TitleForeground", function (r) { _this.addButtonImg(r); });
            this._loadImage("Cmd.New.png", "FormItemLabelForeground", function (r) { _this.addSeriesButtonImg(r); });
            this._loadImage("Cmd.Delete.png", "", function (r) { _this.removeButtonImg(r); });
            this._loadImage("Cmd.Save.png", "TitleForeground", function (r) { _this.saveButtonImg(r); });
            this._loadImage("Cmd.Save.png", "TitleForeground", function (r) { _this.saveButtonImg(r); });
            this._loadImage("Controls.CheckMark.png", "", function (r) { _this.selectedCheckMarkImg(r); });
        };
        Editor.prototype._loadLocalizedLabels = function () {
            var _this = this;
            MobileCRM.bridge.command("getLocalizedLabels", "", function (result) {
                _this.localization(result);
            }, function (err) { Editor.showMessageBox(err, ["OK"]); }, null);
        };
        return Editor;
    }());
    ChartEditor.Editor = Editor;
    /**
     * Validation status class represents status of validation and message if error occurs
     */
    var ValidationStatus = (function () {
        function ValidationStatus() {
            this.message = "";
        }
        return ValidationStatus;
    }());
    /**
    * The possible kinds of charts that are supported.
    */
    var EntityChartKind;
    (function (EntityChartKind) {
        /// <summary>Column chart.</summary>
        EntityChartKind[EntityChartKind["Column"] = 0] = "Column";
        /// <summary>Bar chart.</summary>
        EntityChartKind[EntityChartKind["Bar"] = 1] = "Bar";
        /// <summary>Line chart.</summary>
        EntityChartKind[EntityChartKind["Line"] = 2] = "Line";
        /// <summary>Pie chart.</summary>
        EntityChartKind[EntityChartKind["Pie"] = 3] = "Pie";
        /// <summary>Funnel chart.</summary>
        EntityChartKind[EntityChartKind["Funnel"] = 4] = "Funnel";
        /// <summary>Donut chart.</summary>
        EntityChartKind[EntityChartKind["Donut"] = 5] = "Donut";
        /// <summary>Gauge chart.</summary>
        EntityChartKind[EntityChartKind["Gauge"] = 6] = "Gauge";
        /// <summary>Area chart.</summary>
        EntityChartKind[EntityChartKind["Area"] = 7] = "Area";
    })(EntityChartKind = ChartEditor.EntityChartKind || (ChartEditor.EntityChartKind = {}));
    /**
     * Date grouping kinds for fields type of Date.
     */
    var DateGroupingKind;
    (function (DateGroupingKind) {
        /// <summary>No date grouping.</summary>
        DateGroupingKind[DateGroupingKind["None"] = 0] = "None";
        /// <summary>Group by day.</summary>
        DateGroupingKind[DateGroupingKind["Day"] = 1] = "Day";
        /// <summary>Group by week.</summary>
        DateGroupingKind[DateGroupingKind["Week"] = 2] = "Week";
        /// <summary>Group by month.</summary>
        DateGroupingKind[DateGroupingKind["Month"] = 3] = "Month";
        /// <summary>Group by quarter.</summary>
        DateGroupingKind[DateGroupingKind["Quarter"] = 4] = "Quarter";
        /// <summary>Group by year.</summary>
        DateGroupingKind[DateGroupingKind["Year"] = 5] = "Year";
    })(DateGroupingKind = ChartEditor.DateGroupingKind || (ChartEditor.DateGroupingKind = {}));
    /**
     * The possible aggregation functions.
     */
    var AggregationKind;
    (function (AggregationKind) {
        /// <summary>Calculate average value.</summary>
        AggregationKind[AggregationKind["Average"] = 0] = "Average";
        /// <summary>Count matching entities.</summary>
        AggregationKind[AggregationKind["Count"] = 1] = "Count";
        /// <summary>Count entities with a non-null value in the series property.</summary>
        AggregationKind[AggregationKind["CountNonNull"] = 2] = "CountNonNull";
        /// <summary>Count entities with a distinct non-null value in the series property.</summary>
        AggregationKind[AggregationKind["CountDistinct"] = 3] = "CountDistinct";
        /// <summary>Find maximum value.</summary>
        AggregationKind[AggregationKind["Maximum"] = 4] = "Maximum";
        /// <summary>Find minimum value.</summary>
        AggregationKind[AggregationKind["Minimum"] = 5] = "Minimum";
        /// <summary>Sum values in the series property.</summary>
        AggregationKind[AggregationKind["Sum"] = 6] = "Sum";
    })(AggregationKind = ChartEditor.AggregationKind || (ChartEditor.AggregationKind = {}));
    /**
     * Limit the number of entities to only top X or bottom X.
     */
    var ChartLimit;
    (function (ChartLimit) {
        /// <summary>No limit (display all).</summary>
        ChartLimit[ChartLimit["None"] = 0] = "None";
        /// <summary>Show only top X.</summary>
        ChartLimit[ChartLimit["Top"] = 1] = "Top";
        /// <summary>Show only bottom X.</summary>
        ChartLimit[ChartLimit["Bottom"] = 2] = "Bottom";
    })(ChartLimit = ChartEditor.ChartLimit || (ChartEditor.ChartLimit = {}));
})(ChartEditor || (ChartEditor = {}));
