///<reference path="../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../Controls/event.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var DatePickerViewStatus;
        (function (DatePickerViewStatus) {
            DatePickerViewStatus[DatePickerViewStatus["days"] = 0] = "days";
            DatePickerViewStatus[DatePickerViewStatus["months"] = 1] = "months";
            DatePickerViewStatus[DatePickerViewStatus["years"] = 2] = "years";
        })(DatePickerViewStatus || (DatePickerViewStatus = {}));
        var ItemClickedEventArgs = (function (_super) {
            __extends(ItemClickedEventArgs, _super);
            /**
             * Constructor for TreeItemClickedEventArgs.
             */
            function ItemClickedEventArgs(item) {
                var _this = _super.call(this) || this;
                _this._item = item;
                return _this;
            }
            Object.defineProperty(ItemClickedEventArgs.prototype, "item", {
                /** Get treeViewItem which raised click event.*/
                get: function () {
                    return this._item;
                },
                enumerable: true,
                configurable: true
            });
            return ItemClickedEventArgs;
        }(Resco.EventArgs));
        Controls.ItemClickedEventArgs = ItemClickedEventArgs;
        var ValueChangedEventArgs = (function (_super) {
            __extends(ValueChangedEventArgs, _super);
            /**
             * Constructor for TreeItemClickedEventArgs.
             */
            function ValueChangedEventArgs(value) {
                var _this = _super.call(this) || this;
                _this._value = value;
                return _this;
            }
            Object.defineProperty(ValueChangedEventArgs.prototype, "value", {
                /** Get treeViewItem which raised click event.*/
                get: function () {
                    return this._value;
                },
                enumerable: true,
                configurable: true
            });
            return ValueChangedEventArgs;
        }(Resco.EventArgs));
        Controls.ValueChangedEventArgs = ValueChangedEventArgs;
        var Utilities = (function () {
            function Utilities() {
            }
            /**
             * Gets random string value.
             */
            Utilities.generateUniqueIdentifier = function () {
                var identifier = Math.random().toString(16).slice(-5).toLowerCase();
                return identifier;
            };
            /**
             * Removes class and then add new class to the html element.
             * @param htmlElement
             * @param removeClassName
             * @param addClassName
             */
            Utilities.removeAndAddClassToElement = function (htmlElement, removeClassName, addClassName) {
                if (htmlElement.classList.contains(removeClassName))
                    htmlElement.classList.remove(removeClassName);
                htmlElement.classList.add(addClassName);
            };
            Utilities.compareDate = function (firstDate, secondDate) {
                return (firstDate.getFullYear() === secondDate.getFullYear() &&
                    firstDate.getMonth() === secondDate.getMonth() &&
                    firstDate.getDate() === secondDate.getDate());
            };
            return Utilities;
        }());
        var DatePickerItem = (function () {
            function DatePickerItem(dateValue, isActualMonth, date, isToday) {
                this.dateValue = dateValue;
                this.isActualMonth = isActualMonth;
                this.date = date;
                this.isToday = isToday || false;
            }
            return DatePickerItem;
        }());
        /**
         * Public class for instance of ResoDatePicker for selection date.
         */
        var RescoDatePicker = (function () {
            function RescoDatePicker(settings, parentElement, visibleAfterInit, ownDimensionValues) {
                this._dimension = { width: 0, height: 0, top: 0, left: 0 };
                this._heights = { contentHeight: 0, headerHeight: 0, rowHeight: 0, biggerRowHeight: 0 };
                this._swipe = { xDown: null, yDown: null };
                this._viewStatus = DatePickerViewStatus.days;
                this._generateID(Utilities.generateUniqueIdentifier());
                this.datePickerClicked = new Resco.Event(this);
                this.datePickerBlur = new Resco.Event(this);
                this._settings = settings;
                this.parentElement = parentElement;
                this._defaultActualDate = new Date(this._settings.actualDate);
                this._updateDimensionProperty(ownDimensionValues);
                this._loadDatePickerHTML();
                this._addEventListener();
                if (visibleAfterInit === undefined || visibleAfterInit === true)
                    this.showRescoDatePicker();
                else {
                    this.hideRescoDatePicker(visibleAfterInit);
                }
            }
            /**
             * Return the current position and size of the datePicker
             */
            RescoDatePicker.prototype.getDimension = function () {
                return this._dimension;
            };
            /**
             * Makes RescoDatePicker visible on the HTML page.
             */
            RescoDatePicker.prototype.showRescoDatePicker = function (showToday) {
                if (this._viewStatus !== DatePickerViewStatus.days) {
                    this._viewStatus = DatePickerViewStatus.days;
                }
                if (showToday !== undefined && showToday === true) {
                    this._settings.actualDate = new Date();
                    this._defaultActualDate = new Date();
                }
                this._updateHeaderActualDateDiv();
                this._updateDatesDiv();
                this.rescoDatePickerElement.style.display = "block";
                //@DM: Add invisible layer for handle click out of the rescoDatePicker element
                document.body.insertAdjacentHTML("afterbegin", "<div id='rescoInvisibleControlLayer" + this.id + "' class='rescoInvisibleControlLayer'></div>");
                this._addEventListenerToInvisibleLayer();
            };
            /**
             * Makes RescoDatePicker hidden on the HTML page.
             */
            RescoDatePicker.prototype.hideRescoDatePicker = function (visibleAfterInit) {
                this.rescoDatePickerElement.style.display = "none";
                if (visibleAfterInit === undefined)
                    this._removeEventListenerFromInvisibleLayer();
            };
            RescoDatePicker.prototype.IsVisible = function () {
                if (this.rescoDatePickerElement.style.display === "none")
                    return true;
                return false;
            };
            RescoDatePicker.prototype.updatePosition = function (top, left, zindex) {
                this._dimension.top = top;
                this.rescoDatePickerElement.style.top = this._dimension.top + "px";
                this._dimension.left = left;
                this.rescoDatePickerElement.style.left = this._dimension.left + "px";
                if (zindex !== undefined) {
                    this.rescoDatePickerElement.style.zIndex = zindex;
                    var rescoInvisibleControlLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                    rescoInvisibleControlLayer.style.zIndex = (+zindex - 1).toString();
                }
            };
            RescoDatePicker.prototype._generateID = function (id) {
                var e = document.getElementById(id);
                if (e === null)
                    this.id = id;
                else
                    this._generateID(Utilities.generateUniqueIdentifier());
            };
            RescoDatePicker.prototype._updateDimensionProperty = function (ownDimensionValues) {
                if (ownDimensionValues && this._settings.dimension !== undefined && this._settings.dimension !== null) {
                    this._dimension = this._settings.dimension;
                }
                else {
                    this._dimension.width = 250;
                    this._dimension.height = 250;
                    //TODO: fix if it smaller as screen
                    this._dimension.top = this.parentElement.offsetTop + this.parentElement.offsetHeight;
                    //TODO: fix if it smaller as screen
                    this._dimension.left = (this.parentElement.offsetLeft + this.parentElement.offsetWidth) - this._dimension.width;
                }
                if (this._dimension.top < 0)
                    this._dimension.top = 0;
                if (this._dimension.left < 0)
                    this._dimension.left = 0;
                if (this._dimension.height < 250)
                    this._dimension.height = 250;
                if (this._dimension.width < 150)
                    this._dimension.width = 150;
            };
            /**
             * Change the position of the datePicker dynamically
             * @param dimension new position on the page and its size
             */
            RescoDatePicker.prototype.updateDimensionProperty = function (dimension) {
                ///FIXME: is needed or is same as method updatePosition() ???? 
                this._dimension = dimension;
                if (this._dimension.top < 0 || !this._dimension.top)
                    this._dimension.top = 0;
                if (this._dimension.left < 0 || !this._dimension.left)
                    this._dimension.left = 0;
                if (this._dimension.height < 250 || !this._dimension.height)
                    this._dimension.height = 250;
                if (this._dimension.width < 150 || !this._dimension.width)
                    this._dimension.width = 150;
                document.getElementById(this.id).style.top = this._dimension.top + "px";
                document.getElementById(this.id).style.left = this._dimension.left + "px";
                document.getElementById(this.id).style.width = this._dimension.width + "px";
                document.getElementById(this.id).style.height = this._dimension.height + "px";
            };
            RescoDatePicker.prototype._loadDatePickerHTML = function () {
                this._heights.headerHeight = (this._dimension.height / 5);
                this._heights.contentHeight = this._dimension.height - this._heights.headerHeight; //here it is 200px;
                this._heights.rowHeight = (this._heights.contentHeight - this._heights.headerHeight) / 6;
                this._heights.biggerRowHeight = (this._heights.contentHeight / 4);
                var htmlTemplate = "<div id='" + this.id + "' class='rescoDatePicker' style='width:" + this._dimension.width + "px; top:" + this._dimension.top + "px;left:" + this._dimension.left + "px;'>\
					<div class='header' style='height: " + this._heights.headerHeight + "px'>\
						<div class='datePickerNavButton' data-actiontype='loadPreviousMonth' style='height:" + (this._heights.headerHeight - 10) + "px'><div class='arrow' style='background-image: url(" + this._settings.images[0] + "); height:" + (this._heights.headerHeight - 10) + "px'></div></div>\
						<div class='datePickerDateValue text' data-actualviewtype='0' style='line-height:" + (this._heights.headerHeight - 10) + "px'>" + this._formatDate() + "</div>\
						<div class='datePickerNavButton' data-actiontype='loadNextMonth' style='height:" + (this._heights.headerHeight - 10) + "px'><div class='arrow' style='background-image: url(" + this._settings.images[1] + "); height:" + (this._heights.headerHeight - 10) + "px'></div></div>\
					</div>\
					" + this._generateContentSection() + "\
				</div>";
                document.body.insertAdjacentHTML("beforeend", htmlTemplate);
            };
            RescoDatePicker.prototype.updateDefaultValue = function (date) {
                this._defaultActualDate = new Date(date);
                this._settings.actualDate = new Date(date);
            };
            RescoDatePicker.prototype._formatDate = function () {
                var formattedDate = "";
                switch (this._viewStatus) {
                    case DatePickerViewStatus.days:
                        formattedDate = this._settings.monthNames[this._settings.actualDate.getMonth()] + " " + this._settings.actualDate.getFullYear();
                        break;
                    default:
                        formattedDate = this._settings.actualDate.getFullYear().toString();
                        break;
                }
                return formattedDate;
            };
            RescoDatePicker.prototype._generateContentSection = function () {
                var contentSectionDiv = "";
                switch (this._viewStatus) {
                    case DatePickerViewStatus.days:
                        contentSectionDiv = "\
						<div data-viewtype='" + DatePickerViewStatus.days + "' class='contentSection' style= 'height: " + (this._heights.contentHeight - 20) + "px' >\
							<div class='days' style='height: 30px'>\
								<div class='dayName'>" + this._settings.dayNames[0] + "</div>\
								<div class='dayName'>" + this._settings.dayNames[1] + "</div>\
								<div class='dayName'>" + this._settings.dayNames[2] + "</div>\
								<div class='dayName'>" + this._settings.dayNames[3] + "</div>\
								<div class='dayName'>" + this._settings.dayNames[4] + "</div>\
								<div class='dayName'>" + this._settings.dayNames[5] + "</div>\
								<div class='dayName'>" + this._settings.dayNames[6] + "</div>\
							</div>\
							<div class='dates'>" + this._generateContent(this._heights.rowHeight) + "</div>\
						</div>";
                        break;
                    case DatePickerViewStatus.months:
                        contentSectionDiv = "\
						<div data-viewtype='" + DatePickerViewStatus.months + "' class='contentSection' style='height: " + (this._heights.contentHeight - 20) + "px;'>\
							<div class='dates'>" + this._generateContent(this._heights.biggerRowHeight) + "</div>\
						</div>\
						";
                        break;
                    case DatePickerViewStatus.years:
                        contentSectionDiv = "\
						<div data-viewtype='" + DatePickerViewStatus.years + "' class='contentSection' style='height: " + (this._heights.contentHeight - 20) + "px;'>\
							<div class='dates'>" + this._generateContent(this._heights.biggerRowHeight) + "</div>\
						</div>\
						";
                        break;
                }
                return contentSectionDiv;
            };
            RescoDatePicker.prototype._generateContent = function (rowHeight) {
                this._loadedDates = new Array(); // remove all items if was loaded in previous month.
                this._loadedDates = this._loadData(this._viewStatus);
                switch (this._viewStatus) {
                    case DatePickerViewStatus.days:
                        var datesDivsTemplate = "";
                        for (var i = 0; i < 6; i++) {
                            datesDivsTemplate +=
                                "<div class='row' style='height:" + rowHeight + "px'>" + this._generateDateDivItem(this._loadedDates, i, (rowHeight - 2)) + "</div>";
                        }
                        return datesDivsTemplate;
                    case DatePickerViewStatus.months:
                        var monthViewDivsTemplate = "";
                        for (var i = 0; i < 3; i++) {
                            monthViewDivsTemplate +=
                                "<div class='row' style='height:" + rowHeight + "px'>" + this._generateDateDivItem(this._loadedDates, i, (rowHeight - 2)) + "</div>";
                        }
                        return monthViewDivsTemplate;
                    case DatePickerViewStatus.years:
                        var yearsViewDivsTemplate = "";
                        for (var i = 0; i < 3; i++) {
                            yearsViewDivsTemplate +=
                                "<div class='row' style='height:" + rowHeight + "px'>" + this._generateDateDivItem(this._loadedDates, i, (rowHeight - 2)) + "</div>";
                        }
                        return yearsViewDivsTemplate;
                }
            };
            RescoDatePicker.prototype._generateDateDivItem = function (availableDays, index, rowHeight) {
                var dateDivItems = "";
                switch (this._viewStatus) {
                    case DatePickerViewStatus.days:
                        for (var j = 0; j < 7; j++) {
                            var date = availableDays[(index * 7) + j];
                            dateDivItems += "<div class='dateValue' data-istoday='" + date.isToday + "' data-isactual='" + date.isActualMonth + "' data-isActualDate='" + date.isActualDate + "' style='line-height:" + rowHeight + "px'>" + date.dateValue + "</div>";
                        }
                        return dateDivItems;
                    case DatePickerViewStatus.months:
                        for (var j_1 = 0; j_1 < 4; j_1++) {
                            var date = availableDays[(index * 4) + j_1];
                            dateDivItems += "<div class='dateValue' data-isactual='" + date.isActualMonth + "', style='line-height:" + rowHeight + "px'>" + date.dateValue.slice(0, 3) + "</div>";
                        }
                        return dateDivItems;
                    case DatePickerViewStatus.years:
                        for (var j_2 = 0; j_2 < 4; j_2++) {
                            var date = availableDays[(index * 4) + j_2];
                            dateDivItems += "<div class='dateValue' data-isactual='" + date.isActualMonth + "', style='line-height:" + rowHeight + "px'>" + date.dateValue + "</div>";
                        }
                        return dateDivItems;
                }
            };
            RescoDatePicker.prototype._loadData = function (viewStatus) {
                switch (viewStatus) {
                    case DatePickerViewStatus.months:
                        return this._loadDataForMonthView();
                    case DatePickerViewStatus.years:
                        return this._loadDataForYearsView();
                    default:
                        return this._loadDataForDayView();
                }
            };
            RescoDatePicker.prototype._getFirstMonthDay = function (year, month) {
                return new Date(year, month, 1);
            };
            RescoDatePicker.prototype._getLastMonthDay = function (year, month) {
                return new Date(year, month + 1, 0);
            };
            ;
            RescoDatePicker.prototype._loadDataForDayView = function () {
                var array = new Array();
                var actualDate = this._settings.actualDate, year = actualDate.getFullYear(), month = actualDate.getMonth();
                var firstDay = this._getFirstMonthDay(year, month);
                var lastDay = this._getLastMonthDay(year, month);
                var startOfMonth = firstDay.getDay();
                var missingDays = startOfMonth - this._settings.firstWeekDay;
                if (missingDays < 0) {
                    missingDays = 7 - Math.abs(missingDays);
                }
                var today = new Date();
                var actual = new Date(firstDay);
                actual.setDate(actual.getDate() - missingDays);
                for (var i = 1; i <= 42; i++) {
                    var calendarDate = new DatePickerItem(actual.getDate().toString(), actual.getMonth() === month, new Date(actual));
                    calendarDate.isToday = today.getFullYear() === actual.getFullYear() && today.getMonth() === actual.getMonth() && today.getDate() === actual.getDate();
                    calendarDate.isActualDate = Utilities.compareDate(this._defaultActualDate, actual);
                    array.push(calendarDate);
                    actual.setDate(actual.getDate() + 1);
                }
                return array;
            };
            RescoDatePicker.prototype._loadDataForMonthView = function () {
                var array = new Array();
                var today = new Date(); // to compare actual month;
                for (var i = 0; i < 12; i++) {
                    var date = new Date(this._settings.actualDate.getFullYear(), i, 1);
                    var isActualMonth = date.getFullYear() === today.getFullYear() && date.getMonth() === today.getMonth();
                    var item = new DatePickerItem(this._settings.monthNames[i], isActualMonth, date);
                    array.push(item);
                }
                return array;
            };
            RescoDatePicker.prototype._loadDataForYearsView = function () {
                var array = new Array();
                var today = new Date(); // to compare actual year;
                for (var i = -1; i < 11; i++) {
                    var date = new Date(this._settings.actualDate.getFullYear() + i, 0, 1);
                    var isActualMonth = date.getFullYear() === today.getFullYear();
                    var item = new DatePickerItem(date.getFullYear().toString(), isActualMonth, date);
                    array.push(item);
                }
                return array;
            };
            RescoDatePicker.prototype._addEventListener = function () {
                var _this = this;
                this.rescoDatePickerElement = document.getElementById(this.id);
                // add events to previous - next month
                var navButtons = this.rescoDatePickerElement.getElementsByClassName("datePickerNavButton");
                for (var i = 0; i < navButtons.length; i++) {
                    var navButton = navButtons[i];
                    switch (navButton.dataset.actiontype) {
                        case "loadPreviousMonth":
                            navButton.addEventListener("click", function (e) {
                                _this._moveToPrevious();
                            });
                            break;
                        case "loadNextMonth":
                            navButton.addEventListener("click", function (e) {
                                _this._moveToNext();
                            });
                            break;
                    }
                }
                var headerDateValue = this.rescoDatePickerElement.getElementsByClassName("datePickerDateValue")[0];
                headerDateValue.addEventListener("click", function () {
                    if (DatePickerViewStatus[headerDateValue.dataset.actualviewtype] === DatePickerViewStatus[DatePickerViewStatus.days]) {
                        _this._changeView(DatePickerViewStatus.months);
                    }
                    else if (DatePickerViewStatus[headerDateValue.dataset.actualviewtype] === DatePickerViewStatus[DatePickerViewStatus.months]) {
                        _this._changeView(DatePickerViewStatus.years);
                    }
                });
                this._addEventListenerToContentItems();
                if (this._settings.platform === "Windows")
                    this._addWheelListener();
                else if (this._settings.platform === "Windows10") {
                    this._addWheelListener();
                    this._addSwipeListener();
                }
                else {
                    this._addSwipeListener();
                }
            };
            RescoDatePicker.prototype._addEventListenerToContentItems = function () {
                var _this = this;
                var dayButtons = this.rescoDatePickerElement.getElementsByClassName("dateValue");
                var _loop_1 = function (i) {
                    var dayButton = dayButtons[i];
                    if (dayButton.dataset["isactual"] === "true" && this_1._viewStatus === DatePickerViewStatus.days) {
                        dayButton.addEventListener("click", function () {
                            var item = _this._loadedDates.filter(function (d) { return (d.dateValue === dayButton.textContent && d.isActualMonth); });
                            if (item.length > 0) {
                                _this._defaultActualDate = new Date(item[0].date);
                                _this.datePickerClicked.raise(new ItemClickedEventArgs(item[0]), _this);
                            }
                        });
                    }
                    else if (this_1._viewStatus === DatePickerViewStatus.months) {
                        dayButton.addEventListener("click", function () {
                            var item = _this._loadedDates.filter(function (d) { return d.dateValue.slice(0, 3) === dayButton.textContent; }); //TODO: fix slice, now it is used in 2 places!!
                            if (item.length > 0) {
                                _this._settings.actualDate = item[0].date;
                                _this._changeView(DatePickerViewStatus.days);
                            }
                        });
                    }
                    else if (this_1._viewStatus === DatePickerViewStatus.years) {
                        dayButton.addEventListener("click", function () {
                            var item = _this._loadedDates.filter(function (d) { return d.dateValue === dayButton.textContent; });
                            if (item.length > 0) {
                                _this._settings.actualDate = item[0].date;
                                _this._changeView(DatePickerViewStatus.months);
                            }
                        });
                    }
                };
                var this_1 = this;
                for (var i = 0; i < dayButtons.length; i++) {
                    _loop_1(i);
                }
            };
            RescoDatePicker.prototype._addWheelListener = function () {
                var _this = this;
                this.rescoDatePickerElement.addEventListener("mousewheel", function (e) {
                    var delta = e.wheelDelta;
                    if (delta > 0) {
                        _this._moveToPrevious();
                    }
                    else {
                        _this._moveToNext();
                    }
                    if (e.preventDefault)
                        e.preventDefault();
                    else
                        return false;
                }, false);
            };
            RescoDatePicker.prototype._addSwipeListener = function () {
                var _this = this;
                this._swipe = { xDown: null, yDown: null };
                this.rescoDatePickerElement.addEventListener('touchstart', function (e) {
                    _this._swipe.xDown = e.touches[0].clientX;
                    _this._swipe.yDown = e.touches[0].clientY;
                }, false);
                this.rescoDatePickerElement.addEventListener('touchmove', function (e) {
                    if (!_this._swipe.xDown || !_this._swipe.yDown) {
                        return;
                    }
                    var xUp = e.touches[0].clientX;
                    var yUp = e.touches[0].clientY;
                    var xDiff = _this._swipe.xDown - xUp;
                    var yDiff = _this._swipe.yDown - yUp;
                    if (Math.abs(xDiff) > Math.abs(yDiff)) {
                        if (xDiff > 0) {
                            _this._moveToNext();
                        }
                        else {
                            _this._moveToPrevious();
                        }
                    }
                    _this._swipe.xDown = null;
                    _this._swipe.yDown = null;
                }, false);
            };
            RescoDatePicker.prototype._addEventListenerToInvisibleLayer = function () {
                var _this = this;
                var invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                invisibleDatePickerLayer.addEventListener("click", function (e) {
                    _this._settings.actualDate = new Date(_this._defaultActualDate);
                    _this.datePickerBlur.raise(new Resco.EventArgs(), _this);
                });
            };
            RescoDatePicker.prototype._removeEventListenerFromInvisibleLayer = function () {
                var invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                document.body.removeChild(invisibleDatePickerLayer);
            };
            RescoDatePicker.prototype._changeView = function (view) {
                this._viewStatus = view;
                this.rescoDatePickerElement.removeChild(this.rescoDatePickerElement.getElementsByClassName("contentSection")[0]);
                this.rescoDatePickerElement.insertAdjacentHTML("beforeend", this._generateContentSection());
                this._updateHeaderActualDateDiv();
                this._addEventListenerToContentItems();
            };
            RescoDatePicker.prototype._moveToPrevious = function () {
                switch (this._viewStatus) {
                    case DatePickerViewStatus.days:
                        this._moveToPreviousMonth();
                        break;
                    case DatePickerViewStatus.months:
                        this._moveToPreviousYear();
                        break;
                    case DatePickerViewStatus.years:
                        this._moveToPreviousDecade();
                        break;
                }
            };
            RescoDatePicker.prototype._moveToNext = function () {
                switch (this._viewStatus) {
                    case DatePickerViewStatus.days:
                        this._moveToNextMonth();
                        break;
                    case DatePickerViewStatus.months:
                        this._moveToNextYear();
                        break;
                    case DatePickerViewStatus.years:
                        this._moveToNextDecade();
                        break;
                }
            };
            /**
             * Returns a new Date that adds number of months specified by months argument.
             * @param date - date to which should be months added.
             * @param months - can be possitive or negative number of months that should be added or removed.
             */
            RescoDatePicker.prototype.addMonths = function (date, months) {
                var oldDate = new Date(date);
                if (months !== 0) {
                    var requiredMonth = oldDate.getMonth() + months;
                    oldDate.setMonth(requiredMonth);
                    while (requiredMonth < 0) {
                        requiredMonth += 12;
                    }
                    requiredMonth %= 12;
                    var month = oldDate.getMonth();
                    if (month > requiredMonth)
                        return new Date(oldDate.getFullYear(), month, 0, oldDate.getHours(), oldDate.getMinutes(), oldDate.getSeconds(), oldDate.getMilliseconds());
                }
                return oldDate;
            };
            /**
             * Change calendar preview to next month.
             */
            RescoDatePicker.prototype._moveToNextMonth = function () {
                this._settings.actualDate = this.addMonths(this._settings.actualDate, 1);
                this._updateHeaderActualDateDiv();
                this._updateDatesDiv();
            };
            /**
             * Change calendar preview to previous month.
             */
            RescoDatePicker.prototype._moveToPreviousMonth = function () {
                // add to actualDate previous month;
                this._settings.actualDate = this.addMonths(this._settings.actualDate, -1);
                this._updateHeaderActualDateDiv();
                this._updateDatesDiv();
            };
            RescoDatePicker.prototype._moveToNextYear = function () {
                this._settings.actualDate.setFullYear(this._settings.actualDate.getFullYear() + 1);
                this._changeView(this._viewStatus);
            };
            RescoDatePicker.prototype._moveToPreviousYear = function () {
                this._settings.actualDate.setFullYear(this._settings.actualDate.getFullYear() - 1);
                this._changeView(this._viewStatus);
            };
            RescoDatePicker.prototype._moveToNextDecade = function () {
                this._settings.actualDate.setFullYear(this._settings.actualDate.getFullYear() + 12);
                this._changeView(this._viewStatus);
            };
            RescoDatePicker.prototype._moveToPreviousDecade = function () {
                this._settings.actualDate.setFullYear(this._settings.actualDate.getFullYear() - 12);
                this._changeView(this._viewStatus);
            };
            RescoDatePicker.prototype._updateDatesDiv = function () {
                var mainElement = this.rescoDatePickerElement.getElementsByClassName("dates");
                if (mainElement.length === 1) {
                    var div = mainElement[0];
                    div.innerHTML = this._generateContent(this._heights.rowHeight);
                    this._addEventListenerToContentItems();
                }
                else {
                    console.log("Error more divs with class name 'dates'!");
                }
            };
            RescoDatePicker.prototype._updateHeaderActualDateDiv = function () {
                var dateValueElement = this.rescoDatePickerElement.getElementsByClassName("datePickerDateValue");
                if (dateValueElement.length === 1) {
                    var div = dateValueElement[0];
                    div.dataset.actualviewtype = this._viewStatus.toString();
                    div.textContent = this._formatDate();
                }
            };
            return RescoDatePicker;
        }());
        Controls.RescoDatePicker = RescoDatePicker;
        var RescoInputDatePicker = (function () {
            function RescoInputDatePicker(settings) {
                this.valueChanged = new Resco.Event(this);
                this._initSettings(settings);
                var htmlTemplate = "\
			<div class='rescoInputDatePicker' data-isEditable='" + this._settings.isEditable + "' style='width:" + this._settings.dimension.width + "px; height:" + this._settings.dimension.height + "px;'>\
				<div class='inputPart'>\
					<input placeholder='add date' value='" + this._formatDate() + "' " + (this._settings.readOnly === true ? "readonly='readonly'" : '') + "/>\
				</div>\
				<div class='rescoDatePickerPart' style='height:" + this._settings.dimension.height + "px;'>\
					<div class='icon' style='width:" + this._settings.dimension.height + "px; height:" + this._settings.dimension.height + "px; background-image: url(" + this._settings.datePickerIcon + ")'></div>\
				</div>\
			</div>";
                this._settings.parentElement.insertAdjacentHTML("beforeend", htmlTemplate);
                this._datePicker = new RescoDatePicker(this._settings.datePickerSetting, this._settings.parentElement.getElementsByClassName("rescoDatePickerPart")[0], false, true);
                this._datePicker.datePickerClicked.add(this, this._onClickedDatePicker);
                this._datePicker.datePickerBlur.add(this, this._onBlurDatePicker);
                this.linearDatePickerElement = this._settings.parentElement.getElementsByClassName("rescoInputDatePicker")[0];
                this._inputElement = this.linearDatePickerElement.getElementsByTagName("input")[0];
                if (this._settings.useRotationForIcon) {
                    this._icon = this.linearDatePickerElement.getElementsByClassName("icon")[0];
                }
                if (this._settings.isEditable)
                    this._addEventListener();
                else
                    this._datePicker.parentElement.style.display = "none";
            }
            RescoInputDatePicker.prototype.getRescoDatePickerElement = function () {
                return this._datePicker.rescoDatePickerElement;
            };
            RescoInputDatePicker.prototype.disposeRescoDatePickerElement = function () {
                if (document.body.contains(this._datePicker.rescoDatePickerElement)) {
                    document.body.removeChild(this._datePicker.rescoDatePickerElement);
                }
            };
            RescoInputDatePicker.prototype.changeValue = function (newDate) {
                this.actualDate = new Date(newDate);
                this._datePicker.updateDefaultValue(newDate);
                this._inputElement.value = this._formatDate();
            };
            RescoInputDatePicker.prototype._initSettings = function (settings) {
                this._settings = settings;
                this.actualDate = this._settings.actualDate;
                if (settings.dimension === undefined) {
                    var parentElement = this._settings.parentElement;
                    this._settings.dimension = {
                        width: parentElement.offsetWidth > 0 ? parentElement.offsetWidth : 200,
                        height: parentElement.offsetHeight > 0 ? parentElement.offsetHeight : 40,
                        top: parentElement.offsetTop + parentElement.offsetHeight,
                        left: parentElement.offsetLeft,
                    };
                }
                if (settings.datePickerSetting === undefined) {
                    this._settings.datePickerSetting = {
                        actualDate: new Date(),
                        dayNames: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
                        firstWeekDay: 1,
                        images: [],
                        monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
                        platform: "Windows",
                    };
                }
                //#FIXME use some enum or another option for set dateFormat
                if (settings.dateFormat !== RescoInputDatePicker.dateFormat[0] && settings.dateFormat !== RescoInputDatePicker.dateFormat[1]) {
                    this._settings.dateFormat = RescoInputDatePicker.dateFormat[0];
                }
                if (settings.readOnly === undefined) {
                    this._settings.readOnly = true;
                }
                if (settings.useRotationForIcon === undefined) {
                    this._settings.useRotationForIcon = false;
                }
                if (settings.isEditable === undefined) {
                    this._settings.isEditable = true;
                }
            };
            RescoInputDatePicker.prototype._addEventListener = function () {
                var _this = this;
                if (this._settings.readOnly === true) {
                    this.linearDatePickerElement.addEventListener("click", function (e) {
                        _this._handleRescoDatePickerVisibility();
                    });
                }
                else {
                    var datePickerElem = this.linearDatePickerElement.children[1];
                    datePickerElem.addEventListener("click", function (e) {
                        _this._handleRescoDatePickerVisibility();
                    });
                }
            };
            RescoInputDatePicker.prototype._hideDatePicker = function () {
                if (this._isDatePickerVisible) {
                    this._datePicker.hideRescoDatePicker();
                    this._isDatePickerVisible = false;
                    if (this._settings.useRotationForIcon)
                        this._rotateRescoDatePickerIcon();
                }
            };
            RescoInputDatePicker.prototype._handleRescoDatePickerVisibility = function () {
                if (this._isDatePickerVisible) {
                    this._datePicker.hideRescoDatePicker();
                    this._isDatePickerVisible = false;
                    if (this._settings.useRotationForIcon)
                        this._rotateRescoDatePickerIcon();
                }
                else {
                    this._datePicker.showRescoDatePicker();
                    var boudingClientRect = this._settings.parentElement.getBoundingClientRect();
                    this._datePicker.updatePosition(Math.ceil(boudingClientRect.bottom), Math.floor(boudingClientRect.left), "100"); //@DM update position because during init it has 
                    this._isDatePickerVisible = true;
                    if (this._settings.useRotationForIcon)
                        this._rotateRescoDatePickerIcon();
                }
            };
            RescoInputDatePicker.prototype._onClickedDatePicker = function (sender, e) {
                var item = e.item;
                this.actualDate = item.date;
                this._settings.actualDate = this.actualDate;
                this._inputElement.value = this._formatDate(); //this.actualDate.toString();
                this.valueChanged.raise(new ValueChangedEventArgs(this.actualDate), this);
                this._hideDatePicker();
            };
            RescoInputDatePicker.prototype._onBlurDatePicker = function (sender, e) {
                this._hideDatePicker();
            };
            RescoInputDatePicker.prototype._formatDate = function () {
                var formattedDate = "";
                var y = this.actualDate.getFullYear();
                var m = this.actualDate.getMonth() + 1; //@DM: dates are counted form 0 - 11
                var d = this.actualDate.getDate();
                switch (this._settings.dateFormat) {
                    case RescoInputDatePicker.dateFormat[0]:
                        formattedDate = y + "-" + (m < 10 ? "0" + m : m) + "-" + (d < 10 ? "0" + d : d);
                        break;
                    case RescoInputDatePicker.dateFormat[1]:
                        formattedDate = (d < 10 ? "0" + d : d) + "." + (m < 10 ? "0" + m : m) + "." + y;
                        break;
                }
                return formattedDate;
            };
            RescoInputDatePicker.prototype._rotateRescoDatePickerIcon = function () {
                if (this._isDatePickerVisible) {
                    Utilities.removeAndAddClassToElement(this._icon, "defaultIcon", "rotateIcon");
                }
                else {
                    Utilities.removeAndAddClassToElement(this._icon, "rotateIcon", "defaultIcon");
                }
            };
            return RescoInputDatePicker;
        }());
        RescoInputDatePicker.dateFormat = ["yyyy-mm-dd", "dd.mm.yyyy"];
        Controls.RescoInputDatePicker = RescoInputDatePicker;
        ///// RescoTimePicker
        var RescoTimePickerFormat;
        (function (RescoTimePickerFormat) {
            RescoTimePickerFormat[RescoTimePickerFormat["format12"] = 12] = "format12";
            RescoTimePickerFormat[RescoTimePickerFormat["format24"] = 24] = "format24";
            RescoTimePickerFormat[RescoTimePickerFormat["formatUnlimited"] = -1] = "formatUnlimited";
        })(RescoTimePickerFormat = Controls.RescoTimePickerFormat || (Controls.RescoTimePickerFormat = {}));
        var RescoTimePickerMinRange;
        (function (RescoTimePickerMinRange) {
            RescoTimePickerMinRange[RescoTimePickerMinRange["range1"] = 1] = "range1";
            RescoTimePickerMinRange[RescoTimePickerMinRange["range5"] = 5] = "range5";
            RescoTimePickerMinRange[RescoTimePickerMinRange["range10"] = 10] = "range10";
            RescoTimePickerMinRange[RescoTimePickerMinRange["range15"] = 15] = "range15";
            RescoTimePickerMinRange[RescoTimePickerMinRange["range30"] = 30] = "range30";
            RescoTimePickerMinRange[RescoTimePickerMinRange["range60"] = 60] = "range60";
        })(RescoTimePickerMinRange = Controls.RescoTimePickerMinRange || (Controls.RescoTimePickerMinRange = {}));
        var RescoTime = (function () {
            function RescoTime(date) {
                var h = 0;
                var m = 0;
                if (date !== undefined) {
                    if (typeof date === "number") {
                        var minutes = Math.floor(date / (60 * 1000));
                        h = Math.floor(minutes / 60);
                        m = minutes - (h * 60);
                    }
                    else {
                        h = date.getHours();
                        m = date.getMinutes();
                    }
                }
                this._hour = h;
                this._minute = m;
            }
            Object.defineProperty(RescoTime.prototype, "hour", {
                get: function () {
                    return this._hour;
                },
                set: function (value) {
                    this._hour = value; // RescoTime now does not restrict hours to keep whole time.
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(RescoTime.prototype, "minute", {
                get: function () {
                    return this._minute;
                },
                set: function (value) {
                    var h = Math.floor(value / 60);
                    this._minute = value - (h * 60);
                    this._hour += h;
                },
                enumerable: true,
                configurable: true
            });
            RescoTime.prototype.formatValue = function (format) {
                var timeValue;
                if (format !== undefined && format === RescoTimePickerFormat.format12 && (this._hour < 24)) {
                    var h = (this._hour % 12 || 12);
                    var period = this._hour < 12 ? "AM" : "PM";
                    timeValue = (h < 10 ? "0" + h : h) + ":" + (this._minute < 10 ? "0" + this._minute : this._minute) + period;
                }
                else {
                    timeValue = (this._hour < 10 ? "0" + this._hour : this._hour) + ":" + (this._minute < 10 ? "0" + this._minute : this._minute);
                }
                return timeValue;
            };
            RescoTime.convertMinutesToRescoTime = function (minutes) {
                minutes = Math.floor(minutes);
                //var d = Math.floor(minutes / (24 * 60));
                //minutes -= d * (24 * 60); // RescoTime now does not restrict hours to keep whole time.
                var h = Math.floor(minutes / 60);
                minutes -= h * 60;
                var rt = new Resco.Controls.RescoTime();
                rt.hour = h;
                rt.minute = minutes;
                return rt;
            };
            RescoTime.convertFromRescoTimeToMilisecond = function (time) {
                var minuteInMiliseconds = 60 * 1000;
                return (time.hour * 60 + time.minute) * minuteInMiliseconds;
            };
            return RescoTime;
        }());
        Controls.RescoTime = RescoTime;
        var HoursArray = (function () {
            function HoursArray(format) {
                this._length = 0; // -1 represents unlimited length
                if (format === RescoTimePickerFormat.format12) {
                    this._length = 12;
                }
                else if (format === RescoTimePickerFormat.format24) {
                    this._length = 24;
                }
                else {
                    this._length = -1;
                }
            }
            Object.defineProperty(HoursArray.prototype, "length", {
                get: function () {
                    return this._length;
                },
                enumerable: true,
                configurable: true
            });
            HoursArray.prototype.getHours = function (index) {
                if ((index === 0) && (this.length === 12))
                    return 12;
                else
                    return index;
            };
            return HoursArray;
        }());
        var RescoTimePicker = (function () {
            function RescoTimePicker(settings, parentElement, visibleAfterInit) {
                this.m_dimension = { width: 0, height: 0, top: 0, left: 0 };
                this.m_periods = ["AM", "PM"];
                this.m_periodIndex = 0;
                this._swipe = { xDown: null, yDown: null };
                this.id = Utilities.generateUniqueIdentifier();
                this.m_settings = settings;
                this._initFields(parentElement);
                this._updateDimension();
                this._loadTemplate();
                this.rescoTimePickerElement = document.getElementById(this.id);
                this._addEventListenerToTimePicker();
                if (visibleAfterInit === undefined || visibleAfterInit === true)
                    this.showRescoTimePicker();
                else {
                    this.hideRescoTimePicker(false, visibleAfterInit);
                }
            }
            RescoTimePicker.prototype.showRescoTimePicker = function () {
                this.rescoTimePickerElement.style.display = "";
                this._updateContent();
                //@DM: Add invisible layer for handle click out of the rescoDatePicker element
                document.body.insertAdjacentHTML("afterbegin", "<div id='rescoInvisibleControlLayer" + this.id + "' class='rescoInvisibleControlLayer'></div>");
                this._addEventListenerToInvisibleLayer();
            };
            RescoTimePicker.prototype.hideRescoTimePicker = function (raiseChange, visibleAfterInit) {
                this.rescoTimePickerElement.style.display = "none";
                if (raiseChange) {
                    var newTime = new RescoTime();
                    newTime.hour = this.m_hoursArray.getHours(this.m_hourIndex);
                    newTime.minute = this.m_minutes[this.m_minuteIndex];
                    if (this.m_settings.format === RescoTimePickerFormat.format12) {
                        if (this.m_periodIndex === 1)
                            newTime.hour += (this.m_hourIndex === 0) ? 0 : 12;
                        else if (this.m_hourIndex === 0)
                            newTime.hour = 0;
                    }
                    this.valueChanged.raise(new ValueChangedEventArgs(newTime), this);
                }
                if (visibleAfterInit === undefined)
                    this._removeEventListenerFromInvisibleLayer();
            };
            RescoTimePicker.prototype.updatePosition = function (top, left, zindex) {
                this.m_dimension.top = top;
                this.rescoTimePickerElement.style.top = this.m_dimension.top + "px";
                this.m_dimension.left = left;
                this.rescoTimePickerElement.style.left = this.m_dimension.left + "px";
                if (zindex !== undefined) {
                    this.rescoTimePickerElement.style.zIndex = zindex;
                    var rescoInvisibleControlLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                    rescoInvisibleControlLayer.style.zIndex = (+zindex - 1).toString();
                }
            };
            RescoTimePicker.prototype._initFields = function (parentElement) {
                this.time = this.m_settings.time;
                this.m_hoursArray = new HoursArray(this.m_settings.format);
                if (this.m_settings.format === RescoTimePickerFormat.format12) {
                    this.m_hourIndex = (this.time.hour % 12);
                    this.m_periodIndex = Math.floor(this.time.hour / 12);
                }
                else if (this.m_settings.format === RescoTimePickerFormat.format24) {
                    this.m_hourIndex = (this.time.hour % 24);
                }
                else {
                    this.m_hourIndex = this.time.hour;
                }
                this.m_minutes = new Array();
                var itemsCount = 60 / this.m_settings.minRange;
                for (var i = 0; i < itemsCount; i++) {
                    var minute = this.m_settings.minRange * i;
                    this.m_minutes.push(minute);
                }
                var actualMin = this.m_settings.minRange * Math.floor(this.time.minute / this.m_settings.minRange);
                this.m_minuteIndex = this.m_minutes.indexOf(actualMin);
                this.parentElement = parentElement;
                this.valueChanged = new Resco.Event(this);
            };
            RescoTimePicker.prototype._updateDimension = function () {
                this.m_dimension.height = 200;
                this.m_dimension.width = 200;
                this.m_dimension.left = this.parentElement.offsetLeft;
                this.m_dimension.top = this.parentElement.offsetTop + this.parentElement.offsetHeight;
            };
            RescoTimePicker.prototype._loadTemplate = function () {
                var template = "\
				<div class='rescoTimePicker' id='" + this.id + "' style='width:" + this.m_dimension.height + "px; height:" + this.m_dimension.height + "px; top:" + this.m_dimension.top + "px;left:" + this.m_dimension.left + "px'>\
					<div class='hoursPart' style='height:" + this.m_dimension.height + "px;'>" + this._generateHoursPart() + "</div>\
					<div class='minutesPart' style='height:" + this.m_dimension.height + "px;'>" + this._generateMinutesPart() + "</div>\
			";
                if (this.m_settings.format === RescoTimePickerFormat.format12) {
                    template += "<div class='periodPart' style= 'height:" + this.m_dimension.height + "px'> " + this._generatePeriodPart() + "</div>";
                }
                template += "</div>";
                document.body.insertAdjacentHTML("beforeend", template);
            };
            RescoTimePicker.prototype._loadAvailableHours = function () {
                var hours = new Array();
                if (this.m_hourIndex > 0) {
                    for (var i = this.m_hourIndex - 1; i <= this.m_hourIndex + 1; i++) {
                        if ((this.m_hoursArray.length < 0) || (i < this.m_hoursArray.length))
                            hours.push(this.m_hoursArray.getHours(i).toString()); //TODO add format
                    }
                    if (hours.length < 3)
                        hours.push("");
                }
                else {
                    hours.push("");
                    hours.push(this.m_hoursArray.getHours(this.m_hourIndex).toString());
                    hours.push(this.m_hoursArray.getHours(this.m_hourIndex + 1).toString());
                }
                return hours;
            };
            RescoTimePicker.prototype._loadAvailableMinutes = function () {
                var minutes = new Array();
                if (this.m_minuteIndex > 0) {
                    for (var i = this.m_minuteIndex - 1; i <= this.m_minuteIndex + 1; i++) {
                        if (i < this.m_minutes.length)
                            minutes.push(this.m_minutes[i].toString());
                    }
                    if (minutes.length < 3)
                        minutes.push("");
                }
                else {
                    minutes.push("");
                    minutes.push(this.m_minutes[this.m_minuteIndex].toString());
                    minutes.push(this.m_minutes.length === 1 ? "" : this.m_minutes[this.m_minuteIndex + 1].toString());
                }
                return minutes;
            };
            RescoTimePicker.prototype._loadAvailablePeriods = function () {
                var periods = this.m_periods.slice();
                if (this.m_periodIndex === 0)
                    periods.unshift("");
                else
                    periods.push("");
                return periods;
            };
            RescoTimePicker.prototype._generateHoursPart = function () {
                var hours = this._loadAvailableHours();
                var divs = "\
					<div class='button upHour'><div class='arrow' style='background-image: url(" + this.m_settings.arrowImages[0] + ");'></div></div>\
					<div class='hour previous'>" + hours[0] + "</div>\
					<div class='hour actual'>" + hours[1] + "</div>\
					<div class='hour next'>" + hours[2] + "</div>\
					<div class='button downHour'><div class='arrow' style='background-image: url(" + this.m_settings.arrowImages[1] + ");'></div></div>\
				";
                return divs;
            };
            RescoTimePicker.prototype._generateMinutesPart = function () {
                var minutes = this._loadAvailableMinutes();
                var divs = "\
					<div class='button upMinute'><div class='arrow' style='background-image: url(" + this.m_settings.arrowImages[0] + ");'></div></div>\
					<div class='minute previous'>" + minutes[0] + "</div>\
					<div class='minute actual'>" + minutes[1] + "</div>\
					<div class='minute next'>" + minutes[2] + "</div>\
					<div class='button downMinute'><div class='arrow' style='background-image: url(" + this.m_settings.arrowImages[1] + ");'></div></div>\
				";
                return divs;
            };
            RescoTimePicker.prototype._generatePeriodPart = function () {
                var periods = this._loadAvailablePeriods();
                var divs = "\
					<div class='button upPeriod'><div class='arrow' style='background-image: url(" + this.m_settings.arrowImages[0] + ");'></div></div>\
					<div class='period previous'>" + periods[0] + "</div>\
					<div class='period actual'>" + periods[1] + "</div>\
					<div class='period next'>" + periods[2] + "</div>\
					<div class='button downPeriod'><div class='arrow' style='background-image: url(" + this.m_settings.arrowImages[1] + ");'></div></div>\
				";
                return divs;
            };
            RescoTimePicker.prototype._addEventListenerToTimePicker = function () {
                var _this = this;
                var upHour = this.rescoTimePickerElement.getElementsByClassName("upHour")[0];
                upHour.addEventListener("click", function (e) {
                    _this._moveToPreviousHour();
                });
                var downHour = this.rescoTimePickerElement.getElementsByClassName("downHour")[0];
                downHour.addEventListener("click", function (e) {
                    _this._moveToNextHour();
                });
                var upMinute = this.rescoTimePickerElement.getElementsByClassName("upMinute")[0];
                upMinute.addEventListener("click", function (e) {
                    _this._moveToPreviousMinute();
                });
                var downMinute = this.rescoTimePickerElement.getElementsByClassName("downMinute")[0];
                downMinute.addEventListener("click", function () {
                    _this._moveToNextMinute();
                });
                var hourPart = this.rescoTimePickerElement.getElementsByClassName("hoursPart")[0];
                var minutePart = this.rescoTimePickerElement.getElementsByClassName("minutesPart")[0];
                if (this.m_settings.platform === "Windows") {
                    this._addWheelEventListenerToElement(hourPart, function () { return _this._moveToPreviousHour(); }, function () { return _this._moveToNextHour(); });
                    this._addWheelEventListenerToElement(minutePart, function () { return _this._moveToPreviousMinute(); }, function () { return _this._moveToNextMinute(); });
                }
                else if (this.m_settings.platform === "Windows10") {
                    this._addWheelEventListenerToElement(hourPart, function () { return _this._moveToPreviousHour(); }, function () { return _this._moveToNextHour(); });
                    this._addSwipeEventListenerToElement(hourPart, function () { return _this._moveToPreviousHour(); }, function () { return _this._moveToNextHour(); });
                    this._addWheelEventListenerToElement(minutePart, function () { return _this._moveToPreviousMinute(); }, function () { return _this._moveToNextMinute(); });
                    this._addSwipeEventListenerToElement(minutePart, function () { return _this._moveToPreviousMinute(); }, function () { return _this._moveToNextMinute(); });
                }
                else {
                    this._addSwipeEventListenerToElement(hourPart, function () { return _this._moveToPreviousHour(); }, function () { return _this._moveToNextHour(); });
                    this._addSwipeEventListenerToElement(minutePart, function () { return _this._moveToPreviousMinute(); }, function () { return _this._moveToNextMinute(); });
                }
                this._addClickEventListenerToElement(hourPart, function () { return _this._moveToPreviousHour(); }, function () { return _this._moveToNextHour(); });
                this._addClickEventListenerToElement(minutePart, function () { return _this._moveToPreviousMinute(); }, function () { return _this._moveToNextMinute(); });
                if (this.m_settings.format === RescoTimePickerFormat.format12) {
                    var periodPart = this.rescoTimePickerElement.getElementsByClassName("periodPart")[0];
                    this._addClickEventListenerToElement(periodPart, function () { return _this._moveToPreviousPeriod(); }, function () { return _this._moveToNextPeriod(); });
                    this._addWheelEventListenerToElement(periodPart, function () { return _this._moveToPreviousPeriod(); }, function () { return _this._moveToNextPeriod(); });
                    var upPeriod = this.rescoTimePickerElement.getElementsByClassName("upPeriod")[0];
                    upPeriod.addEventListener("click", function (e) {
                        _this._moveToPreviousPeriod();
                    });
                    var downPeriod = this.rescoTimePickerElement.getElementsByClassName("downPeriod")[0];
                    downPeriod.addEventListener("click", function (e) {
                        _this._moveToNextPeriod();
                    });
                }
            };
            RescoTimePicker.prototype._addWheelEventListenerToElement = function (element, movePrevious, moveNext) {
                element.addEventListener("mousewheel", function (e) {
                    var delta = e.wheelDelta;
                    if (delta > 0) {
                        movePrevious();
                    }
                    else {
                        moveNext();
                    }
                    if (e.preventDefault)
                        e.preventDefault();
                    else
                        return false;
                }, false);
            };
            RescoTimePicker.prototype._addSwipeEventListenerToElement = function (element, movePrevious, moveNext) {
                var _this = this;
                this._swipe = { xDown: null, yDown: null };
                element.addEventListener('touchstart', function (e) {
                    _this._swipe.xDown = e.touches[0].clientX;
                    _this._swipe.yDown = e.touches[0].clientY;
                }, false);
                element.addEventListener('touchmove', function (e) {
                    if (!_this._swipe.xDown || !_this._swipe.yDown) {
                        return;
                    }
                    var xUp = e.touches[0].clientX;
                    var yUp = e.touches[0].clientY;
                    var xDiff = _this._swipe.xDown - xUp;
                    var yDiff = _this._swipe.yDown - yUp;
                    if (Math.abs(xDiff) < Math.abs(yDiff)) {
                        if (yDiff > 0) {
                            moveNext();
                        }
                        else {
                            movePrevious();
                        }
                    }
                    _this._swipe.xDown = null;
                    _this._swipe.yDown = null;
                }, false);
            };
            RescoTimePicker.prototype._addClickEventListenerToElement = function (element, movePrevious, moveNext) {
                if (element !== undefined && element.children !== undefined)
                    for (var i = 0; i < element.children.length; i++) {
                        var child = element.children[i];
                        if (child.classList.contains("previous")) {
                            child.addEventListener("click", function () {
                                movePrevious();
                            });
                        }
                        if (child.classList.contains("next")) {
                            child.addEventListener("click", function () {
                                moveNext();
                            });
                        }
                    }
            };
            RescoTimePicker.prototype._moveToPreviousHour = function () {
                if (this.m_hourIndex > 0) {
                    this.m_hourIndex--;
                    this._updateHoursElementsContent();
                }
            };
            RescoTimePicker.prototype._moveToNextHour = function () {
                if ((this.m_hoursArray.length < 0) || (this.m_hourIndex < this.m_hoursArray.length - 1)) {
                    this.m_hourIndex++;
                    this._updateHoursElementsContent();
                }
            };
            RescoTimePicker.prototype._moveToPreviousMinute = function () {
                if (this.m_minuteIndex > 0) {
                    this.m_minuteIndex--;
                    this._updateMinuteElementsContent();
                }
            };
            RescoTimePicker.prototype._moveToNextMinute = function () {
                if (this.m_minuteIndex < this.m_minutes.length - 1) {
                    this.m_minuteIndex++;
                    this._updateMinuteElementsContent();
                }
            };
            RescoTimePicker.prototype._moveToPreviousPeriod = function () {
                if (this.m_periodIndex > 0) {
                    this.m_periodIndex--;
                    this._updatePeriodElementsContent();
                }
            };
            RescoTimePicker.prototype._moveToNextPeriod = function () {
                if (this.m_periodIndex < this.m_periods.length - 1) {
                    this.m_periodIndex++;
                    this._updatePeriodElementsContent();
                }
            };
            RescoTimePicker.prototype._updateHoursElementsContent = function () {
                var hours = this._loadAvailableHours();
                var hoursElements = this.rescoTimePickerElement.getElementsByClassName("hour");
                for (var i = 0; i < hoursElements.length; i++) {
                    hoursElements[i].textContent = hours[i];
                }
            };
            RescoTimePicker.prototype._updateMinuteElementsContent = function () {
                var minutes = this._loadAvailableMinutes();
                var minuteElements = this.rescoTimePickerElement.getElementsByClassName("minute");
                for (var i = 0; i < minuteElements.length; i++) {
                    minuteElements[i].textContent = minutes[i];
                }
            };
            RescoTimePicker.prototype._updatePeriodElementsContent = function () {
                var periods = this._loadAvailablePeriods();
                var periodElements = this.rescoTimePickerElement.getElementsByClassName("period");
                for (var i = 0; i < periodElements.length; i++) {
                    periodElements[i].textContent = periods[i];
                }
            };
            RescoTimePicker.prototype._addEventListenerToInvisibleLayer = function () {
                var _this = this;
                var invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                invisibleDatePickerLayer.addEventListener("click", function (e) {
                    _this.hideRescoTimePicker(true);
                });
            };
            RescoTimePicker.prototype._removeEventListenerFromInvisibleLayer = function () {
                var invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                if (invisibleDatePickerLayer !== null)
                    document.body.removeChild(invisibleDatePickerLayer);
            };
            RescoTimePicker.prototype._updateContent = function () {
                var hour = this.time.hour;
                if (this.m_settings.format === RescoTimePickerFormat.format12) {
                    hour = (hour % 12);
                }
                else if (this.m_settings.format === RescoTimePickerFormat.format24) {
                    hour = (hour % 24);
                }
                if (this.m_hourIndex !== hour) {
                    this.m_hourIndex = hour;
                    this._updateHoursElementsContent();
                }
                var actualMin = this.m_settings.minRange * Math.floor(this.time.minute / this.m_settings.minRange);
                var minIndex = this.m_minutes.indexOf(actualMin);
                if (actualMin !== minIndex) {
                    this.m_minuteIndex = minIndex;
                    this._updateMinuteElementsContent();
                }
            };
            return RescoTimePicker;
        }());
        Controls.RescoTimePicker = RescoTimePicker;
        var RescoInputTimePicker = (function () {
            function RescoInputTimePicker(settings) {
                this.m_isTimePickerVisible = false;
                this.valueChanged = new Resco.Event(this);
                this._initSettings(settings);
                var htmlTemplate = "\
			<div class='rescoInputTimePicker' data-isEditable='" + this.m_settings.isEditable + "' style='width:" + this.m_settings.dimension.width + "px; height:" + this.m_settings.dimension.height + "px;'>\
				<div class='inputPart'>\
					<input placeholder='add time' value='" + this.actualTime.formatValue(this.m_settings.timePickerSettings.format) + "' " + (this.m_settings.readOnly === true ? "readonly='readonly'" : '') + "/>\
				</div>\
				<div class='rescoTimePickerPart' style='height:" + this.m_settings.dimension.height + "px;'>\
					<div class='icon' style='width:" + this.m_settings.dimension.height + "px; height:" + this.m_settings.dimension.height + "px; background-image: url(" + this.m_settings.timePickerIcon + ")'></div>\
				</div>\
			</div>";
                this.m_settings.parentElement.insertAdjacentHTML("beforeend", htmlTemplate);
                this.inputTimePicker = this.m_settings.parentElement.getElementsByClassName("rescoInputTimePicker")[0];
                this.m_inputElement = this.inputTimePicker.getElementsByTagName("input")[0];
                if (this.m_settings.useRotationForIcon) {
                    this.m_icon = this.inputTimePicker.getElementsByClassName("icon")[0];
                }
                this.m_rescoTimePicker = new RescoTimePicker(this.m_settings.timePickerSettings, this.m_settings.parentElement.getElementsByClassName("rescoTimePickerPart")[0], false);
                this.m_rescoTimePicker.valueChanged.add(this, this._onTimePickerValueChanged);
                if (this.m_settings.isEditable)
                    this._addEventListenerToTimePicker();
                else
                    this.m_rescoTimePicker.parentElement.style.display = "none";
            }
            RescoInputTimePicker.prototype.getRescoTimePickerElement = function () {
                return this.m_rescoTimePicker.rescoTimePickerElement;
            };
            RescoInputTimePicker.prototype.disposeRescoTimePickerElement = function () {
                if (document.body.contains(this.m_rescoTimePicker.rescoTimePickerElement)) {
                    document.body.removeChild(this.m_rescoTimePicker.rescoTimePickerElement);
                }
            };
            RescoInputTimePicker.prototype.changeTime = function (time) {
                this.actualTime = this.validateTime(time);
                this.m_settings.actualTime = this.actualTime;
                this.m_settings.timePickerSettings.time = this.actualTime;
                this.m_rescoTimePicker.time = this.actualTime;
                this.m_inputElement.value = this.actualTime.formatValue(this.m_settings.timePickerSettings.format);
            };
            RescoInputTimePicker.prototype.validateTime = function (time) {
                var validTime = new RescoTime();
                if (this.m_settings.timePickerSettings.format === RescoTimePickerFormat.format12) {
                    validTime.hour = time.hour % 12;
                }
                else if (this.m_settings.timePickerSettings.format === RescoTimePickerFormat.format24) {
                    validTime.hour = time.hour % 24;
                }
                else {
                    validTime.hour = time.hour;
                }
                validTime.minute = time.minute;
                return validTime;
            };
            RescoInputTimePicker.prototype._initSettings = function (settings) {
                this.m_settings = settings;
                this.actualTime = this.validateTime(this.m_settings.actualTime);
                if (this.m_settings.timePickerSettings === undefined) {
                    this.m_settings.timePickerSettings = {
                        format: Resco.Controls.RescoTimePickerFormat.format24,
                        minRange: Resco.Controls.RescoTimePickerMinRange.range5,
                        arrowImages: [],
                        platform: "Windows",
                        time: this.actualTime,
                    };
                }
                if (this.m_settings.dimension === undefined) {
                    var parentElement = this.m_settings.parentElement;
                    this.m_settings.dimension = {
                        width: parentElement.offsetWidth > 0 ? parentElement.offsetWidth : 100,
                        height: parentElement.offsetHeight > 0 ? parentElement.offsetHeight : 40,
                        top: parentElement.offsetTop + parentElement.offsetHeight,
                        left: parentElement.offsetLeft,
                    };
                }
                if (this.m_settings.readOnly === undefined) {
                    this.m_settings.readOnly = true;
                }
                if (this.m_settings.useRotationForIcon === undefined) {
                    this.m_settings.useRotationForIcon = false;
                }
                if (this.m_settings.isEditable === undefined) {
                    this.m_settings.isEditable = true;
                }
            };
            RescoInputTimePicker.prototype._addEventListenerToTimePicker = function () {
                var _this = this;
                if (this.m_settings.readOnly === true) {
                    this.inputTimePicker.addEventListener("click", function (e) {
                        _this._handleRescoTimePickerVisibility();
                    });
                }
                else {
                    var timePickerElem = this.inputTimePicker.children[1];
                    timePickerElem.addEventListener("click", function (e) {
                        _this._handleRescoTimePickerVisibility();
                    });
                }
            };
            RescoInputTimePicker.prototype._onTimePickerValueChanged = function (sender, e) {
                var value = e.value;
                this.actualTime = this.validateTime(value);
                this.m_inputElement.value = this.actualTime.formatValue(this.m_settings.timePickerSettings.format);
                this.m_isTimePickerVisible = false;
                this.m_settings.timePickerSettings.time = this.actualTime;
                this.m_rescoTimePicker.time = this.actualTime;
                this.valueChanged.raise(new ValueChangedEventArgs(this.actualTime), this);
                if (this.m_settings.useRotationForIcon)
                    this._rotateRescoTimePickerIcon();
            };
            RescoInputTimePicker.prototype._handleRescoTimePickerVisibility = function () {
                if (this.m_isTimePickerVisible) {
                    this.m_isTimePickerVisible = false;
                    if (this.m_settings.useRotationForIcon)
                        this._rotateRescoTimePickerIcon();
                    this.m_rescoTimePicker.hideRescoTimePicker(true);
                }
                else {
                    this.m_isTimePickerVisible = true;
                    if (this.m_settings.useRotationForIcon)
                        this._rotateRescoTimePickerIcon();
                    this.m_rescoTimePicker.showRescoTimePicker();
                    var boundingClientRect = this.m_settings.parentElement.getBoundingClientRect();
                    this.m_rescoTimePicker.updatePosition(Math.ceil(boundingClientRect.bottom), Math.floor(boundingClientRect.left), "100"); //@DM update position because during init it has 
                }
            };
            RescoInputTimePicker.prototype._rotateRescoTimePickerIcon = function () {
                if (this.m_isTimePickerVisible) {
                    Utilities.removeAndAddClassToElement(this.m_icon, "defaultIcon", "rotateIcon");
                }
                else {
                    Utilities.removeAndAddClassToElement(this.m_icon, "rotateIcon", "defaultIcon");
                }
            };
            return RescoInputTimePicker;
        }());
        Controls.RescoInputTimePicker = RescoInputTimePicker;
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
