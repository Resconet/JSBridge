///<reference path="utilities.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var ButtonsBar = (function () {
                function ButtonsBar() {
                    this.autoPlannerPopupMenu = undefined;
                    this._template = '\
			<div id="schedulerButtonsBar">\
				<div class="toolbarButton" onclick="Resco.Controls.Scheduler.SettingsDialog.show(_scheduler);">\
					<div id="settingsIcon" class="imageButton" style="background-image: url(\'settings.png\');"></div>\
					<div id="showSettingsDialog" class="textButton" data-localization="Scheduler.Msg.SETTINGS">SETTINGS</div>\
				</div>\
				<div class="toolbarButton" onclick="_scheduler.buttonsBar.onAutoPlannerClick();">\
				    <div id="autoPlannerIcon" class="imageButton" style="background-image: url(\'settingsM.png\');"></div>\
					<div id="runReschedule" class="textButton" data-localization="Scheduler.Msg.RUNAUTOSCHEDULE">RUN AUTO-SCHEDULE</div>\
				</div>\
				<div class="labelBar">\
					<label id="filterStatus"></label>\
				</div>\
				<div class="zoomControl">\
					<div id="leftArrow" onclick="_scheduler.viewCtrl.doPageScroll(-1);"></div>\
					<div id="todayButton" class="textButton" onclick="_scheduler.viewCtrl.showDate(null);" data-localization="Msg.TODAY">TODAY</div>\
					<div id="rightArrow" onclick="_scheduler.viewCtrl.doPageScroll(+1);"></div>\
					<div id="calendarPreview" onclick="_scheduler.viewCtrl.openCalendarPreview();">\
						<div class="calendarPreviewIcon"></div>\
						<div class="calendarPreviewArrow"></div>\
					</div>\
					<select id="zoomLevel" style="width: 120px; height: 100%;" onChange="_scheduler.viewCtrl.setZoomLevel();">\
						<option value="h" data-localization="Msg.Day">Day</option>\
						<option value="h2" data-localization="Msg.Days" data-localizationvalues="2">2 Days</option>\
						<option value="h3" data-localization="Msg.Days" data-localizationvalues="3">3 Days</option>\
						<option value="d" data-localization="Msg.Week">Week</option>\
						<option value="d2" data-localization="Msg.Weeks" data-localizationvalues="2">2 Weeks</option>\
						<option value="d4" data-localization="Msg.Weeks" data-localizationvalues="4">4 Weeks</option>\
						<option value="d6" data-localization="Msg.Weeks" data-localizationvalues="6">6 Weeks</option>\
						<option value="m" data-localization="Msg.MonthOverview">Month overview</option>\
					</select>\
				</div>\
			</div>\
		';
                }
                Object.defineProperty(ButtonsBar.prototype, "element", {
                    get: function () {
                        if (!this._element) {
                            this._element = this._createButtonsBarElement();
                            Scheduler.StringTable.localizeElements(this._element);
                        }
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "filterElement", {
                    get: function () {
                        return this.element.find("#settingsIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "autoPlannerElement", {
                    get: function () {
                        return this.element.find("#autoPlannerIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "filterStatusElement", {
                    get: function () {
                        return this.element.find("#filterStatus");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "leftArrowElement", {
                    get: function () {
                        return this.element.find("#leftArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "todayButtonElement", {
                    get: function () {
                        return this.element.find("#todayButton");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "rightArrowElement", {
                    get: function () {
                        return this.element.find("#rightArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewElement", {
                    get: function () {
                        return this.element.find("#calendarPreview");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewIconElement", {
                    get: function () {
                        return this.calendarPreviewElement.find(".calendarPreviewIcon");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "calendarPreviewArrowElement", {
                    get: function () {
                        return this.calendarPreviewElement.find(".calendarPreviewArrow");
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(ButtonsBar.prototype, "zoomLevelElement", {
                    get: function () {
                        return this.element.find("#zoomLevel");
                    },
                    enumerable: true,
                    configurable: true
                });
                ButtonsBar.prototype.updateAutoPlannerIcon = function () {
                    var mode = Scheduler.Container.ref.settings.autoPlanner.manualScheduleMode;
                    var element = this.element.find("#autoPlannerIcon")[0];
                    if (mode == Scheduler.eMode.Manual)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsM.png");
                    else if (mode == Scheduler.eMode.SemiOptimized)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsS.png");
                    else if (mode == Scheduler.eMode.RouteOptimization)
                        Scheduler.Container.setElementBackgroundImage(element, "settingsT.png");
                    else
                        Scheduler.Container.setElementBackgroundImage(element, "settingsA.png");
                };
                ButtonsBar.prototype.onCustomFilterChanged = function (hasFilter) {
                    var icon = this.filterElement;
                    if (icon) {
                        var image = Scheduler.Container.imageFolder + (hasFilter ? "settingsFiltered.png" : "settings.png");
                        icon.css({ "background-image": "url(" + image + ")" });
                    }
                };
                ;
                ButtonsBar.prototype.onAutoPlannerStateChanged = function (started) {
                    var buttonCtrl = this.element.find("#runReschedule");
                    ;
                    if (buttonCtrl) {
                        if (started)
                            buttonCtrl.text(Scheduler.StringTable.get("Scheduler.Msg.STOPAUTOSCHEDULE"));
                        else
                            buttonCtrl.text(Scheduler.StringTable.get("Scheduler.Msg.RUNAUTOSCHEDULE"));
                    }
                    if (started) {
                        var element = this.element.find("#autoPlannerIcon")[0];
                        Scheduler.Container.setElementBackgroundImage(element, "stop.png");
                    }
                    else
                        this.updateAutoPlannerIcon();
                };
                ButtonsBar.prototype.onAutoPlannerClick = function () {
                    if (!this.autoPlannerPopupMenu) {
                        this.autoPlannerPopupMenu = new Controls.PopupMenu();
                        this.autoPlannerPopupMenu.width = 350;
                        this.autoPlannerPopupMenu.iconSize = 22;
                        this.autoPlannerPopupMenu.menuColor = "#eeeeee";
                        this.autoPlannerPopupMenu.borderColor = "#aaaaaa";
                        this.autoPlannerPopupMenu.useBorder = true;
                    }
                    this.autoPlannerPopupMenu.items = [];
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.SemiOptimization") || "Optimize schedules per Resource", "url(" + Scheduler.Container.imageFolder + "settingsS.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.SemiOptimized);
                    }));
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.RouteOptimization") || "Optimization Route (per day)", "url(" + Scheduler.Container.imageFolder + "settingsT.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.RouteOptimization);
                    }));
                    this.autoPlannerPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.FullOptimization") || "Do Full Optimization", "url(" + Scheduler.Container.imageFolder + "settingsA.png)", function (e) {
                        Scheduler.AutoPlanner.Core.run(Scheduler.eMode.Optimized);
                    }));
                    var offset = this.autoPlannerElement.offset();
                    this.autoPlannerPopupMenu.x = offset.left;
                    this.autoPlannerPopupMenu.y = this.element.outerHeight(true);
                    this.autoPlannerPopupMenu.open();
                };
                ButtonsBar.prototype._createButtonsBarElement = function () {
                    return Scheduler.Utilities.createFromTemplate(this._template);
                };
                return ButtonsBar;
            }());
            Scheduler.ButtonsBar = ButtonsBar;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
