///<reference path="utilities.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var InfoBar = (function () {
                function InfoBar(imagesRootPath) {
                    this._template = '\
			<div id="schedulerInfoBar">\
				<div id="statusInfo">\
					<span class="text"></span>\
				</div>\
			</div>\
		';
                    this._kpiControl = new KPIControl(imagesRootPath);
                }
                Object.defineProperty(InfoBar.prototype, "element", {
                    get: function () {
                        if (!this._element)
                            this._element = this._createInfoBarElement();
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(InfoBar.prototype, "kpiControl", {
                    get: function () {
                        return this._kpiControl;
                    },
                    enumerable: true,
                    configurable: true
                });
                InfoBar.prototype.setStatusInfo = function (text) {
                    this.element.find("#statusInfo span").text(text ? text : "");
                };
                InfoBar.prototype._createInfoBarElement = function () {
                    var infoBar = Scheduler.Utilities.createFromTemplate(this._template);
                    infoBar.append(this._kpiControl.element);
                    return infoBar;
                };
                return InfoBar;
            }());
            Scheduler.InfoBar = InfoBar;
            var KPIControl = (function () {
                function KPIControl(imagesRootPath) {
                    this._totalScheduledTime = 0;
                    this._averageTravelTime = 0;
                    this._completedTasksCount = 0;
                    this._allScheduledTasksCount = 0; // without TimeOffs
                    this._allUnscheduledTasksCount = 0;
                    this._ruleViolationsCount = 0;
                    this._jeopardyCount = 0;
                    this._imagesRootPath = "";
                    this._template = '\
			<div id="kpiControl">\
				<div id="unscheduledTasksCount" class="kpiControlItem hidden">\
					<div class="kpiImage" style="background-color: yellow;"></div>\
					<span class="kpiText">0</span>\
				</div>\
				<div id="totalScheduledTime" class="kpiControlItem">\
					<div class="kpiImage" data-icon="kpiScheduled.png"></div>\
					<span class="kpiText">0h 0m</span>\
				</div>\
				<div id="averageTravelTime" class="kpiControlItem">\
					<div class="kpiImage" data-icon="kpiTravel.png"></div>\
					<span class="kpiText">0h 0m</span>\
				</div>\
				<div id="completedTasksRate" class="kpiControlItem">\
					<div class="kpiImage" data-icon="kpiCompleted.png"></div>\
					<span class="kpiText">0/0</span>\
				</div>\
				<div id="ruleViolationsCount" class="kpiControlItem">\
					<div class="kpiImage" data-icon="kpiRuleViolations.png"></div>\
					<span class="kpiText">0</span>\
				</div>\
				<div id="jeopardyCount" class="kpiControlItem">\
					<div class="kpiImage" data-icon="kpiJeopardy.png"></div>\
					<span class="kpiText">0</span>\
				</div>\
			</div>\
		';
                    if (imagesRootPath)
                        this._imagesRootPath = imagesRootPath;
                }
                Object.defineProperty(KPIControl.prototype, "element", {
                    get: function () {
                        if (!this._element)
                            this._element = this._createKPIControlElement();
                        return this._element;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "totalScheduledTime", {
                    get: function () {
                        return this._totalScheduledTime;
                    },
                    set: function (value) {
                        if (this._totalScheduledTime !== value) {
                            this._totalScheduledTime = value;
                            var minutes = Scheduler.milisecondsToMinutes(this._totalScheduledTime);
                            var h = Math.floor(minutes / 60);
                            var m = minutes % 60;
                            var text = Scheduler.StringTable.get("Scheduler.Msg.HoursMinutes", [h.toString(), m.toString()]);
                            this._updateKPIText(this.element.find("#totalScheduledTime"), text);
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "averageTravelTime", {
                    get: function () {
                        return this._averageTravelTime;
                    },
                    set: function (value) {
                        if (this._averageTravelTime !== value) {
                            this._averageTravelTime = value;
                            var minutes = Scheduler.milisecondsToMinutes(this._averageTravelTime);
                            var h = Math.floor(minutes / 60);
                            var m = minutes % 60;
                            var text = Scheduler.StringTable.get("Scheduler.Msg.HoursMinutes", [h.toString(), m.toString()]);
                            this._updateKPIText(this.element.find("#averageTravelTime"), text);
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "completedTasksCount", {
                    get: function () {
                        return this._completedTasksCount;
                    },
                    set: function (value) {
                        if (this._completedTasksCount !== value) {
                            this._completedTasksCount = value;
                            this._updateCompletedTasksRate();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "allScheduledTasksCount", {
                    get: function () {
                        return this._allScheduledTasksCount;
                    },
                    set: function (value) {
                        if (this._allScheduledTasksCount !== value) {
                            this._allScheduledTasksCount = value;
                            this._updateCompletedTasksRate();
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "allUnscheduledTasksCount", {
                    get: function () {
                        return this._allUnscheduledTasksCount;
                    },
                    set: function (value) {
                        if (this._allUnscheduledTasksCount !== value) {
                            this._allUnscheduledTasksCount = value;
                            this._updateKPIText(this.element.find("#unscheduledTasksCount"), this._allUnscheduledTasksCount.toString());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "ruleViolationsCount", {
                    get: function () {
                        return this._ruleViolationsCount;
                    },
                    set: function (value) {
                        if (this._ruleViolationsCount !== value) {
                            this._ruleViolationsCount = value;
                            this._updateKPIText(this.element.find("#ruleViolationsCount"), this._ruleViolationsCount.toString());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(KPIControl.prototype, "jeopardyCount", {
                    get: function () {
                        return this._jeopardyCount;
                    },
                    set: function (value) {
                        if (this._jeopardyCount !== value) {
                            this._jeopardyCount = value;
                            this._updateKPIText(this.element.find("#jeopardyCount"), this._jeopardyCount.toString());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                KPIControl.prototype._updateCompletedTasksRate = function () {
                    var text = this._completedTasksCount.toString() + "/" + this._allScheduledTasksCount.toString();
                    this._updateKPIText(this.element.find("#completedTasksRate"), text);
                };
                KPIControl.prototype._updateKPIText = function (kpiControlItem, text) {
                    if (text) {
                        kpiControlItem.find("span.kpiText").text(text);
                    }
                };
                KPIControl.prototype._createKPIControlElement = function () {
                    var kpiControl = Scheduler.Utilities.createFromTemplate(this._template);
                    Scheduler.StringTable.localizeElements(kpiControl);
                    var images = kpiControl.find(".kpiImage");
                    for (var i = 0; i < images.length; i++) {
                        var element = images[i];
                        var icon = element.attributes["data-icon"];
                        if (icon && icon.nodeValue)
                            element.style.backgroundImage = "url(" + this._imagesRootPath + icon.nodeValue + ")";
                    }
                    return kpiControl;
                };
                return KPIControl;
            }());
            Scheduler.KPIControl = KPIControl;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
