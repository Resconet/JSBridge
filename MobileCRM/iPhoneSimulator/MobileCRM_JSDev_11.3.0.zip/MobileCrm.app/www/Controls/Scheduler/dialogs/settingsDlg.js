///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../../Controls/Scheduler/container.ts" />
///<reference path="../../../Controls/appColors.ts" />
///<reference path="../../../Controls/listBox.ts" />
///<reference path="baseDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            // Class for custom defined settings item
            var FilterListItem = (function () {
                function FilterListItem(id, name) {
                    this.id = id;
                    this.name = name;
                }
                return FilterListItem;
            }());
            Scheduler.FilterListItem = FilterListItem;
            // Class for custom defined filters
            var FilterList = (function () {
                function FilterList(name, localizationKey, filteredByLocalizationKey, dataFetch) {
                    this.name = name;
                    this.dataFetch = dataFetch;
                    this.localizationKey = localizationKey;
                    this.filteredByLocalizationKey = filteredByLocalizationKey;
                }
                FilterList.initialize = function (filterDataSources) {
                    if (!filterDataSources)
                        return;
                    var self = this;
                    FilterList.CustomFilters = [];
                    for (var i = 0; i < filterDataSources.length; i++) {
                        var dataSource = filterDataSources[i];
                        FilterList.CustomFilters.push(new FilterList(dataSource.name, dataSource.localizationKey, dataSource.filteredByLocalizationKey, dataSource.fetch));
                    }
                };
                FilterList.prototype.loadItems = function (onLoadCallback) {
                    var name = this.name;
                    var list = FilterList._filterItemCacheDictionary[name];
                    if (list !== undefined)
                        onLoadCallback(list);
                    else {
                        MobileCRM.FetchXml.Fetch.executeFromXML(this.dataFetch, function (result) {
                            var list = result.map(function (i) { return new FilterListItem(i[0], i[1]); });
                            FilterList._filterItemCacheDictionary[name] = list;
                            onLoadCallback(list);
                        }, function (err) {
                            FilterList._filterItemCacheDictionary[name] = null;
                            Scheduler.StringTable.alert(Scheduler.StringTable.get("Err.CantFetchEntity") + " " + name + ". " + err);
                            onLoadCallback(null);
                        }, null);
                    }
                };
                return FilterList;
            }());
            FilterList.CustomFilters = [];
            FilterList._filterItemCacheDictionary = {};
            Scheduler.FilterList = FilterList;
            // Settings dialog implementation
            var SettingsDialog = (function (_super) {
                __extends(SettingsDialog, _super);
                function SettingsDialog(container) {
                    var _this = _super.call(this) || this;
                    _this._pages = [];
                    _this.settings = null;
                    _this.container = container;
                    _this.settings = new Scheduler.Settings(container.settings);
                    _this.onShowDialog();
                    return _this;
                }
                SettingsDialog.show = function (container) {
                    if (SettingsDialog._dialogInstance)
                        SettingsDialog._dialogInstance.destroy();
                    SettingsDialog._dialogInstance = new SettingsDialog(container);
                };
                SettingsDialog.prototype.addCustomPage = function (dialog, pageDiv, name, localizationKey) {
                    name = name.toUpperCase();
                    dialog.find(".rescoTabCtrl").append('<li><a id="tab_' + name + '" href="javascript:void(0)" class="rescoTabButton" draggable="false" data-localization="' + localizationKey + '">' + name + '</a></li>');
                    pageDiv.attr("id", name);
                    pageDiv.insertBefore(dialog.find(".dialogControlContainer"));
                };
                SettingsDialog.prototype.onShowDialog = function () {
                    var _this = this;
                    if (this.container.dataLoadEnabed(true) === false)
                        return;
                    var self = this;
                    this.dialog = Scheduler.Utilities.createFromTemplate('<div class="rescoDialog" >\
				<ul class="rescoTabCtrl">\
				</ul>\
				<div class="dialogControlContainer">\
				  <button class="closeButton" data-localization="Msg.Close">Close</button>&nbsp;\
				  <button id="saveButton" data-localization="Msg.SaveClose">Save & Close</button>\
				</div>\
			</div>');
                    var customizationPage = new CustomizationPage(this, this.settings);
                    this.addPage(customizationPage);
                    this.addPage(new SchedulePage(this, this.settings));
                    this.addPage(new ViewsPage(this, this.settings));
                    this.addPage(new ScheduleRulesPage(this, this.settings));
                    for (var i = 0; i < FilterList.CustomFilters.length; i++) {
                        if (FilterList.CustomFilters[i].dataFetch)
                            this.addPage(new CustomFilterPage(this, this.settings, FilterList.CustomFilters[i], i));
                    }
                    this.initializeTabDialog(this.dialog);
                    this.dialog.find("#saveButton").click(function (e) {
                        self.onSave();
                        _this.destroy();
                    });
                    Scheduler.StringTable.localizeElements(this.dialog);
                    _super.prototype.create.call(this, this.dialog, 600, 500);
                    customizationPage.initializeSlider();
                };
                SettingsDialog.prototype.onSave = function () {
                    var oldFilter = this.container.settings;
                    var newFilter = this.settings;
                    var requireReloadAll = !oldFilter || !newFilter.customFilterSelection;
                    if (newFilter.moveStepInMinutes < newFilter.roundMinutes)
                        newFilter.moveStepInMinutes = newFilter.roundMinutes;
                    if (!requireReloadAll) {
                        var src = oldFilter.customFilterSelection;
                        for (var i = 0; i < FilterList.CustomFilters.length; i++) {
                            var name_1 = FilterList.CustomFilters[i].name;
                            var srcList = src[name_1];
                            var dstList = newFilter.customFilterSelection[name_1];
                            if (!Scheduler.arraysAreEqual(srcList, dstList)) {
                                requireReloadAll = true;
                                break;
                            }
                        }
                    }
                    if (oldFilter.resourceView !== newFilter.resourceView) {
                        Scheduler.Container.ref.setResourceView(newFilter.resourceView);
                        requireReloadAll = true;
                    }
                    if (oldFilter.unscheduledView != newFilter.unscheduledView) {
                        Scheduler.Container.ref.setHorizontalView(newFilter.unscheduledView);
                        requireReloadAll = true;
                    }
                    if (oldFilter.autoPlanner.manualScheduleMode != newFilter.autoPlanner.manualScheduleMode)
                        this.container.buttonsBar.updateAutoPlannerIcon();
                    if (requireReloadAll) {
                        this.settings.setDirty();
                        this.container.settings = newFilter;
                        this.container.reloadAll();
                    }
                    else if (newFilter.isDirty)
                        this.container.viewCtrl.onFilterChanged(newFilter);
                };
                SettingsDialog.prototype.destroy = function () {
                    for (var i = 0; i < this._pages.length; i++)
                        this._pages[i].removeRescoComponents();
                    SettingsDialog._dialogInstance = null;
                    _super.prototype.destroy.call(this);
                };
                SettingsDialog.prototype.addPage = function (page) {
                    var rescoTabCtrl = this.dialog.find(".rescoTabCtrl");
                    var dialogControlContainer = this.dialog.find(".dialogControlContainer");
                    rescoTabCtrl.append(page.tabElement);
                    dialogControlContainer.before(page.tabContentElement);
                    this._pages.push(page);
                };
                SettingsDialog.prototype.createRescoInputTimePicker = function (element, actualTime) {
                    var timePickerSettings = {
                        format: Resco.Controls.RescoTimePickerFormat.format24,
                        minRange: Resco.Controls.RescoTimePickerMinRange.range5,
                        arrowImages: [
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_up.png", ""),
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_down.png", "")
                        ],
                        platform: MobileCRM.bridge.platform,
                        time: actualTime,
                    };
                    var settings = {
                        actualTime: actualTime,
                        parentElement: element[0],
                        timePickerIcon: Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_down.png", ""),
                        useRotationForIcon: true,
                        timePickerSettings: timePickerSettings,
                        readOnly: true,
                        dimension: { width: 100, height: 27, left: 0, top: 0 },
                        isEditable: true,
                    };
                    return new Resco.Controls.RescoInputTimePicker(settings);
                };
                return SettingsDialog;
            }(Scheduler.BaseDlg));
            SettingsDialog._dialogInstance = null;
            Scheduler.SettingsDialog = SettingsDialog;
            var CustomizationPage = (function (_super) {
                __extends(CustomizationPage, _super);
                function CustomizationPage(parent, filter) {
                    var _this = _super.call(this, parent, "SETTINGS", "Scheduler.Msg.SETTINGS", "SETTINGS", "Scheduler.Msg.FilterSettings", "Settings constants.") || this;
                    _this.filter = null;
                    _this.addBodyContent('<p data-localization="Scheduler.Msg.ShowTimeInterval">Working hours you will use on the scheduler view</p>\
					<div>\
						<div id="rescoSlider"></div>\
					</div>\
					<p class="line" />\
					<p>\
						<input id="filterDlgShowCompletedAndCanceled" type="checkbox" class="showCompletedAndCanceled">\
						<label for="filterDlgShowCompletedAndCanceled" data-localization="Scheduler.Msg.ShowCompleted">Show completed or canceled tasks</label>\
					</p>\
					<p>\
						<input id="filterDlgShowWeekends" type="checkbox" class="showWeekends">\
						<label for="filterDlgShowWeekends" data-localization="Scheduler.Msg.ShowWeekends">Show weekends</label>\
					</p>\
						<div class="moveStepBlock" style="-webkit-flex:1;-ms-flex:1;flex:1;">\
						<p data-localization="Scheduler.Msg.RoundMinutes">Round minutes:</p>\
						<select class="roundMinutes" style="width:120px;min-height:27px;">\
							<option value="1" data-localization="Msg.Minute" data-localizationvalues="1">1 minute</option>\
							<option value="5" data-localization="Msg.Minutes" data-localizationvalues="5" selected="selected">5 minutes</option>\
							<option value="10" data-localization="Msg.Minutes" data-localizationvalues="10">10 minutes</option>\
							<option value="15" data-localization="Msg.Minutes" data-localizationvalues="15">15 minutes</option>\
							<option value="20" data-localization="Msg.Minutes" data-localizationvalues="20">20 minutes</option>\
							<option value="30" data-localization="Msg.Minutes" data-localizationvalues="30">30 minutes</option>\
							<option value="60" data-localization="Msg.Minutes" data-localizationvalues="60">60 minutes</option>\
						</select>\
					</div>\
					<div class="moveStepBlock" style="-webkit-flex:1;-ms-flex:1;flex:1;">\
						<p data-localization="Scheduler.Msg.MoveStep">Manual scheduling move step:</p>\
						<select class="moveStep" style="width:120px;min-height:27px;">\
							<option value="1" data-localization="Msg.Minute" data-localizationvalues="1">1 minute</option>\
							<option value="5" data-localization="Msg.Minutes" data-localizationvalues="5">5 minutes</option>\
							<option value="10" data-localization="Msg.Minutes" data-localizationvalues="10">10 minutes</option>\
							<option value="15" data-localization="Msg.Minutes" data-localizationvalues="15" selected="selected">15 minutes</option>\
							<option value="20" data-localization="Msg.Minutes" data-localizationvalues="20">20 minutes</option>\
							<option value="30" data-localization="Msg.Minutes" data-localizationvalues="30">30 minutes</option>\
							<option value="60" data-localization="Msg.Minutes" data-localizationvalues="60">60 minutes</option>\
						</select>\
					</div>');
                    _this.filter = filter;
                    var self = _this;
                    var content = _this.tabContentBodyElement;
                    if (!filter.roundMinutes)
                        filter.roundMinutes = 5;
                    if (!filter.moveStepInMinutes)
                        filter.moveStepInMinutes = 15;
                    _this.disableSettingsItemsUnusedInMonthView(parent.container.viewCtrl.zoom.inMonthsMode());
                    content.find(".showCompletedAndCanceled")
                        .change(function (e) {
                        self.filter.showCompletedAndCanceled = e.target.checked;
                        self.filter.setDirty();
                    })
                        .prop('checked', self.filter.showCompletedAndCanceled);
                    content.find(".showWeekends")
                        .change(function (e) {
                        self.filter.showWeekendsAndHolidays = e.target.checked;
                        self.filter.setDirty();
                    })
                        .prop('checked', self.filter.showWeekendsAndHolidays);
                    content.find(".roundMinutes")
                        .val(filter.roundMinutes)
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        var value = +ctrlTarget.options[idx].value;
                        filter.roundMinutes = value;
                        self.filter.setDirty();
                    });
                    content.find(".moveStep")
                        .val(filter.moveStepInMinutes)
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        var value = +ctrlTarget.options[idx].value;
                        filter.moveStepInMinutes = value;
                        self.filter.setDirty();
                    });
                    return _this;
                }
                CustomizationPage.prototype.disableSettingsItemsUnusedInMonthView = function (disable) {
                    var content = this.tabContentBodyElement;
                    if (disable) {
                        content.find(".moveStep").attr("disabled", "disabled");
                        content.find(".showCompletedAndCanceled").attr("disabled", "disabled");
                        content.find(".showWeekends").attr("disabled", "disabled");
                    }
                    else {
                        content.find(".moveStep").removeAttr("disabled");
                        content.find(".showCompletedAndCanceled").removeAttr("disabled");
                        content.find(".showWeekends").removeAttr("disabled");
                    }
                };
                CustomizationPage.prototype.initializeSlider = function () {
                    var _this = this;
                    var parent = this.dialog;
                    var content = this.tabContentBodyElement;
                    var rescoSlider = new Resco.Controls.Scheduler.Slider(content.find("#rescoSlider")[0], this.filter.startWorkingHour, this.filter.endWorkingHour, parent.container.viewCtrl.zoom.inMonthsMode());
                    rescoSlider.startValueChanged.add(this, function (sender, e) {
                        _this.filter.startWorkingHour = e.value;
                        _this.filter.setDirty();
                    });
                    rescoSlider.endValueChanged.add(this, function (sender, e) {
                        _this.filter.endWorkingHour = e.value;
                        _this.filter.setDirty();
                    });
                };
                return CustomizationPage;
            }(Scheduler.BasePage));
            var CustomFilterPage = (function (_super) {
                __extends(CustomFilterPage, _super);
                function CustomFilterPage(parent, filter, list, index) {
                    var _this = _super.call(this, parent, "listOf" + list.name, list.localizationKey, list.name, "Scheduler.Msg.ClickToFilte", "Click to select settings items.") || this;
                    _this._filterList = list;
                    _this._settings = filter;
                    _this._index = index;
                    var content = _this.tabContentBodyElement;
                    var self = _this;
                    var id = 'listOf' + list.name;
                    //let name = list.name.toUpperCase();
                    _this.addBodyContent('<div id="' + id + '"></div>');
                    list.loadItems(function (items) {
                        self.initializeList(content.find("#" + id), items, index);
                    });
                    return _this;
                }
                CustomFilterPage.prototype.initializeList = function (ctrl, list, index) {
                    var _this = this;
                    if (list && list.length > 0) {
                        var filterItem_1 = FilterList.CustomFilters[index];
                        var selected = this._settings.customFilterSelection[filterItem_1.name];
                        if (selected === undefined)
                            selected = null;
                        var listItems = list.slice();
                        listItems.splice(0, 0, new FilterListItem("", Scheduler.StringTable.get("Msg.All")));
                        var listBox = new Controls.ListBox(Scheduler.Container.appColors);
                        listBox.dataSource = listItems;
                        listBox.displayMember = "name";
                        listBox.valueMember = "id";
                        var somethingIsSelected = false;
                        for (var i = 0; i < listBox.items.length; i++) {
                            var listItem = listBox.items[i];
                            if (selected != null && selected.indexOf(listItem.data) >= 0) {
                                listItem.isSelected = true;
                                somethingIsSelected = true;
                            }
                        }
                        if (!somethingIsSelected && listBox.items.length > 0)
                            listBox.items[0].isSelected = true;
                        listBox.selectionChanged.add(this, function (s, e) {
                            var selected = [];
                            if (e.changedItem.data === "" && s.items[0].isSelected === true) {
                                for (var i = 1; i < s.items.length; i++)
                                    s.items[i].isSelected = false;
                            }
                            else {
                                s.items[0].isSelected = false;
                                for (var i = 1; i < s.items.length; i++) {
                                    if (s.items[i].isSelected === true)
                                        selected.push(s.items[i].data);
                                }
                            }
                            _this._settings.customFilterSelection[filterItem_1.name] = selected.length > 0 ? selected : null;
                            _this._settings.setDirty();
                        });
                        ctrl.append(listBox.element);
                    }
                    else
                        ctrl.hide();
                };
                return CustomFilterPage;
            }(Scheduler.BasePage));
            var ViewsPage = (function (_super) {
                __extends(ViewsPage, _super);
                function ViewsPage(parent, filter) {
                    var _this = _super.call(this, parent, "tab_VIEW", "Scheduler.Msg.VIEW", "VIEW", "Scheduler.Msg.ViewTitle", "Define custom views") || this;
                    _this.addBodyContent('<p data-localization="Scheduler.Msg.UnscheduledTaskView">Unscheduled Task View</p>\
					<select class="unscheduledView" style="width:100%"></select>\
				<p></p>\
				<p data-localization="Scheduler.Msg.ResourceView">Resource View</p>\
					<select class="resourceView" style="width:100%"></select>\
				<p></p>');
                    _this._settings = filter;
                    _this.initializeList(".unscheduledView", Scheduler.Container.inputs.unscheduledTasks, "unscheduledView");
                    _this.initializeList(".resourceView", Scheduler.Container.inputs.resources, "resourceView");
                    return _this;
                }
                ViewsPage.prototype.initializeList = function (element, input, selectedView) {
                    var content = this.tabContentBodyElement;
                    var selectCtrl = content.find(element);
                    var viewList = (input && input.entityViews) ? input.entityViews.split(':') : [];
                    if (!viewList.length) {
                        var option = document.createElement('option');
                        option.text = "Default";
                        option.selected = true;
                        option.value = "";
                        selectCtrl.append(option);
                    }
                    else {
                        var selected = this._settings[selectedView];
                        var self_1 = this;
                        viewList.sort();
                        for (var i = 0; i < viewList.length; i++) {
                            var option = document.createElement('option');
                            var view = viewList[i];
                            var idx = view.indexOf('.');
                            option.text = idx >= 0 ? view.substring(idx + 1) : view;
                            if (option.text[0] == '@') {
                                option.text = option.text.substring(1);
                                if (!selected)
                                    selected = this._settings[selectedView] = view;
                            }
                            option.value = option.text;
                            if (option.value === selected)
                                option.selected = true;
                            if (option.text == '@FallbackView')
                                option.text = 'Default';
                            selectCtrl.append(option);
                        }
                        selectCtrl.change(function (e) {
                            var item = e.target;
                            var idx = item.selectedIndex;
                            if (idx >= 0 && item[idx].value !== "") {
                                self_1._settings.setDirty();
                                self_1._settings[selectedView] = item[idx].value;
                            }
                        });
                    }
                };
                return ViewsPage;
            }(Scheduler.BasePage));
            var SchedulePage = (function (_super) {
                __extends(SchedulePage, _super);
                function SchedulePage(parent, settings) {
                    var _this = _super.call(this, parent, "tab_SCHEDULE", "Scheduler.Msg.MANUAL_MOVE", "SCHEDULE", "Scheduler.Msg.ScheduleTitle", "Manual & Auto-schedule behavior.") || this;
                    _this.addBodyContent('</br>\
				<span data-localization="Scheduler.Msg.ViewSettings">Behavior after manual drag & drop the task on the time table:</span>\
				<select class="settingsDlgDropBehavior" style="width:450px;">\
					<option value="0" data-localization="Scheduler.Msg.ManualDrop">Manually select time slot and Resource</option>\
					<option value="1" data-localization="Scheduler.Msg.SemiOptimizedDrop">Optimize time slots for selected Resource</option>\
					<option value="2" data-localization="Scheduler.Msg.OptimizedDrop">Optimize time slots and used Resource (full optimization)</option>\
				</select>\
				</br></br>\
				<p class="title" data-localization="Scheduler.Msg.RescheduleTitle">Auto-schedule constants</p>\
				<p></p>\
				<p>\
					<input id="settingsDlgAutoScheduleNew" type="checkbox" class="autoScheduleNew">\
					<label for="settingsDlgAutoScheduleNew" data-localization="Scheduler.Msg.AutoScheduleNew">Auto-schedule new Tasks</label>\
				</p>\
				<p>\
					<input id="settingsDlgAutoScheduleConflicted" type="checkbox" class="autoScheduleConflicted">\
					<label for="settingsDlgAutoScheduleConflicted" data-localization="Scheduler.Msg.AutoScheduleConflicted">Reschedule conflicted Tasks</label>\
				</p>\
				<p>\
					<input id="settingsDlgAutoScheduleReady" type="checkbox" class="autoScheduleReady">\
					<label for="settingsDlgAutoScheduleReady" data-localization="Scheduler.Msg.AutoScheduleReady">Reschedule already scheduled tasks (not started)</label>\
				</p>\
				<p>\
					<input id="settingsDlgCalculateTravel" type="checkbox" class="calculateTravel">\
					<label for="settingsDlgCalculateTravel" data-localization="Scheduler.Msg.CalculateTravel">Use google.maps to calculate travel duration (Google API Key required)</label>\
				</p>\
				</br>\
				<p>\
					<span data-localization="Scheduler.Msg.OldUnscheduledTasks">Before start of optimization:</span></br>\
					<select class="unrealizedTaskStrategy" style="width:450px;">\
						<option value="0" data-localization="Scheduler.Msg.DoNothing">Do nothing</option>\
						<option value="1" data-localization="Scheduler.Msg.SetAsCanceled">Set old unrealized tasks as Canceled</option>\
					</select>\
				</p>\
				');
                    var content = _this.tabContentBodyElement;
                    var autoPlanner = settings.autoPlanner;
                    var self = _this;
                    content.find(".settingsDlgDropBehavior")
                        .val([autoPlanner.manualScheduleMode.toString()])
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        autoPlanner.manualScheduleMode = +ctrlTarget.options[idx].value;
                        settings.setDirty();
                    });
                    content.find(".autoScheduleNew")
                        .change(function (e) {
                        autoPlanner.autoScheduleNewTasks = e.target.checked;
                        settings.setDirty();
                    })
                        .prop('checked', autoPlanner.autoScheduleNewTasks);
                    content.find(".autoScheduleConflicted")
                        .change(function (e) {
                        autoPlanner.autoScheduleConflictedTasks = e.target.checked;
                        settings.setDirty();
                    })
                        .prop('checked', autoPlanner.autoScheduleConflictedTasks);
                    content.find(".autoScheduleReady")
                        .change(function (e) {
                        autoPlanner.autoScheduleTasksYetNotStarted = e.target.checked;
                        settings.setDirty();
                    })
                        .prop('checked', autoPlanner.autoScheduleTasksYetNotStarted);
                    content.find(".unrealizedTaskStrategy")
                        .val(autoPlanner.unrealizedTaskStrategy)
                        .change(function (e) {
                        var ctrlTarget = e.target;
                        var idx = ctrlTarget.selectedIndex;
                        var value = +ctrlTarget.options[idx].value;
                        autoPlanner.unrealizedTaskStrategy = value;
                        settings.setDirty();
                    });
                    content.find(".calculateTravel")
                        .change(function (e) {
                        settings.autoPlanner.calculateTravel = e.target.checked;
                        settings.setDirty();
                        ;
                    })
                        .prop('checked', settings.autoPlanner.calculateTravel);
                    return _this;
                }
                return SchedulePage;
            }(Scheduler.BasePage));
            var ScheduleRulesPage = (function (_super) {
                __extends(ScheduleRulesPage, _super);
                function ScheduleRulesPage(parent, settings) {
                    var _this = _super.call(this, parent, "tab_RULES", "Scheduler.Msg.RULES", "RULES", "Scheduler.Msg.AutoScheduleRules", "Auto-schedule rules.") || this;
                    _this.addBodyContent('<p data-localization="Scheduler.Msg.ShiftBetweenTask">The minimum gap between scheduled task and current time</p>\
				<div data-timeField="minGapBetweenTaskAndPlanning" class="minGapBetweenTaskAndPlanning"></div>\
				<p data-localization="Scheduler.Msg.PauseBetweenTasks">The minimum gap between tasks</p>\
				<div data-timeField="minGapBetweenTasks" class="minGapBetweenTasks"></div>\
				');
                    var self = _this;
                    var content = _this.tabContentBodyElement;
                    var autoPlanner = settings.autoPlanner;
                    _this._settings = settings;
                    _this._timePicker = [];
                    var element = content.find(".minGapBetweenTaskAndPlanning");
                    if (element.length === 1) {
                        var time = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(autoPlanner.minGapBetweenTaskAndPlanning));
                        var timePicker = parent.createRescoInputTimePicker(element, time);
                        timePicker.valueChanged.add(_this, _this.onMinOffsetFromNowChanged);
                        _this._timePicker.push(timePicker);
                    }
                    element = content.find(".minGapBetweenTasks");
                    if (element.length === 1) {
                        var time = Resco.Controls.RescoTime.convertMinutesToRescoTime(Scheduler.milisecondsToMinutes(autoPlanner.minGapBetweenTasks));
                        var timePicker = parent.createRescoInputTimePicker(element, time);
                        timePicker.valueChanged.add(self, _this.onMinOffsetFromOtherTask);
                        _this._timePicker.push(timePicker);
                    }
                    return _this;
                }
                ScheduleRulesPage.prototype.onMinOffsetFromNowChanged = function (sender, e) {
                    var fileDlg = this.dialog;
                    this._settings.autoPlanner.minGapBetweenTaskAndPlanning = Resco.Controls.RescoTime.convertFromRescoTimeToMilisecond(e.value);
                    this._settings.setDirty();
                };
                ScheduleRulesPage.prototype.onMinOffsetFromOtherTask = function (sender, e) {
                    var fileDlg = this.dialog;
                    this._settings.autoPlanner.minGapBetweenTasks = Resco.Controls.RescoTime.convertFromRescoTimeToMilisecond(e.value);
                    this._settings.setDirty();
                };
                ScheduleRulesPage.prototype.removeRescoComponents = function () {
                    if (this._timePicker) {
                        for (var i = 0; i < this._timePicker.length; i++) {
                            var picker = this._timePicker[i];
                            if (picker) {
                                picker.valueChanged.clear();
                                picker.disposeRescoTimePickerElement();
                                this._timePicker[i] = null;
                            }
                        }
                    }
                };
                return ScheduleRulesPage;
            }(Scheduler.BasePage));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
