///<reference path="interfaces.ts" />
///<reference path="timeRange.ts" />
///<reference path="task.ts" />
///<reference path="dialogs/autoplannerResultDlg.ts" />
///<reference path="dialogs/substituteTaskDlg.ts" />
///<reference path="dialogs/rebookDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var AutoPlanner;
            (function (AutoPlanner) {
                // ToDo: Load all resources
                // ToDo: Support priority
                // ToDo: avoid conslole.log
                // ToDo: If WorkOrder has estimatedTome > workingDay, cut it into several schedules
                var TypeOfSubstitution;
                (function (TypeOfSubstitution) {
                    TypeOfSubstitution[TypeOfSubstitution["DoNotChangeSchedule"] = 0] = "DoNotChangeSchedule";
                    TypeOfSubstitution[TypeOfSubstitution["AsSoonAsPossible"] = 1] = "AsSoonAsPossible";
                    TypeOfSubstitution[TypeOfSubstitution["TheSameDay"] = 2] = "TheSameDay";
                    TypeOfSubstitution[TypeOfSubstitution["TheSameMonth"] = 3] = "TheSameMonth";
                })(TypeOfSubstitution = AutoPlanner.TypeOfSubstitution || (AutoPlanner.TypeOfSubstitution = {}));
                var calculateTravelDurations = false;
                var enableAdvancedTravelMode = true;
                var TaskWrapper = (function (_super) {
                    __extends(TaskWrapper, _super);
                    function TaskWrapper(canModify, task, resource, workStartTime) {
                        var _this = _super.call(this, workStartTime, task.getTotalWorkTime(), task.getTravel(), task.entityInput) || this;
                        _this.task = task;
                        _this.canModify = canModify;
                        _this.resource = resource;
                        return _this;
                    }
                    TaskWrapper.prototype.setStart = function (start) {
                        start = Scheduler.Container.roundTime(start + this.getTravel().to);
                        this.setWorkStart(start);
                    };
                    TaskWrapper.prototype.getParent = function () {
                        return this.resource;
                    };
                    TaskWrapper.prototype.getName = function () {
                        return this.task.getName();
                    };
                    TaskWrapper.prototype.isEditable = function () {
                        return this.task.isEditable();
                    };
                    TaskWrapper.prototype.attachParent = function (resource) {
                        this.resource = resource;
                    };
                    TaskWrapper.prototype.changes = function (undo) {
                        if (!this.canModify) {
                            return undefined;
                        }
                        var changes = {};
                        var hasChange = false;
                        var currentParent = this.task.getParent();
                        if (this.getWorkStart()) {
                            if (this.resource !== currentParent) {
                                if (this.resource) {
                                    var status_1;
                                    if (this.task.getStatus().isUnscheduled()) {
                                        if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Scheduled))
                                            status_1 = Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Scheduled];
                                    }
                                    else
                                        status_1 = this.task.getStatus();
                                    if (status_1) {
                                        undo["parentID"] = currentParent ? currentParent.getID() : undefined;
                                        undo["statuscode"] = this.task.getStatus().value();
                                        changes["parentID"] = this.resource.getID();
                                        changes["statuscode"] = status_1.value();
                                        hasChange = true;
                                    }
                                }
                                else {
                                    if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Unscheduled)) {
                                        undo["parentID"] = currentParent ? currentParent.getID() : undefined;
                                        undo["statuscode"] = this.task.getStatus().value();
                                        changes["parentID"] = null;
                                        changes["statuscode"] = Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Unscheduled].value();
                                        hasChange = true;
                                    }
                                }
                            }
                            if (this.getWorkStart() !== this.task.getWorkStart()) {
                                undo["start"] = this.task.getWorkStart();
                                undo["end"] = this.task.getWorkEnd();
                                undo["totalWork"] = this.task.getTotalWorkTime();
                                changes["start"] = this.getWorkStart();
                                changes["end"] = this.getWorkEnd();
                                changes["totalWork"] = this.getTotalWorkTime();
                                hasChange = true;
                            }
                            var travel = this.getTravel();
                            var taskTravel = this.task.getTravel();
                            if (!travel.equal(taskTravel)) {
                                if (travel.to !== taskTravel.to) {
                                    undo["travelTo"] = taskTravel.to;
                                    changes["travelTo"] = travel.to;
                                }
                                if (travel.from !== taskTravel.from) {
                                    undo["travelFrom"] = taskTravel.from;
                                    changes["travelFrom"] = travel.from;
                                }
                                if (travel.mode !== taskTravel.mode) {
                                    undo["travelmode"] = taskTravel.mode;
                                    changes["travelmode"] = travel.mode;
                                }
                                undo["travelMode"] = taskTravel.mode;
                                changes["travelMode"] = travel.mode;
                                hasChange = true;
                            }
                        }
                        else if (!this.resource && currentParent) {
                            if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Unscheduled)) {
                                undo["parentID"] = currentParent.getID();
                                undo["statuscode"] = this.task.getStatus().value();
                                changes["parentID"] = null;
                                changes["statuscode"] = Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Unscheduled].value();
                                hasChange = true;
                            }
                        }
                        if (hasChange) {
                            undo["task"] = this.task;
                            undo["id"] = this.task.getID();
                            changes["task"] = this.task;
                            changes["id"] = this.task.getID();
                            return changes;
                        }
                        return undefined;
                    };
                    TaskWrapper.prototype.changeLog = function () {
                        if (!this.canModify)
                            return undefined;
                        if (this.resource && this.getWorkStart()) {
                            var log = "";
                            if (!TaskWrapper.attachedTo) {
                                TaskWrapper.attachedTo = Scheduler.StringTable.get("Scheduler.Msg.AttachedTo");
                                TaskWrapper.rescheduledTo = Scheduler.StringTable.get("Scheduler.Msg.RescheduledTo");
                                TaskWrapper.travelOptimized = Scheduler.StringTable.get("Scheduler.Msg.TravelOptimized");
                            }
                            if (this.resource !== this.task.getParent())
                                log += " " + TaskWrapper.attachedTo + " \'" + this.resource.getName() + "\',";
                            if (this.getWorkStart() !== this.task.getWorkStart()) {
                                var d = new Date(this.getWorkStart());
                                log += " " + TaskWrapper.rescheduledTo + " " + d.toLocaleDateString() + " " + d.toLocaleTimeString() + ",";
                            }
                            var travel = this.getTravel();
                            var taskTravel = this.task.getTravel();
                            if (!travel.equal(taskTravel))
                                log += TaskWrapper.travelOptimized;
                            if (log !== "")
                                return "<i>" + this.task.getName() + "</i>" + log;
                        }
                        else if (!this.resource && this.task.getParent())
                            return "<i>" + this.task.getName() + "</i> " + TaskWrapper.attachedTo + "'-'";
                        return undefined;
                    };
                    TaskWrapper.prototype.calculateTravelToClient = function () {
                        var travel = this.getTravel();
                        if (travel.to > 0 || !calculateTravelDurations)
                            return travel.to;
                        else {
                            /*
                            var location = this.task.getLocation();
                            var self = this;
            
                            if (location) {
                                Geo.Service.getRouteDuration((duration: number) => {
                                    self.setTravel(new Travel(duration, duration, TravelMode.Default));
                                }, location);
                            }*/
                            return 0;
                        }
                    };
                    TaskWrapper.prototype.travelDuration = function () {
                        return this.getTravel().duration;
                    };
                    TaskWrapper.prototype.totalTaskDuration = function () {
                        if (this.getTravel().to === 0)
                            this.calculateTravelToClient();
                        return this.getEnd() - this.getStart();
                    };
                    TaskWrapper.calculateTravelDuration = function (onFinishCallback, resultA, resultB) {
                        Scheduler.Geo.Service.getRouteDuration(onFinishCallback, resultA.task.getLocation(), resultB.task.getLocation());
                    };
                    TaskWrapper.prototype.clone = function () {
                        return new TaskWrapper(this.canModify, this.task, this.resource, this.getWorkStart());
                    };
                    TaskWrapper.cloneArray = function (arr) {
                        var dst = new Array(arr.length);
                        for (var i = 0; i < arr.length; i++) {
                            var src = arr[i];
                            dst[i] = new TaskWrapper(src.canModify, src.task, src.resource, src.getWorkStart());
                        }
                        return dst;
                    };
                    return TaskWrapper;
                }(Scheduler.TaskSchedule));
                AutoPlanner.TaskWrapper = TaskWrapper;
                var Position = (function () {
                    function Position() {
                    }
                    return Position;
                }());
                var SlotManager = (function () {
                    function SlotManager(inputs, resource, items) {
                        this.itemIdx = -1;
                        this.resource = resource;
                        this.items = items ? items : resource.scheduled;
                        this.slots = inputs.workingHours;
                        this.workingDayDuration = resource.resource.getOffice().workingDayDuration * Scheduler.minuteInMiliseconds;
                        this.minGapBetweenTasks = inputs.settings.minGapBetweenTasks;
                    }
                    SlotManager.prototype.reset = function () {
                        this.slotIdx = this.itemIdx = 0;
                        this.slotBegin = this.start = this.end = this.itemStart = this.itemEnd = 0;
                        if (this.slots.length > 0) {
                            this.slotBegin = this.start = this.slots[0].start;
                            this.end = this.slots[0].end;
                            //console.log('SLOT' + this.slotIdx + '( ' + new Date(this.start).toLocaleDateString() + ' ' + new Date(this.start).toLocaleTimeString() + ' - ' + new Date(this.end).toLocaleTimeString() + ' [' + ((this.end - this.start) / hourInMiliseconds).toFixed(2) + 'h]');
                            if (this.items.length > 0) {
                                this.itemStart = this.items[0].getStart();
                                this.itemEnd = this.items[0].getEnd();
                                //console.log('  Task' + this.itemIdx + ':' + new Date(this.itemStart).toLocaleString() + ' - ' + new Date(this.itemEnd).toLocaleString() + ' [' + ((this.itemEnd - this.itemStart) / hourInMiliseconds).toFixed(2) + 'h]');
                            }
                            else {
                                this.itemStart = this.slots[this.slots.length - 1].end + Scheduler.dayInMiliseconds * 30;
                                this.itemEnd = this.itemStart + 1;
                            }
                        }
                    };
                    SlotManager.prototype.calculateEmptySlots = function () {
                        var emptySlots = 0;
                        this.itemIdx = -1;
                        if (this.items.length) {
                            var ret;
                            while ((ret = this.findNextEmptySlot(1)) != undefined && ret.itemIndex < this.items.length) {
                                emptySlots += ret.end - ret.start;
                                //console.log('FREE' + this.slotIdx + '( ' + new Date(ret.start).toLocaleDateString() + ' ' + new Date(ret.start).toLocaleTimeString() + ' - ' + new Date(ret.end).toLocaleTimeString() + ' [' + ((ret.end - ret.start) / hourInMiliseconds).toFixed(2) + 'h]');
                            }
                        }
                        return emptySlots;
                    };
                    SlotManager.prototype.findTheBestPositionToFitItem = function (item) {
                        var travelTo = item.calculateTravelToClient();
                        var requestedSlotSize = item.getEnd() - item.getStart();
                        var oldWorkStart = item.getWorkStart();
                        var ret;
                        this.itemIdx = -1;
                        while ((ret = this.findNextEmptySlot(requestedSlotSize)) != undefined) {
                            var start = ret.start;
                            //console.log('    GAP:' + new Date(start).toLocaleString() + ' - ' + new Date(ret.end).toLocaleString() + ' [' + ((ret.end - start) / Scheduler.hourInMiliseconds).toFixed(2) + 'h]');
                            if (!ret.firstInSlot)
                                start += this.minGapBetweenTasks;
                            if (requestedSlotSize <= this.workingDayDuration) {
                                // check if next task is in the some day
                                item.setStart(start);
                                var end = item.getEnd();
                                if (this.minGapBetweenTasks && ret.nextItemStart === ret.end)
                                    end += this.minGapBetweenTasks;
                                if (end <= ret.nextItemStart && (ret.end - item.getStart()) >= requestedSlotSize)
                                    return { workStart: item.getWorkStart(), index: ret.itemIndex, resource: this.resource };
                            }
                            else if (ret.end - start > (2 * Scheduler.hourInMiliseconds + travelTo)) {
                                item.setStart(start);
                                if (ret.nextItemStart - item.getStart() >= requestedSlotSize)
                                    return { workStart: item.getWorkStart(), index: ret.itemIndex, resource: this.resource };
                            }
                        }
                        item.setWorkStart(oldWorkStart);
                        return undefined;
                    };
                    SlotManager.prototype.findNextEmptySlot = function (minSlotSize) {
                        if (this.itemIdx < 0)
                            this.reset();
                        if (minSlotSize > this.workingDayDuration) {
                            var days = Math.floor(minSlotSize / this.workingDayDuration);
                            minSlotSize -= (days * this.workingDayDuration);
                            if (minSlotSize < 2 * Scheduler.hourInMiliseconds)
                                minSlotSize = 2 * Scheduler.hourInMiliseconds;
                        }
                        while (1) {
                            while (this.end <= this.start) {
                                if (++this.slotIdx >= this.slots.length)
                                    return undefined;
                                var slot = this.slots[this.slotIdx];
                                this.start = this.slotBegin = slot.start;
                                this.end = slot.end;
                                //console.log('SLOT' + this.slotIdx + '( ' + new Date(this.start).toLocaleDateString() + ' ' + new Date(this.start).toLocaleTimeString() + ' - ' + new Date(this.end).toLocaleTimeString() + ' [' + ((this.end - this.start) / hourInMiliseconds).toFixed(2) + 'h]');
                                if (this.itemStart <= this.start && this.start < this.itemEnd)
                                    this.start = this.itemEnd;
                            }
                            while (this.itemEnd <= this.start) {
                                if (++this.itemIdx < this.items.length) {
                                    this.itemStart = this.items[this.itemIdx].getStart();
                                    this.itemEnd = this.items[this.itemIdx].getEnd();
                                }
                                else {
                                    this.itemStart = this.slots[this.slots.length - 1].end + Scheduler.dayInMiliseconds * 30;
                                    this.itemEnd = this.itemStart + Scheduler.dayInMiliseconds * 30;
                                }
                                //console.log('  Task' + this.itemIdx + ':' + new Date(this.itemStart).toLocaleString() + ' - ' + new Date(this.itemEnd).toLocaleString() + ' [' + ((this.itemEnd - this.itemStart) / hourInMiliseconds).toFixed(2) + 'h]');
                            }
                            var size;
                            if (this.itemStart >= this.end) {
                                if ((size = this.end - this.start) < minSlotSize)
                                    this.start = this.end;
                                else {
                                    var ret = { start: this.start, end: this.end, itemIndex: this.itemIdx, firstInSlot: this.slotBegin == this.start, nextItemStart: this.itemStart };
                                    this.start = this.end;
                                    if (size >= minSlotSize)
                                        return ret;
                                }
                            }
                            else if ((size = this.itemStart - this.start) > 0) {
                                var ret = { start: this.start, end: this.itemStart, itemIndex: this.itemIdx, firstInSlot: this.slotBegin == this.start, nextItemStart: this.itemStart };
                                this.start = this.itemEnd;
                                if (size >= minSlotSize)
                                    return ret;
                            }
                            else
                                this.start = this.itemEnd;
                        }
                        this.itemIdx = -1;
                        return undefined;
                    };
                    return SlotManager;
                }());
                var ResourceWrapper = (function () {
                    function ResourceWrapper(inputs, resource, task, doNotOptimize) {
                        var _this = this;
                        this.stat = new AutoPlanner.ResultReview();
                        this.doNotOptimize = false;
                        this.resource = resource;
                        this.inputs = inputs;
                        this.scheduled = [];
                        this.unscheduled = [];
                        this.doNotOptimize = doNotOptimize ? true : false;
                        if (resource) {
                            if (task) {
                                if (this.inputs.workingHours.length > 0) {
                                    var begin = this.inputs.workingHours[0].start;
                                    this.resource.forEach(function (child) {
                                        if (child !== task && child.getEnd() > begin)
                                            _this.scheduled.push(new TaskWrapper(false, child, child.resource, child.getWorkStart()));
                                        return false;
                                    }, true);
                                }
                                this.unscheduled.push(new TaskWrapper(true, task, this.inputs.settings.autoScheduleMode == Scheduler.eMode.Optimized ? undefined : task.resource, task.getWorkStart()));
                            }
                            else
                                this.reset();
                        }
                    }
                    ResourceWrapper.prototype.sort = function () {
                        this.scheduled.sort(function (a, b) { return a.getWorkStart() - b.getWorkStart(); });
                    };
                    ResourceWrapper.prototype.reset = function () {
                        this.stat = new AutoPlanner.ResultReview();
                        if (!this.resource)
                            return;
                        var self = this;
                        var begin = this.inputs.workingHours.length > 0 ? this.inputs.workingHours[0].start : Date.now().valueOf();
                        var initialState = this.stat.initial;
                        var maxTaskEnd = this.inputs.viewStartTime, taskEnd;
                        var tmp = [];
                        this.scheduled = [];
                        this.unscheduled = [];
                        if (this.doNotOptimize) {
                            this.resource.forEach(function (task) {
                                if (task.getEnd() > begin) {
                                    var travelTo = task.getWorkStart() - task.getStart();
                                    var travelFrom = task.getEnd() - task.getWorkEnd();
                                    var duration = task.getEnd() - task.getStart();
                                    initialState.travelDuration += travelTo + travelFrom;
                                    initialState.workingDuration += duration;
                                    if (maxTaskEnd < (taskEnd = task.getEnd()))
                                        maxTaskEnd = taskEnd;
                                    var item = new TaskWrapper(false, task, task.getParent(), task.getWorkStart());
                                    tmp.push(item);
                                    self.scheduled.push(item);
                                }
                                return false;
                            }, true);
                            this.stat.totalTasks = self.scheduled.length;
                            this.stat.processedTasks = 0;
                        }
                        else {
                            var optimizeMode = this.inputs.settings.autoScheduleMode == Scheduler.eMode.Optimized;
                            var optimizeRoute = this.inputs.settings.autoScheduleMode == Scheduler.eMode.RouteOptimization;
                            var addAll = this.inputs.settings.autoScheduleTasksYetNotStarted;
                            var addConflicted = this.inputs.settings.autoScheduleConflictedTasks;
                            var globalUnscheduled = self.inputs.newTasks;
                            var workingIntervalContainFuture = this.inputs.workingIntervalContainFuture;
                            this.resource.forEach(function (task) {
                                var travelTo = task.getWorkStart() - task.getStart();
                                var travelFrom = task.getEnd() - task.getWorkEnd();
                                var duration = task.getEnd() - task.getStart();
                                if (task.isEditable()) {
                                    if (addAll || (addConflicted && task.hasViolations())) {
                                        initialState.travelDuration += travelTo + travelFrom;
                                        initialState.workingDuration += duration;
                                        if (maxTaskEnd < (taskEnd = task.getEnd()))
                                            maxTaskEnd = taskEnd;
                                        var item;
                                        if (optimizeRoute) {
                                            self.stat.totalTasks++;
                                            self.scheduled.push(item = new TaskWrapper(true, task, task.getParent(), task.getWorkStart()));
                                        }
                                        else if (optimizeMode)
                                            globalUnscheduled.push(item = new TaskWrapper(true, task, undefined, 0));
                                        else {
                                            self.stat.totalTasks++;
                                            self.unscheduled.push(item = new TaskWrapper(true, task, task.getParent(), 0));
                                        }
                                        tmp.push(item);
                                        return false;
                                    }
                                }
                                if (task.getEnd() > begin || workingIntervalContainFuture) {
                                    tmp.push(new TaskWrapper(false, task, task.getParent(), task.getWorkStart()));
                                    self.stat.totalTasks++;
                                    initialState.travelDuration += travelTo + travelFrom;
                                    initialState.workingDuration += duration;
                                    if (maxTaskEnd < (taskEnd = task.getEnd()))
                                        maxTaskEnd = taskEnd;
                                    self.scheduled.push(new TaskWrapper(false, task, task.getParent(), task.getWorkStart()));
                                }
                                return false;
                            }, true);
                            this.stat.processedTasks = this.stat.totalTasks;
                        }
                        if (!this.initialState) {
                            this.initialState = new AutoPlanner.StateItem();
                            this.initialState.totalDuration = maxTaskEnd - this.inputs.viewStartTime;
                            if (tmp.length > 0) {
                                var mng = new SlotManager(this.inputs, this, tmp);
                                this.initialState.emptyGaps = mng.calculateEmptySlots();
                            }
                        }
                        this.stat.initial = this.initialState;
                        this.stat.totalWorkingTime = this.inputs.getTotalWorkingTime();
                        this.slotMng = new SlotManager(this.inputs, this);
                    };
                    ResourceWrapper.prototype.calculateFinalState = function (items) {
                        var stat = this.stat;
                        var state = new AutoPlanner.StateItem();
                        if (!items)
                            items = this.scheduled;
                        stat.changeLogs = undefined;
                        state.travelDuration = state.workingDuration = 0;
                        if (!items || items.length === 0)
                            state.totalDuration = stat.initial.totalDuration;
                        else {
                            var self = this;
                            stat.changeLogs = [];
                            if (this.slotMng) {
                                state.emptyGaps = this.slotMng.calculateEmptySlots();
                                state.totalDuration = items[items.length - 1].getEnd() - this.inputs.viewStartTime;
                                for (var i = 0; i < items.length; i++) {
                                    var item = items[i];
                                    var changeLog = item.changeLog();
                                    if (item.task.getStart() < item.task.getWorkStart())
                                        state.travelDuration += item.travelDuration();
                                    state.workingDuration += item.totalTaskDuration();
                                    if (changeLog)
                                        stat.changeLogs.push(changeLog);
                                }
                            }
                            else {
                                for (var i = 0; i < items.length; i++) {
                                    var changeLog = items[i].changeLog();
                                    if (changeLog)
                                        stat.changeLogs.push(changeLog);
                                }
                            }
                        }
                        stat.final = state;
                        stat.changedTasks = stat.changeLogs ? stat.changeLogs.length : 0;
                        return stat.changedTasks > 0;
                    };
                    ResourceWrapper.prototype.loadRouteDurations = function () {
                        if (!this.unscheduled)
                            return;
                        for (var i = 0; i < this.unscheduled.length; i++) {
                            var r = this.unscheduled[i];
                            if (r.getTravel().to == 0) {
                                Scheduler.Geo.Service.getRouteDuration(function (duration) {
                                    r.setTravel(new Scheduler.Travel(duration, duration, Scheduler.TravelMode.Default));
                                }, r.task.getLocation());
                            }
                        }
                    };
                    ResourceWrapper.prototype.getUsableNewTasks = function () {
                        if (this.inputs.newTasks && this.resource) {
                            var unscheduled = this.inputs.newTasks;
                            var results = [];
                            for (var i = 0; i < unscheduled.length; i++) {
                                var r = unscheduled[i];
                                if (r.getWorkStart() === 0 && r.task.isValidAssignment(this.resource))
                                    results.push(r);
                            }
                            return results.length ? results : undefined;
                        }
                        return undefined;
                    };
                    ResourceWrapper.prototype.tasksExistsInDifferentDays = function (A, B) {
                        var AEnd = new Date(A.getEnd() - A.getTravel().from);
                        var BStart = new Date(B.getStart());
                        return AEnd.getDate() !== BStart.getDate() || AEnd.getMonth() !== BStart.getMonth() || AEnd.getFullYear() !== BStart.getFullYear();
                    };
                    //private optimizeTravelPerDay: (items: Array<TaskWrapper>) => void = this.optimizeTravelPerDayBySimpleMode;
                    ResourceWrapper.prototype.optimizeTravel = function (onFinished) {
                        var dayGroupedItems = this.getDayGroupedItems();
                        if (dayGroupedItems)
                            this.optimizeTravelRecursive(0, onFinished, dayGroupedItems);
                        else
                            onFinished(undefined);
                    };
                    ResourceWrapper.prototype.optimizeTravelRecursive = function (dayIndex, onFinished, dayGroupedItems) {
                        if (dayIndex < dayGroupedItems.length && !this.inputs.aborted) {
                            var self = this;
                            var items = dayGroupedItems[dayIndex];
                            var waypoints = [];
                            var waypointItems = [];
                            var origin;
                            var destination;
                            var item;
                            var startTime;
                            var i = 0;
                            // find first task which can't be modified (use it as a origin) otherwise office is origin
                            while (i < items.length && !(item = items[i]).canModify) {
                                origin = item;
                                startTime = item.getEnd() + self.inputs.settings.minGapBetweenTasks;
                                i++;
                            }
                            // find waypoints 
                            while (i < items.length && (item = items[i]).canModify) {
                                var location = item.task.getLocation();
                                if (location) {
                                    waypointItems.push(item);
                                    waypoints.push(location);
                                }
                                i++;
                            }
                            // find last task which can't be modified (use it as a destination) otherwise office is destination
                            if (i < items.length)
                                destination = item;
                            if (waypoints.length === 0) {
                                self.optimizeTravelRecursive(++dayIndex, onFinished, dayGroupedItems);
                                return;
                            }
                            else {
                                var itemCount = waypointItems.length;
                                if (!startTime)
                                    startTime = waypointItems[0].getStart();
                                if (!enableAdvancedTravelMode) {
                                    Scheduler.Geo.Service.calculateTravelDurationsFromOffice(function (durations) {
                                        if (durations && durations.length == itemCount) {
                                            for (i = 0; i < itemCount; i++) {
                                                var duration = durations[i];
                                                var item = waypointItems[i];
                                                item.setTravel(new Scheduler.Travel(duration, duration, Scheduler.TravelMode.FromOfficeToOffice));
                                                item.setStart(startTime);
                                                startTime = item.getEnd() + self.inputs.settings.minGapBetweenTasks;
                                            }
                                        }
                                        self.optimizeTravelRecursive(++dayIndex, onFinished, dayGroupedItems);
                                    }, waypoints);
                                }
                                else {
                                    Scheduler.Geo.Service.findOptimalRoute(function (route) {
                                        if (route && route.waypoint_order.length == itemCount && route.durations.length == itemCount + 1) {
                                            for (i = 0; i < itemCount; i++) {
                                                var idx = route.waypoint_order[i];
                                                var item = waypointItems[idx];
                                                var travelMode = origin ? Scheduler.TravelMode.FromPreviousClient : Scheduler.TravelMode.FromOffice;
                                                var durationFromClient = 0;
                                                // if it is last task and we are traveling back to office
                                                if (i == itemCount - 1 && route.destination.isOffice) {
                                                    durationFromClient = route.durations[i + 1];
                                                    travelMode |= Scheduler.TravelMode.ToOffice;
                                                }
                                                else
                                                    travelMode |= Scheduler.TravelMode.ToNextClient;
                                                item.setTravel(new Scheduler.Travel(route.durations[i], durationFromClient, travelMode));
                                                item.setStart(startTime);
                                                startTime = item.getEnd() + self.inputs.settings.minGapBetweenTasks;
                                            }
                                        }
                                        self.optimizeTravelRecursive(++dayIndex, onFinished, dayGroupedItems);
                                    }, waypoints, origin ? origin.task.getLocation() : undefined, destination ? destination.task.getLocation() : undefined);
                                }
                            }
                        }
                        else
                            onFinished(undefined);
                    };
                    ResourceWrapper.prototype.getDayGroupedItems = function () {
                        var len;
                        var list = this.scheduled;
                        if (!list || (list.length) == 0)
                            return undefined;
                        list.sort(function (a, b) { return a.getStart() - b.getStart(); });
                        var arrsPerDay = [];
                        var arr = [];
                        var day = new Date(list[0].getStart());
                        arr.push(list[0]);
                        for (var i = 1; i < list.length; i++) {
                            var d = new Date(list[i].getStart());
                            if (day.getFullYear() !== d.getFullYear() || day.getMonth() !== d.getMonth() || day.getDate() !== d.getDate()) {
                                day = d;
                                if (arr.length > 0) {
                                    arrsPerDay.push(arr);
                                    arr = [];
                                }
                            }
                            arr.push(list[i]);
                        }
                        if (arr.length > 0)
                            arrsPerDay.push(arr);
                        return arrsPerDay;
                    };
                    /*
                    private optimizeTravelBetweenTwoTasks(A: TaskWrapper, B: TaskWrapper) {
                        if (enableAdvancedTravelMode) {
                            if (!A.canModify || !B.canModify || !B.isEditable())
                                return;
                            var locationA = A.task.getLocation();
                            var locationB = B.task.getLocation();
                            var self = this;
                            //var travelToOfficeA = null, travelToOfficeB = null, travelAB = null;
            
                            Scheduler.Geo.Service.getRouteDuration((travelToOfficeA: number) => {
                                //travelToOfficeA = duration;
                                Scheduler.Geo.Service.getRouteDuration((travelToOfficeB: number) => {
                                    //travelToOfficeB = duration;
                                    Scheduler.Geo.Service.getRouteDuration((travelAB: number) => {
                                        var travelA = A.getTravel();
                                        var travelB = B.getTravel();
            
                                        if (travelAB > 0 && travelAB < (travelToOfficeA + travelToOfficeB + 15 * minuteInMiliseconds)) {
                                            if (!travelA.to)
                                                travelA.to = travelToOfficeA;
                                            travelA.from = 0;
                                            travelA.to = travelAB;
                                        }
                                        else {
                                            travelA.from = travelToOfficeA;
                                            travelB.to = travelToOfficeB;
                                        }
                                        B.setStart(A.getEnd() + self.inputs.constants.minGapBetweenTasks);
            
                                    }, locationA, locationB );
                                }, locationB);
                            }, locationA);
                        }
                        else if (A.canModify && A.getTravel().duration == 0) {
                            Scheduler.Geo.Service.getRouteDuration((travelDuration: number) => {
                                A.setTravel(new Travel(travelDuration, travelDuration, TravelMode.Default));
                            }, A.task.getLocation() );
                        }
                    }*/
                    ResourceWrapper.prototype.fitSingleTaskIntoFreeSlots = function (result) {
                        if (!this.slotMng)
                            this.slotMng = new SlotManager(this.inputs, this);
                        var ret = this.slotMng.findTheBestPositionToFitItem(result);
                        return (ret && ret.workStart) ? ret.workStart : 0;
                    };
                    return ResourceWrapper;
                }());
                var Iteration = (function () {
                    function Iteration(inputs) {
                        this.inputs = inputs;
                    }
                    Iteration.run = function (inputs, onReady) {
                        var iteration = undefined;
                        try {
                            inputs.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.OptimizationInProcess") + "...");
                            iteration = new Iteration(inputs);
                            if (inputs.settings.autoScheduleMode == Scheduler.eMode.RouteOptimization)
                                calculateTravelDurations = true;
                            else if (inputs.settings.autoScheduleMode == Scheduler.eMode.Optimized)
                                iteration.runFullOptimization();
                            else
                                iteration.runSemiOptimization();
                            if (calculateTravelDurations && !iteration.inputs.aborted) {
                                iteration.runRouteOptimization(0, function (err) {
                                    iteration.sendResultEvent(true, onReady);
                                });
                                return;
                            }
                            else if (!inputs.aborted) {
                                iteration.sendResultEvent(true, onReady);
                                return;
                            }
                        }
                        catch (e) {
                            inputs.writeError(e.message, true);
                        }
                        iteration.sendResultEvent(false, onReady);
                    };
                    Iteration.prototype.runRouteOptimization = function (index, onFinished) {
                        var inResources = this.inputs.resourceList;
                        if (index < inResources.length) {
                            var self = this;
                            this.inputs.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.TravelRouteOptimization") + "..." + (index + 1) + "/" + inResources.length);
                            inResources[index].optimizeTravel(function (err) {
                                if (!err && !self.inputs.aborted)
                                    self.runRouteOptimization(++index, onFinished);
                                else
                                    onFinished(undefined);
                            });
                        }
                        else
                            onFinished(undefined);
                    };
                    Iteration.prototype.runFullOptimization = function () {
                        var unscheduled = this.inputs.newTasks;
                        var self = this;
                        // first optimize tasks owned by resources
                        this.forEach(function (res) {
                            if (res.unscheduled.length)
                                self.fitUnscheduledItems(res, res.unscheduled);
                        });
                        if (unscheduled.length > 1) {
                            this.inputs.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.UnscheduledTasksOptimization") + "...");
                            unscheduled.sort(function (a, b) { return a.task.getTotalWorkTime() - b.task.getTotalWorkTime(); });
                        }
                        // tasks are sorted. Large ones are on the end of array, small ones on the beginning
                        for (var j = unscheduled.length - 1; j >= 0 && !this.inputs.aborted; j--) {
                            var item = unscheduled[j];
                            var bestResult = this.findTheBestPositionToFitItem(item);
                            if (bestResult) {
                                item.attachParent(bestResult.resource.resource);
                                if (item.getWorkStart() != bestResult.workStart)
                                    item.setWorkStart(bestResult.workStart);
                                bestResult.resource.scheduled.splice(bestResult.index, 0, item);
                                unscheduled.splice(j, 1);
                            }
                            else {
                                // not available resource found
                                item.attachParent(undefined);
                            }
                        }
                    };
                    Iteration.prototype.runSemiOptimization = function () {
                        var _this = this;
                        this.forEach(function (res) {
                            var counter = 0;
                            if (res.unscheduled.length)
                                counter = _this.fitUnscheduledItems(res, res.unscheduled);
                            var unscheduled = res.getUsableNewTasks();
                            if (unscheduled && !_this.inputs.aborted)
                                counter += _this.fitUnscheduledItems(res, unscheduled);
                            if (counter)
                                res.sort();
                        });
                    };
                    Iteration.prototype.fitUnscheduledItems = function (resource, unscheduled) {
                        var counter = 0;
                        if (unscheduled.length > 1)
                            unscheduled.sort(function (a, b) { return a.getTotalWorkTime() - b.getTotalWorkTime(); });
                        // tasks are sorted. Large ones are on the end of array, small ones on the beginning
                        var mng = resource.slotMng;
                        for (var j = unscheduled.length - 1; j >= 0; j--) {
                            var result = unscheduled[j];
                            var ret;
                            if ((ret = mng.findTheBestPositionToFitItem(result))) {
                                counter++;
                                if (result.getWorkStart() !== ret.workStart)
                                    result.setWorkStart(ret.workStart);
                                if (!result.getParent())
                                    result.attachParent(resource.resource);
                                resource.scheduled.splice(ret.index, 0, result);
                                unscheduled.splice(j, 1);
                            }
                        }
                        return counter;
                    };
                    /// use binary tree search, therefore expect sorted array 'items'
                    Iteration.prototype.findBestItemToFit = function (requiredDuration, items) {
                        var fromIdx = 0;
                        var toIdx = items.length - 1;
                        var duration = items[toIdx].totalTaskDuration();
                        if (requiredDuration < duration)
                            return -1;
                        while (fromIdx < toIdx) {
                            var middleIdx = (fromIdx + toIdx) >> 1;
                            duration = items[middleIdx].totalTaskDuration();
                            if (requiredDuration > duration)
                                toIdx = middleIdx - 1;
                            else if (requiredDuration < duration)
                                fromIdx = middleIdx + 1;
                            else
                                return middleIdx;
                        }
                        return toIdx;
                    };
                    Iteration.prototype.findTheBestPositionToFitItem = function (item) {
                        var linkedResources = this.inputs.getLinkedResources(item.task);
                        if (!linkedResources)
                            return undefined;
                        item.attachParent(undefined);
                        item.calculateTravelToClient();
                        var bestStartTime = new Date(2050, 1, 1).valueOf();
                        var bestResource = undefined;
                        for (var i = 0; i < linkedResources.length; i++) {
                            var resource = linkedResources[i];
                            var ret = resource.slotMng.findTheBestPositionToFitItem(item);
                            if (ret && bestStartTime > ret.workStart) {
                                bestStartTime = ret.workStart;
                                bestResource = ret;
                            }
                        }
                        return bestResource;
                    };
                    Iteration.prototype.forEach = function (callback) {
                        var inResources = this.inputs.resourceList;
                        for (var i = 0; i < inResources.length && !this.inputs.aborted; i++)
                            callback(inResources[i]);
                    };
                    Iteration.prototype.sendResultEvent = function (success, onReady) {
                        var stat = new AutoPlanner.ResultReview();
                        var changes = undefined;
                        if (this.inputs.aborted)
                            success = false;
                        stat.changeLogs = [];
                        stat.errors = this.inputs.errors;
                        if (success) {
                            var newTasks = this.inputs.newTasks;
                            changes = [];
                            stat.totalTasks += this.inputs.newTaskLength;
                            stat.processedTasks += this.inputs.newTaskLength;
                            if (newTasks.length) {
                                for (var j = 0; j < newTasks.length; j++) {
                                    if (newTasks[j].changeLog() === undefined) {
                                        stat.errors.push("'" + newTasks[j].getName() + "' not scheduled");
                                        stat.processedTasks--;
                                    }
                                }
                            }
                            this.forEach(function (resource) {
                                var rStat = resource.stat;
                                if (resource.calculateFinalState(resource.scheduled)) {
                                    changes.push(resource);
                                    stat.totalTasks += rStat.totalTasks;
                                    stat.processedTasks += rStat.processedTasks;
                                    stat.changedTasks += rStat.changedTasks;
                                    stat.totalWorkingTime += rStat.totalWorkingTime;
                                    stat.initial.emptyGaps += rStat.initial.emptyGaps;
                                    stat.initial.travelDuration += rStat.initial.travelDuration;
                                    stat.initial.workingDuration += rStat.initial.workingDuration;
                                    stat.initial.totalDuration += rStat.initial.totalDuration;
                                    stat.final.emptyGaps += rStat.final.emptyGaps;
                                    stat.final.travelDuration += rStat.final.travelDuration;
                                    stat.final.workingDuration += rStat.final.workingDuration;
                                    stat.final.totalDuration += rStat.final.totalDuration;
                                    for (var j = 0; j < rStat.changeLogs.length; j++)
                                        stat.changeLogs.push(rStat.changeLogs[j]);
                                }
                                else {
                                    stat.totalTasks += rStat.totalTasks;
                                    stat.processedTasks += rStat.processedTasks;
                                }
                                if (resource.unscheduled) {
                                    var list = resource.unscheduled;
                                    for (var j = 0; j < list.length; j++)
                                        stat.errors.push("'" + list[j].getName() + "' not scheduled");
                                }
                            });
                            var missingResourceID = this.inputs.missingResources.Values();
                            if (missingResourceID.length) {
                                var err = Scheduler.StringTable.get("Scheduler.Msg.MissingResources") || "Missing Resources";
                                err += ": <br>";
                                for (var i = 0; i < missingResourceID.length; i++)
                                    err += "   " + missingResourceID[i] + "<br>";
                                stat.errors.push(err);
                            }
                        }
                        else {
                            this.forEach(function (resource) {
                                var rStat = resource.stat;
                                stat.totalTasks += rStat.totalTasks;
                                stat.processedTasks += rStat.processedTasks;
                            });
                        }
                        onReady(changes, stat);
                    };
                    return Iteration;
                }());
                var Inputs = (function (_super) {
                    __extends(Inputs, _super);
                    function Inputs(container) {
                        var _this = _super.call(this) || this;
                        _this.tasksToSetUnscheduled = [];
                        _this.tasksToSetCanceled = [];
                        _this.newTaskLength = 0;
                        _this.workingIntervalContainFuture = false;
                        _this.aborted = false;
                        _this.statusText = "";
                        _this.errors = [];
                        _this.missingResources = new Scheduler.Dictionary();
                        _this.container = container;
                        _this.settings = new Scheduler.AutoPlannerSettings(container.settings.autoPlanner);
                        var startTime = Date.now() + _this.settings.minGapBetweenTaskAndPlanning;
                        var viewTimeRange = container.viewCtrl.zoom.getTimeRange();
                        _this.viewStartTime = viewTimeRange.start;
                        _this.viewEndTime = viewTimeRange.end;
                        if (startTime < viewTimeRange.start || startTime >= viewTimeRange.end)
                            startTime = viewTimeRange.start;
                        _this.setTimeInterval(startTime);
                        return _this;
                    }
                    Inputs.viewContainFuture = function () {
                        var viewTimeRange = Scheduler.Container.ref.viewCtrl.zoom.getTimeRange();
                        return viewTimeRange.end > Date.now();
                    };
                    Inputs.prototype.setTimeInterval = function (viewStartTime, viewEndTime) {
                        if (!viewEndTime)
                            viewEndTime = this.viewEndTime;
                        this.workingIntervalContainFuture = this.viewEndTime > Date.now();
                        this.workingHours = Scheduler.Container.defaultOffice.getWorkingSlots(viewStartTime, viewEndTime);
                    };
                    Inputs.prototype.writeError = function (error, abort) {
                        this.errors.push(error);
                        this.container.setStatusInfo(error);
                        if (abort)
                            this.aborted = true;
                    };
                    Inputs.prototype.writeStatus = function (status) {
                        this.container.setStatusInfo(status);
                    };
                    Inputs.prototype.getTotalWorkingTime = function () {
                        if (this.totalWorkingTime === undefined) {
                            this.totalWorkingTime = 0;
                            for (var i = this.workingHours.length - 1; i >= 0; i--)
                                this.totalWorkingTime += this.workingHours[i].duration();
                        }
                        return this.totalWorkingTime;
                    };
                    Inputs.prototype.reset = function () {
                        if (resourceList) {
                            var resourceList = this.resourceList;
                            for (var i = 0; i < resourceList.length; i++)
                                resourceList[i].reset();
                        }
                    };
                    Inputs.prototype.initializeSingleResource = function (resource) {
                        var settings = this.settings;
                        this.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.Initializing") + "...");
                        this.resourceList = undefined;
                        this.newTasks = [];
                        if (this.workingHours.length > 0) {
                            this.viewStartTime = this.workingHours[0].start;
                            this.viewEndTime = this.workingHours[this.workingHours.length - 1].end + this.settings.maxOvertimePerDay * Scheduler.minuteInMiliseconds;
                        }
                        else
                            this.viewStartTime = this.viewEndTime = Date.now().valueOf();
                        var res = new ResourceWrapper(this, resource);
                        this.Add(resource.getID(), res);
                        return res.stat.processedTasks;
                    };
                    Inputs.prototype.initialize = function (tasksWithoutResource) {
                        var self = this;
                        var settings = this.settings;
                        var counter = 0;
                        this.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.Initializing") + "...");
                        this.resourceList = undefined;
                        this.newTasks = [];
                        if (this.workingHours.length > 0) {
                            this.viewStartTime = this.workingHours[0].start;
                            this.viewEndTime = this.workingHours[this.workingHours.length - 1].end + this.settings.maxOvertimePerDay * Scheduler.minuteInMiliseconds;
                        }
                        else
                            this.viewStartTime = this.viewEndTime = Date.now().valueOf();
                        if (settings.autoScheduleNewTasks && settings.autoScheduleMode != Scheduler.eMode.RouteOptimization) {
                            var tasks = this.container.getTasksFromHorizontalListItems(); //this.container.unscheduledTasksBar.tasks;
                            if (tasks) {
                                for (var j = 0; j < tasks.length; j++)
                                    this.newTasks.push(new TaskWrapper(true, tasks[j], undefined, 0));
                            }
                        }
                        this.container.forEachResourceInRange(0, function (resource) {
                            var res = new ResourceWrapper(self, resource);
                            self.Add(resource.getID(), res);
                            counter += res.stat.processedTasks;
                            //}
                        });
                        this.newTaskLength = this.newTasks.length;
                        for (var i = this.newTaskLength - 1; i >= 0; i--) {
                            var item = this.newTasks[i];
                            if (!item.getParent()) {
                                tasksWithoutResource.push(item.task);
                                /*
                                var task = item.task;
                                var resources = AllowedResources.WorkOrder.TaskWrapper(task.workorderid);
                                if (!resources)
                                    ordersPerTerritory.AddTask(task);
                                else
                                    task.setLinkedResources(resources);
                                */
                            }
                        }
                        this.resourceList = this.Values();
                        return counter + this.newTaskLength;
                    };
                    Inputs.prototype.getLinkedResources = function (task) {
                        var linkedResourceIds = task.linkedResources();
                        if (!linkedResourceIds || linkedResourceIds.length == 0)
                            return this.resourceList;
                        var linkedResources = [];
                        var missing = 0;
                        for (var i = 0; i < linkedResourceIds.length; i++) {
                            var resId = linkedResourceIds[i];
                            var res = this.Item(resId);
                            if (res)
                                linkedResources.push(res);
                            else {
                                var newRes = this.container.findResource(resId);
                                if (newRes) {
                                    res = new ResourceWrapper(this, newRes, undefined);
                                    this.Add(resId, res);
                                    this.resourceList = undefined;
                                    linkedResources.push(res);
                                }
                                else {
                                    missing++;
                                    this.missingResources.Add(resId, resId);
                                }
                            }
                        }
                        if (!this.resourceList)
                            this.resourceList = this.Values();
                        return linkedResources.length ? linkedResources : (missing ? undefined : this.resourceList);
                    };
                    Inputs.prototype.addLinkedResources = function () {
                        var items = this.newTasks;
                        for (var j = items.length - 1; j >= 0; j--) {
                            if (!items[j].getParent()) {
                                var task = items[j].task;
                                var linkedResourceIds = task.linkedResources();
                                //if (linkedResourceIds === undefined) {
                                //	linkedResourceIds = AllowedResources.WorkOrder.TaskWrapper(task.workorderid);
                                //	task.setLinkedResources(linkedResourceIds ? linkedResourceIds : null);
                                //}
                                var len = !linkedResourceIds ? 0 : linkedResourceIds.length;
                                for (var i = 0; i < len; i++) {
                                    var resId = linkedResourceIds[i];
                                    if (!this.ContainsKey(resId)) {
                                        var newRes = this.container.findResource(resId);
                                        if (newRes) {
                                            this.resourceList = undefined;
                                            this.Add(resId, new ResourceWrapper(this, newRes, undefined, true));
                                        }
                                        else
                                            this.missingResources.Add(resId, resId);
                                    }
                                }
                            }
                        }
                        if (!this.resourceList)
                            this.resourceList = this.Values();
                    };
                    Inputs.prototype.loadCustomerAddresses = function (onFinish) {
                        var tasks = [];
                        this.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.AddressesLoading") + "...");
                        for (var j = 0; j < this.resourceList.length; j++) {
                            var res = this.resourceList[j];
                            var unscheduled = res.unscheduled;
                            if (!unscheduled || !unscheduled.length) {
                                if (res.stat.processedTasks == 0)
                                    continue;
                                unscheduled = res.scheduled;
                            }
                            for (var i = 0; i < unscheduled.length; i++) {
                                var r = unscheduled[i];
                                if (r.canModify)
                                    tasks.push(r.task);
                            }
                        }
                        if (this.newTasks) {
                            for (var i = 0; i < this.newTasks.length; i++)
                                tasks.push(this.newTasks[i].task);
                        }
                        var self = this;
                        if (tasks.length > 0 && this.container)
                            this.container.dataProvider.loadLocations(tasks, function (error) { onFinish(tasks.length); });
                        else
                            onFinish(0);
                    };
                    return Inputs;
                }(Scheduler.Dictionary));
                var Core = (function () {
                    function Core(container) {
                        var settings = container.settings.autoPlanner;
                        this.inputs = new Inputs(container);
                        calculateTravelDurations = settings.autoScheduleMode == Scheduler.eMode.RouteOptimization || settings.calculateTravel;
                        enableAdvancedTravelMode = Scheduler.Container.inputs.scheduledTasks.attrTravelMode ? true : false;
                    }
                    Core.isRunning = function () {
                        return Core._autoScheduleCore !== undefined;
                    };
                    // run auto-schedule based on actual constants
                    Core.run = function (mode) {
                        var container = Scheduler.Container.ref;
                        var dataRange = container.viewCtrl.zoom.getTimeRange();
                        if (Core._autoScheduleCore)
                            Core._autoScheduleCore.promptCloseAutoschedule();
                        else if (dataRange.end < Date.now().valueOf())
                            Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.SelectActualDate") || "Optimization can't be done for the selected time interval. Select actual or future time interval and run optimization again.");
                        else {
                            var autoPlannerSettings = container.settings.autoPlanner;
                            if (autoPlannerSettings.autoScheduleConflictedTasks || autoPlannerSettings.autoScheduleTasksYetNotStarted) {
                                var yes = Scheduler.StringTable.get("Cmd.Yes");
                                var no = Scheduler.StringTable.get("Cmd.No");
                                var prompt;
                                if (mode == Scheduler.eMode.Optimized)
                                    prompt = Scheduler.StringTable.get("Scheduler.Msg.AskRunAutoSchedule");
                                else
                                    prompt = Scheduler.StringTable.get("Scheduler.Msg.AskRunSemiOptimization");
                                var popup = new MobileCRM.UI.MessageBox(prompt);
                                popup.items = [yes, no];
                                popup.multiLine = true;
                                popup.show(function (button) {
                                    if (button === yes)
                                        AutoPlanner.Core.doOptimization(container, mode);
                                });
                            }
                            else
                                AutoPlanner.Core.doOptimization(container, mode);
                        }
                    };
                    Core.doOptimization = function (container, mode) {
                        var settings = container.settings;
                        if (settings.autoPlanner.autoScheduleMode != mode) {
                            settings.autoPlanner.autoScheduleMode = mode;
                            settings.setDirty();
                            container.settings = settings;
                        }
                        var core = new AutoPlanner.Core(container);
                        Core._autoScheduleCore = core;
                        container.buttonsBar.onAutoPlannerStateChanged(true);
                        if (container.allDataLoaded === true)
                            core.onAutoSchedulerDataCompleted(null, null);
                        else {
                            container.setStatusInfo(Scheduler.StringTable.get("Scheduler.Msg.LoadingRestOfResources") + "...");
                            container.onDataLoadCompleted.add(core, core.onAutoSchedulerDataCompleted);
                            container.listCtrl.loadUntilEnd();
                        }
                    };
                    Core.prototype.promptCloseAutoschedule = function () {
                        var container = Scheduler.Container.ref;
                        var yes = Scheduler.StringTable.get("Cmd.Yes");
                        var no = Scheduler.StringTable.get("Cmd.No");
                        if (Core._autoScheduleCore) {
                            var popup = new MobileCRM.UI.MessageBox(Scheduler.StringTable.get("Scheduler.Msg.AskStopAutoSchedule"));
                            popup.items = [yes, no];
                            popup.multiLine = true;
                            popup.show(function (button) {
                                if (button === yes)
                                    Core.stopAutoSchedule();
                            });
                        }
                    };
                    // abort running auto-schedule
                    Core.stopAutoSchedule = function () {
                        if (Core._autoScheduleCore) {
                            Core._autoScheduleCore.abort();
                            Core._autoScheduleCore = undefined;
                        }
                    };
                    Core.prototype.onOptimizationFinished = function (error) {
                        if (Core._autoScheduleCore) {
                            var core = Core._autoScheduleCore;
                            var container = core.inputs.container;
                            container.buttonsBar.onAutoPlannerStateChanged(false);
                            Core._autoScheduleCore = undefined;
                            container.setButtonsBarInfo();
                            container.setStatusInfo();
                            container.redraw();
                            if (error)
                                Scheduler.StringTable.alert(error);
                        }
                    };
                    Core.optimizeResource = function (resource) {
                        if (Core._autoScheduleCore)
                            Core._autoScheduleCore.promptCloseAutoschedule();
                        else if (!resource)
                            Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.SelectResourceToOptimize") || "Select resource to optimize");
                        else {
                            var container = Scheduler.Container.ref;
                            var core = new AutoPlanner.Core(container);
                            var settings = core.inputs.settings;
                            settings.autoScheduleNewTasks = false;
                            settings.autoScheduleConflictedTasks = true;
                            settings.autoScheduleTasksYetNotStarted = true;
                            Core._autoScheduleCore = core;
                            if (core.inputs.workingHours.length === 0)
                                core.onOptimizationFinished(Scheduler.StringTable.get("Scheduler.Msg.SmallTimeForOptimize"));
                            else if (core.inputs.initializeSingleResource(resource) == 0)
                                core.onOptimizationFinished(Scheduler.StringTable.get("Scheduler.Msg.NothingToOptimize"));
                            else {
                                container.buttonsBar.onAutoPlannerStateChanged(true);
                                core.processOptimization(core.onOptimizationFinished);
                            }
                        }
                    };
                    Core.findSubstitution = function (task) {
                        if (Core._autoScheduleCore)
                            Core._autoScheduleCore.promptCloseAutoschedule();
                        else if (!task || !task.isEditable)
                            Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.SelectTaskToSubstitute") || "Select editable task to substitute");
                        else {
                            var container = Scheduler.Container.ref;
                            if (Inputs.viewContainFuture() == false) {
                                Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Msg.ProperViewTimeRange") || "For planning, please select proper view time range (calendar with time after today).");
                                return;
                            }
                            Resco.Controls.Scheduler.SubstituteTaskDlg.show(container, task, function (resource, startTime) {
                                if (resource && startTime) {
                                    task.tryReassign(resource, startTime + task.getTravel().to, function (success) { });
                                    return true;
                                }
                                return false;
                            });
                        }
                    };
                    Core.findSubstituteResults = function (substitutionType, task, result) {
                        task.loadLinkedResources(function (error) {
                            if (error) {
                                Scheduler.StringTable.alert(error);
                                result(undefined);
                                return;
                            }
                            var container = Scheduler.Container.ref;
                            var resources = [];
                            var resource = task.resource;
                            container.forEachResource(function (r) {
                                if (resource != r && task.isValidAssignment(r))
                                    resources.push(r);
                            });
                            if (resources.length > 0) {
                                var core = new AutoPlanner.Core(container);
                                var settings = core.inputs.settings;
                                var now = Date.now() + settings.minGapBetweenTaskAndPlanning;
                                var resourceTimePair = [];
                                settings.autoScheduleNewTasks = false;
                                settings.autoScheduleConflictedTasks = true;
                                settings.autoScheduleTasksYetNotStarted = true;
                                if (substitutionType == TypeOfSubstitution.DoNotChangeSchedule) {
                                    var startTime = task.getStart();
                                    if (startTime >= now) {
                                        var requiredSlot = new Scheduler.TimeRange(startTime, task.getEnd());
                                        for (var i = 0; i < resources.length; i++) {
                                            var res = resources[i];
                                            if (res.slotIsFreeForScheduling(requiredSlot))
                                                resourceTimePair.push(new Scheduler.ResourceStartPair(res, startTime));
                                        }
                                    }
                                }
                                else {
                                    if (substitutionType == TypeOfSubstitution.AsSoonAsPossible) {
                                        core.inputs.setTimeInterval(now);
                                    }
                                    else {
                                        var d = new Date(task.getWorkStart()); // should not to be aligned (use correct day with all moveStep aligned)
                                        var startDay = void 0;
                                        var endDay = void 0;
                                        if (substitutionType == TypeOfSubstitution.TheSameDay) {
                                            startDay = new Date(d.getFullYear(), d.getMonth(), d.getDate());
                                            endDay = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1);
                                        }
                                        else {
                                            startDay = new Date(d.getFullYear(), d.getMonth());
                                            endDay = new Date(d.getFullYear(), d.getMonth() + 1);
                                        }
                                        core.inputs.setTimeInterval(startDay.valueOf(), endDay.valueOf());
                                    }
                                    var taskWrapper = new TaskWrapper(true, task, undefined, Scheduler.Container.roundTime(task.getWorkStart()));
                                    for (var i = 0; i < resources.length; i++) {
                                        var res = resources[i];
                                        var r = new ResourceWrapper(core.inputs, res, task, false);
                                        var newWorkStart = r.fitSingleTaskIntoFreeSlots(taskWrapper);
                                        if (newWorkStart > 0) {
                                            var t = new TaskWrapper(true, task, res, newWorkStart);
                                            resourceTimePair.push(new Scheduler.ResourceStartPair(res, t.getStart()));
                                        }
                                    }
                                }
                                if (resourceTimePair.length > 0) {
                                    resourceTimePair.sort(function (a, b) {
                                        return a.resource.getName().localeCompare(b.resource.getName());
                                    });
                                    result(resourceTimePair);
                                    return;
                                }
                            }
                            result(undefined);
                        });
                    };
                    Core.rebookTask = function (task) {
                        if (Core._autoScheduleCore)
                            Core._autoScheduleCore.promptCloseAutoschedule();
                        else if (!task || !task.isEditable)
                            Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.SelectTaskToRebook") || "Select editable task to rebook");
                        else {
                            var container = Scheduler.Container.ref;
                            var core = new AutoPlanner.Core(container);
                            if (Inputs.viewContainFuture() == false) {
                                Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Msg.ProperViewTimeRange") || "For planning, please select proper view time range (calendar with time after today).");
                                return;
                            }
                            Resco.Controls.Scheduler.RebookDlg.show(container, task, function (timeRange) {
                                if (!timeRange || !timeRange.start)
                                    return false;
                                var parent = task.resource;
                                var settings = core.inputs.settings;
                                var now = Date.now() + core.inputs.settings.minGapBetweenTaskAndPlanning;
                                if (timeRange.start < now)
                                    timeRange.start = Scheduler.Container.defaultOffice.findNextWorkingTimeBegin(now);
                                if (timeRange.end < timeRange.start)
                                    timeRange.end = timeRange.start + Scheduler.weekInMiliseconds;
                                settings.autoScheduleNewTasks = false;
                                settings.autoScheduleConflictedTasks = true;
                                settings.autoScheduleTasksYetNotStarted = true;
                                core.inputs.setTimeInterval(timeRange.start, timeRange.end);
                                var res = new ResourceWrapper(core.inputs, parent, task);
                                var result = new TaskWrapper(true, task, parent, Scheduler.Container.roundTime(task.getWorkStart()));
                                var workStart = res.fitSingleTaskIntoFreeSlots(result);
                                if (workStart == 0) {
                                    Scheduler.StringTable.alert(Scheduler.StringTable.get("Scheduler.Err.ResourceTooBusy") || "Resource is too busy. There is no time slot long enough for rebook of the required task.");
                                    return false;
                                }
                                else {
                                    if (core.inputs.viewStartTime <= workStart && workStart < core.inputs.viewEndTime) {
                                        result.setWorkStart(workStart);
                                        task.tryReassign(parent, workStart, function (success) {
                                        });
                                    }
                                    return true;
                                }
                            });
                        }
                    };
                    Core.prototype.beforeAutoschedule = function (mode, resultCallback) {
                        var status;
                        if ((mode === Scheduler.eUnrealizedTaskStrategy.SetAsCanceled)) {
                            if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Canceled))
                                status = Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Canceled];
                        }
                        else if ((mode === Scheduler.eUnrealizedTaskStrategy.SetAsUnscheduled)) {
                            if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Unscheduled))
                                status = Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.Unscheduled];
                        }
                        //else { // do nothing } // mode === AutoPlanner.eUnrealizedTaskStrategy.DoNothing
                        if (!status) {
                            resultCallback(undefined);
                            return;
                        }
                        var now = new Date().valueOf();
                        var changeList = [];
                        var container = this.inputs.container;
                        container.forEachScheduledTaskInRange(0, function (task, parent) {
                            if (task.getWorkEnd() < now && task.getStatus().canBeRescheduled())
                                changeList.push({ "task": task, "statuscode": status.value() });
                        }, false);
                        if (changeList.length > 0) {
                            container.setStatusInfo(Scheduler.StringTable.get("Scheduler.Msg.SavingUnrealizedTasks") + "...");
                            container.saveTasks(changeList, resultCallback, true);
                        }
                        else
                            resultCallback(undefined);
                    };
                    // Called when all data are loaded (before runAutoSchedule start processing of data).
                    Core.prototype.onAutoSchedulerDataCompleted = function (sender, e) {
                        var self = this;
                        var container = this.inputs.container;
                        container.onDataLoadCompleted.remove(this, this.onAutoSchedulerDataCompleted);
                        this.beforeAutoschedule(container.settings.autoPlanner.unrealizedTaskStrategy, function (err) {
                            self.runOptimization(self.onOptimizationFinished);
                        });
                    };
                    Core.prototype.abort = function () {
                        this.inputs.aborted = true;
                    };
                    Core.optimizeManuallyDroppedTask = function (onCalculated, task, startWorkTime, parent) {
                        var core = new AutoPlanner.Core(Scheduler.Container.ref);
                        var settings = core.inputs.settings;
                        settings.autoScheduleConflictedTasks = true;
                        settings.autoScheduleNewTasks = true;
                        settings.autoScheduleTasksYetNotStarted = true;
                        if (!startWorkTime)
                            startWorkTime = task.getWorkStart();
                        startWorkTime = Scheduler.Container.roundTime(startWorkTime);
                        if (!parent)
                            parent = task.resource;
                        if (settings.manualScheduleMode == Scheduler.eMode.Manual || settings.manualScheduleMode == Scheduler.eMode.RouteOptimization)
                            onCalculated(new TaskWrapper(true, task, parent, startWorkTime));
                        else if (settings.manualScheduleMode == Scheduler.eMode.SemiOptimized && parent) {
                            var res = new ResourceWrapper(core.inputs, parent, task);
                            var result = new TaskWrapper(true, task, parent, startWorkTime);
                            var workStart = res.fitSingleTaskIntoFreeSlots(result);
                            if (core.inputs.viewStartTime <= workStart && workStart < core.inputs.viewEndTime)
                                result.setWorkStart(workStart);
                            onCalculated(result);
                        }
                        else {
                            task.loadLinkedResources(function (err) {
                                var result = core.findBestResource(task.getLinkedResources(), task);
                                onCalculated(result);
                            });
                        }
                    };
                    Core.prototype.runOptimization = function (onFinishCallback) {
                        var self = this;
                        var tasksWithoutResource = [];
                        if (this.inputs.workingHours.length === 0)
                            onFinishCallback(Scheduler.StringTable.get("Scheduler.Msg.SmallTimeForOptimize"));
                        else if (this.inputs.initialize(tasksWithoutResource) === 0)
                            onFinishCallback(Scheduler.StringTable.get("Scheduler.Msg.NothingToOptimize"));
                        else {
                            //var territoryList = ordersPerTerritory.Territories();
                            if (tasksWithoutResource.length > 0) {
                                //if (territoryList && territoryList.length > 0) {
                                self.inputs.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.LoadingListOfResources"));
                                self.inputs.container.dataProvider.loadQualifiedResources(tasksWithoutResource, function (error) {
                                    if (error) {
                                        self.abort();
                                        onFinishCallback(error);
                                    }
                                    else
                                        self.processOptimization(onFinishCallback);
                                });
                                return;
                            }
                            self.processOptimization(onFinishCallback);
                        }
                    };
                    Core.prototype.processOptimization = function (onFinishCallback) {
                        this.inputs.addLinkedResources();
                        if (this.inputs.aborted)
                            onFinishCallback(undefined);
                        else {
                            var self = this;
                            if (calculateTravelDurations) {
                                self.inputs.loadCustomerAddresses(function (loadedCount) {
                                    Iteration.run(self.inputs, function (result, stat) {
                                        self.onResultReady(result, stat, onFinishCallback);
                                    });
                                });
                            }
                            else {
                                Iteration.run(self.inputs, function (result, stat) {
                                    self.onResultReady(result, stat, onFinishCallback);
                                });
                            }
                        }
                    };
                    Core.prototype.onResultReady = function (result, stat, onFinishCallback) {
                        var self = this;
                        var undo = [];
                        var changes = result ? this.getChanges(result, undo) : undefined;
                        this.inputs.writeStatus("");
                        this.inputs.container.updateHorizontalListController(true, function () {
                            AutoPlanner.ResultDialog.show(self.inputs.container, stat, function (btn) {
                                if (!changes)
                                    onFinishCallback(undefined);
                                else {
                                    self.undoResult(result, undo, false);
                                    self.inputs.container.updateHorizontalListController(true, function () {
                                        if (btn === "DISCARD") {
                                            onFinishCallback(undefined);
                                        }
                                        else {
                                            self.inputs.writeStatus(Scheduler.StringTable.get("Scheduler.Msg.AutoScheduleSave") + "...");
                                            self.inputs.container.saveTasks(changes, onFinishCallback, false);
                                        }
                                    });
                                }
                            });
                        });
                    };
                    Core.prototype.undoResult = function (resultArr, undo, redraw) {
                        var container = this.inputs.container;
                        var changes = 0;
                        for (var i = 0; i < undo.length; i++) {
                            if (undo[i].task.setValues(undo[i]))
                                changes++;
                        }
                        for (var i = 0; i < resultArr.length; i++)
                            resultArr[i].resource.resetSort();
                        if (redraw && changes > 0)
                            this.inputs.container.redraw();
                    };
                    Core.prototype.addChangedItems = function (items, undo, changes) {
                        var changeCounter = 0;
                        for (var j = 0; j < items.length; j++) {
                            var result = items[j];
                            var localUndo = {};
                            var change = result.changes(localUndo);
                            if (change) {
                                changes.push(change);
                                if (result.task.setValues(change)) {
                                    changeCounter++;
                                    undo.push(localUndo);
                                }
                            }
                        }
                        return changeCounter;
                    };
                    Core.prototype.getChanges = function (resultArr, undo) {
                        var container = this.inputs.container;
                        var changes = [];
                        var changeCounter = 0;
                        for (var i = 0; i < resultArr.length; i++) {
                            var res = resultArr[i];
                            if (res.resource)
                                res.resource.resetSort();
                            if (res.scheduled)
                                changeCounter += this.addChangedItems(res.scheduled, undo, changes);
                            if (res.unscheduled)
                                changeCounter += this.addChangedItems(res.unscheduled, undo, changes);
                        }
                        if (changeCounter)
                            this.inputs.container.redraw();
                        return changes.length > 0 ? changes : undefined;
                    };
                    Core.prototype.findBestResource = function (allowedResourceIds, task) {
                        var allowedResources = [];
                        if (allowedResourceIds && allowedResourceIds.length > 0) {
                            for (var i = 0; i < allowedResourceIds.length; i++) {
                                var res = this.inputs.container.findResource(allowedResourceIds[i]);
                                if (res)
                                    allowedResources.push(res);
                            }
                        }
                        else
                            allowedResources = this.inputs.container.resourceDictionary.Values();
                        var bestWorkStart = new Date(2050, 1, 1).valueOf();
                        var bestResult = undefined;
                        var result = new TaskWrapper(true, task, undefined, 0);
                        for (var i = 0; i < allowedResources.length; i++) {
                            var resource = new ResourceWrapper(this.inputs, allowedResources[i], task);
                            var workStart = resource.fitSingleTaskIntoFreeSlots(result);
                            if (this.inputs.viewStartTime <= workStart && workStart < this.inputs.viewEndTime) {
                                if (0 < workStart && workStart < bestWorkStart) {
                                    bestWorkStart = workStart;
                                    bestResult = new TaskWrapper(true, task, allowedResources[i], workStart);
                                }
                            }
                        }
                        return bestResult;
                    };
                    return Core;
                }());
                AutoPlanner.Core = Core;
            })(AutoPlanner = Scheduler.AutoPlanner || (Scheduler.AutoPlanner = {}));
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
