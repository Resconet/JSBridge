///<reference path="../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../Controls/popupMenu.ts"/>
///<reference path="../../Controls/gestureManager.ts"/>
///<reference path="resource.ts" />
///<reference path="utilities.ts" />
///<reference path="enums.ts" />
///<reference path="container.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var Group = (function () {
                function Group(id, name, locationRef, territory) {
                    this.id = id;
                    this.name = name;
                    this.territory = territory;
                    this.locationRef = locationRef;
                }
                return Group;
            }());
            Scheduler.Group = Group;
            var Travel = (function () {
                function Travel(travelTo, travelFrom, mode) {
                    this.to = travelTo;
                    this.from = travelFrom;
                    this.mode = mode ? mode : Scheduler.TravelMode.Default;
                }
                Object.defineProperty(Travel.prototype, "toInMinutes", {
                    get: function () {
                        return Math.floor(this.to / Scheduler.minuteInMiliseconds);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Travel.prototype, "fromInMinutes", {
                    get: function () {
                        return Math.floor(this.from / Scheduler.minuteInMiliseconds);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Travel.prototype, "duration", {
                    get: function () {
                        return this.to + this.from;
                    },
                    enumerable: true,
                    configurable: true
                });
                Travel.prototype.equal = function (travel) {
                    return this.to === travel.to && this.from === travel.from && this.mode === travel.mode;
                };
                Travel.prototype.clone = function () {
                    return new Travel(this.to, this.from, this.mode);
                };
                return Travel;
            }());
            Scheduler.Travel = Travel;
            var TaskSchedule = (function () {
                function TaskSchedule(workStart, totalWorkTime, travel, entityInput, containerView) {
                    this._containerView = Scheduler.TaskContainerView.None; // determine parent view container where the TaskSchedule (task box) is currently present
                    this.hasScheduledStart = false; // is false when start is set to temporary Date.now() value
                    this.entityInput = entityInput;
                    this._containerView = ((containerView === undefined) || (containerView === null)) ? Scheduler.TaskContainerView.None : containerView;
                    this._updateTaskSchedule(workStart, totalWorkTime, travel);
                    this.hasScheduledStart = true;
                }
                Object.defineProperty(TaskSchedule.prototype, "containerView", {
                    /*
                    get entityInput(): ScheduledDataInput {
                        return this._entityInput;
                    }
            
                    set entityInput(value: ScheduledDataInput) {
                        if (value !== this._entityInput) {
                            this._entityInput = value;
                            this._updateTaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), this.getTravel());
                        }
                    }*/
                    get: function () {
                        return this._containerView;
                    },
                    set: function (value) {
                        if (value !== this._containerView) {
                            this._containerView = value;
                            this._updateTaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), this.getTravel());
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                TaskSchedule.prototype.cloneTaskSchedule = function () {
                    return new TaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), this.getTravel(), this.entityInput, this.containerView);
                };
                TaskSchedule.prototype.getTotalWorkTime = function () {
                    return this._taskSchedule.getTotalWorkTime();
                };
                TaskSchedule.prototype.setTotalWorkTime = function (value) {
                    this._updateTaskSchedule(this.getWorkStart(), value, this.getTravel());
                };
                TaskSchedule.prototype.getWorkStart = function () {
                    return this._taskSchedule.getWorkStart();
                };
                TaskSchedule.prototype.setWorkStart = function (value) {
                    this._updateTaskSchedule(value, this.getTotalWorkTime(), this.getTravel());
                    this.hasScheduledStart = true;
                };
                TaskSchedule.prototype.getWorkEnd = function () {
                    return this._taskSchedule.getWorkEnd();
                };
                TaskSchedule.prototype.getStart = function () {
                    return this._taskSchedule.getStart();
                };
                TaskSchedule.prototype.getEnd = function () {
                    return this._taskSchedule.getEnd();
                };
                TaskSchedule.prototype.setTravel = function (travel) {
                    this._updateTaskSchedule(this.getWorkStart(), this.getTotalWorkTime(), travel);
                };
                TaskSchedule.prototype.getTravel = function () {
                    return this._taskSchedule.getTravel();
                };
                TaskSchedule.prototype.getTotalTravelTo = function () {
                    return this._taskSchedule.getTotalTravelTo();
                };
                TaskSchedule.prototype.getTotalTravelFrom = function () {
                    return this._taskSchedule.getTotalTravelFrom();
                };
                TaskSchedule.prototype.createContent = function (task, parentElement, doNotCreateIfNotNecessary) {
                    if (this._taskSchedule instanceof SplittedSchedule) {
                        this._taskSchedule.createContent(task, parentElement);
                    }
                    else {
                        if (!doNotCreateIfNotNecessary || !SimpleSchedule.isDrawnAsSimple(parentElement)) {
                            parentElement.innerHTML = "";
                            this._taskSchedule.createContent(task, parentElement);
                        }
                    }
                };
                /**
                 * Returns true if work is scheduled outside working hours.
                 */
                TaskSchedule.prototype.isOutsideWorkingHours = function () {
                    return this._taskSchedule.isOutsideWorkingHours();
                };
                /**
                 * Returns true if there is not enough time for travel to and travel from.
                 * @param task Task for which TravelUnavailability should be checked.
                 * @param tasksInCollisionCount Tasks of this task resource in which is this task in collision. (Used to reduce resource.getPeriodCollisions() calls.)
                 */
                TaskSchedule.prototype.isTravelUnavailability = function (task, tasksInCollisionCount) {
                    return this._taskSchedule.isTravelUnavailability(task, tasksInCollisionCount);
                };
                TaskSchedule.prototype.isTimeOff = function () {
                    if (Scheduler.Container.inputs.timeOffSchedules && Scheduler.Container.inputs.timeOffSchedules.entityName) {
                        if (this.entityInput.entityName === Scheduler.Container.inputs.timeOffSchedules.entityName) {
                            return true;
                        }
                    }
                    return false;
                };
                TaskSchedule.prototype._updateTaskSchedule = function (workStart, totalWorkTime, travel) {
                    this._taskSchedule = this._createTaskSchedule(workStart, totalWorkTime, travel);
                };
                TaskSchedule.prototype._createTaskSchedule = function (workStart, totalWorkTime, travel) {
                    if (Scheduler.Container.constants.viewSplitOvertimeTasks && (this.containerView !== Scheduler.TaskContainerView.IsInUndefinedTasksContainer) && !this.isTimeOff()) {
                        var range = new Scheduler.TimeRange(workStart, workStart + totalWorkTime);
                        if (range.duration() > (Scheduler.Container.defaultOffice.workingDayDuration * Scheduler.minuteInMiliseconds)) {
                            var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(range, travel.to, travel.from);
                            if (workTimeRanges[0].start > range.start) {
                                // use implementation for splitted TaskSchedule with start in next working hours
                                return new SplittedNextSchedule(workStart, totalWorkTime, travel);
                            }
                            else if (workTimeRanges.length > 1) {
                                // use implementation for splitted TaskSchedule with start in current working hours
                                return new SplittedSchedule(workStart, totalWorkTime, travel);
                            }
                        }
                    }
                    // use implementation for simple TaskSchedule
                    return new SimpleSchedule(workStart, totalWorkTime, travel);
                };
                return TaskSchedule;
            }());
            Scheduler.TaskSchedule = TaskSchedule;
            // Implementation for simple TaskSchedule.
            var SimpleSchedule = (function () {
                function SimpleSchedule(workStart, totalWorkTime, travel) {
                    this._workStart = workStart;
                    this._totalWorkTime = totalWorkTime;
                    this._travel = travel.clone();
                }
                SimpleSchedule.prototype.getTotalWorkTime = function () {
                    return this._totalWorkTime;
                };
                SimpleSchedule.prototype.getWorkStart = function () {
                    return this._workStart;
                };
                SimpleSchedule.prototype.getWorkEnd = function () {
                    return this.getWorkStart() + this.getTotalWorkTime();
                };
                SimpleSchedule.prototype.getStart = function () {
                    return this.getWorkStart() - this.getTravel().to;
                };
                SimpleSchedule.prototype.getEnd = function () {
                    return this.getWorkEnd() + this.getTravel().from;
                };
                SimpleSchedule.prototype.getTravel = function () {
                    return this._travel;
                };
                SimpleSchedule.prototype.getTotalTravelTo = function () {
                    return this.getTravel().to;
                };
                SimpleSchedule.prototype.getTotalTravelFrom = function () {
                    return this.getTravel().from;
                };
                SimpleSchedule.prototype.createContent = function (task, element) {
                    var view = task.container.viewCtrl;
                    var taskStatus = task.getStatus();
                    var taskIsInPast = task.getEnd() < view.timeNow;
                    element.classList.remove("splittedTask");
                    element.classList.add("taskStatusColor");
                    if (taskIsInPast)
                        taskStatus.setElementCSS(element, Scheduler.StatusCSS.PastTask);
                    else
                        taskStatus.setElementCSS(element, Scheduler.StatusCSS.Default);
                    var taskNameDiv = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskNameDiv"]);
                    var taskBottomDiv = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskBottomDiv"]);
                    var nameText = Scheduler.Utilities.createNewHTMLElement("span", null, null, ["text"], task.name);
                    taskNameDiv.appendChild(nameText);
                    if (task.progress > 0 && taskStatus.hasProgress() && !task.isTimeOff()) {
                        var bkgProgressColor = taskStatus.progressColor();
                        var progress = task.progress;
                        if (progress > 100)
                            progress = 100;
                        var taskProgressBar = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: progress + "%" }], ["taskProgressBar"]);
                        var progressText = Scheduler.Utilities.createNewHTMLElement("span", null, null, ["taskProgress", "text"], progress + "%");
                        taskProgressBar.style.backgroundColor = taskIsInPast ? Scheduler.ColorCache.applyColorAlpha(bkgProgressColor, 0.3) : bkgProgressColor;
                        taskBottomDiv.appendChild(taskProgressBar);
                        taskBottomDiv.appendChild(progressText);
                    }
                    taskBottomDiv.appendChild(this._createTaskAlertElement(task));
                    element.appendChild(taskNameDiv);
                    element.appendChild(taskBottomDiv);
                };
                /**
                 * Returns true if work is scheduled outside working hours.
                 */
                SimpleSchedule.prototype.isOutsideWorkingHours = function () {
                    var timeRange = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkEnd());
                    var workingHoursTimeRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(timeRange.start);
                    if (!timeRange.isInside(workingHoursTimeRange))
                        return true;
                    return false;
                };
                /**
                 * Returns true if there is not enough time for travel to and travel from.
                 * @param resource Task resource.
                 * @param tasksInCollisionCount Tasks of this task resource in which is this task in collision. (Used to reduce resource.getPeriodCollisions() calls.)
                 */
                SimpleSchedule.prototype.isTravelUnavailability = function (task, tasksInCollisionCount) {
                    var displayedTimeRange = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkEnd());
                    var earliestWorkingHoursRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(displayedTimeRange.start);
                    if (!displayedTimeRange.isInside(earliestWorkingHoursRange))
                        return { unavailable: false, collisions: [] };
                    var displayedTimeRangeWithTravel = new Scheduler.TimeRange(this.getStart(), this.getEnd());
                    if (displayedTimeRangeWithTravel.start < earliestWorkingHoursRange.start)
                        return { unavailable: true, collisions: [] };
                    if (displayedTimeRangeWithTravel.end > earliestWorkingHoursRange.end)
                        return { unavailable: true, collisions: [] };
                    if (task.resource) {
                        var tasksWithTravelInCollision = task.resource.getPeriodCollisions(displayedTimeRangeWithTravel, false, false, task.id);
                        if (tasksWithTravelInCollision.length > tasksInCollisionCount)
                            return { unavailable: true, collisions: tasksWithTravelInCollision };
                    }
                    return { unavailable: false, collisions: [] };
                };
                SimpleSchedule.prototype._createTaskAlertElement = function (task) {
                    var imageSize = 16;
                    var image = Scheduler.Utilities.createNewHTMLElement("image", null, [{ styleName: "width", styleValue: imageSize + "px" }, { styleName: "height", styleValue: imageSize + "px" }], ["taskAlert"]);
                    if (task.getStatus().isUnscheduled() && !task.isUnscheduledNew()) {
                        Scheduler.Container.setElementBackgroundImage(image, "jeopardy.png");
                        this._updateAlertElement(image, task.isInJeopardy());
                    }
                    else {
                        Scheduler.Container.setElementBackgroundImage(image, "ruleViolations.png");
                        this._updateAlertElement(image, task.hasViolations());
                    }
                    return image;
                };
                /**
                 * Use in case when task alert element is not appended yet to the ganttElement when task is constructing.
                 * @param visible
                 * @param alertElement
                 */
                SimpleSchedule.prototype._updateAlertElement = function (alertElement, visible) {
                    if (alertElement && alertElement.classList) {
                        if (visible)
                            alertElement.classList.add("visible");
                        else
                            alertElement.classList.remove("visible");
                    }
                };
                SimpleSchedule.isDrawnAsSimple = function (parentElement) {
                    if (parentElement) {
                        if (!parentElement.classList.contains("splittedTask") && (parentElement.children.length > 0))
                            return parentElement.children.item(0).classList.contains("taskNameDiv");
                    }
                    return false;
                };
                return SimpleSchedule;
            }());
            // Implementation for splitted TaskSchedule with start in current working hours.
            var SplittedSchedule = (function (_super) {
                __extends(SplittedSchedule, _super);
                function SplittedSchedule(workStart, totalWorkTime, travel) {
                    return _super.call(this, workStart, totalWorkTime, travel) || this;
                }
                SplittedSchedule.prototype.getWorkEnd = function () {
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime()), this.getTravel().to, this.getTravel().from);
                    return workTimeRanges[workTimeRanges.length - 1].end;
                };
                SplittedSchedule.prototype.getStart = function () {
                    return this.getWorkStart() - this.getTravel().to;
                };
                SplittedSchedule.prototype.getTotalTravelTo = function () {
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime()), this.getTravel().to, this.getTravel().from);
                    return workTimeRanges.length * this.getTravel().to;
                };
                SplittedSchedule.prototype.getTotalTravelFrom = function () {
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime()), this.getTravel().to, this.getTravel().from);
                    return workTimeRanges.length * this.getTravel().from;
                };
                SplittedSchedule.prototype.createContent = function (task, parentElement, hasStartInNext) {
                    var travel = this.getTravel();
                    var range = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime());
                    var workTimeRanges = Scheduler.Container.defaultOffice.getWorkTimeRanges(range, travel.to, travel.from);
                    var view = task.container.viewCtrl;
                    parentElement.classList.remove("taskStatusColor");
                    parentElement.classList.add("splittedTask");
                    parentElement.style.backgroundColor = "";
                    parentElement.innerHTML = "";
                    var taskBoxDashedDiv = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskBoxDashedDiv"]);
                    parentElement.appendChild(taskBoxDashedDiv);
                    var taskSubTravels = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskSubTravels"]);
                    var taskBoxDivOffset = view.zoom.timeToPixelPosition(range.start);
                    for (var i = 0; i < workTimeRanges.length; i++) {
                        var workTimeRange = workTimeRanges[i];
                        var x1 = view.zoom.timeToPixelPosition(workTimeRange.start) - taskBoxDivOffset;
                        var x2 = view.zoom.timeToPixelPosition(workTimeRange.end) - taskBoxDivOffset;
                        // travel to
                        if ((i > 0) || hasStartInNext) {
                            var tt1 = view.zoom.timeToPixelPosition(workTimeRange.start - travel.to) - taskBoxDivOffset;
                            var travelToElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "left", styleValue: tt1 + "px" },
                                { styleName: "width", styleValue: (x1 - tt1) + "px" }], ["taskTravelTo"]);
                            taskSubTravels.appendChild(travelToElement);
                        }
                        // subDiv
                        var taskBoxSubDiv = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "left", styleValue: x1 + "px" }, { styleName: "width", styleValue: (x2 - x1) + "px" }], ["taskBoxSubDiv"]);
                        _super.prototype.createContent.call(this, task, taskBoxSubDiv);
                        parentElement.appendChild(taskBoxSubDiv);
                        // travel from
                        if (i < (workTimeRanges.length - 1)) {
                            var tf2 = view.zoom.timeToPixelPosition(workTimeRange.end + travel.from) - taskBoxDivOffset;
                            var travelFromElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "left", styleValue: x2 + "px" }, { styleName: "width", styleValue: (tf2 - x2) + "px" }], ["taskTravelFrom"]);
                            taskSubTravels.appendChild(travelFromElement);
                        }
                    }
                    parentElement.appendChild(taskSubTravels);
                };
                /**
                 * Returns false always.
                 */
                SplittedSchedule.prototype.isOutsideWorkingHours = function () {
                    return false;
                };
                /**
                 * Returns true if there is not enough time for travel to and travel from.
                 * @param resource Task resource.
                 * @param tasksInCollisionCount Tasks of this task resource in which is this task in collision. (Used to reduce resource.getPeriodCollisions() calls.)
                 */
                SplittedSchedule.prototype.isTravelUnavailability = function (task, tasksInCollisionCount) {
                    var displayedTimeRange = new Scheduler.TimeRange(this.getWorkStart(), this.getWorkEnd());
                    var earliestWorkingHoursRange = Scheduler.Container.defaultOffice.getEarliestWorkingHoursRange(displayedTimeRange.start);
                    var lastWorkingHoursTimeRange = Scheduler.Container.defaultOffice.getLastWorkingHoursRange(displayedTimeRange.end);
                    var displayedTimeRangeWithTravel = new Scheduler.TimeRange(this.getStart(), this.getEnd());
                    if (displayedTimeRangeWithTravel.start < earliestWorkingHoursRange.start)
                        return { unavailable: true, collisions: [] };
                    if (displayedTimeRangeWithTravel.end > lastWorkingHoursTimeRange.end)
                        return { unavailable: true, collisions: [] };
                    if (task.resource) {
                        var tasksWithTravelInCollision = task.resource.getPeriodCollisions(displayedTimeRangeWithTravel, false, false, task.id);
                        if (tasksWithTravelInCollision.length > tasksInCollisionCount)
                            return { unavailable: true, collisions: tasksWithTravelInCollision };
                    }
                    return { unavailable: false, collisions: [] };
                };
                return SplittedSchedule;
            }(SimpleSchedule));
            // Implementation for splitted TaskSchedule with start in next working hours.
            var SplittedNextSchedule = (function (_super) {
                __extends(SplittedNextSchedule, _super);
                function SplittedNextSchedule() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                SplittedNextSchedule.prototype.getStart = function () {
                    return this.getWorkStart();
                };
                SplittedNextSchedule.prototype.createContent = function (task, parentElement) {
                    _super.prototype.createContent.call(this, task, parentElement, true);
                };
                return SplittedNextSchedule;
            }(SplittedSchedule));
            var Task = (function (_super) {
                __extends(Task, _super);
                function Task(input, id, name, start, end, workDuration) {
                    var _this = _super.call(this, start, workDuration ? workDuration : end - start, new Travel(0, 0), input) || this;
                    _this.ruleViolations = [];
                    _this.progress = 0;
                    _this.id = id;
                    _this.name = name;
                    _this.container = Scheduler.Container.ref;
                    return _this;
                }
                Task.prototype.clone = function () {
                    var task = new Task(this.entityInput, this.id, this.name, this.getWorkStart(), this.getWorkStart() + this.getTotalWorkTime());
                    for (var key in this) {
                        if (typeof (this[key]) !== "function") {
                            task[key] = this[key];
                        }
                    }
                    return task;
                };
                ;
                Task.prototype.getID = function () {
                    return this.id;
                };
                Task.prototype.getName = function () {
                    return this.name;
                };
                Task.prototype.getBoxPosition = function () {
                    return this.ganttElement.position();
                };
                Object.defineProperty(Task.prototype, "taskBoxDiv", {
                    get: function () {
                        return this.ganttElement.children(".taskBoxDiv");
                    },
                    enumerable: true,
                    configurable: true
                });
                Task.prototype.drawBox = function (parentElement, refreshableContainer) {
                    this.updateRuleViolations();
                    if (refreshableContainer && this.ganttElement) {
                        var taskBox = refreshableContainer.find(".taskBoxWrapper[data-taskid='" + this.id + "']");
                        if (taskBox && taskBox.length > 0)
                            return;
                    }
                    if (!this.getStatus().isUnscheduled() || this.isUnscheduledNew())
                        this.createTaskElement(parentElement);
                };
                Task.prototype.setValues = function (values, ignoreVerification) {
                    var changes = 0;
                    var resetSort = 0;
                    if (values.name) {
                        this.name = values.name;
                        changes++;
                    }
                    if (values.progress || values.progress === 0) {
                        this.progress = values.progress;
                        changes++;
                    }
                    if ((values.travelTo === 0 || values.travelTo > 0) ||
                        (values.travelFrom === 0 || values.travelFrom > 0)) {
                        if (values.travelTo === undefined)
                            values.travelTo = this.getTravel().to;
                        if (values.travelFrom === undefined)
                            values.travelFrom = this.getTravel().from;
                        this.setTravel(new Travel(values.travelTo, values.travelFrom, values.travelMode));
                        changes++;
                    }
                    //if (values.scheduledBreak === 0 && values.scheduledBreak > 0) { // scheduledBreak is not used now
                    //	this.scheduledBreak = values.scheduledBreak;
                    //	changes++;
                    //}
                    if (values.start) {
                        this.setWorkStart(values.start);
                        changes++;
                        resetSort++;
                    }
                    if (values.end) {
                        this.setTotalWorkTime(values.end - values.start);
                        changes++;
                        resetSort++;
                    }
                    // reassign must be after start/end save
                    var parentID = this.resource ? this.resource.getID() : undefined;
                    if (values.hasOwnProperty("parentID")) {
                        var statuscode = values.statuscode;
                        this.container.reassignTask(this, values.parentID, false);
                        if (statuscode !== undefined)
                            this.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(statuscode));
                        changes++;
                        resetSort++;
                    }
                    else if (values.statuscode !== undefined) {
                        this.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(values.statuscode));
                        if (this.getStatus().isUnscheduled() && !this.isUnscheduledNew())
                            this.container.setTaskAsUnscheduled(this, false);
                        resetSort++;
                        changes++;
                    }
                    if (resetSort && this.resource)
                        this.resource.resetSort();
                    return changes > 0;
                };
                /*
                public setTimes(workStart: number, workEnd: number, travelTo?: number, travelFrom?: number): boolean {
                    this.start = workStart;
                    this.end = workEnd;
                    if (travelTo )
                        this.travelTo = travelTo;
                    if (travelFrom)
                        this.travelFrom = travelFrom;
                    return true;
                }*/
                Task.prototype.isValidAssignment = function (newParent) {
                    if (!this.allowedResourceIds)
                        return this.allowedResourceIds === null; // if undefined, allowedResourceIds has not been loaded yet
                    if (newParent) {
                        var id = newParent.getID();
                        if (this.resource && this.resource.getID() === id)
                            return true;
                        for (var i = 0; i < this.allowedResourceIds.length; i++) {
                            var resourceId = this.allowedResourceIds[i];
                            if (resourceId === id) {
                                return true;
                            }
                        }
                    }
                    return false;
                };
                Task.prototype.getParent = function () {
                    return this.resource;
                };
                Task.prototype.setParent = function (res) {
                    this.resource = res;
                };
                Task.prototype.hasViolations = function () {
                    return this.ruleViolations.length > 0;
                };
                Task.prototype.linkedResources = function () {
                    return this.allowedResourceIds;
                };
                Task.prototype.setLocation = function (location) {
                    this.location = location;
                };
                Task.prototype.getLocation = function () {
                    return this.location;
                };
                Task.prototype.loadLocation = function (onLoad) {
                    if (this.location !== undefined || !this.container) {
                        if (onLoad)
                            onLoad(null);
                    }
                    else
                        this.container.dataProvider.loadLocations([this], onLoad);
                };
                Task.prototype.removeBox = function () {
                    var draggableContainer = this.container.draggableContainer;
                    if (draggableContainer.isFocusedTask(this))
                        draggableContainer.takeFocusFromFocusedTask();
                    if (this.ganttElement) {
                        this.ganttElement.remove();
                        this.ganttElement = undefined;
                    }
                };
                Task.prototype.isUnscheduledNew = function () {
                    return this.id.indexOf("New_") === 0;
                };
                Task.prototype.getStatus = function () {
                    return this._status;
                };
                Task.prototype.setStatus = function (status) {
                    if (status) {
                        this._status = status;
                        if (this.getStatus().isFinished())
                            this.progress = 100;
                    }
                };
                Task.prototype.isEditable = function () {
                    return this.entityInput.canWrite && (this.container ? this.container.canModifyTasks : true) && this.getStatus().isEditable();
                };
                Task.isValidStatusValue = function (statusValue) {
                    var statusList = Scheduler.Container.statusCodeTable.statusList;
                    for (var i = 0; i < statusList.length; i++) {
                        if (statusList[i].value() === statusValue)
                            return true;
                    }
                    return false;
                };
                Task.prototype.getLinkedResources = function () {
                    return this.allowedResourceIds;
                };
                Task.prototype.setLinkedResources = function (resIds) {
                    this.allowedResourceIds = resIds;
                };
                Task.prototype.loadLinkedResources = function (onFinishCallback) {
                    if (this.allowedResourceIds !== undefined) {
                        if (onFinishCallback)
                            onFinishCallback(null);
                    }
                    else if (this.container) {
                        var self = this;
                        this.container.dataProvider.loadQualifiedResources([this], function (error) {
                            //self.allowedResourceIds = allowedResourceIds !== undefined ? allowedResourceIds : null;
                            if (onFinishCallback)
                                onFinishCallback(error);
                        });
                    }
                };
                Task.prototype.failed = function (errorCallback, errId) {
                    if (errorCallback)
                        errorCallback(Scheduler.StringTable.get(errId));
                    return false;
                };
                Task.prototype.isValidMove = function (parent, start, end, errorCallback) {
                    var timeRangeWithTravel = new Scheduler.TimeRange(start, end);
                    if (!this.isEditable() || this.container.isLocked())
                        return this.failed(errorCallback, "Err.CantModifyEntity");
                    if (!timeRangeWithTravel.isValid() /*|| !timeRangeWithTravel.isInside(this.container.editableRange)*/)
                        return this.failed(errorCallback, "Err.TimesOutOfScope");
                    // validation of parent
                    if (!parent) {
                        parent = this.resource;
                        if (!parent)
                            return this.failed(errorCallback, "Scheduler.Err.NoResourceIdForNewTask");
                    }
                    else if (parent !== this.resource) {
                        if (!this.isValidAssignment(parent))
                            return this.failed(errorCallback, "Scheduler.Err.AssigmentFailed");
                    }
                    //scheduled during weekend
                    var office = parent ? parent.getOffice() : Scheduler.Container.defaultOffice;
                    if (!office.checkWeekendWork(timeRangeWithTravel))
                        return this.failed(errorCallback, "Scheduler.Err.FreeWeekend");
                    var h = Scheduler.Holidays.isHoliday(new Date(timeRangeWithTravel.start));
                    if (h && !h.isWorking)
                        return this.failed(errorCallback, "Scheduler.Err.FreeHoliday");
                    var tasksInCollision;
                    if ((tasksInCollision = parent.getPeriodCollisions(timeRangeWithTravel, true, false, this.id)).length > 0) {
                        if (tasksInCollision[0].isTimeOff())
                            return this.failed(errorCallback, "Scheduler.Err.ResourceHasTimeOff");
                        else
                            return this.failed(errorCallback, "Scheduler.Err.TaskInConflict");
                    }
                    return true;
                };
                Task.prototype.getRowIndex = function () {
                    return this.resource ? this.resource.rowIndex : -1;
                };
                ;
                Task.prototype.canReassign = function (newParent, start, end, errorCallback) {
                    if (this.isValidMove(newParent, start, end, errorCallback) && (this.shouldReassignOrMove(newParent) !== null)) {
                        return true;
                    }
                    return false;
                };
                Task.prototype._checkSchedulingInPast = function (workStart, onFinishCallback) {
                    if (workStart < Date.now()) {
                        var yes_1 = Scheduler.StringTable.get("Cmd.Yes");
                        var no = Scheduler.StringTable.get("Cmd.No");
                        var popup = new MobileCRM.UI.MessageBox(Scheduler.StringTable.get("Scheduler.Msg.AskSchedulingInPast"));
                        popup.items = [yes_1, no];
                        popup.multiLine = true;
                        popup.show(function (button) {
                            onFinishCallback(button === yes_1);
                        });
                    }
                    else {
                        onFinishCallback(true);
                    }
                };
                Task.prototype.tryReassign = function (newParent, workStart, onFinishCallback) {
                    var _this = this;
                    var newTaskSchedule = this.cloneTaskSchedule();
                    newTaskSchedule.setWorkStart(workStart);
                    if (this.canReassign(newParent, newTaskSchedule.getStart(), newTaskSchedule.getEnd(), null)) {
                        var reassignOrMove_1 = this.shouldReassignOrMove(newParent);
                        if (reassignOrMove_1 !== null) {
                            this._checkSchedulingInPast(workStart, function (success) {
                                if (success) {
                                    var taskChanges = _this.prepareTaskChanges(workStart, _this.getTotalWorkTime(), reassignOrMove_1 === true ? newParent : null);
                                    _this.container.saveTask(_this, taskChanges)
                                        .then(function (task) {
                                        onFinishCallback(true);
                                    })
                                        .catch(function (error) {
                                        Scheduler.StringTable.alert(error);
                                        onFinishCallback(false);
                                    }); //@JC performs move, resize or parent task reassignment asynchronously if JSBridge finds taskChanges as valid.
                                }
                                else {
                                    onFinishCallback(false);
                                }
                            });
                            return;
                        }
                    }
                    onFinishCallback(false);
                };
                Task.prototype.shouldReassignOrMove = function (newParent) {
                    if (!newParent) {
                        return null; // Not valid new Resource!
                    }
                    if (this.getStatus().isUnscheduled()) {
                        return true; // reassign
                    }
                    else {
                        if (this.resource) {
                            if (newParent.getID() === this.id) {
                                return null; // Task cannot be assigned to itself!
                            }
                            if (newParent.getID() === this.resource.getID()) {
                                return false; // move
                            }
                            else {
                                return true; // reassign
                            }
                        }
                        else {
                            return null; // Not valid task Resource!
                        }
                    }
                };
                Task.prototype.prepareTaskChanges = function (workStart, totalWorkTime, newParent) {
                    var taskChanges = {};
                    if (this.isUnscheduledNew()) {
                        //copy all properties except internal
                        for (var key in this) {
                            if (Task.internalProperties.indexOf(key) === -1) {
                                taskChanges[key] = this[key];
                            }
                        }
                    }
                    taskChanges.id = this.id;
                    taskChanges.start = workStart;
                    taskChanges.totalWork = totalWorkTime;
                    if (newParent)
                        taskChanges.parentID = newParent.getID();
                    return taskChanges;
                };
                Task.prototype.applyChanges = function (taskChanges, redraw) {
                    if (taskChanges.name)
                        this.name = taskChanges.name;
                    if (taskChanges.progress !== undefined && taskChanges.progress !== null && taskChanges.progress >= 0)
                        this.progress = taskChanges.progress;
                    if (taskChanges.travelTo !== undefined || taskChanges.travelFrom !== undefined || taskChanges.travelMode !== undefined) {
                        var travel = this.getTravel().clone();
                        if (taskChanges.travelTo === 0 || taskChanges.travelTo >= 0)
                            travel.to = taskChanges.travelTo;
                        if (taskChanges.travelFrom === 0 || taskChanges.travelFrom >= 0)
                            travel.from = taskChanges.travelFrom;
                        if (taskChanges.travelMode !== undefined)
                            travel.mode = taskChanges.travelMode;
                        this.setTravel(travel);
                    }
                    //if (taskChanges.scheduledBreak !== undefined && taskChanges.scheduledBreak !== null && taskChanges.scheduledBreak >= 0)
                    //	this.scheduledBreak = taskChanges.scheduledBreak; // scheduledBreak is not used now
                    if (taskChanges.start || taskChanges.totalWork) {
                        if (taskChanges.start)
                            this.setWorkStart(taskChanges.start);
                        if (taskChanges.totalWork)
                            this.setTotalWorkTime(taskChanges.totalWork);
                        //taskChanges.end = this.getWorkEnd(); // we have to recalculate and save also new working end
                        if (this.resource)
                            this.resource.resetSort();
                    }
                    // reassign must be after start/totalWork save
                    if (taskChanges.hasOwnProperty("parentID"))
                        this.container.reassignTask(this, taskChanges.parentID, redraw);
                    if (taskChanges.statuscode !== undefined) {
                        this.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(taskChanges.statuscode));
                        if (this.getStatus().isUnscheduled() && !this.isUnscheduledNew()) {
                            this.container.setTaskAsUnscheduled(this, redraw);
                            return;
                        }
                        else if (this.resource)
                            this.resource.resetSort();
                    }
                    if (redraw) {
                        this.updateBoxElement();
                    }
                };
                /*
                public isHorizontalChild(): boolean {
                    //var taskParent = this.getParent();
                    return this.resource != undefined;// && this.level > 0;//  taskParent ? taskParent.horizontalChildrenTasks : false;
                }*/
                /**
                 * Append task box from undefinedTasksContainer to draggableContainer
                 */
                Task.prototype.appendTaskBoxFromUTCToDC = function () {
                    if (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer) {
                        var undefinedTasksContainer = $("#undefinedTasks");
                        if (undefinedTasksContainer.length > 0) {
                            var draggableContainer = this.container.draggableContainer.element;
                            var delta = Scheduler.Utilities.getContainersOffsetDelta(undefinedTasksContainer, draggableContainer);
                            var taskBox = this.ganttElement;
                            if (taskBox) {
                                var taskBoxPosition = taskBox.position();
                                draggableContainer.append(taskBox);
                                taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                                this.containerView = Scheduler.TaskContainerView.IsInDraggableContainer;
                            }
                        }
                    }
                };
                /**
                 * Append task box from tasksContainer to draggableContainer
                 */
                Task.prototype.appendTaskBoxFromTCToDC = function () {
                    if (this.containerView === Scheduler.TaskContainerView.IsInTasksContainer) {
                        var draggableContainer = this.container.draggableContainer.element;
                        var delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.viewCtrl.viewBody.tasksContainerElement, draggableContainer);
                        var taskBox = this.ganttElement;
                        if (taskBox) {
                            var taskBoxPosition = taskBox.position();
                            draggableContainer.append(taskBox);
                            taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                            this.containerView = Scheduler.TaskContainerView.IsInDraggableContainer;
                        }
                    }
                };
                /**
                 * Append task box from draggableContainer to tasksContainer
                 */
                Task.prototype.appendTaskBoxFromDCToTC = function () {
                    if (this.containerView === Scheduler.TaskContainerView.IsInDraggableContainer) {
                        var tasksContainerElement = this.container.viewCtrl.viewBody.tasksContainerElement;
                        var delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.draggableContainer.element, tasksContainerElement);
                        var taskBox = this.ganttElement;
                        if (taskBox) {
                            var taskBoxPosition = taskBox.position();
                            tasksContainerElement.append(taskBox);
                            taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                            this.containerView = Scheduler.TaskContainerView.IsInTasksContainer;
                            if (taskBox.hasClass("unscheduledTask")) {
                                taskBox.removeClass("unscheduledTask");
                                var imageElement = taskBox.find(".taskAlert");
                                Scheduler.Container.setElementBackgroundImage(imageElement[0], "ruleViolations.png");
                            }
                        }
                    }
                };
                /**
                 * Append task box from draggableContainer or tasksContainer to undefinedTasksContainer
                 */
                Task.prototype.appendTaskBoxFromDCOrTCToUTC = function () {
                    var undefinedTasksContainer = $("#undefinedTasks");
                    if (undefinedTasksContainer.length > 0) {
                        var delta = null;
                        if (this.containerView === Scheduler.TaskContainerView.IsInDraggableContainer) {
                            delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.draggableContainer.element, undefinedTasksContainer);
                        }
                        else if (this.containerView === Scheduler.TaskContainerView.IsInTasksContainer) {
                            delta = Scheduler.Utilities.getContainersOffsetDelta(this.container.viewCtrl.viewBody.tasksContainerElement, undefinedTasksContainer);
                        }
                        if (delta) {
                            var taskBox = this.ganttElement;
                            if (taskBox) {
                                var taskBoxPosition = taskBox.position();
                                undefinedTasksContainer.append(taskBox);
                                taskBox.css({ left: taskBoxPosition.left + delta.x, top: taskBoxPosition.top + delta.y });
                                this.containerView = Scheduler.TaskContainerView.IsInUndefinedTasksContainer;
                                taskBox.addClass("unscheduledTask");
                                var imageElement = taskBox.find(".taskAlert");
                                Scheduler.Container.setElementBackgroundImage(imageElement[0], "jeopardy.png");
                            }
                        }
                    }
                };
                /**
                 * Update task box and recreate task box content DOM elements to match with task data
                 */
                Task.prototype.updateBoxElement = function () {
                    var view = this.container.viewCtrl;
                    if (this.containerView !== Scheduler.TaskContainerView.None) {
                        if (this.ganttElement) {
                            var taskBoxDimensions = this.getTaskBoxDimensions();
                            if (!taskBoxDimensions) {
                                if (view.hasTaskOutsideTimeRange(this)) {
                                    view.container.removeTask(this);
                                }
                                else {
                                    this.removeBox();
                                    this.updateRuleViolations(true);
                                }
                                view.onTasksChanged();
                                return;
                            }
                            if (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer)
                                taskBoxDimensions.x = parseFloat(this.ganttElement[0].style.left); //this.ganttElement.position().left;
                            this.ganttElement[0].dataset.taskid = this.id;
                            this.ganttElement.css({ "left": taskBoxDimensions.x, "top": taskBoxDimensions.y });
                            this.updateBoxElementContent(taskBoxDimensions);
                        }
                    }
                    this._updateTaskOnEditEvent();
                    this.updateRuleViolations(true);
                    view.onTasksChanged();
                };
                //TODO: candidate for optimization
                //public createTaskBodyContent(view: View, svg: any, taskSvg: any, dimensions: Rectangle) {
                //	let task: Task = this;
                //	let isInUTRow: boolean = (task.containerView === TaskContainerView.IsInUndefinedTasksContainer);
                //	let radius = Container.constants.ganttTaskCornersRadius;
                //	let bodySvg = svg.svg(taskSvg, dimensions.x, dimensions.y, dimensions.width, dimensions.height, { class: "taskBoxBodySVG", draggable: "false" });
                //	//external box
                //	svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, radius, radius, { class: "taskLayout"} );
                //	svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, radius, radius, { fill: "rgba(255,255,255,.3)" });
                //	//svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, radius, radius, { class: "taskLayout", "opacity": "0.6" });
                //	if (!isInUTRow) {
                //		//external dep
                //		//if (task.hasExternalDep)
                //		//	svg.rect(bodySvg, 0, 0, dimensions.width, dimensions.height, { fill: "url(#extDep)" });
                //		//break box
                //		if (task.scheduledBreak > 0) {
                //			let breakWidth = view.zoom.timeDurationToWidth(task.scheduledBreak);
                //			svg.rect(bodySvg, ((dimensions.width - breakWidth) / 2), 0, breakWidth, dimensions.height, { class: "taskBreak" });
                //		}
                //		//progress
                //		if (task.progress > 0) {
                //			let progress = (task.progress > 100 ? 100 : (task.progress < 0 ? 0 : task.progress));
                //			let progressBarWidth = (progress / 100) * dimensions.width;
                //			svg.rect(bodySvg, 0, dimensions.height / 2, progressBarWidth, dimensions.height / 2, radius, radius, { class: "taskProgress" });
                //			let progressDigits = progress.toString().length;
                //			let progressTextWidth = Task.cachedTextsBounds.tryGetProgressTextWidth(progressDigits);
                //			let progressTextYOffset = Task.cachedTextsBounds.progressTextYOffset;
                //			if (!Task.cachedTextsBounds.progressTextYOffset && Task.cachedTextsBounds.progressTextYOffset !== 0) {
                //				progressTextYOffset = null;
                //			}
                //			let progressTextOffset = 5;
                //			let progressText = svg.text(bodySvg, progressTextOffset, progressTextYOffset === null ? 0 : progressTextYOffset, progress + "%", { class: "taskProgressText" });
                //			if (progressTextYOffset === null || progressTextWidth === null) {
                //				let progressTextBBox = progressText.getBBox();
                //				if (progressTextYOffset === null) {
                //					Task.cachedTextsBounds.progressTextYOffset = Math.round(Math.floor(Math.abs(progressTextBBox.y) / 2) + ((dimensions.height * 3) / 4)); //@JC labelBBox.y value represents characters height that is drawn up on the row line
                //					progressText.setAttribute("y", Task.cachedTextsBounds.progressTextYOffset);
                //				}
                //				if (progressTextWidth === null) {
                //					progressTextWidth = Math.ceil(progressTextBBox.width);
                //					Task.cachedTextsBounds.trySetProgressTextWidth(progressDigits, progressTextWidth);
                //				}
                //			}
                //			if ((!progressTextWidth) || (dimensions.width < (2 * (progressTextOffset + progressTextWidth)))) {
                //				progressText.setAttribute("visibility", "hidden");
                //			}
                //			else {
                //				if ((progressBarWidth + progressTextOffset + progressTextWidth) < dimensions.width) {
                //					progressText.setAttribute("x", progressBarWidth + progressTextOffset);
                //				}
                //				else {
                //					progressText.setAttribute("x", progressBarWidth - (progressTextOffset + progressTextWidth));
                //				}
                //			}
                //		}
                //	}
                //	//task label
                //	let label;
                //	if (!Task.cachedTextsBounds.labelYOffset && Task.cachedTextsBounds.labelYOffset !== 0) {
                //		label = svg.text(bodySvg, 0, 0, task.name, { class: "taskLabelSVG", "text-anchor": "start" });
                //		let labelBBox = label.getBBox();
                //		Task.cachedTextsBounds.labelYOffset = Math.round(Math.floor(Math.abs(labelBBox.y) / 2) + (dimensions.height / 4)); //@JC labelBBox.y value represents characters height that is drawn up on the row line
                //		label.setAttribute("y", Task.cachedTextsBounds.labelYOffset);
                //	}
                //	else {
                //		label = svg.text(bodySvg, 0, Task.cachedTextsBounds.labelYOffset, task.name, { class: "taskLabelSVG", "text-anchor": "start" });
                //	}
                //	if (dimensions.width < view.taskMinWidthForText) {
                //		label.setAttribute("visibility", "hidden");
                //	}
                //	if (!isInUTRow) {
                //		// creates rule violations indicator image
                //		let imageSize = 16;
                //		let imagePadding = 2;
                //		svg.image(bodySvg, dimensions.width - (imageSize + imagePadding), dimensions.height - (imageSize + imagePadding), imageSize, imageSize, "res/ruleViolations.png", { class: "taskViolationAlert" });
                //		this._updateViolationAlert();
                //		// creates X elements
                //		svg.line(bodySvg, 0, 0, dimensions.width, dimensions.height, { class: "taskReassignmentIndicator" });
                //		svg.line(bodySvg, 0, dimensions.height, dimensions.width, 0, { class: "taskReassignmentIndicator" });
                //	}
                //	else {
                //		// creates jeopardy indicator image
                //		let imageSize = 16;
                //		let imagePadding = 2;
                //		svg.image(bodySvg, dimensions.width - (imageSize + imagePadding), dimensions.height - (imageSize + imagePadding), imageSize, imageSize, "res/jeopardy.png", { class: "taskJeopardyAlert" });
                //		this.updateJeopardyAlert(this.isInJeopardy());
                //	}
                //}
                //public createTaskContent(view: View, svg: any, taskSvg: any, taskBody: TaskRectangle) {
                //	let task: Task = this;
                //	var radius = Container.constants.ganttTaskCornersRadius + view.taskFocusWidth;
                //	var bodyRect: Rectangle = { x: 0, y: view.taskFocusWidth, width: taskBody.width, height: taskBody.height - 2 * view.taskFocusWidth };
                //	if (task.containerView !== TaskContainerView.IsInUndefinedTasksContainer) {
                //		var lineY = (taskBody.height - view.container.constants.ganttTaskTravelLineWidth) / 2;
                //		let travelToWidth = taskBody.travelToWidth < 0 ? 0 : taskBody.travelToWidth;
                //		let travelFromWidth = taskBody.travelFromWidth < 0 ? 0 : taskBody.travelFromWidth;
                //		if ((bodyRect.width - (travelToWidth + travelFromWidth)) < Container.constants.viewTaskMinWidth) {
                //			if ((travelToWidth > 0) && !(travelFromWidth > 0)) {
                //				travelToWidth = bodyRect.width - Container.constants.viewTaskMinWidth;
                //			}
                //			else if (!(travelToWidth > 0) && (travelFromWidth > 0)) {
                //				travelFromWidth = bodyRect.width - Container.constants.viewTaskMinWidth;
                //			}
                //			else if ((travelToWidth > 0) && (travelFromWidth > 0)) {
                //				travelToWidth = travelFromWidth = Math.floor((bodyRect.width - Container.constants.viewTaskMinWidth) / 2);
                //			}
                //		}
                //		if (travelToWidth > 0) {
                //			svg.rect(taskSvg, 0, lineY, travelToWidth, view.container.constants.ganttTaskTravelLineWidth, { class: "taskTravelTo" });
                //			bodyRect.x += travelToWidth;
                //			bodyRect.width -= travelToWidth;
                //		}
                //		if (travelFromWidth > 0) {
                //			bodyRect.width -= travelFromWidth;
                //			svg.rect(taskSvg, travelToWidth + bodyRect.width, lineY, travelFromWidth, view.container.constants.ganttTaskTravelLineWidth, { class: "taskTravelFrom" });
                //		}
                //	}
                //	// creates focused effect element
                //	svg.rect(taskSvg, bodyRect.x - view.taskFocusWidth, bodyRect.y - view.taskFocusWidth, bodyRect.width + (2 * view.taskFocusWidth), bodyRect.height + (2 * view.taskFocusWidth), radius, radius, { class: "taskFocusedLayout" });
                //	task.createTaskBodyContent(view, svg, taskSvg, bodyRect);
                //}
                /**
                 * Calculates dimension rectangle (size and position) for task DOM element box based on TaskContainerView.
                 */
                Task.prototype.getTaskBoxDimensions = function (workStart) {
                    var view = this.container.viewCtrl;
                    var constants = Scheduler.Container.constants;
                    if (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer) {
                        return { x: view.xOffsetUT + constants.unscheduledViewTaskSpacing, y: 0, width: constants.unscheduledViewTaskWidth, height: view.getRowHeight(-1), travelFromWidth: 0, travelToWidth: 0 };
                    }
                    else {
                        var y = 0;
                        var height = void 0;
                        var newTaskSchedule = this.cloneTaskSchedule();
                        if (workStart)
                            newTaskSchedule.setWorkStart(workStart);
                        var displayedTimeRangeWithTravel = new Scheduler.TimeRange(newTaskSchedule.getStart(), newTaskSchedule.getEnd());
                        var visibleRange = view.zoom.getVisibleTimeRange();
                        if (!visibleRange.contain(displayedTimeRangeWithTravel))
                            return undefined;
                        var x1 = view.zoom.timeToPixelPosition(displayedTimeRangeWithTravel.start, true);
                        var x2 = view.zoom.timeToPixelPosition(displayedTimeRangeWithTravel.end, true);
                        var width = x2 - x1;
                        var travelToWidth = 0;
                        var travelFromWidth = 0;
                        // @JC: There must be used not rounded width, because in case when zoom is to small, task with short duration disappear (are not drawn and count with in KPI).
                        if ((width <= 0) && (displayedTimeRangeWithTravel.start !== displayedTimeRangeWithTravel.end))
                            return undefined;
                        // @JC: Now it is necessary to round it.
                        x1 = Math.round(x1);
                        x2 = Math.round(x2);
                        width = x2 - x1;
                        if (this.resource) {
                            var rowIndex = this.resource.rowIndex;
                            y = view.getRowPosition(rowIndex);
                            height = view.getRowHeight(rowIndex);
                        }
                        else
                            height = view.getRowHeight(-1);
                        // compute and restrict travel if necessary
                        if (width < constants.viewTaskMinWidth) {
                            width = constants.viewTaskMinWidth;
                        }
                        else {
                            var displayedTimeRange = new Scheduler.TimeRange(newTaskSchedule.getWorkStart(), newTaskSchedule.getWorkEnd());
                            if (this.getTravel().to > 0)
                                travelToWidth = view.zoom.timeToPixelPosition(displayedTimeRange.start) - x1;
                            if (this.getTravel().from > 0)
                                travelFromWidth = x2 - view.zoom.timeToPixelPosition(displayedTimeRange.end);
                            if ((width - (travelToWidth + travelFromWidth)) < constants.viewTaskMinWidth) {
                                if ((travelToWidth > 0) && !(travelFromWidth > 0)) {
                                    travelToWidth = width - constants.viewTaskMinWidth;
                                }
                                else if (!(travelToWidth > 0) && (travelFromWidth > 0)) {
                                    travelFromWidth = width - constants.viewTaskMinWidth;
                                }
                                else if ((travelToWidth > 0) && (travelFromWidth > 0)) {
                                    travelToWidth = travelFromWidth = Math.floor((width - constants.viewTaskMinWidth) / 2);
                                }
                            }
                        }
                        return { x: x1, y: y, width: width, height: height, travelFromWidth: travelFromWidth, travelToWidth: travelToWidth };
                    }
                };
                Task.prototype.getAvailableResorcesIdForMove = function () {
                    var ids = new Array();
                    if (this.allowedResourceIds && this.allowedResourceIds.length > 0) {
                        var resources = this.container.resourceDictionary;
                        var _loop_1 = function (resource) {
                            var id = { rowIndex: resource.rowIndex, canAssign: false };
                            if (this_1.allowedResourceIds.filter(function (i) { return i === resource.getID(); }).length === 1) {
                                id.canAssign = true;
                            }
                            ids.push(id);
                        };
                        var this_1 = this;
                        for (var _i = 0, _a = resources.Values(); _i < _a.length; _i++) {
                            var resource = _a[_i];
                            _loop_1(resource);
                        }
                    }
                    return ids;
                };
                Task.prototype.updateRuleViolations = function (updateTasksInCollision) {
                    var uniqueTasksInCollision = new Scheduler.Dictionary();
                    var oldTasksInCollision = [];
                    var newTasksInCollision = [];
                    if (updateTasksInCollision) {
                        //update old tasks in collision
                        oldTasksInCollision = this._getTasksInCollision(this.ruleViolations);
                        for (var i = 0; i < oldTasksInCollision.length; i++) {
                            var task = oldTasksInCollision[i];
                            if (!uniqueTasksInCollision.ContainsKey(task.id)) {
                                uniqueTasksInCollision.Add(task.id, task);
                            }
                        }
                    }
                    if (this.resource) {
                        if (!this.isTimeOff() && (!this.getStatus().isUnscheduled() && !this.getStatus().isFinished())) {
                            this.ruleViolations = this.resource.getRuleViolations(this);
                            this.updateAlert(this.hasViolations());
                            if (updateTasksInCollision) {
                                //update new tasks in collision
                                newTasksInCollision = this._getTasksInCollision(this.ruleViolations);
                                for (var i = 0; i < newTasksInCollision.length; i++) {
                                    var task = newTasksInCollision[i];
                                    if (!uniqueTasksInCollision.ContainsKey(task.id)) {
                                        uniqueTasksInCollision.Add(task.id, task);
                                    }
                                }
                            }
                        }
                    }
                    if (updateTasksInCollision) {
                        for (var i = 0; i < uniqueTasksInCollision.Keys().length; i++) {
                            uniqueTasksInCollision.Item(uniqueTasksInCollision.Keys()[i]).updateRuleViolations();
                        }
                    }
                };
                Task.prototype._getTasksInCollision = function (ruleViolations) {
                    var tasks = [];
                    for (var i = 0; i < ruleViolations.length; i++) {
                        var ruleViolation = ruleViolations[i];
                        if ((ruleViolation.violationType === Scheduler.RuleViolationType.OverlappingTasks) ||
                            (ruleViolation.violationType === Scheduler.RuleViolationType.OverlappingTimeOffs) ||
                            (ruleViolation.violationType === Scheduler.RuleViolationType.TravelUnavailability)) {
                            for (var j = 0; j < ruleViolation.tasksInCollision.length; j++) {
                                tasks.push(ruleViolation.tasksInCollision[j]);
                            }
                        }
                    }
                    return tasks;
                };
                /**
                 * Show or hide task alert.
                 * @param visible
                 */
                Task.prototype.updateAlert = function (visible) {
                    if (this.ganttElement) {
                        if (visible)
                            this.ganttElement.find(".taskAlert").addClass("visible");
                        else
                            this.ganttElement.find(".taskAlert").removeClass("visible");
                    }
                };
                Task.prototype.isInJeopardy = function () {
                    if (this.getStatus().isUnscheduled() && !this.isUnscheduledNew()) {
                        var beforeTime = Scheduler.Container.constants.jeopardyBeforeHours * Scheduler.hourInMiliseconds;
                        //if (this.hasScheduledStart) { // unscheduled task has always invalid time, therefore this case is not used now.
                        //	if ((this.start - beforeTime) < Date.now())
                        //		return true;
                        //}
                        //else
                        if (this.requiredWindow) {
                            if ((this.requiredWindow.end - (beforeTime + (this.getEnd() - this.getStart()))) < Date.now())
                                return true;
                        }
                    }
                    return false;
                };
                /**
                 * Returns true if work starts before requiredWindow start.
                 */
                Task.prototype.isBeforeWindowStart = function () {
                    if (this.requiredWindow && (this.requiredWindow.start > this.getWorkStart()))
                        return true;
                    return false;
                };
                /**
                 * Returns true if work ends after requiredWindow end.
                 */
                Task.prototype.isAfterWindowEnd = function () {
                    if (this.requiredWindow && (this.requiredWindow.end < this.getWorkEnd()))
                        return true;
                    return false;
                };
                Task.prototype.createTaskElement = function (parentElement) {
                    var view = this.container.viewCtrl;
                    var status = this.getStatus();
                    if (status.isUnscheduled()) {
                        if (this.isUnscheduledNew()) {
                            this.containerView = Scheduler.TaskContainerView.IsInDraggableContainer;
                        }
                        else {
                            this.containerView = Scheduler.TaskContainerView.IsInUndefinedTasksContainer;
                        }
                    }
                    else {
                        var timeRange = new Scheduler.TimeRange(this.getStart(), this.getEnd());
                        if (!view.zoom.getVisibleTimeRange().contain(timeRange)) {
                            return;
                        }
                        this.containerView = Scheduler.TaskContainerView.IsInTasksContainer;
                    }
                    //@DM: this part of code have to be here because in method getTaskBoxDimensions is reference to task.containerView!!!
                    var taskDimensions = this.getTaskBoxDimensions();
                    if (taskDimensions === undefined)
                        return;
                    var isInUTRow = (this.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer);
                    var taskBoxWrapper = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: taskDimensions.width + "px" }, { styleName: "left", styleValue: taskDimensions.x + "px" }, { styleName: "top", styleValue: taskDimensions.y + "px" }], ["taskBoxWrapper", "taskBox", isInUTRow ? "unscheduledTask" : ""], null, [{ attributeName: "data-taskid", attributeValue: this.id }]);
                    var travelToElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: taskDimensions.travelToWidth + "px" }], ["taskTravelTo"]);
                    var travelFromElement = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: taskDimensions.travelFromWidth + "px" }], ["taskTravelFrom"]);
                    var taskBoxDiv = Scheduler.Utilities.createNewHTMLElement("div", null, [{ styleName: "width", styleValue: (taskDimensions.width - taskDimensions.travelToWidth - taskDimensions.travelFromWidth) + "px" }], ["taskBoxDiv"]);
                    var taskBoxDivContent = Scheduler.Utilities.createNewHTMLElement("div", null, null, ["taskBoxDivContent"]);
                    this.createContent(this, taskBoxDivContent);
                    taskBoxDiv.appendChild(taskBoxDivContent);
                    taskBoxWrapper.appendChild(travelToElement);
                    taskBoxWrapper.appendChild(taskBoxDiv);
                    taskBoxWrapper.appendChild(travelFromElement);
                    parentElement.appendChild(taskBoxWrapper);
                    this.ganttElement = $(taskBoxWrapper);
                    this._addDoubleTapEventToTaskElement();
                    if (Scheduler.Container.constants.taskTooltipEnabled)
                        this._addTooltipEvents();
                    this._updateTaskOnEditEvent();
                    if (status.isUnscheduled() && !this.isUnscheduledNew()) {
                        var settings = Scheduler.Container.constants;
                        view.xOffsetUT += settings.unscheduledViewTaskWidth + settings.unscheduledViewTaskSpacing;
                    }
                };
                Task.prototype._addTooltipEvents = function () {
                    var _this = this;
                    var taskBox = this.ganttElement;
                    taskBox.mouseover(function (event) {
                        var draggableContainer = _this.container.draggableContainer;
                        if (Task._tooltipOnTask && Task._tooltipOnTask != _this)
                            Task.removeTooltip();
                        if (!Task._tooltipOnTask && (!draggableContainer || !draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.DragRecognized)))
                            _this._createTooltip();
                    });
                    taskBox.mouseout(function (event) {
                        Task.removeTooltip();
                    });
                };
                Task.prototype._createTooltip = function () {
                    var content;
                    var start = this.getWorkStart();
                    var end = this.getWorkEnd();
                    content = "<div class=\"taskTooltip\">";
                    content += "<h3>" + this.getName() + "</h3>";
                    if (start && end >= start) {
                        content += "<div>";
                        if (this.isTimeOff() == false) {
                            var range = new Scheduler.TimeRange(start, end);
                            content += "<p><b>STATUS: </b> " + this.getStatus().name() + "</p>";
                            content += "<p><b>WORK START: </b> " + Scheduler.Container.constants.fullDateTime(new Date(start)) + "</p>";
                            if (range.days() > 1)
                                content += "<p><b>WORK END: </b> " + Scheduler.Container.constants.fullDateTime(new Date(end));
                            else
                                content += "<p><b>DURATION: </b> " + range.durationToString();
                            var travel = this.getTravel() ? this.getTravel().duration : 0;
                            if (travel > 0) {
                                content += "     <b>TRAVEL: </b> " + Scheduler.TimeRange.convertDurationToString(travel);
                            }
                            content += "</p>";
                        }
                        else {
                            content += "<p><b>START: </b> " + Scheduler.Container.constants.fullDateTime(new Date(start)) + "</p>";
                            content += "<p><b>END: </b> " + Scheduler.Container.constants.fullDateTime(new Date(end)) + "</p>";
                        }
                        content += "</div>";
                    }
                    content += "</div>";
                    var tooltip = $(content);
                    var taskDimensions = this.getTaskBoxDimensions();
                    if (taskDimensions) {
                        //let isInUTRow: boolean = (this.containerView === TaskContainerView.IsInUndefinedTasksContainer);
                        tooltip.css("left", taskDimensions.x + "px");
                        tooltip.css("top", (taskDimensions.y + taskDimensions.height) + "px");
                    }
                    if (tooltip.insertAfter(this.ganttElement))
                        Task._tooltipOnTask = this;
                };
                Task.removeTooltip = function () {
                    var tooltip = this._tooltip();
                    if (tooltip)
                        tooltip.remove();
                    Task._tooltipOnTask = undefined;
                };
                Task._tooltip = function () {
                    var task = Task._tooltipOnTask;
                    if (task && task.container.viewCtrl)
                        return task.container.viewCtrl.element.find(".taskTooltip");
                    return undefined;
                };
                Task.prototype._addDoubleTapEventToTaskElement = function () {
                    var _this = this;
                    var taskBox = this.ganttElement;
                    if (taskBox) {
                        var draggableContainer_1 = this.container.draggableContainer;
                        if (Controls.GestureManager.pointerEventType !== Controls.PointerEventType.mouse) {
                            var taskboxHammer = new Hammer(taskBox.get(0));
                            taskboxHammer.on("doubletap", function (e) {
                                if (_this.container.loadingInProcess == false && !draggableContainer_1.moveManager.hasStateFlags(Scheduler.DragDropActions.DragRecognized)) {
                                    if (taskBox) {
                                        _this.container.onTaskDoubleClick.raise(new Scheduler.DoubleClickEventArgs(_this.id));
                                    }
                                }
                            });
                        }
                        else {
                            taskBox.on("dblclick", null, function (e) {
                                if (_this.container.loadingInProcess == false && !draggableContainer_1.moveManager.hasStateFlags(Scheduler.DragDropActions.DragRecognized)) {
                                    _this.container.onTaskDoubleClick.raise(new Scheduler.DoubleClickEventArgs(_this.id));
                                }
                            });
                        }
                    }
                };
                Task.prototype._updateTaskOnEditEvent = function () {
                    var _this = this;
                    var draggableContainer = this.container.draggableContainer;
                    var eventNameEnd = Controls.GestureManager.UP;
                    if (this.isEditable()) {
                        if (draggableContainer.isFocusedTask(this)) {
                            draggableContainer.setFocusToTask(this, true); // set this task (with the same id) that is appended to DOM to focusedTask what enable visually focus the correct task
                        }
                        if (this.ganttElement) {
                            this.ganttElement.off(eventNameEnd).on(eventNameEnd, null, function (e) {
                                if (!draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing)) {
                                    if (!draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.WasProcessed)) {
                                        draggableContainer.setFocusToTask(_this, false); // task got focus
                                    }
                                }
                            });
                        }
                    }
                    else {
                        if (draggableContainer.isFocusedTask(this))
                            draggableContainer.takeFocusFromFocusedTask();
                        if (this.ganttElement)
                            this.ganttElement.off(eventNameEnd);
                    }
                };
                Task.prototype.setFocus = function () {
                    if (this.ganttElement) {
                        this.ganttElement.addClass("focused");
                        this.ganttElement.find(".taskBoxDiv").css("outline-color", Scheduler.Container.inputs.scheduledTasks.focusedColor);
                        this._addEventTargetElement();
                    }
                };
                Task.prototype.takeFocus = function () {
                    if (this.ganttElement) {
                        this.ganttElement.removeClass("focused");
                        this.ganttElement.find(".taskBoxDiv").css("outline-color", "");
                        this._removeEventTargetElement();
                    }
                };
                Task.prototype._addEventTargetElement = function () {
                    if (this.ganttElement)
                        this.ganttElement.children(".taskBoxDiv").append("<div class='eventTargetElement'>");
                };
                Task.prototype._removeEventTargetElement = function () {
                    if (this.ganttElement)
                        this.ganttElement.find(".eventTargetElement").remove();
                };
                /**
                 * Returns distance in pixels between WorkStart (taskBoxDiv) and task box element.
                 */
                Task.prototype.getWorkStartXPosition = function () {
                    return this.ganttElement.children(".taskBoxDiv").position().left;
                };
                /**
                 * Handles operations that should be performed when task move started. Task box element is in the draggableContainer yet.
                 * @param owningResource Resource under which task box element is currently present.
                 * @param workStart Time in milliseconds when the work starts, given by move point position.
                 */
                Task.prototype.onDragStart = function (owningResource, workStart) {
                    var view = this.container.viewCtrl;
                    Task.removeTooltip();
                    if (this.getStatus().isUnscheduled()) {
                        var startTime = view.zoom.getVisibleTimeRange().start;
                        var duration = this.getTotalWorkTime();
                        this.setWorkStart(startTime);
                        this.setTotalWorkTime(duration);
                    }
                    if (this.isEditable() && !this.container.isLocked()) {
                        this.loadLinkedResources(function (error) { view.createCoverLayer(); });
                    }
                    this._createTextBoxElement(this.ganttElement.children(".taskBoxDiv")[0]);
                    this.container.viewCtrl.taskPopupMenu.close();
                };
                /**
                 * Handles operations that should be performed when task is moving. Task box element is in the draggableContainer.
                 * @param owningResource Resource under which task box element is currently present.
                 * @param workStart Time in milliseconds when the work starts, given by move point position.
                 */
                Task.prototype.onDragMove = function (owningResource, workStart) {
                    var view = this.container.viewCtrl;
                    var taskBox = this.ganttElement;
                    // update task text element and violations checking
                    var textBox = taskBox.find(".taskText");
                    var textBoxText = "";
                    var canReassign = false;
                    var workStartRounded;
                    if (!workStart) {
                        if (textBox)
                            textBoxText = Scheduler.StringTable.get("Err.TimesOutOfScope");
                    }
                    else {
                        var taskBoxDimensions = this.getTaskBoxDimensions(workStart);
                        if (!taskBoxDimensions)
                            return;
                        this.updateBoxElementContent(taskBoxDimensions, workStart, true);
                        workStartRounded = Scheduler.Container.roundTimeToMoveStep(workStart);
                        var newTaskSchedule = this.cloneTaskSchedule();
                        newTaskSchedule.setWorkStart(workStartRounded);
                        canReassign = this.canReassign(owningResource, newTaskSchedule.getStart(), newTaskSchedule.getEnd(), function (error) {
                            if (textBox)
                                textBoxText = error;
                        });
                    }
                    this._updateDeniedColor(!canReassign);
                    if (textBox) {
                        if (canReassign) {
                            textBox.removeClass("violation");
                        }
                        else {
                            textBox.addClass("violation");
                        }
                    }
                    if (textBox) {
                        if (!textBoxText)
                            textBoxText = this._dateMillisecondsToText(workStartRounded);
                        $("span", textBox).text(textBoxText);
                    }
                };
                Task.prototype.calculateOptimalPosition = function (onCalculated, task, startWorkTime, resource) {
                    var settings = this.container.settings.autoPlanner;
                    if (settings.manualScheduleMode == Scheduler.eMode.Manual || settings.manualScheduleMode == Scheduler.eMode.RouteOptimization) {
                        startWorkTime = Scheduler.Container.roundTimeToMoveStep(startWorkTime);
                        onCalculated(new Scheduler.AutoPlanner.TaskWrapper(true, task, resource, startWorkTime));
                    }
                    else
                        Scheduler.AutoPlanner.Core.optimizeManuallyDroppedTask(onCalculated, task, startWorkTime, resource);
                };
                /**
                 * Handles operations that should be performed when task move ended. Task box element is in the tasksContainer yet.
                 * @param owningResource Resource under which task box element is currently present.
                 * @param workStart Time in milliseconds when the work starts, given by move point position.
                 * @param onFinishCallback Is called when task handle operations have finished. If argument success is set to false task move will be reverted.
                 */
                Task.prototype.onDrop = function (owningResource, workStart, onFinishCallback) {
                    var _this = this;
                    var view = this.container.viewCtrl;
                    var textBox = this.ganttElement.find(".taskText");
                    if (textBox)
                        textBox.remove();
                    view.removeCoverLayer();
                    var workStartRounded = Scheduler.Container.roundTimeToMoveStep(workStart);
                    var newResource = !owningResource ? this.resource : owningResource;
                    if ((workStartRounded === null) || (!owningResource && this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.WasLeaved)) || (Scheduler.milisecondsToMinutes(this.getWorkStart()) === Scheduler.milisecondsToMinutes(workStartRounded) && newResource === this.resource))
                        onFinishCallback(false); // revertMove
                    else {
                        this.calculateOptimalPosition(function (result) {
                            if (result)
                                _this.tryReassign(result.getParent(), result.getWorkStart(), onFinishCallback);
                            else
                                onFinishCallback(false); // revertMove
                        }, this, workStartRounded, newResource);
                    }
                };
                /**
                 * Handles operations that should be performed when task move should be reverted.
                 */
                Task.prototype.onMoveRevert = function () {
                    if (this.isUnscheduledNew()) {
                        //if (this.group) { // Temporary disabled due to low perfomance of showing items on horizontal list. Method that supports it needs to be added to HTML advanced list.
                        //	let scrollPosition = this.container.horizontalListCtrl.getScrollPosition();
                        //	this.container.dataProvider.showUnscheduledTasksEntities([this.group.id], true, () => {
                        //		this.container.revertSelectedItem();
                        //		if ((scrollPosition !== undefined) && (scrollPosition !== null))
                        //			this.container.horizontalListCtrl.setScrollPosition(scrollPosition);
                        //	});
                        //}
                        this.container.revertSelectedItem(); // Temporary added because above code was disabled and thus it does not call this method asynchronous more.
                        this.container.removeTask(this);
                    }
                    else {
                        var taskBox = this.ganttElement;
                        if (taskBox) {
                            var taskBoxDimensions = this.getTaskBoxDimensions();
                            if (taskBoxDimensions) {
                                this.updateBoxElementContent(taskBoxDimensions);
                            }
                        }
                    }
                };
                Task.prototype._createTextBoxElement = function (parentElement) {
                    var textBox = Scheduler.Utilities.createNewHTMLElement("div", "taskText" + this.id, null, ["taskText"]);
                    var span = Scheduler.Utilities.createNewHTMLElement("span");
                    textBox.appendChild(span);
                    parentElement.appendChild(textBox);
                };
                Task.prototype._dateMillisecondsToText = function (dateMilliseconds) {
                    if (!dateMilliseconds)
                        return "";
                    var date = new Date(dateMilliseconds);
                    var options = { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" };
                    return date.toLocaleString([], options);
                };
                Task.prototype._updateDeniedColor = function (isDenied) {
                    if (this.ganttElement) {
                        this.ganttElement.find(".taskStatusColor").css("background-color", isDenied ? Scheduler.Container.inputs.scheduledTasks.deniedColor : this.getStatus().color());
                        this.ganttElement.find(".taskText").css("color", isDenied ? Scheduler.Container.inputs.scheduledTasks.deniedColor : "rgb(0, 0, 0)");
                    }
                };
                /**
                 * Update size of taskBox container and its inner html elements.
                 * @param taskBoxDimensions
                 */
                Task.prototype.updateTaskBoxSize = function (taskBoxDimensions) {
                    this.ganttElement.css("width", taskBoxDimensions.width + "px");
                    this.ganttElement.children(".taskTravelTo").css("width", taskBoxDimensions.travelToWidth + "px");
                    this.ganttElement.children(".taskTravelFrom").css("width", taskBoxDimensions.travelFromWidth + "px");
                    this.ganttElement.children(".taskBoxDiv").css("width", (taskBoxDimensions.width - taskBoxDimensions.travelFromWidth - taskBoxDimensions.travelToWidth) + "px");
                };
                /**
                 * Update size of taskBox container and its inner html elements. Replace elements if it is necessary, when task become displayed as splitted or as normal.
                 * @param taskBoxDimensions
                 */
                Task.prototype.updateBoxElementContent = function (taskBoxDimensions, workStart, doNotCreateIfNotNecessary) {
                    this.updateTaskBoxSize(taskBoxDimensions);
                    var newTaskSchedule = this.cloneTaskSchedule();
                    if (workStart)
                        newTaskSchedule.setWorkStart(workStart);
                    newTaskSchedule.createContent(this, this.ganttElement.find(".taskBoxDivContent")[0], doNotCreateIfNotNecessary);
                };
                Task.prototype.setAsCompleted = function () {
                    this._setStatusAs(Scheduler.TaskStatusType.Completed);
                };
                Task.prototype.setAsCanceled = function () {
                    this._setStatusAs(Scheduler.TaskStatusType.Canceled);
                };
                Task.prototype._setStatusAs = function (taskStatusType) {
                    if (Scheduler.Container.statusCodeTable.isSupported(taskStatusType)) {
                        var taskChanges = {};
                        taskChanges["id"] = this.id;
                        taskChanges["statuscode"] = Scheduler.Container.statusCodeTable.primaryStatuses[taskStatusType].value();
                        this.container.saveTask(this, taskChanges).catch(function (error) {
                            Scheduler.StringTable.alert(error);
                        });
                    }
                };
                Task.isElementOfFocusedTask = function (element) {
                    return $(element).closest(".taskBoxWrapper.focused").length > 0;
                };
                Task.getIdFromChildElement = function (element) {
                    var taskElement = $(element).closest(".taskBoxWrapper");
                    if (taskElement.length > 0)
                        return taskElement.attr("data-taskid");
                    return null;
                };
                return Task;
            }(TaskSchedule));
            Task.internalProperties = ["ganttElement", "container", "resource"];
            Scheduler.Task = Task;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
