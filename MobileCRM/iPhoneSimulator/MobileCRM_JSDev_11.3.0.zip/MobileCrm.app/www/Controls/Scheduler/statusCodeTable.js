///<reference path="interfaces.ts" />
///<reference path="enums.ts" />
///<reference path="constants.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var Status = (function () {
                function Status(value, name, localizationKey, taskStatusType, color, progressColor, textColor, borderColor, borderWidth, borderRadius) {
                    this._value = value;
                    this._name = name || "";
                    this._localizationKey = localizationKey || "";
                    this._taskStatusType = +taskStatusType;
                    this._color = color || "";
                    this._progressColor = progressColor || "";
                    if (!this._progressColor && this.hasProgress())
                        this._progressColor = Scheduler.ColorCache.tryGetRelatedColor(this._color);
                    this._defaultCSS = "";
                    this._pastTaskCSS = "";
                    this._defaultCSS += "background-color:" + color + "; ";
                    this._pastTaskCSS += "background-color:" + Scheduler.ColorCache.applyColorAlpha(color, 0.3) + "; ";
                    if (textColor) {
                        this._defaultCSS += "color:" + textColor + "; ";
                        this._pastTaskCSS += "color:" + textColor + "; ";
                    }
                    if (borderWidth) {
                        if (!borderColor)
                            borderColor = "rgb(90,90,90)";
                        this._defaultCSS += "border-style:solid; ";
                        this._pastTaskCSS += "border-style:solid; ";
                        this._defaultCSS += "border-color:" + borderColor + "; ";
                        this._pastTaskCSS += "border-color:" + Scheduler.ColorCache.applyColorAlpha(borderColor, 0.3) + "; ";
                        this._defaultCSS += "border-width:" + borderWidth + "px; ";
                        this._pastTaskCSS += "border-width:" + borderWidth + "px; ";
                    }
                    if (borderRadius) {
                        this._defaultCSS += "border-radius:" + borderRadius + "px; ";
                        this._pastTaskCSS += "border-radius:" + borderRadius + "px; ";
                    }
                }
                Status.prototype.value = function () {
                    return this._value;
                };
                Status.prototype.name = function () {
                    return this._name;
                };
                Status.prototype.localizationKey = function () {
                    return this._localizationKey;
                };
                Status.prototype.taskStatusType = function () {
                    return this._taskStatusType;
                };
                Status.prototype.setElementCSS = function (element, type) {
                    element.setAttribute('style', type == Scheduler.StatusCSS.PastTask ? this._pastTaskCSS : this._defaultCSS);
                };
                Status.prototype.color = function () {
                    return this._color;
                };
                Status.prototype.progressColor = function () {
                    return this._progressColor;
                };
                Status.prototype.isUnscheduled = function () {
                    return this._taskStatusType === Scheduler.TaskStatusType.Unscheduled; // JC: !!!Do not change this condition without complete verification/rewriting of the scheduler status behavior!!!
                };
                Status.prototype.isEditable = function () {
                    return this._taskStatusType <= Scheduler.TaskStatusType.Scheduled; // JC: !!!Do not change this condition without complete verification/rewriting of the scheduler status behavior!!!
                };
                Status.prototype.isFinished = function () {
                    return this._taskStatusType >= Scheduler.TaskStatusType.Completed; // JC: !!!Do not change this condition without complete verification/rewriting of the scheduler status behavior!!!
                };
                Status.prototype.canBeRescheduled = function () {
                    return this._taskStatusType === Scheduler.TaskStatusType.Scheduled; // JC: !!!Do not change this condition without complete verification/rewriting of the scheduler status behavior!!!
                };
                Status.prototype.hasProgress = function () {
                    return (this._taskStatusType > Scheduler.TaskStatusType.Scheduled) && (this._taskStatusType < Scheduler.TaskStatusType.Canceled) && (this._taskStatusType != Scheduler.TaskStatusType.TimeOff); // JC: !!!Do not change this condition without complete verification/rewriting of the scheduler status behavior!!!
                };
                return Status;
            }());
            Scheduler.Status = Status;
            var StatusCodeTable = (function () {
                function StatusCodeTable(input) {
                    this.codeByNameDictionary = {}; // array of statuses of individual taskStatusType types that are used to back conversion. If are not provided by customization, the first custom status from each taskStatusType set is chosen.
                    this.codeByValueDictionary = {}; // array of statuses of individual taskStatusType types that are used to back conversion. If are not provided by customization, the first custom status from each taskStatusType set is chosen.
                    var statusCodeList = input.statusList;
                    var borderWidth = input.scheduledTasks.borderWidth;
                    var borderRadius = input.scheduledTasks.borderRadius;
                    this.statusList = [];
                    this.primaryStatuses = [
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null
                    ]; //TaskStatusType.Canceled
                    if (borderWidth === undefined)
                        borderWidth = 1;
                    if (borderRadius === undefined)
                        borderRadius = 0;
                    if (statusCodeList) {
                        for (var i = 0; i < statusCodeList.length; i++) {
                            var code = statusCodeList[i];
                            var status_1 = new Status(code.value, code.name, code.localizationKey, code.taskStatusType, code.color, code.progressColor, code.textColor, code.borderColor, borderWidth, borderRadius);
                            this.statusList.push(status_1);
                            this.codeByNameDictionary[status_1.name()] = status_1;
                            this.codeByValueDictionary[status_1.value()] = status_1;
                            if (status_1.taskStatusType() >= Scheduler.TaskStatusType.Unscheduled && status_1.taskStatusType() <= Scheduler.TaskStatusType.Canceled && (!code.isSecondaryValue || !this.primaryStatuses[status_1.taskStatusType()]))
                                this.primaryStatuses[status_1.taskStatusType()] = status_1;
                        }
                    }
                    if (input.timeOffSchedules) {
                        var tfInput = input.timeOffSchedules;
                        var color = tfInput.color || "rgb(160,160,160)";
                        var textColor = tfInput.textColor || "white";
                        var borderColor = tfInput.borderColor || "rgb(90,90,90)";
                        var status_2 = new Status(-1, "TimeOff", "Scheduler.WOS.statuscode.5", Scheduler.TaskStatusType.TimeOff, color, color, textColor, borderColor, borderWidth, borderRadius);
                        this.statusList.push(status_2);
                        if (!this.primaryStatuses[Scheduler.TaskStatusType.TimeOff])
                            this.primaryStatuses[Scheduler.TaskStatusType.TimeOff] = status_2;
                    }
                }
                StatusCodeTable.prototype.isSupported = function (taskStatusType) {
                    return this.primaryStatuses[taskStatusType] != null;
                };
                StatusCodeTable.prototype.getStatusByName = function (name) {
                    return this.codeByNameDictionary[name];
                    //for (let i = 0; i < this.statusList.length; i++) {
                    //	let status: IStatus = this.statusList[i];
                    //	if (status.name() === name)
                    //		return status;
                    //}
                    //return null;
                };
                StatusCodeTable.prototype.getStatusByValue = function (value) {
                    return this.codeByValueDictionary[value];
                    //for (let i = 0; i < this.statusList.length; i++) {
                    //	let status: IStatus = this.statusList[i];
                    //	if (status.value() === value)
                    //		return status;
                    //}
                    //return null;
                };
                StatusCodeTable.prototype.getSupportedStatusesValues = function () {
                    var statusesValues = [];
                    for (var i = 0; i < this.statusList.length; i++) {
                        var status_3 = this.statusList[i];
                        if (this.primaryStatuses[status_3.taskStatusType()] != null)
                            statusesValues.push(status_3.value());
                    }
                    return statusesValues;
                };
                StatusCodeTable.prototype.getUnscheduledStatusesValues = function () {
                    var statusesValues = [];
                    for (var i = 0; i < this.statusList.length; i++) {
                        var status_4 = this.statusList[i];
                        if (status_4.isUnscheduled())
                            statusesValues.push(status_4.value());
                    }
                    return statusesValues;
                };
                StatusCodeTable.prototype.getFinishedStatusesValues = function () {
                    var statusesValues = [];
                    for (var i = 0; i < this.statusList.length; i++) {
                        var status_5 = this.statusList[i];
                        if (status_5.isFinished())
                            statusesValues.push(status_5.value());
                    }
                    return statusesValues;
                };
                /**
                 * Returns value (in array) of all custom statuses that have their taskStatusType equal with type given by taskStatusType argument.
                 * @param taskStatusType type to match custom statuses.
                 */
                StatusCodeTable.prototype.getAllStatusesValuesOfType = function (taskStatusType) {
                    var statusesValues = [];
                    for (var i = 0; i < this.statusList.length; i++) {
                        var status_6 = this.statusList[i];
                        if (status_6.taskStatusType() === taskStatusType)
                            statusesValues.push(status_6.value());
                    }
                    return statusesValues;
                };
                /**
                 * Returns primary status of TaskStatusType.Scheduled type, if any custom state of TaskStatusType.Scheduled type is provided by statusCodeTable.
                 * Otherwise returns primary status of TaskStatusType.Confirmed type, if any custom state of TaskStatusType.Confirmed type is provided by statusCodeTable.
                 * Otherwise returns null.
                 */
                StatusCodeTable.prototype.getScheduledOrConfirmedStatusIfExist = function () {
                    if (this.isSupported(Scheduler.TaskStatusType.Scheduled))
                        return this.primaryStatuses[Scheduler.TaskStatusType.Scheduled];
                    else if (this.isSupported(Scheduler.TaskStatusType.Confirmed))
                        return this.primaryStatuses[Scheduler.TaskStatusType.Confirmed];
                    return null;
                };
                return StatusCodeTable;
            }());
            Scheduler.StatusCodeTable = StatusCodeTable;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
