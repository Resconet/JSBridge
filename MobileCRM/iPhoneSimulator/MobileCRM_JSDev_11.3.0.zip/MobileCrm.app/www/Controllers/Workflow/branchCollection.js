/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="stepCollection.ts" />
/// <reference path="step.ts" />
/// <reference path="branch.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var BranchCollection = (function (_super) {
                __extends(BranchCollection, _super);
                function BranchCollection() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                BranchCollection.prototype._getName = function () {
                    return "BranchCollection";
                };
                BranchCollection.deserializeXML = function ($step) {
                    var s = new BranchCollection();
                    s._deserializeXML($step);
                    return s;
                };
                BranchCollection.prototype.decode = function (steps) {
                    this.steps.forEach(function (branch) { return branch.decode(steps); });
                    var ip = steps.length;
                    this.steps.forEach(function (branch) { return branch.jumpEnd.fixupOffset(ip); });
                };
                return BranchCollection;
            }(Workflow.StepCollection));
            Workflow.BranchCollection = BranchCollection;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
