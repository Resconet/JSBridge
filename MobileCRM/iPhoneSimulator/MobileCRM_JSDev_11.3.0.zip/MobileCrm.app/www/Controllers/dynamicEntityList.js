/// <reference path="../Controls/IView.ts" />
/// <reference path="../Data/metaData.ts"/>
/// <reference path="../Data/fetch.ts"/>
/// <reference path="../Data/dynamicEntity.ts"/>
/// <reference path="listController.ts"/>
/// <reference path="entityList.ts"/>
/// <reference path="listTemplateManager.ts"/>
/// <reference path="Workflow/engine.ts"/>
/// <reference path="Workflow/executionContext.ts"/>
/// <reference path="Workflow/variable.ts"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var DynamicEntityList = (function (_super) {
            __extends(DynamicEntityList, _super);
            function DynamicEntityList(nativeType) {
                return _super.call(this, nativeType ? nativeType : DynamicEntityList) || this;
            }
            DynamicEntityList.prototype.setView = function (listView, mode) {
                if (this.m_listView) {
                    this.m_listView.templateSelector = null;
                }
                this._setListView(mode != MobileCrm.UI.ViewMode.Lookup, listView);
                this.m_listView = listView;
                if (this.m_listView) {
                    this.m_listView.imageLoader = MobileCrm.UI.ListController.loadCellImage;
                    this.m_currentView = null;
                    this.loadConfiguration(mode);
                    //if (this.m_listView.filterGroup() == null && this.filterGroup != null) {
                    //   this.m_listView.filterGroup(this.filterGroup);
                    //}
                    //TODO: this._loadSaveFilter(false);
                }
            };
            DynamicEntityList.prototype.onButtonClick = function (view, buttonName, entity, row) {
                if (buttonName == "Call") {
                }
                else if (buttonName == "Email") {
                }
                else if (buttonName == "SMS") {
                }
                else if (buttonName.startsWith("Create.")) {
                    //var pp = buttonName.split(".");
                    //if (pp.length > 1) {
                    //    var rel: MobileCrm.Data.Relationship = null;
                    //    var entityName = pp[1];
                    //    if (pp.length > 2) {
                    //        rel = new MobileCrm.Data.Relationship(pp[2]);
                    //        rel.target = entity;
                    //    }
                    //    this._createNewEntity(entityName, rel, null);
                    //}
                }
                else if (buttonName.startsWith("Open.")) {
                    var pp = buttonName.split(".");
                    if (pp.length > 2) {
                        //var relatedEntity = <MobileCrm.Data.IReference>entity.tryGetValue(pp[2]).value;
                        //if (relatedEntity && ControllerFactory.instance.hasDetail(relatedEntity.entityName)) {
                        //    this._showEntityDialog(relatedEntity);
                        //}
                    }
                }
                _super.prototype.onButtonClick.call(this, view, buttonName, entity, row);
            };
            DynamicEntityList.prototype.reload = function () {
                this._loadTemplateAndQuery();
                this.m_listView.dataSource = this._loadDataSource();
            };
            DynamicEntityList.prototype.update = function () {
                this.m_listView.updateList();
            };
            DynamicEntityList.prototype._loadTemplateAndQuery = function () {
                var currentView = MobileCrm.UI.EntityList.DefaultViewName;
                var viewFilter = this.viewFilter;
                if (viewFilter) {
                    currentView = (viewFilter.selectedValue);
                }
                if (currentView != this.m_currentView) {
                    var view = this.m_listView;
                    if (viewFilter) {
                        if (view) {
                            this._clearListView(view);
                        }
                        this._loadView(currentView, false);
                    }
                    this.m_currentView = currentView;
                    if (view) {
                        this._prepareListView(view, this.viewFilter);
                    }
                }
            };
            DynamicEntityList.prototype._clearListView = function (view) {
                view.setFilterText("", false);
                view.dataSource = null;
                view.clearTemplates();
            };
            DynamicEntityList.prototype._prepareListView = function (view, viewFilter) {
                this._updateViewLabel(view, viewFilter);
                this._setupListRowWorkflow(view, this.m_templateSelector);
                this.setupTemplates(this.m_listView, this._getButtonsForViewMode(this.listMode));
            };
            DynamicEntityList.prototype._updateViewLabel = function (view, filter) {
                var viewLabel = "";
                if (filter && filter.values.length > 1 && filter.values[1].value != "AdvancedFindPlaceHolder") {
                    viewLabel = filter.selectedText;
                }
                else if (this.listMode == MobileCrm.UI.ViewMode.Dashboard) {
                    viewLabel = view.caption();
                }
                view.caption(viewLabel);
                view.emptyFilterText("Search " + viewLabel + "..."); // TODO: Localize: (MobileCrm.Localization.instance.format("FmtSearch", viewLabel));
            };
            Object.defineProperty(DynamicEntityList.prototype, "viewFilter", {
                get: function () {
                    if (this.filterGroup) {
                        return this.filterGroup.getFilter("View");
                    }
                    return null;
                },
                enumerable: true,
                configurable: true
            });
            DynamicEntityList.prototype.openConfiguration = function (viewName, isPrivate) {
                if (viewName && viewName == "@@FallbackView") {
                    return this._openFallbackConfiguration();
                }
                else if (isPrivate) {
                    // TODO: call _openUIConfig with special string (name of the private view?)
                }
                var reader = this._openUIConfig("Controllers\\" + this.entityName + ".list");
                if (reader == null) {
                    reader = this._openFallbackConfiguration();
                }
                return reader;
            };
            DynamicEntityList.prototype._openUIConfig = function (uiPath) {
                if (this.getUIConfig) {
                    var lines = this.getUIConfig.call(this.getUIConfigScope ? this.getUIConfigScope : this, uiPath);
                    return new Resco.TextReader(lines);
                }
                // TODO: Configuration: return MobileCrm.Configuration.instance.openUIConfig(uiPath);
                return new Resco.TextReader([]);
            };
            DynamicEntityList.prototype._openFallbackConfiguration = function () {
                var fetchStr = "<fetch></fetch>";
                var metaEntity = MobileCrm.Data.MetaData.instance.tryGetEntity(this.entityName);
                if (metaEntity) {
                    var fetch = new MobileCrm.Data.Fetch.Fetch(metaEntity, metaEntity.name);
                    fetch.entity.addAttribute(metaEntity.primaryKeyName, false);
                    fetch.entity.addAttribute(metaEntity.primaryFieldName, false);
                    fetch.entity.orderBy(metaEntity.primaryFieldName, false);
                    fetchStr = fetch.serializeXML();
                }
                var fallbackCfg = ["V2",
                    "@@FallbackView",
                    "1",
                    fetchStr,
                    "T;;240;40",
                    "S;PrimaryName;0;Primary;10;8;220;36;13",
                    ""];
                return new Resco.TextReader(fallbackCfg);
            };
            DynamicEntityList.prototype.parseViews = function (views, listMode) {
                var initialView = null;
                var reader = this.openConfiguration();
                if (reader) {
                    var line = reader.readLine();
                    if (ViewParser.TryParseVersion(line) >= 2) {
                        var loadMask = (1 << listMode) | (1 << MobileCrm.UI.ViewMode.Default);
                        var loadAll = this.allowedViews == null || this.allowedViews.length == 0 || this.allowedViews.containsKey("*");
                        while (line != null) {
                            if (ViewParser.TryParseVersion(line) >= 2) {
                                var viewName = reader.readLine();
                                var viewMode = parseInt(reader.readLine());
                                if ((viewMode & (UI.ViewOptions.OnlineOnly | UI.ViewOptions.OfflineOnly)) != 0) {
                                    // TODO: Configuration
                                    //if (MobileCrm.Configuration.instance.isOnline != ((viewMode & ViewOptions.OnlineOnly) != 0)) {
                                    //    line = reader.readLine();
                                    //    continue;
                                    //}
                                }
                                if ((viewMode & loadMask) != 0) {
                                    var isHidden = ((viewMode & UI.ViewOptions.IsHidden) != 0);
                                    if ((loadAll && !isHidden) || (this.allowedViews != null && this.allowedViews.containsKey(viewName))) {
                                        this._addViewToList(views, this.entityName, viewName);
                                        if ((viewMode & UI.ViewOptions.HasGPS) != 0) {
                                            this.hasMapViews = true;
                                        }
                                    }
                                }
                            }
                            line = reader.readLine();
                        }
                        if (views.length == 0) {
                            this._addViewToList(views, this.entityName, "@@FallbackView");
                        }
                        var init;
                        if (this.initialView) {
                            for (var i = 0; i < views.length; i++) {
                                if (views[i].value == this.initialView) {
                                    initialView = this.initialView;
                                    break;
                                }
                            }
                        }
                        if (!initialView && views.length > 0) {
                            initialView = views[0].value;
                        }
                        return { result: true, initialView: initialView };
                    }
                    else if (line == "V1") {
                        return { result: false, initialView: initialView };
                    }
                    else {
                        throw "Invalid list templates file format";
                    }
                }
            };
            DynamicEntityList.prototype.handleParseViews = function (context, consumer, consumerOwner) {
                var reader = this.openConfiguration();
                return ViewParser.parseViews(reader, context, consumer, consumerOwner);
            };
            DynamicEntityList.prototype._addViewToList = function (views, entityName, viewName) {
                var viewLabel = viewName;
                if (viewName == "@@FallbackView") {
                    viewLabel = MobileCrm.UI.EntityList.DefaultViewName;
                }
                views.push(new Resco.KeyValuePair(viewLabel /* TODO: Localize: MobileCrm.Localization.instance.getComponentLabel(entityName, "View", viewLabel)*/, viewName));
            };
            DynamicEntityList.prototype.loadConfiguration = function (mode) {
                this.listMode = mode;
                var views = new Array();
                var parseResult = this.parseViews(views, this.listMode);
                if (!parseResult || !parseResult.result) {
                    // load configuration V1
                }
                if (views.length < 2 && this.listMode != MobileCrm.UI.ViewMode.Default) {
                    this._loadView(parseResult.initialView, false);
                    if (this.listMode == MobileCrm.UI.ViewMode.Dashboard) {
                        this.listView.caption(parseResult.initialView /* TODO: Localize: MobileCrm.Localization.instance.getComponentLabel(this.entityName, "View", parseResult.initialView)*/);
                    }
                }
                else {
                    views.sort(function (a, b) { return a.key.localeCompare(b.key); });
                    var viewItem = new Resco.UI.FilterItem("View", "View", views);
                    for (var i = 0; i < views.length; i++) {
                        if (views[i].value == parseResult.initialView) {
                            viewItem.selectedIndex(i);
                            break;
                        }
                    }
                    this.filterGroup = new Resco.UI.FilterGroup();
                    this.filterGroup.filters.push(viewItem);
                    // TODO: advancedfind
                }
            };
            DynamicEntityList.prototype.selectView = function (viewName) {
                var viewFilter = this.viewFilter;
                var view = this.m_listView;
                if (viewFilter) {
                    if (view)
                        this._clearListView(view);
                    this._loadView(viewName, false);
                    viewFilter.selectedValue = viewName;
                }
                this.m_currentView = viewName;
                if (view)
                    this._prepareListView(view, this.viewFilter);
            };
            DynamicEntityList.prototype._loadView = function (viewName, isPrivate) {
                var reader = this.openConfiguration(viewName, isPrivate);
                var result;
                while ((result = ViewParser.ReadView(reader)) != null) {
                    var loadMask = (1 << this.listMode) | (1 << MobileCrm.UI.ViewMode.Default);
                    if ((result.mode & loadMask) != 0 && result.name == viewName) {
                        this._loadViewInternal(reader, result.mode, result.version);
                        break;
                    }
                }
            };
            DynamicEntityList.prototype._loadViewInternal = function (reader, mode, version) {
                this.m_templateSelector = null;
                this.m_multiSelectCommands = null;
                // TODO:
                //foreach(var button in m_searchButtons)
                //	button.AllowedFields = null;
                if (version >= 7) {
                    this.m_multiSelectCommands = reader.readLine();
                    reader.readLine(); // Execute Rule
                    reader.readLine(); // CanExecute Rule
                }
                if (version >= 6) {
                    /*m_searchButtons[1].AllowedFields =*/ reader.readLine(); // TODO: Sort - not implemented yet
                    /*m_searchButtons[0].AllowedFields =*/ reader.readLine(); // TODO: Filter - not implemented yet
                }
                if (version >= 5) {
                    this.m_templateSelector = reader.readLine();
                }
                if (version >= 4) {
                    this._loadViewButtons(reader.readLine());
                }
                this.m_repositoryConfig = reader.readLine();
                this.rowTemplates = new Array();
                MobileCrm.UI.ListTemplateManager.Deserialize(this.rowTemplates, reader, false);
                //TODO: applysyncfilter
            };
            DynamicEntityList.prototype._applyMergedFilter = function () {
                if (this.mergedFilter) {
                    var fetch = MobileCrm.Data.Fetch.Fetch.deserializeJSON(this.m_repositoryConfig);
                    var merged = MobileCrm.Data.Fetch.Fetch.deserializeJSON(this.mergedFilter);
                    fetch.mergeFilter(merged);
                    //this.m_repositoryConfig = fetch.serializeJSON();
                }
            };
            DynamicEntityList.prototype._loadViewButtons = function (buttons) {
                if (buttons && this.hasButtons) {
                    if (buttons == "none") {
                        this.listButtons.push("More");
                    }
                    else {
                        // if entity has detail: ControllerFactory.Instance.HasDetail(this.entityName)
                        buttons += ";More";
                        this.listButtons = buttons.split(";");
                    }
                }
            };
            DynamicEntityList.prototype._getDataSourceEnumerator = function () {
                if (this.getDataSourceEnumerator) {
                    var fetch = this.prepareQuery(this.m_listView.filterText);
                    return this.getDataSourceEnumerator(fetch);
                }
                // TODO: Repository
                //var repository = this._loadRepository(this.m_listView);
                // new MobileCrm.UI.OnlineEntityQuery<TEntity>(repository);
                return null;
            };
            DynamicEntityList.prototype._loadDataSource = function () {
                // todo: this.loadSaveFilter(true)
                //var repository = this._loadRepository(this.m_listView);
                // new MobileCrm.UI.OnlineEntityQuery<TEntity>(repository);
                return this._getDataSourceEnumerator();
            };
            DynamicEntityList.prototype._loadRepository = function (view) {
                //var fetch = this.prepareQuery(view.filterText);
                //return new MobileCrm.Data.DynamicRepository(fetch, "", MobileCrm.Data.DynamicEntity, true);
            };
            DynamicEntityList.prototype.loadDataQuery = function (filterText) {
                this._loadTemplateAndQuery();
                return this.prepareQuery(filterText);
            };
            DynamicEntityList.prototype.prepareQuery = function (filterText) {
                var fetch = MobileCrm.Data.Fetch.Fetch.deserializeJSON(this.m_repositoryConfig);
                this._customizeQuery(filterText, fetch);
                return fetch;
            };
            DynamicEntityList.prototype._customizeQuery = function (filterText, fetch) {
                if (!fetch) {
                    return;
                }
                this._applySearchText(fetch, filterText);
                //if (this.relationship && this.relationship.target) {
                //    this._applyMacrosEntity(fetch.entity, this._asDynamicEntity(this.relationship.target));
                //    var entity = fetch.entity;
                //    if (this.relationship.intersectEntity) {
                //        var c = fetch.entity.meta.primaryKeyName;
                //        entity = entity.addLink(this.relationship.intersectEntity, this.relationship.intersectProperty, c, "inner");
                //    }
                //    if (this.relationship.sourceProperty != "@virtual") {
                //        entity.filter.where(this.relationship.sourceProperty, this.relationship.target.id);
                //    }
                //}
                //var macroTarget: MobileCrm.Data.DynamicEntity = null;
                //if (this.lookupSource) {
                //    macroTarget = this._asDynamicEntity(this.lookupSource.target);
                //}
                //else if (this.relationship) {
                //    macroTarget = this._asDynamicEntity(this.relationship.target);
                //}
                //if (macroTarget) {
                //    this._applyMacrosEntity(fetch.entity, macroTarget);
                //}
            };
            //private _asDynamicEntity(ref: MobileCrm.Data.IReference): MobileCrm.Data.DynamicEntity {
            //    if (ref instanceof MobileCrm.Data.DynamicEntity) {
            //        return <MobileCrm.Data.DynamicEntity>ref;
            //    }
            //    return null;
            //}
            //private _asIReference(value: any): MobileCrm.Data.IReference {
            //    if (value instanceof MobileCrm.Data.AbstractEntity || value instanceof MobileCrm.Data.Reference) {
            //        return <MobileCrm.Data.IReference>value;
            //    }
            //    return null;
            //}
            DynamicEntityList.prototype._applySearchText = function (fetch, filterText) {
                if (fetch && !fetch.entity.applySearchText(filterText)) {
                    var primaryName = fetch.entity.meta.primaryFieldName;
                    if (primaryName) {
                        fetch.entity.filter.startsWith(primaryName, filterText);
                    }
                }
            };
            DynamicEntityList.prototype._applyMacrosEntity = function (entity, related /*MobileCrm.Data.DynamicEntity*/) {
                var _this = this;
                this._applyMacrosFilter(entity.filter, related);
                if (entity.links) {
                    entity.links.forEach(function (e) {
                        _this._applyMacrosEntity(e, related);
                    }, this);
                }
            };
            DynamicEntityList.prototype._applyMacrosFilter = function (filter, related /*MobileCrm.Data.DynamicEntity*/) {
                var _this = this;
                if (filter.conditions) {
                    filter.conditions.forEach(function (c) {
                        _this._updateValue(c, related);
                    }, this);
                }
                if (filter.filters) {
                    filter.filters.forEach(function (f) {
                        _this._applyMacrosFilter(f, related);
                    }, this);
                }
            };
            DynamicEntityList.prototype._updateValue = function (c, related /*MobileCrm.Data.DynamicEntity*/) {
                // TODO: rewrite to typescript
                if (c.value) {
                    var v = Resco.asString(c.value);
                    if (v != null) {
                        var b = v.indexOf("{{");
                        var e = v.indexOf("}}");
                        if (b >= 0 && e > b) {
                            var value = null;
                            var propertyName = v.substr(b + 2, e - b - 2);
                            if (propertyName == "self") {
                                value = related.id;
                            }
                            else {
                                var retVal = related.tryGetValue(propertyName);
                                if (retVal.result) {
                                    value = retVal.value;
                                }
                            }
                            if (value) {
                                var r = value; // this._asIReference(value);
                                if (r) {
                                    value = r.id;
                                }
                                if (b > 0 || e + 2 != v.length) {
                                    var sb = v.substr(0, b);
                                    sb += value;
                                    sb += v.substring(e + 2 - b, v.length - 1);
                                    value = sb;
                                }
                            }
                            c.value = value;
                            if (!value) {
                                c.operator = "null";
                            }
                        }
                    }
                }
            };
            DynamicEntityList.prototype._setupListRowWorkflow = function (view, templateSelector) {
                this.m_templateSelector = templateSelector;
                if (templateSelector) {
                    view.templateSelector = this.selectTemplateWorkflow;
                    view.templateSelectorOwner = this;
                }
                else {
                    view.templateSelector = null;
                }
            };
            // TODO: Workflow
            DynamicEntityList.prototype.selectTemplateWorkflow = function (rowData, selected) {
                var result = selected ? 1 : 0;
                var entity = MobileCrm.Data.DynamicEntity.as(rowData);
                if (this.m_templateSelector) {
                    var resultVar;
                    if (!this.m_selectorVars) {
                        resultVar = new UI.Workflow.SimpleVariable("TemplateIndex", MobileCrm.Data.CrmType.Integer, 0);
                        this.m_selectorVars = new Resco.Dictionary();
                        this.m_selectorVars.set("Entity", new UI.Workflow.EntityVariable(entity));
                        this.m_selectorVars.set("TemplateIndex", resultVar);
                    }
                    else {
                        this.m_selectorVars.getValue("Entity").entity = entity;
                        resultVar = this.m_selectorVars.getValue("TemplateIndex");
                        resultVar.value = 0;
                    }
                    var r = UI.Workflow.Engine.setup(this.m_templateSelector, entity.entityName, this.m_selectorVars);
                    if (r.context) {
                        if (r.context.execute()) {
                            if (r.context.tempVariable.length > 0) {
                                r.context.tempVariable.getValues().forEach(function (v) {
                                    var tmp = UI.Workflow.TemporaryVariable.as(v);
                                    if (tmp) {
                                        // TODO: CustomProperties
                                        //entity.addCustomProperty(null, tmp.name, tmp.value, tmp.type);
                                    }
                                }, this);
                            }
                            result = (resultVar.value * 2) + (selected ? 1 : 0);
                        }
                    }
                }
                return result;
            };
            return DynamicEntityList;
        }(MobileCrm.UI.EntityList));
        UI.DynamicEntityList = DynamicEntityList;
        var ViewParser = (function () {
            function ViewParser() {
            }
            ViewParser.ReadView = function (reader) {
                var mode = 0;
                var version = 0;
                var line;
                while ((line = reader.readLine()) != null) {
                    version = ViewParser.TryParseVersion(line);
                    if (version >= 2) {
                        line = reader.readLine();
                        mode = parseInt(reader.readLine());
                        return { name: line, mode: mode, version: version };
                    }
                }
                return null;
            };
            ViewParser.TryParseVersion = function (line) {
                if (line.length == 2 && line[0] == 'V') {
                    return parseInt(line[1]);
                }
                return 0;
            };
            ViewParser.parseViews = function (reader, context, consumer, consumerOwner) {
                var result;
                while ((result = ViewParser.ReadView(reader)) != null) {
                    if (consumer.call(consumerOwner ? consumerOwner : this, context, result.name, result.mode, result.version, reader)) {
                        return true;
                    }
                }
                return false;
            };
            ViewParser.readView = function (reader) {
                var kind = 0;
                var version = 0;
                var line;
                while ((line = reader.readLine()) != null) {
                    version = ViewParser.TryParseVersion(line);
                    if (version >= 2) {
                        line = reader.readLine();
                        kind = Resco.strictParseInt(reader.readLine());
                        return { name: line, kind: kind, version: version };
                    }
                }
                return null;
            };
            ViewParser.loadViewDefinition = function (reader, entityName, loadMask, viewName, views) {
                var result = null;
                while ((result = ViewParser.readView(reader)) != null) {
                    var kind = result.kind;
                    var version = result.version;
                    var name = result.name;
                    if ((kind & loadMask) != 0 && (!viewName || name == viewName)) {
                        var view = new ViewDefinition();
                        view.entityName = entityName;
                        view.version = version;
                        view.kind = kind;
                        view.name = name;
                        if (version >= 7) {
                            view.multiSelectCommands = reader.readLine();
                            reader.readLine();
                            reader.readLine();
                        }
                        if (version >= 6) {
                            view.allowedSortFields = reader.readLine();
                            view.allowedFilterFields = reader.readLine();
                        }
                        if (view.version >= 5) {
                            view.selector = reader.readLine();
                        }
                        if (view.version >= 4) {
                            view.buttons = reader.readLine();
                        }
                        view.fetch = reader.readLine();
                        view.templates = new Array();
                        while (true) {
                            var line = reader.readLine();
                            if (!line) {
                                break;
                            }
                            view.templates.push(line);
                        }
                        views.push(view);
                        if (viewName != null) {
                            break;
                        }
                    }
                }
            };
            return ViewParser;
        }());
        UI.ViewParser = ViewParser;
        var ViewDefinition = (function () {
            function ViewDefinition() {
            }
            Object.defineProperty(ViewDefinition.prototype, "entityLabel", {
                get: function () {
                    return this.entityName; // TODO: Localize: Localization.instance.get(this.entityName);
                },
                enumerable: true,
                configurable: true
            });
            return ViewDefinition;
        }());
        UI.ViewDefinition = ViewDefinition;
        var BaseDynamicEntityList = (function (_super) {
            __extends(BaseDynamicEntityList, _super);
            function BaseDynamicEntityList(nativeType) {
                return _super.call(this, nativeType ? nativeType : BaseDynamicEntityList) || this;
            }
            return BaseDynamicEntityList;
        }(DynamicEntityList));
        UI.BaseDynamicEntityList = BaseDynamicEntityList;
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
