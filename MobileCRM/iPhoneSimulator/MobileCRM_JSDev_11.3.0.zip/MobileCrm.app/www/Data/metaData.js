/// <reference path="../Helpers/common.ts" />
/// <reference path="metaEntity.ts" />
var MobileCrm;
(function (MobileCrm) {
    var Data;
    (function (Data) {
        var StateStatusMap = (function () {
            function StateStatusMap(status, state, stateInvariantName) {
                this.m_status = status;
                this.m_state = state;
                this.m_stateInvariantName = stateInvariantName;
            }
            Object.defineProperty(StateStatusMap.prototype, "status", {
                get: function () {
                    return this.m_status;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(StateStatusMap.prototype, "state", {
                get: function () {
                    return this.m_state;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(StateStatusMap.prototype, "stateInvariantName", {
                get: function () {
                    return this.m_stateInvariantName;
                },
                enumerable: true,
                configurable: true
            });
            return StateStatusMap;
        }());
        Data.StateStatusMap = StateStatusMap;
        var MetaData = (function () {
            // do not allow to initialize this class outside of this class -> always use instance
            function MetaData() {
            }
            Object.defineProperty(MetaData, "instance", {
                get: function () {
                    if (!MetaData.s_instance) {
                        MetaData.s_instance = new MetaData();
                    }
                    return MetaData.s_instance;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaData.prototype, "entities", {
                get: function () {
                    if (!this.m_dict) {
                        this.m_dict = new Resco.Dictionary();
                    }
                    return this.m_dict;
                },
                enumerable: true,
                configurable: true
            });
            MetaData.prototype.clearChache = function () {
                this.m_dict = null;
                this.m_emptyStateMap = null;
            };
            MetaData.prototype.init = function (metaEntities) {
                var _this = this;
                this.m_dict = new Resco.Dictionary();
                metaEntities.forEach(function (meta) { return _this.m_dict.add(meta.name, meta); }, this);
            };
            MetaData.prototype.tryGetEntity = function (entityName) {
                var entities = this.entities;
                if (entities.containsKey(entityName)) {
                    return entities.getValue(entityName);
                }
                return null;
            };
            return MetaData;
        }());
        Data.MetaData = MetaData;
    })(Data = MobileCrm.Data || (MobileCrm.Data = {}));
})(MobileCrm || (MobileCrm = {}));
