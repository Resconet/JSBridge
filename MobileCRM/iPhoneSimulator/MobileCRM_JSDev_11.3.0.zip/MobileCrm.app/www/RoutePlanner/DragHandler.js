/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
var RoutePlanner;
(function (RoutePlanner) {
    /**
     * Implements the drag'n'drop handler sorting the list of sibling elements (of any kind).
     * Sorts the list of any items having ".sortable" class.
     * Starts dragging on element having class ".draghandle".
     * Gives ".dragover" class to the ".dropindicator" element which is the target of the drop operation
     */
    var DragHandler = (function () {
        /**
         * Constructs the drag handler and binds the mousedown/touchstart event handler waiting for mouse event to element with class "draghandle".
         * @param dropHandler A callback obtaining the result of a drag/drop - a sortable element which was dragged and the index which it was dropped on.
         */
        function DragHandler(dropHandler) {
            var platform = MobileCRM.bridge.platform;
            if (platform == "iOS" || platform == "Android") {
                DragHandler.startEvent = "touchstart";
                this._endEvent = "touchend";
                this._moveEvent = "touchmove";
            }
            else {
                DragHandler.startEvent = "mousedown";
                this._endEvent = "mouseup";
                this._moveEvent = "mousemove";
            }
            this._dropHandler = dropHandler;
            this._touchListenerOptions = platform == "Android" ? { passive: false, capture: true } : true; // Passive listeners cannot call preventDefault in Chrome (Android)
            document.addEventListener(DragHandler.startEvent, this.onTouchStarted.bind(this), this._touchListenerOptions);
        }
        DragHandler.prototype.onTouchStarted = function (e) {
            if (this._dragItem)
                this.endDragging(); // Cleanup for unfinished drags (touchend outside of window)
            var handler = $(e.target);
            if (!handler.hasClass("draghandle"))
                handler = handler.parents(".draghandle");
            if (handler.length > 0) {
                var sortable = handler.parents(".sortable");
                if (sortable.length > 0) {
                    var touch = DragHandler.getTouchPos(e);
                    if (touch) {
                        this.onTriggerDown(sortable, touch);
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                    }
                }
            }
        };
        DragHandler.prototype.onTriggerDown = function (sortable, touch) {
            this._dragItem = sortable;
            this._dragItemIndex = sortable.prevAll(".sortable").length;
            this._dragStartX = touch.pageX;
            this._dragStartY = touch.pageY;
            this._sortables = this._dragItem.siblings(".sortable");
            this._touchMoveListener = this.onDragging.bind(this);
            this._touchEndListener = this.onDrop.bind(this);
            document.addEventListener(this._moveEvent, this._touchMoveListener, this._touchListenerOptions);
            document.addEventListener(this._endEvent, this._touchEndListener, this._touchListenerOptions);
        };
        DragHandler.prototype.onDragging = function (eventObj) {
            var touch = DragHandler.getTouchPos(eventObj);
            if (touch) {
                var x = touch.pageX;
                var y = touch.pageY;
                this.translateChildren(x - this._dragStartX, y - this._dragStartY);
                this.updateDropTarget(x, y);
                eventObj.preventDefault();
                eventObj.stopPropagation();
                eventObj.stopImmediatePropagation();
            }
        };
        DragHandler.prototype.onDragCancel = function (eventObj) {
            this.endDragging();
        };
        DragHandler.prototype.onDrop = function (eventObj) {
            var touch = DragHandler.getTouchPos(eventObj);
            var dropIndex = this.updateDropTarget(touch.pageX, touch.pageY);
            this._dropHandler(this._dragItem, dropIndex);
            this.endDragging();
            eventObj.preventDefault();
            eventObj.stopPropagation();
            eventObj.stopImmediatePropagation();
            var h = function (e) {
                e.stopImmediatePropagation();
                e.stopPropagation();
                e.preventDefault();
            };
            // Workaround for unwanted onclick handler firing. I haven't found any better solution
            document.addEventListener("click", h, true);
            setTimeout(function () { return document.removeEventListener("click", h, true); });
        };
        DragHandler.prototype.endDragging = function () {
            this.translateChildren(0, 0);
            $(".dragover").removeClass("dragover");
            document.removeEventListener(this._moveEvent, this._touchMoveListener, this._touchListenerOptions);
            document.removeEventListener(this._endEvent, this._touchEndListener, this._touchListenerOptions);
            this._touchEndListener = null;
            this._touchMoveListener = null;
            this._dragItem = null;
            this._sortables = null;
        };
        DragHandler.prototype.translateChildren = function (dx, dy) {
            this._dragItem.children().css("transform", "translate(" + dx + "px, " + dy + "px)");
        };
        DragHandler.getTouchPos = function (e) {
            if (e["pageX"] !== undefined)
                return e;
            var touches = e["touches"];
            if (touches.length <= 0)
                touches = e["changedTouches"];
            return touches[0];
        };
        DragHandler.prototype.getDropTarget = function (x, y) {
            var i;
            for (i = 0; i < this._sortables.length; i++) {
                var sortable = $(this._sortables[i]);
                var topY = sortable.offset().top;
                if (topY > y)
                    return i;
            }
            return i;
        };
        DragHandler.prototype.updateDropTarget = function (x, y) {
            var index = this.getDropTarget(x, y);
            var indicatorIndex = index <= this._dragItemIndex ? index : index + 1;
            $(".dragover").removeClass("dragover");
            $(this._dragItem.siblings(".dropindicator")[indicatorIndex]).addClass("dragover");
            return index;
        };
        return DragHandler;
    }());
    RoutePlanner.DragHandler = DragHandler;
})(RoutePlanner || (RoutePlanner = {}));
