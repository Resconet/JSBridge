///<reference path="../../Controllers/entityList.ts" />
///<reference path="../../Controllers/Workflow/workflow.ts" />
///<reference path="inputs.ts" />
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var AsyncInitState;
            (function (AsyncInitState) {
                AsyncInitState[AsyncInitState["NotRequested"] = 0] = "NotRequested";
                AsyncInitState[AsyncInitState["Requested"] = 1] = "Requested";
                AsyncInitState[AsyncInitState["Initialized"] = 2] = "Initialized";
            })(AsyncInitState || (AsyncInitState = {}));
            var DataProvider = (function () {
                function DataProvider(inputData) {
                    this._isListConfigInitialized = false;
                    this._isHorizontalListConfigInitialized = false;
                    this._isTaskConfigInitialized = false;
                    this._isStylesConfigInitialized = AsyncInitState.NotRequested;
                    this._isMetaDataInitialized = AsyncInitState.NotRequested;
                    this._stylesCallbacks = [];
                    this._metaDataCallbacks = [];
                    this._hiddenHorizontalListEntitiesIds = [];
                    this._unscheduledItemAttributeMap = undefined;
                    this._inputData = inputData;
                }
                DataProvider.prototype.getSettings = function () {
                    return Scheduler.Container.ref.settings;
                };
                DataProvider.prototype.setupAllowedViews = function (controller, config, selectedViewKey) {
                    if (!config)
                        return;
                    var configViews = config ? config.entityViews : null;
                    var hasView = (configViews && configViews.length > 0) ? true : false;
                    if (!hasView || configViews.indexOf(config.entityName + ".*") >= 0) {
                        var viewFilter = controller.viewFilter;
                        if (viewFilter && viewFilter.values) {
                            var viewNames = "";
                            for (var i = 0; i < viewFilter.values.length; i++) {
                                if (viewNames !== "")
                                    viewNames += ":";
                                viewNames += config.entityName + "." + viewFilter.values[i].value;
                            }
                            if (hasView) {
                                var tmp = config.entityName + ".@";
                                var startIdx = configViews.indexOf(tmp);
                                if (startIdx >= 0) {
                                    var endIdx = configViews.indexOf(':', startIdx);
                                    var initialConfig = endIdx < 0 ? configViews.substring(startIdx) : configViews.substring(startIdx, endIdx);
                                    var initialName = config.entityName + "." + initialConfig.substring(tmp.length);
                                    viewNames = viewNames.replace(initialName, initialConfig);
                                }
                            }
                            else {
                                hasView = (viewNames && viewNames.length > 0) ? true : false;
                            }
                            config.entityViews = viewNames;
                        }
                    }
                    if (hasView)
                        controller.setupAllowedViews(config.entityViews);
                    if (controller.allowedViews) {
                        var settings = Scheduler.Container.ref.settings;
                        var selectedView = settings[selectedViewKey];
                        if (selectedView && controller.allowedViews.containsKey(selectedView)) {
                            controller.selectView(selectedView);
                        }
                        else {
                            var keys = controller.allowedViews.getKeys();
                            if (keys.length > 0) {
                                selectedView = controller.initialView ? controller.initialView : keys[0];
                                controller.selectView(selectedView);
                            }
                            else {
                                selectedView = undefined;
                            }
                            if (selectedView !== settings[selectedViewKey]) {
                                settings[selectedViewKey] = selectedView;
                                settings.setDirty();
                                Scheduler.Container.ref.settings = settings; // force settings to be saved
                            }
                        }
                    }
                };
                DataProvider.prototype.createResourceController = function (listCtrl, onFinishCallback) {
                    var _this = this;
                    var config = Scheduler.Container.inputs.resources;
                    this._initListController(config.entityName, function (viewConfig) {
                        var _controller = MobileCrm.ControllerFactory.instance.getListController(config.entityName);
                        // list configuration and datasource getter
                        _controller.getUIConfig = function (uiPath) { return viewConfig; };
                        _controller.getUIConfigScope = _this;
                        _controller.getDataSourceEnumerator = function (fetch) { return _this.getResourceEnumerator(fetch); };
                        _controller.setView(listCtrl, MobileCrm.UI.ViewMode.Default);
                        _this.setupAllowedViews(_controller, config, "resourceView");
                        onFinishCallback(_controller);
                    });
                };
                DataProvider.prototype.createUnscheduledTasksController = function (horizontalListCtrl, onFinishCallback) {
                    var _this = this;
                    var config = Scheduler.Container.inputs.unscheduledTasks;
                    this._initHorizontalListController(config.entityName, function (viewConfig) {
                        var _controller = MobileCrm.ControllerFactory.instance.getListController(config.entityName);
                        // list configuration and datasource getter
                        _controller.getUIConfig = function (uiPath) { return viewConfig; };
                        _controller.getUIConfigScope = _this;
                        _controller.getDataSourceEnumerator = function (fetch) { return _this.getUnscheduledTasksEnumerator(fetch); };
                        _controller.setView(horizontalListCtrl, MobileCrm.UI.ViewMode.Default);
                        _this.setupAllowedViews(_controller, config, "unscheduledView");
                        onFinishCallback(_controller);
                    });
                };
                DataProvider.prototype.createTaskController = function (onFinishCallback) {
                    var _this = this;
                    var config = Scheduler.Container.inputs.scheduledTasks;
                    this._initTaskController(config.entityName, function (viewConfig) {
                        var _controller = MobileCrm.ControllerFactory.instance.getListController(config.entityName, Scheduler.TaskDynamicEntityList);
                        _controller.getUIConfig = function (uiPath) { return viewConfig; };
                        _controller.getUIConfigScope = _this;
                        _controller.loadConfiguration(MobileCrm.UI.ViewMode.Default); //_controller.setView(undefined, MobileCrm.UI.ViewMode.Default);
                        _this.setupAllowedViews(_controller, config, "scheduledView");
                        onFinishCallback(_controller);
                    });
                };
                DataProvider.prototype._toValue = function (name, item) {
                    var idx;
                    return (name && (idx = this._unscheduledItemAttributeMap[name]) !== undefined) ? item[idx] : undefined;
                };
                DataProvider.prototype.rowToUnscheduledTask = function (row) {
                    var inputData = this._inputData.unscheduledTasks;
                    var item = row.data.m_data;
                    if (!this._unscheduledItemAttributeMap) {
                        var entityProperties = row.data.repository.properties;
                        var epLength = entityProperties.length;
                        this._unscheduledItemAttributeMap = {};
                        for (var i = 0; i < epLength; i++)
                            this._unscheduledItemAttributeMap[entityProperties[i].name] = i;
                    }
                    var estimatedduration;
                    var now = Date.now();
                    var id = this._toValue(inputData.primaryKeyName, item);
                    var name = this._toValue(inputData.primaryFieldName, item);
                    var locationRef = inputData.attrLocationRef ? this._toValue(inputData.attrLocationRef, item) : undefined;
                    var territoryRef = inputData.attrTerritoryRef ? this._toValue(inputData.attrTerritoryRef, item) : undefined;
                    var task = new Scheduler.Task(this._inputData.scheduledTasks, "New_" + id, name, 0, 0);
                    if (!inputData.attrEstimatedDuration || !(estimatedduration = +this._toValue(inputData.attrEstimatedDuration, item)))
                        estimatedduration = inputData.defaultDuration;
                    if ((estimatedduration === undefined) || (estimatedduration === null) || estimatedduration < 0)
                        estimatedduration = Scheduler.Container.constants.defaultTaskDuration;
                    estimatedduration = Scheduler.minutesToMiliseconds(estimatedduration);
                    task.group = new Scheduler.Group(id, name, locationRef, territoryRef);
                    task.progress = inputData.attrProgress ? this._toValue(inputData.attrProgress, item) || 0 : 0;
                    task.setWorkStart(now);
                    task.hasScheduledStart = false;
                    task.setTotalWorkTime(estimatedduration);
                    var status = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                    task.setStatus(new Scheduler.Status(undefined, "NewSourceTask", "", Scheduler.TaskStatusType.Unscheduled, status ? status.color() : inputData.color));
                    if (task.group.locationRef && inputData.attrAddress && (task.location = this.getAddress(inputData.attrAddress, item)) !== undefined) {
                        Scheduler.LocationCache.Add(task.group.locationRef.id, task.location);
                    }
                    //			if ((task.location = WorkOrderEntity._getAddress(resultObject.customerAddress)) !== undefined && task.group)
                    //				LocationCache.Add(task.group.locationRef.id, task.location);
                    //task.setTravelFrom(this.ctrl.geo.duration(task.customerAddress));
                    //task.setTravelTo(task.getTravelFrom());
                    return task;
                };
                DataProvider.prototype.getAddress = function (inputData, prop) {
                    var latitude = undefined;
                    var longitude = undefined;
                    if (inputData.latitude) {
                        latitude = this._toValue(inputData.latitude, prop);
                        longitude = this._toValue(inputData.longitude, prop);
                    }
                    var address = "";
                    var s;
                    if ((s = this._toValue(inputData.country, prop)) !== undefined)
                        address += s + ",";
                    if ((s = this._toValue(inputData.stateorprovince, prop)))
                        address += s + ",";
                    if ((s = this._toValue(inputData.city, prop))) {
                        var p = this._toValue(inputData.postalcode, prop);
                        if (p)
                            address += p + " " + s + ",";
                        else
                            address += s + ",";
                    }
                    if ((s = this._toValue(inputData.street1, prop)))
                        address += s + ",";
                    if ((s = this._toValue(inputData.street2, prop)))
                        address += s + ",";
                    if (address !== "" || (latitude && longitude))
                        return new Scheduler.Location(address, latitude, longitude);
                    return undefined;
                };
                DataProvider.prototype.loadUnscheduledTasks = function (resources, onFinishCallback, maxCount) {
                    if (onFinishCallback)
                        onFinishCallback(null);
                };
                /// Default implementation initialize location during load (in case address attribute is defined in UnscheduledDataInput)
                DataProvider.prototype.loadLocations = function (tasks, onLoad) {
                    if (onLoad)
                        onLoad(null);
                };
                /// Default implementation set all resources as qualified  
                DataProvider.prototype.loadQualifiedResources = function (tasks, onFinishCallback) {
                    if (tasks) {
                        for (var i = 0; i < tasks.length; i++) {
                            var task = tasks[i];
                            if (task.getLinkedResources() === undefined)
                                task.setLinkedResources(null);
                        }
                    }
                    onFinishCallback(null);
                };
                DataProvider.prototype.saveTask = function (task, taskChanges) {
                    return __awaiter(this, void 0, void 0, function () {
                        var start, end, totalWork, status_1;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    start = +taskChanges.start;
                                    end = +taskChanges.end;
                                    totalWork = +taskChanges.totalWork;
                                    if (task.getStatus().isUnscheduled() && taskChanges.statuscode === undefined) {
                                        status_1 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                        if (!status_1)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity"));
                                        taskChanges.statuscode = status_1.value();
                                    }
                                    if (start && !end) {
                                        end = start + (totalWork || task.getTotalWorkTime());
                                        totalWork = undefined;
                                    }
                                    if (!(task.isUnscheduledNew() == false)) return [3 /*break*/, 2];
                                    return [4 /*yield*/, this._updateTask(task, taskChanges, start, end)];
                                case 1:
                                    _a.sent();
                                    return [3 /*break*/, 4];
                                case 2: return [4 /*yield*/, this._createNewTask(task, taskChanges, start, end)];
                                case 3:
                                    _a.sent();
                                    _a.label = 4;
                                case 4: return [4 /*yield*/, task.reloadTemplateData()];
                                case 5:
                                    _a.sent();
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype._createNewTask = function (task, taskChanges, start, end) {
                    return __awaiter(this, void 0, void 0, function () {
                        var resource, input, sourceInput, resourceInput, entity, props, status_2, status_3, ruleResult, _start, _end, result;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    resource = task.resource;
                                    input = this._inputData.scheduledTasks;
                                    sourceInput = this._inputData.unscheduledTasks;
                                    resourceInput = this._inputData.resources;
                                    entity = MobileCRM.DynamicEntity.createNew(input.entityName);
                                    props = entity.properties;
                                    props[input.attrScheduledStart] = new Date(start || task.getWorkStart());
                                    props[input.attrScheduledEnd] = new Date(end || task.getWorkEnd());
                                    if (!props[input.attrStatus]) {
                                        status_2 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                        if (!status_2)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity"));
                                        taskChanges.statuscode = status_2.value();
                                        props[input.attrStatus] = taskChanges.statuscode;
                                    }
                                    else {
                                        status_3 = props[input.attrStatus];
                                        taskChanges.statuscode = status_3;
                                    }
                                    if (task.group && sourceInput && sourceInput.entityName)
                                        props[input.attrSourceRef] = new MobileCRM.Reference(sourceInput.entityName, task.group.id, task.group.name);
                                    if (resource)
                                        props[input.attrResourceRef] = new MobileCRM.Reference(resourceInput.entityName, resource.getID(), resource.getName());
                                    else if (taskChanges.parentID)
                                        props[input.attrResourceRef] = new MobileCRM.Reference(resourceInput.entityName, taskChanges.parentID, null);
                                    else
                                        throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoResourceIdForNewTask"));
                                    if (!props[input.primaryFieldName])
                                        props[input.primaryFieldName] = task.name;
                                    if (!this.m_rule)
                                        this.m_rule = new CreateRule(this._inputData);
                                    return [4 /*yield*/, this.m_rule.executeCreateRule(entity)];
                                case 1:
                                    ruleResult = _a.sent();
                                    if (ruleResult) {
                                        if (ruleResult.errorMsg)
                                            throw new Resco.Exception(ruleResult.errorMsg);
                                    }
                                    _start = entity.properties[input.attrScheduledStart];
                                    if (_start != undefined)
                                        taskChanges.start = +_start;
                                    _end = entity.properties[input.attrScheduledEnd];
                                    if (_start != undefined && _end != undefined)
                                        taskChanges.totalWork = (+_end) - (+_start);
                                    return [4 /*yield*/, entity.saveAsync()];
                                case 2:
                                    result = _a.sent();
                                    props = result.properties;
                                    task.id = result.id;
                                    task.name = props[input.primaryFieldName];
                                    taskChanges.name = task.name;
                                    task.entityInput.entityName = result.entityName;
                                    if (!ruleResult) return [3 /*break*/, 4];
                                    return [4 /*yield*/, ruleResult.updateSource()];
                                case 3:
                                    _a.sent();
                                    _a.label = 4;
                                case 4: return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype._updateTask = function (task, taskChanges, start, end) {
                    return __awaiter(this, void 0, void 0, function () {
                        var input, entity, list, fetch, result;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    input = this._inputData.scheduledTasks;
                                    entity = new MobileCRM.FetchXml.Entity(input.entityName);
                                    if (!this._attributesToSave) {
                                        list = new Array();
                                        list.push(new MobileCRM.FetchXml.Attribute(input.primaryKeyName));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.primaryFieldName));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.attrResourceRef));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.attrScheduledStart));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.attrScheduledEnd));
                                        list.push(new MobileCRM.FetchXml.Attribute(input.attrStatus));
                                        if (input.attrSourceRef)
                                            list.push(new MobileCRM.FetchXml.Attribute(input.attrSourceRef));
                                        this._attributesToSave = list;
                                    }
                                    entity.attributes = this._attributesToSave;
                                    entity.addFilter().where(input.primaryKeyName, "eq", task.id);
                                    fetch = new MobileCRM.FetchXml.Fetch(entity);
                                    return [4 /*yield*/, fetch.executeAsync("DynamicEntities")];
                                case 1:
                                    result = _a.sent();
                                    if (result.length === 0)
                                        throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoTasks"));
                                    return [4 /*yield*/, this._updateTaskEntity(result[0], input, task, taskChanges, start, end)];
                                case 2:
                                    _a.sent();
                                    return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype._updateTaskEntity = function (entity, input, task, taskChanges, start, end) {
                    return __awaiter(this, void 0, void 0, function () {
                        var resource, prop, oldStatuscode, changes, status_4, resId, newEntity;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    resource = task.resource;
                                    prop = entity.properties;
                                    oldStatuscode = prop[input.attrStatus];
                                    changes = 0;
                                    if (!Scheduler.Container.statusCodeTable.getStatusByValue(oldStatuscode).isEditable())
                                        throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity") + " " + input.entityName + ".");
                                    if (taskChanges.statuscode !== undefined && taskChanges.statuscode != oldStatuscode && Scheduler.Task.isValidStatusValue(taskChanges.statuscode)) {
                                        prop[input.attrStatus] = taskChanges.statuscode;
                                        changes++;
                                    }
                                    if (start && !Scheduler.Utilities.equalDates(start, prop[input.attrScheduledStart])) {
                                        prop[input.attrScheduledStart] = new Date(start);
                                        changes++;
                                    }
                                    if (end && !Scheduler.Utilities.equalDates(end, prop[input.attrScheduledEnd])) {
                                        prop[input.attrScheduledEnd] = new Date(end);
                                        changes++;
                                    }
                                    if (taskChanges.name !== undefined) {
                                        prop[input.primaryFieldName] = taskChanges.name;
                                        changes++;
                                    }
                                    if (Scheduler.Container.statusCodeTable.getStatusByValue(oldStatuscode).isUnscheduled()) {
                                        if (!resource)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Scheduler.Err.NoResourceIdForNewTask"));
                                        status_4 = Scheduler.Container.statusCodeTable.getScheduledOrConfirmedStatusIfExist();
                                        if (!status_4)
                                            throw new Resco.Exception(Scheduler.StringTable.get("Err.CantModifyEntity"));
                                        prop[input.attrStatus] = status_4.value();
                                        prop[input.attrResourceRef] = resource.reference();
                                        changes++;
                                    }
                                    else if (resource) {
                                        resId = prop[input.attrResourceRef];
                                        if (!resId || resId.id !== resource.getID()) {
                                            prop[input.attrResourceRef] = resource.reference();
                                            changes++;
                                        }
                                    }
                                    if (!(changes > 0)) return [3 /*break*/, 2];
                                    return [4 /*yield*/, entity.saveAsync()];
                                case 1:
                                    newEntity = _a.sent();
                                    if (newEntity && task.isUnscheduledNew()) {
                                        task.id = newEntity.id;
                                        task.entityInput.entityName = input.entityName;
                                    }
                                    _a.label = 2;
                                case 2: return [2 /*return*/];
                            }
                        });
                    });
                };
                DataProvider.prototype.onTaskDlgInitialized = function (dialog) {
                };
                /*** PRIVATE METHODS ***/
                DataProvider.prototype._initListController = function (controllerName, onFinishCallback) {
                    var _this = this;
                    this._isListConfigInitialized = false;
                    var viewConfig;
                    var onMultiFinishCallback = function () {
                        if ((_this._isStylesConfigInitialized === AsyncInitState.Initialized) && (_this._isMetaDataInitialized === AsyncInitState.Initialized) && _this._isListConfigInitialized)
                            onFinishCallback(viewConfig);
                    };
                    var onInitViewConfig = function (config, callback) {
                        if (!config)
                            config = _this._createFallbackView(_this._inputData.resources);
                        viewConfig = config.split("\r\n");
                        _this._isListConfigInitialized = true;
                        callback();
                    };
                    this._initStylesConcurrently(onMultiFinishCallback);
                    this._initMetaDataConcurrently(onMultiFinishCallback);
                    this._readConfig("Controllers\\" + controllerName + ".list", function (view) { return onInitViewConfig(view, onMultiFinishCallback); }, function (err) {
                        Scheduler.StringTable.alert(err);
                    });
                };
                DataProvider.prototype._initHorizontalListController = function (controllerName, onFinishCallback) {
                    var _this = this;
                    this._isHorizontalListConfigInitialized = false;
                    var viewConfig;
                    var onMultiFinishCallback = function () {
                        if ((_this._isStylesConfigInitialized === AsyncInitState.Initialized) && (_this._isMetaDataInitialized === AsyncInitState.Initialized) && _this._isHorizontalListConfigInitialized)
                            onFinishCallback(viewConfig);
                    };
                    var onInitViewConfig = function (config, callback) {
                        if (!config)
                            config = _this._createFallbackView(_this._inputData.unscheduledTasks);
                        viewConfig = config.split("\r\n");
                        _this._isHorizontalListConfigInitialized = true;
                        callback();
                    };
                    this._initStylesConcurrently(onMultiFinishCallback);
                    this._initMetaDataConcurrently(onMultiFinishCallback);
                    this._readConfig("Controllers\\" + controllerName + ".list", function (view) { return onInitViewConfig(view, onMultiFinishCallback); }, function (err) {
                        Scheduler.StringTable.alert(err);
                    });
                };
                DataProvider.prototype._initTaskController = function (controllerName, onFinishCallback) {
                    var _this = this;
                    this._isTaskConfigInitialized = false;
                    var viewConfig;
                    var onMultiFinishCallback = function () {
                        if ((_this._isStylesConfigInitialized === AsyncInitState.Initialized) && (_this._isMetaDataInitialized === AsyncInitState.Initialized) && _this._isTaskConfigInitialized)
                            onFinishCallback(viewConfig);
                    };
                    var onInitViewConfig = function (config, callback) {
                        if (!config)
                            config = _this._createFallbackView(_this._inputData.scheduledTasks);
                        viewConfig = config.split("\r\n");
                        _this._isTaskConfigInitialized = true;
                        callback();
                    };
                    this._initStylesConcurrently(onMultiFinishCallback);
                    this._initMetaDataConcurrently(onMultiFinishCallback);
                    this._readConfig("Controllers\\" + controllerName + ".list", function (view) { return onInitViewConfig(view, onMultiFinishCallback); }, function (err) {
                        Scheduler.StringTable.alert(err);
                    });
                };
                DataProvider.prototype._createFallbackView = function (input) {
                    var fmtFallback = "V2\r\n" +
                        "@@FallbackView\r\n" +
                        "1\r\n" +
                        "{0}\r\n" +
                        "T;;240;40\r\n" +
                        "S;PrimaryName;0;Primary;10;8;220;36;13\r\n";
                    var fetchXml = Resco.formatString("<fetch><entity name=\"{0}\"><attribute name=\"{1}\" /><order attribute=\"{1}\" /></entity></fetch>", [input.entityName, input.primaryFieldName]);
                    return Resco.formatString(fmtFallback, [fetchXml]);
                };
                DataProvider.prototype.addFilters = function (entity, inputData) {
                    var filterList = this._inputData.filterList;
                    if (filterList && inputData.filterLinks) {
                        var customFilter = this.getSettings().customFilterSelection;
                        for (var i = 0; i < filterList.length; i++) {
                            var filter = filterList[i];
                            var filterLink = inputData.filterLinks ? inputData.filterLinks[filter.name] : undefined;
                            var filterIds = void 0;
                            if (filterLink && filterLink.attrToFilterBy && (filterIds = customFilter[filter.name]) && filterIds.length > 0) {
                                if (filterLink.entityName) {
                                    var linkEntity = entity.addLink(filterLink.entityName, filterLink.from, filterLink.to, filterLink.linkType);
                                    linkEntity.filter.In(filterLink.attrToFilterBy, filterIds);
                                }
                                else
                                    entity.filter.In(filterLink.attrToFilterBy, filterIds);
                            }
                        }
                    }
                };
                DataProvider.prototype.getResourceEnumerator = function (fetch) {
                    var entity = fetch.entity;
                    this.addFilters(entity, this._inputData.resources);
                    return new MobileCrm.UI.JSBridgeEntityQuery(fetch);
                };
                DataProvider.prototype.addUnique = function (attribute, entity, len) {
                    if (attribute) {
                        for (var i = 0; i < len; i++) {
                            if (entity.attributes[i].name === attribute)
                                return;
                        }
                        entity.attributes.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(attribute, undefined)));
                    }
                };
                DataProvider.prototype.getUnscheduledTasksEnumerator = function (fetch) {
                    var entity = fetch.entity;
                    var input = this._inputData.unscheduledTasks;
                    var scheduledTasks = this._inputData.scheduledTasks;
                    var address = input.attrAddress;
                    var attributesLen = entity.attributes.length;
                    this.addUnique(input.primaryKeyName, entity, attributesLen);
                    this.addUnique(input.primaryFieldName, entity, attributesLen);
                    this.addUnique(input.attrLocationRef, entity, attributesLen);
                    this.addUnique(input.attrTerritoryRef, entity, attributesLen);
                    this.addUnique(input.attrEstimatedDuration, entity, attributesLen);
                    this.addUnique(input.attrProgress, entity, attributesLen);
                    if (address) {
                        if (!address.entityName) {
                            this.addUnique(address.latitude, entity, attributesLen);
                            this.addUnique(address.longitude, entity, attributesLen);
                            this.addUnique(address.country, entity, attributesLen);
                            this.addUnique(address.stateorprovince, entity, attributesLen);
                            this.addUnique(address.city, entity, attributesLen);
                            this.addUnique(address.postalcode, entity, attributesLen);
                            this.addUnique(address.street1, entity, attributesLen);
                            this.addUnique(address.street2, entity, attributesLen);
                        }
                        else {
                            if (!this._addressAttributes) {
                                var addressAttrs = [];
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.latitude, undefined)));
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.longitude, undefined)));
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.country, undefined)));
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.stateorprovince, undefined)));
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.city, undefined)));
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.postalcode, undefined)));
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.street1, undefined)));
                                addressAttrs.push(new MobileCrm.Data.Fetch.Attribute(new MobileCrm.Data.MetaProperty(address.street2, undefined)));
                                this._addressAttributes = addressAttrs;
                            }
                            var linkEntity = entity.addLink(address.entityName, address.from, address.to, address.linkType);
                            linkEntity.attributes = this._addressAttributes;
                        }
                    }
                    //Container.ref.enabledFilterDoNotOfferScheduledTasks = false;
                    if (scheduledTasks.entityName != "fs_workorderschedule") {
                        var addLink = true;
                        if (entity.links) {
                            for (var i = 0; i < entity.links.length; i++) {
                                var link = entity.links[i];
                                if (link.name == scheduledTasks.entityName &&
                                    link.from == scheduledTasks.attrSourceRef &&
                                    link.to == input.primaryKeyName) {
                                    addLink = false;
                                }
                            }
                        }
                        if (addLink) {
                            var linkEntity = entity.addLink(scheduledTasks.entityName, scheduledTasks.attrSourceRef, input.primaryKeyName, "outer");
                            var days = this.getSettings().daysWhenSourcesIsNotOfferedForScheduling;
                            linkEntity.alias = "L0";
                            if (!days)
                                days = Scheduler.Container.constants.daysWhenSourcesIsNotOfferedForScheduling;
                            var filter = entity.filter.or();
                            // Settings below will be set in corresponding view in Woodford
                            // show all accounts that do not have appointments
                            // show all accounts that have all appointments older than x days
                            //let c1 = settings.where(scheduledTasks.primaryKeyName, "null", null);
                            //let c2 = settings.where(scheduledTasks.attrScheduledStart, Container.constants.daysWhenSourcesIsNotOfferedForScheduling, "olderthan-x-days");
                            //c1.entityName = "L0";
                            //c2.entityName = "L0";
                            //Container.ref.enabledFilterDoNotOfferScheduledTasks = true;
                        }
                    }
                    this.addFilters(entity, input);
                    if (Scheduler.Container.constants.hideUnscheduledTaskAfterScheduling && (this._hiddenHorizontalListEntitiesIds.length > 0))
                        entity.filter.NotIn(input.primaryKeyName, this._hiddenHorizontalListEntitiesIds);
                    return new MobileCrm.UI.JSBridgeEntityQuery(fetch);
                };
                DataProvider.prototype._initStylesConcurrently = function (onMultiFinishCallback) {
                    var _this = this;
                    if (this._isStylesConfigInitialized === AsyncInitState.Initialized) {
                        onMultiFinishCallback();
                    }
                    else {
                        this._stylesCallbacks.push(onMultiFinishCallback);
                        if (this._isStylesConfigInitialized === AsyncInitState.NotRequested) {
                            this._isStylesConfigInitialized = AsyncInitState.Requested;
                            this._readConfig("Controllers\\Styles", function (result) {
                                MobileCrm.ControllerFactory.instance.initializeStyles(result.split("\r\n"));
                                _this._isStylesConfigInitialized = AsyncInitState.Initialized;
                                for (var i = 0; i < _this._stylesCallbacks.length; i++) {
                                    _this._stylesCallbacks[i]();
                                }
                                _this._stylesCallbacks = [];
                            }, function (err) {
                                MobileCRM.bridge.alert(err);
                            });
                        }
                    }
                };
                DataProvider.prototype._initMetaDataConcurrently = function (onMultiFinishCallback) {
                    var _this = this;
                    if (this._isMetaDataInitialized === AsyncInitState.Initialized) {
                        onMultiFinishCallback();
                    }
                    else {
                        this._metaDataCallbacks.push(onMultiFinishCallback);
                        if (this._isMetaDataInitialized === AsyncInitState.NotRequested) {
                            this._isMetaDataInitialized = AsyncInitState.Requested;
                            this._initMetaData(function () {
                                _this._isMetaDataInitialized = AsyncInitState.Initialized;
                                for (var i = 0; i < _this._metaDataCallbacks.length; i++) {
                                    _this._metaDataCallbacks[i]();
                                }
                                _this._metaDataCallbacks = [];
                            });
                        }
                    }
                };
                DataProvider.prototype._initMetaData = function (success) {
                    MobileCRM.Metadata.requestObject(function (metadata) {
                        var metaEntites = [];
                        var jsbMetadata = metadata;
                        for (var entityName in jsbMetadata.entities) {
                            var jsbMeta = jsbMetadata.entities[entityName];
                            var meta = new MobileCrm.Data.MetaEntity(jsbMeta.name, jsbMeta.primaryKeyName, jsbMeta.primaryFieldName, jsbMeta.objectTypeCode, jsbMeta.attributes);
                            meta.permissionMask = jsbMeta.permissionMask;
                            for (var j = 0; j < jsbMeta.properties.length; j++) {
                                var jsbProp = jsbMeta.properties[j];
                                var prop = new MobileCrm.Data.MetaProperty(jsbProp.name, jsbProp.type, jsbProp.targets);
                                prop.defaultValue = jsbProp.defaultValue;
                                prop.format = jsbProp.format;
                                prop.maximum = jsbProp.maximum;
                                prop.minimum = jsbProp.minimum;
                                prop.precision = jsbProp.precision;
                                prop.required = jsbProp.required;
                                prop.permissions = jsbProp.permission;
                                meta.add(prop);
                            }
                            metaEntites.push(meta);
                        }
                        MobileCrm.Data.MetaData.instance.init(metaEntites);
                        success();
                    }, MobileCRM.bridge.alert);
                };
                DataProvider.prototype._readConfig = function (path, success, failure) {
                    var reader = MobileCRM.bridge.exposeObjectAsync("MobileCrm.Data:MobileCrm.Configuration.Instance.OpenUIConfig", [path]);
                    reader.invokeMethodAsync("ReadToEnd", [], success, failure, this);
                    reader.invokeMethodAsync("Dispose", [], undefined, undefined, this);
                    reader.release();
                };
                DataProvider.prototype.rowToResource = function (listRows, e) {
                    var length;
                    if (!listRows || !(length = listRows.length))
                        return null;
                    var resourceIdIndex = -1;
                    var resourceNameIndex = -1;
                    var repos = listRows[0].data.m_repository.properties;
                    for (var i = 0; i < repos.length; i++) {
                        var entityName = repos[i].name;
                        var entity = repos[i].entity;
                        if (resourceIdIndex < 0 && entityName == entity.m_primaryKeyName)
                            resourceIdIndex = i;
                        else if (resourceNameIndex < 0 && entityName == entity.m_primaryFieldName)
                            resourceNameIndex = i;
                    }
                    if (resourceIdIndex < 0 || resourceNameIndex < 0)
                        return null;
                    var resources = [];
                    var startRow = e.startIndex;
                    var endRow = e.endIndex;
                    if (endRow === undefined || endRow === null || endRow < startRow)
                        endRow = startRow + length;
                    for (var i = startRow; i < endRow; i++) {
                        var row = listRows[i].data.m_data;
                        resources.push(new Scheduler.Resource(row[resourceIdIndex], row[resourceNameIndex], null, i, Scheduler.Container.defaultOffice));
                    }
                    return resources;
                };
                DataProvider.prototype.loadTasks = function (inputTasks, timeOffs, resources, timeRange, filter, onFinishCallback) {
                    var _this = this;
                    this._loadTasks(inputTasks, resources, timeRange, filter, function (entityResult) {
                        var resourceDict = new Scheduler.ResourceDictionary();
                        resourceDict.add(resources);
                        _this._addTasksToResources(entityResult, inputTasks, resourceDict, timeRange);
                        if (!timeOffs)
                            onFinishCallback();
                        else {
                            _this._loadTimeOffs(timeOffs, undefined, timeRange, filter, function (entityResult) {
                                var lastResurce = undefined;
                                var timeOffStatus = Scheduler.Container.statusCodeTable.primaryStatuses[Scheduler.TaskStatusType.TimeOff];
                                for (var i = 0; i < entityResult.length; i++) {
                                    var prop = entityResult[i].properties;
                                    var start = prop[timeOffs.attrScheduledStart];
                                    var end = prop[timeOffs.attrScheduledEnd];
                                    var resourceid = prop[timeOffs.attrResourceRef];
                                    if (!start || !end || !resourceid)
                                        continue;
                                    if (!lastResurce || (lastResurce.getID() !== resourceid.id)) {
                                        var resource = resourceDict.Item(resourceid.id);
                                        if (!resource)
                                            continue;
                                        lastResurce = resource;
                                    }
                                    var task = new Scheduler.Task(timeOffs, prop[timeOffs.primaryKeyName], prop[timeOffs.primaryFieldName], new Date(start).valueOf(), new Date(end).valueOf());
                                    task.setStatus(timeOffStatus);
                                    if (task && timeRange.contain(new Scheduler.TimeRange(task.getWorkStart(), task.getWorkStart() + task.getTotalWorkTime())))
                                        lastResurce.addTask(task);
                                }
                                onFinishCallback();
                            });
                        }
                    });
                };
                DataProvider.prototype._loadTasks = function (inputData, resources, timeRange, filter, entityResultCallback) {
                    var entity = new MobileCRM.FetchXml.Entity(inputData.entityName);
                    var filters = [];
                    if (!this._taskDataAttributes) {
                        this._taskDataAttributes = this._createTaskDataAttributes(inputData);
                    }
                    entity.attributes = this._taskDataAttributes.slice(); // !!!It is necessary to set a new copy (instance) here, because in other case calling "entity.addAttribute()" method below (in taskTemplateController.addAttributesAndLinks()) will accumulate attributes, by adding them to the same instance every call of that code!!!
                    if (resources) {
                        var resourceIds = resources.map(function (i) { return i.getID(); });
                        if (resourceIds && (resourceIds.length > 0)) {
                            var resourceFilter = new MobileCRM.FetchXml.Filter();
                            resourceFilter.isIn(inputData.attrResourceRef, resourceIds);
                            filters.push(resourceFilter);
                        }
                    }
                    if (inputData.attrStatus) {
                        var statusCodeTable = Scheduler.Container.statusCodeTable;
                        var statusArray = statusCodeTable.getSupportedStatusesValues();
                        if (statusArray && (statusArray.length > 0)) {
                            var statusFilter = new MobileCRM.FetchXml.Filter();
                            statusFilter.isIn(inputData.attrStatus, statusArray);
                            filters.push(statusFilter);
                        }
                        if ((statusArray = statusCodeTable.getUnscheduledStatusesValues()) && (statusArray.length > 0)) {
                            var unscheduledFilter = new MobileCRM.FetchXml.Filter();
                            unscheduledFilter.notIn(inputData.attrStatus, statusArray);
                            filters.push(unscheduledFilter);
                        }
                        if (!filter.showCompletedAndCanceled && !filter.monthOverviewMode() && (statusArray = statusCodeTable.getFinishedStatusesValues()) && (statusArray.length > 0)) {
                            var finishedFilter = new MobileCRM.FetchXml.Filter();
                            finishedFilter.notIn(inputData.attrStatus, statusArray);
                            filters.push(finishedFilter);
                        }
                    }
                    if (timeRange) {
                        var startPeriod = undefined;
                        var endPeriod = undefined;
                        if (timeRange.start > 0) {
                            startPeriod = new Date(timeRange.start);
                        }
                        if (timeRange.end > timeRange.start) {
                            endPeriod = new Date(timeRange.end);
                        }
                        if (startPeriod || endPeriod) {
                            var timeFilter = new MobileCRM.FetchXml.Filter();
                            if (startPeriod)
                                timeFilter.where(inputData.attrScheduledStart, "ge", startPeriod);
                            if (endPeriod)
                                timeFilter.where(inputData.attrScheduledEnd, "lt", endPeriod);
                            filters.push(timeFilter);
                        }
                    }
                    /*
                    if (inputData.attrStatecode ) {
                        let statusCodeFilter = new MobileCRM.FetchXml.Filter();
                        statusCodeFilter.where(inputData.attrStatecode, "eq", 0);
                        filters.push(statusCodeFilter);
                    }*/
                    entity.addFilter().filters = filters;
                    entity.orderBy(inputData.attrResourceRef, false);
                    if (Scheduler.Container.ref.taskTemplateCtrl.isInitialized) {
                        Scheduler.Container.ref.taskTemplateCtrl.addAttributesAndLinks(entity);
                    }
                    var fetch = new Scheduler.MultipageFetch();
                    fetch.execute(entity, entityResultCallback);
                };
                DataProvider.prototype._loadTimeOffs = function (inputData, resources, timeRange, filter, entityResultCallback) {
                    var entity = new MobileCRM.FetchXml.Entity(inputData.entityName);
                    var filters = [];
                    if (!this._timeOffsDataAttributes)
                        this._timeOffsDataAttributes = this._createTaskDataAttributes(inputData);
                    entity.attributes = this._timeOffsDataAttributes;
                    if (resources) {
                        var resourceIds = resources.map(function (i) { return i.getID(); });
                        if (resourceIds && (resourceIds.length > 0)) {
                            var resourceFilter = new MobileCRM.FetchXml.Filter();
                            resourceFilter.isIn(inputData.attrResourceRef, resourceIds);
                            filters.push(resourceFilter);
                        }
                    }
                    if (timeRange) {
                        var startPeriod = undefined;
                        var endPeriod = undefined;
                        if (timeRange.start > 0)
                            startPeriod = new Date(timeRange.start);
                        if (timeRange.end > timeRange.start)
                            endPeriod = new Date(timeRange.end);
                        if (startPeriod || endPeriod) {
                            var timeFilter = new MobileCRM.FetchXml.Filter();
                            if (startPeriod)
                                timeFilter.where(inputData.attrScheduledStart, "ge", startPeriod);
                            if (endPeriod)
                                timeFilter.where(inputData.attrScheduledEnd, "lt", endPeriod);
                            filters.push(timeFilter);
                        }
                    }
                    if (filters.length > 0)
                        entity.addFilter().filters = filters;
                    entity.orderBy(inputData.attrResourceRef, false);
                    var fetch = new Scheduler.MultipageFetch();
                    fetch.execute(entity, entityResultCallback);
                };
                DataProvider.prototype._createTaskDataAttributes = function (inputData) {
                    var attrs = [];
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.primaryKeyName));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.primaryFieldName));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrResourceRef));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrScheduledStart));
                    attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrScheduledEnd));
                    if (inputData.attrStatus)
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrStatus));
                    if (inputData.attrSourceRef)
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrSourceRef));
                    if (inputData.attrTravelFrom) {
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrTravelTo));
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrTravelFrom));
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrTravelMode));
                    }
                    if (inputData.attrWorkduration)
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrWorkduration));
                    if (inputData.attrProgress)
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrProgress));
                    if (inputData.attrWindowStart) {
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrWindowStart));
                        attrs.push(new MobileCRM.FetchXml.Attribute(inputData.attrWindowEnd));
                    }
                    return attrs;
                };
                DataProvider.prototype._addTasksToResources = function (entityResult, inputData, resourceDict, timeRange) {
                    var lastResource = undefined;
                    for (var i = 0; i < entityResult.length; i++) {
                        var prop = entityResult[i].properties;
                        var scheduledstart = prop[inputData.attrScheduledStart];
                        var scheduledend = prop[inputData.attrScheduledEnd];
                        var ownerid = prop[inputData.attrResourceRef];
                        if (!scheduledstart || !scheduledend)
                            continue;
                        if (!lastResource || (lastResource.getID() !== ownerid.id)) {
                            var resource = resourceDict.Item(ownerid.id);
                            if (!resource)
                                continue;
                            lastResource = resource;
                        }
                        var task = this.rowToScheduledTask(prop);
                        if (task && timeRange.contain(new Scheduler.TimeRange(task.getWorkStart(), task.getWorkStart() + task.getTotalWorkTime())))
                            lastResource.addTask(task);
                    }
                };
                DataProvider.prototype.rowToScheduledTask = function (prop, task) {
                    var inputData = this._inputData.scheduledTasks;
                    if (!task)
                        task = this._createScheduledTaskFromRow(prop, inputData);
                    else if (prop[inputData.primaryKeyName] === task.id)
                        this._updateScheduledTaskFromRow(prop, inputData, task);
                    if (!task) {
                        if (Scheduler.Container.ref.taskTemplateCtrl.isInitialized) {
                            task.templateData = Scheduler.Container.ref.taskTemplateCtrl.toTemplateData(inputData.entityName, prop);
                        }
                    }
                    else {
                        task.updateTemplateData(inputData.entityName, prop);
                    }
                    return task;
                };
                DataProvider.prototype._createScheduledTaskFromRow = function (prop, inputData) {
                    var scheduledstart = prop[inputData.attrScheduledStart];
                    var scheduledend = prop[inputData.attrScheduledEnd];
                    var statuscode = prop[inputData.attrStatus];
                    if (!scheduledstart || !scheduledend)
                        return null;
                    var startDate = new Date(scheduledstart);
                    var endDate = new Date(scheduledend);
                    var sourceRef = inputData.attrSourceRef || prop[inputData.attrSourceRef];
                    var travel;
                    var task = new Scheduler.Task(inputData, prop[inputData.primaryKeyName], prop[inputData.primaryFieldName], 0, 0);
                    task.progress = inputData.attrProgress ? (prop[inputData.attrProgress] || 0) : 0;
                    task.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(statuscode));
                    if (sourceRef && sourceRef.id) {
                        var locationRef = inputData.attrLocationRef ? prop[inputData.attrLocationRef] : undefined;
                        var territoryRef = inputData.attrTerritoryRef ? prop[inputData.attrTerritoryRef] : undefined;
                        task.group = new Scheduler.Group(sourceRef.id, sourceRef.primaryName, locationRef, territoryRef); //, prop.territoryid);
                    }
                    if (inputData.attrTravelFrom && inputData.attrTravelTo) {
                        travel = task.getTravel();
                        travel.to = (prop[inputData.attrTravelTo] || 0) * Scheduler.minuteInMiliseconds;
                        travel.from = (prop[inputData.attrTravelFrom] || 0) * Scheduler.minuteInMiliseconds;
                        travel.mode = prop[inputData.attrTravelMode] ? prop[inputData.attrTravelMode] || 0 : 0;
                    }
                    var windowstart = prop[inputData.attrWindowStart] || 0;
                    var windowend = prop[inputData.attrWindowEnd] || 0;
                    if (windowstart && windowend < windowstart)
                        task.requiredWindow = new Scheduler.TimeRange(windowstart, windowend);
                    else
                        task.requiredWindow = undefined;
                    if (!task.isEditable()) {
                        if (task.getStatus().isFinished() && inputData.attrProgress)
                            task.progress = 100;
                        if (startDate && endDate && inputData.attrStartedOn && inputData.attrEndedOn) {
                            var startedOn = void 0;
                            var arrivedOn = void 0;
                            var scheduledDuration = endDate.valueOf() - startDate.valueOf();
                            if ((startedOn = prop[inputData.attrStartedOn] || 0)) {
                                var endedOn = prop[inputData.attrEndedOn] || 0;
                                startDate = new Date(startedOn);
                                endDate = endedOn ? new Date(endedOn) : new Date(startDate.valueOf() + scheduledDuration);
                            }
                            else if ((arrivedOn = prop[inputData.attrArrivedOn] || 0)) {
                                startDate = new Date(arrivedOn);
                                endDate = new Date(startDate.valueOf() + scheduledDuration);
                            }
                        }
                    }
                    var start = startDate.valueOf();
                    task.setWorkStart(start);
                    task.hasScheduledStart = true;
                    var workduration;
                    if (inputData.attrWorkduration && (workduration = prop[inputData.attrWorkduration]) !== undefined)
                        task.setTotalWorkTime(Scheduler.minutesToMiliseconds(workduration));
                    else {
                        var end = endDate.valueOf();
                        if (end < start)
                            end = start;
                        task.setTotalWorkTime(end - start);
                    }
                    return task;
                };
                DataProvider.prototype._updateScheduledTaskFromRow = function (prop, inputData, task) {
                    var scheduledstart = prop[inputData.attrScheduledStart];
                    var scheduledend = prop[inputData.attrScheduledEnd];
                    var statuscode = prop[inputData.attrStatus];
                    var startDate = scheduledstart ? new Date(scheduledstart) : undefined;
                    var endDate = scheduledend ? new Date(scheduledend) : undefined;
                    var travel = task.getTravel();
                    var s;
                    if ((s = prop[inputData.primaryFieldName]) !== undefined)
                        task.name = s;
                    if (inputData.attrTravelFrom) {
                        if ((s = prop[inputData.attrTravelFrom]) !== undefined)
                            travel.from = Scheduler.minutesToMiliseconds(+s);
                        if ((s = prop[inputData.attrTravelTo]) !== undefined)
                            travel.to = Scheduler.minutesToMiliseconds(+s);
                        if (inputData.attrTravelMode && (s = prop[inputData.attrTravelMode]) !== undefined)
                            travel.mode = +s;
                    }
                    if (inputData.attrWorkduration && (s = prop[inputData.attrWorkduration]) !== undefined)
                        task.setTotalWorkTime(Scheduler.minutesToMiliseconds(+s));
                    //if (prop.scheduledbreak !== undefined) // scheduledBreak is not used now
                    //	task.scheduledBreak = minutesToMiliseconds(+prop.scheduledbreak);
                    if (inputData.attrWindowStart) {
                        var wStart = prop[inputData.attrWindowStart];
                        var wEnd = prop[inputData.attrWindowEnd];
                        if (wStart > 0 && wStart < wEnd)
                            task.requiredWindow = new Scheduler.TimeRange(wStart, wEnd);
                    }
                    if (statuscode !== undefined) {
                        task.setStatus(Scheduler.Container.statusCodeTable.getStatusByValue(statuscode));
                        if (!task.isEditable()) {
                            if (startDate && endDate) {
                                var scheduledDuration = endDate.valueOf() - startDate.valueOf();
                                if (inputData.attrStartedOn) {
                                    if ((s = prop[inputData.attrStartedOn])) {
                                        startDate = new Date(s);
                                        s = prop[inputData.attrEndedOn];
                                        endDate = s ? new Date(s) : new Date(startDate.valueOf() + scheduledDuration);
                                    }
                                    else if ((s = prop[inputData.attrArrivedOn])) {
                                        startDate = new Date(s);
                                        endDate = new Date(startDate.valueOf() + scheduledDuration);
                                    }
                                }
                            }
                        }
                    }
                    if (startDate) {
                        task.setWorkStart(startDate.valueOf());
                        task.hasScheduledStart = true;
                    }
                    if (endDate) {
                        var start = task.getWorkStart();
                        var end = endDate.valueOf();
                        if (end < start)
                            end = start;
                        task.setTotalWorkTime(end - start);
                    }
                };
                DataProvider.prototype.hideUnscheduledTasksEntities = function (ids, redraw, onFinishCallback) {
                    if (Scheduler.Container.constants.hideUnscheduledTaskAfterScheduling) {
                        var wasAdded = false;
                        for (var i = 0; i < ids.length; i++) {
                            var id = ids[i];
                            var index = this._hiddenHorizontalListEntitiesIds.indexOf(id);
                            if (index === -1) {
                                this._hiddenHorizontalListEntitiesIds.push(id);
                                wasAdded = true;
                            }
                        }
                        if (wasAdded) {
                            Scheduler.Container.ref.updateHorizontalListController(redraw, onFinishCallback);
                            return;
                        }
                    }
                    if (onFinishCallback)
                        onFinishCallback();
                };
                DataProvider.prototype.showUnscheduledTasksEntities = function (ids, redraw, onFinishCallback) {
                    if (Scheduler.Container.constants.hideUnscheduledTaskAfterScheduling) {
                        var wasRemoved = false;
                        if (ids.length === 1) {
                            // search from end, because searched item will be the last item or close to end.
                            var index = this._hiddenHorizontalListEntitiesIds.lastIndexOf(ids[0]);
                            if ((0 <= index) && (index < this._hiddenHorizontalListEntitiesIds.length)) {
                                this._hiddenHorizontalListEntitiesIds.splice(index, 1);
                                wasRemoved = true;
                            }
                        }
                        else {
                            for (var i = 0; i < ids.length; i++) {
                                var index = this._hiddenHorizontalListEntitiesIds.indexOf(ids[i]);
                                if ((0 <= index) && (index < this._hiddenHorizontalListEntitiesIds.length)) {
                                    this._hiddenHorizontalListEntitiesIds.splice(index, 1);
                                    wasRemoved = true;
                                }
                            }
                        }
                        if (wasRemoved) {
                            Scheduler.Container.ref.updateHorizontalListController(redraw, onFinishCallback);
                            return;
                        }
                    }
                    if (onFinishCallback)
                        onFinishCallback();
                };
                return DataProvider;
            }());
            Scheduler.DataProvider = DataProvider;
            var RuleResult = (function () {
                function RuleResult(msg, srcEntity) {
                    if (msg === void 0) { msg = undefined; }
                    if (srcEntity === void 0) { srcEntity = undefined; }
                    this.errorMsg = msg;
                    this._sourceEntity = srcEntity;
                }
                Object.defineProperty(RuleResult.prototype, "sourceEntity", {
                    get: function () {
                        return this._sourceEntity;
                    },
                    enumerable: true,
                    configurable: true
                });
                ;
                RuleResult.prototype.updateSource = function () {
                    return __awaiter(this, void 0, void 0, function () {
                        return __generator(this, function (_a) {
                            if (this._sourceEntity)
                                this._sourceEntity.saveAsync();
                            return [2 /*return*/];
                        });
                    });
                };
                return RuleResult;
            }());
            var CreateRule = (function () {
                function CreateRule(input) {
                    this.ActivityEntity = "Activity Entity";
                    this.SourceEntity = "Source Entity";
                    this.m_metaDataCache = new Resco.Dictionary();
                    this.m_createRule = input.createRule;
                    if (this.m_createRule) {
                        this.activityName = input.scheduledTasks.entityName;
                        this.activitySourceRef = input.scheduledTasks.attrSourceRef;
                        if (this.m_createRule.indexOf(this.ActivityEntity) < 0) {
                            this.activityName = null;
                        }
                        if (input.unscheduledTasks && this.activitySourceRef) {
                            this.sourceName = input.unscheduledTasks.entityName;
                            this.sourceKeyName = input.unscheduledTasks.primaryKeyName;
                            if (!this.sourceKeyName || this.m_createRule.indexOf(this.SourceEntity) < 0)
                                this.sourceName = null;
                        }
                    }
                }
                Object.defineProperty(CreateRule.prototype, "needModifyTask", {
                    get: function () {
                        return this.activityName && this.activityName.length > 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(CreateRule.prototype, "needModifySource", {
                    get: function () {
                        return this.activityName && this.activityName.length > 0;
                    },
                    enumerable: true,
                    configurable: true
                });
                CreateRule.prototype.executeCreateRule = function (entity) {
                    return __awaiter(this, void 0, void 0, function () {
                        var self, activityMeta, srcMeta, srcMeta, e_1;
                        return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0:
                                    self = this;
                                    if (!this.m_createRule)
                                        return [2 /*return*/, undefined];
                                    _a.label = 1;
                                case 1:
                                    _a.trys.push([1, 9, , 10]);
                                    if (!self.activityName) return [3 /*break*/, 5];
                                    return [4 /*yield*/, this._getMetaEntity(self.activityName)];
                                case 2:
                                    activityMeta = _a.sent();
                                    if (!self.sourceName) return [3 /*break*/, 4];
                                    return [4 /*yield*/, this._getMetaEntity(self.sourceName)];
                                case 3:
                                    srcMeta = _a.sent();
                                    return [2 /*return*/, self._executeCreateRule(entity, activityMeta, srcMeta)];
                                case 4: return [2 /*return*/, self._executeCreateRule(entity, activityMeta, undefined)];
                                case 5:
                                    if (!self.sourceName) return [3 /*break*/, 7];
                                    return [4 /*yield*/, this._getMetaEntity(self.sourceName)];
                                case 6:
                                    srcMeta = _a.sent();
                                    return [2 /*return*/, self._executeCreateRule(entity, undefined, srcMeta)];
                                case 7: return [2 /*return*/, undefined];
                                case 8: return [3 /*break*/, 10];
                                case 9:
                                    e_1 = _a.sent();
                                    return [2 /*return*/, new RuleResult(e_1.message)];
                                case 10: return [2 /*return*/];
                            }
                        });
                    });
                };
                CreateRule.prototype._getMetaEntity = function (entityName) {
                    var _this = this;
                    return new Promise(function (resolve, reject) {
                        var meta = _this.m_metaDataCache.getValue(entityName);
                        if (meta) {
                            //var meta = MobileCRM.Metadata.getEntity(entityName);
                            resolve(meta);
                        }
                        else {
                            MobileCRM.MetaEntity.loadByName(entityName, function (meta) {
                                _this.m_metaDataCache.set(entityName, meta);
                                resolve(meta);
                            }, function (error) {
                                reject(new Resco.Exception(error));
                            });
                        }
                    });
                };
                CreateRule.prototype._createDynamicEntity = function (entityName, meta, entity) {
                    if (entity === void 0) { entity = undefined; }
                    var repo = new MobileCrm.Data.DynamicRepository();
                    // initialize repository with properties obtained through JSBridge
                    meta.properties.forEach(function (prop) { return repo.add(new MobileCrm.Data.MetaProperty(prop.name, prop.type, prop.targets)); });
                    var ret = new MobileCrm.Data.DynamicEntity(entityName, repo);
                    if (entity) {
                        meta.properties.forEach(function (prop) {
                            var value = entity.properties[prop.name];
                            if (value)
                                ret.trySetValue(prop.name, value);
                        });
                    }
                    return ret;
                };
                CreateRule.prototype._updateValues = function (entity, data, variables) {
                    data.repository.properties.forEach(function (metaProp) {
                        var variable = variables.entity.tryGetValue(metaProp.name).value; // TODO: make sure that dates are formatted as required by JSBridge;
                        if (variable)
                            entity.properties[metaProp.name] = variable;
                    });
                };
                CreateRule.prototype._executeCreateRule = function (entity, activityMeta, srcMeta) {
                    var activityEntity = activityMeta ? this._createDynamicEntity(this.activityName, activityMeta, entity) : null;
                    var variables = new Resco.Dictionary();
                    var activityVar = new MobileCrm.UI.Workflow.EntityVariable(activityEntity);
                    var sourceVar = null;
                    var sourceEntity = null;
                    var sourceRef = null;
                    variables.add(this.ActivityEntity, activityVar);
                    if (srcMeta && this.activitySourceRef && entity && (sourceRef = entity.properties[this.activitySourceRef])) {
                        sourceEntity = this._createDynamicEntity(this.sourceName, srcMeta);
                        sourceEntity.trySetValue(this.sourceKeyName, sourceRef.id);
                        variables.add(this.SourceEntity, sourceVar = new MobileCrm.UI.Workflow.EntityVariable(sourceEntity));
                    }
                    var errorMessageVar = new MobileCrm.UI.Workflow.SimpleVariable("ErrorMessage", MobileCrm.Data.CrmType.String, "");
                    variables.add("ErrorMessage", errorMessageVar);
                    //variables.add("Configuration", configVar = new MobileCrm.UI.Workflow.ConfigurationVariable(/*MobileCrm.UI.Configuration.instance.constants*/));
                    //var colorVariable = new MobileCrm.UI.Workflow.SimpleVariable("Color", MobileCrm.Data.CrmType.String, false);
                    //variables.add("Color", colorVariable);
                    var r = MobileCrm.UI.Workflow.Engine.setup(this.m_createRule, this.activityName, variables);
                    this.m_createRule = r.workflow; // cache the workflow
                    if (r.context && r.context.execute()) {
                        var srcEntity = undefined;
                        if (sourceVar) {
                            srcEntity = new MobileCRM.DynamicEntity(sourceEntity.entityName, sourceRef.id, sourceRef.name);
                            this._updateValues(srcEntity, sourceEntity, sourceVar);
                            //srcEntity[this.sourceKeyName] = sourceId;
                        }
                        if (entity)
                            this._updateValues(entity, activityEntity, activityVar);
                        return new RuleResult(errorMessageVar.value, srcEntity);
                    }
                    return undefined;
                };
                return CreateRule;
            }());
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
