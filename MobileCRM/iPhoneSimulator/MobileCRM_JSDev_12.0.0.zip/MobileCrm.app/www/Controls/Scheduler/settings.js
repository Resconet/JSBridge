///<reference path="../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="stringTable.ts" />
///<reference path="interfaces.ts" />
///<reference path="geo.ts" />
///<reference path="timeRange.ts" />
///<reference path="utilities.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            // Optimization mode used when user move by task
            var eMode;
            (function (eMode) {
                eMode[eMode["Manual"] = 0] = "Manual";
                eMode[eMode["SemiOptimized"] = 1] = "SemiOptimized";
                eMode[eMode["Optimized"] = 2] = "Optimized";
                eMode[eMode["RouteOptimization"] = 3] = "RouteOptimization"; // optimize daily route for selected resource 
            })(eMode = Scheduler.eMode || (Scheduler.eMode = {}));
            // Define how optimization algorithm will work with unrealized tasks (tasks scheduled before actual time).
            var eUnrealizedTaskStrategy;
            (function (eUnrealizedTaskStrategy) {
                eUnrealizedTaskStrategy[eUnrealizedTaskStrategy["DoNothing"] = 0] = "DoNothing";
                eUnrealizedTaskStrategy[eUnrealizedTaskStrategy["SetAsCanceled"] = 1] = "SetAsCanceled";
                eUnrealizedTaskStrategy[eUnrealizedTaskStrategy["SetAsUnscheduled"] = 2] = "SetAsUnscheduled"; // set such task as unscheduled and try to reschedule it
            })(eUnrealizedTaskStrategy = Scheduler.eUnrealizedTaskStrategy || (Scheduler.eUnrealizedTaskStrategy = {}));
            var AutoPlannerSettings = (function () {
                function AutoPlannerSettings(settings) {
                    this.manualScheduleMode = eMode.SemiOptimized;
                    this.autoScheduleMode = eMode.Optimized;
                    this.minGapBetweenTaskAndPlanning = 30 * Scheduler.minuteInMiliseconds;
                    this.minGapBetweenTasks = 10 * Scheduler.minuteInMiliseconds;
                    this.maxOvertimePerDay = 0;
                    this.autoScheduleNewTasks = true;
                    this.autoScheduleConflictedTasks = true;
                    this.autoScheduleTasksYetNotStarted = false;
                    this.calculateTravel = false;
                    this.unrealizedTaskStrategy = eUnrealizedTaskStrategy.DoNothing;
                    if (settings) {
                        this.manualScheduleMode = settings.manualScheduleMode;
                        this.autoScheduleMode = settings.autoScheduleMode;
                        this.minGapBetweenTaskAndPlanning = settings.minGapBetweenTaskAndPlanning !== undefined ? settings.minGapBetweenTaskAndPlanning : 30 * Scheduler.minuteInMiliseconds;
                        this.minGapBetweenTasks = settings.minGapBetweenTasks !== undefined ? settings.minGapBetweenTasks : 10 * Scheduler.minuteInMiliseconds;
                        this.autoScheduleNewTasks = settings.autoScheduleNewTasks;
                        this.autoScheduleConflictedTasks = settings.autoScheduleConflictedTasks;
                        this.autoScheduleTasksYetNotStarted = settings.autoScheduleTasksYetNotStarted;
                        this.maxOvertimePerDay = settings.maxOvertimePerDay;
                        this.calculateTravel = settings.calculateTravel;
                        this.unrealizedTaskStrategy = settings.unrealizedTaskStrategy;
                    }
                }
                return AutoPlannerSettings;
            }());
            Scheduler.AutoPlannerSettings = AutoPlannerSettings;
            // Class specifying basic data filtration conditions
            var Settings = (function () {
                function Settings(settings) {
                    this.version = Settings.VERSION;
                    this.isDirty = false;
                    this.zoomLevel = "d";
                    this.selectedDate = new Date();
                    this.showCompletedAndCanceled = false;
                    this.showWeekendsAndHolidays = false;
                    this.startWorkingHour = 0;
                    this.endWorkingHour = 24;
                    this.moveStepInMinutes = 15;
                    this.roundMinutes = 5;
                    this.customFilterSelection = {};
                    this.autoPlanner = new AutoPlannerSettings();
                    if (settings)
                        this.copy(settings);
                    this.isDirty = false;
                }
                Settings.prototype.setDirty = function () {
                    this.isDirty = true;
                };
                Settings.prototype.monthOverviewMode = function () {
                    return this.zoomLevel && this.zoomLevel.charAt(0) === 'm';
                };
                Settings.prototype.hasValidWorkingHours = function () {
                    return (this.startWorkingHour > 0 || this.endWorkingHour < 24) && this.startWorkingHour < 24 && this.endWorkingHour > this.startWorkingHour;
                };
                Settings.prototype.selectDate = function (selectedDate) {
                    this.selectedDate = selectedDate;
                };
                Settings.prototype.copy = function (src) {
                    this.zoomLevel = src.zoomLevel;
                    this.selectedDate = new Date(src.selectedDate);
                    this.showCompletedAndCanceled = src.showCompletedAndCanceled;
                    this.showWeekendsAndHolidays = src.showWeekendsAndHolidays;
                    this.startWorkingHour = src.startWorkingHour;
                    this.endWorkingHour = src.endWorkingHour;
                    this.resourceView = src.resourceView;
                    this.unscheduledView = src.unscheduledView;
                    this.scheduledView = src.scheduledView;
                    this.daysWhenSourcesIsNotOfferedForScheduling = src.daysWhenSourcesIsNotOfferedForScheduling;
                    this.defaultTaskDuration = src.defaultTaskDuration;
                    this.moveStepInMinutes = src.moveStepInMinutes;
                    this.roundMinutes = src.roundMinutes;
                    this.customFilterSelection = {};
                    this.autoPlanner = new AutoPlannerSettings(src.autoPlanner);
                    if (src.version >= Settings.VERSION) {
                        for (var prop in src.customFilterSelection) {
                            var ids = src.customFilterSelection[prop];
                            if (ids && ids.length) {
                                var arr = [];
                                this.customFilterSelection[prop] = Scheduler.mergeArrays(arr, ids);
                            }
                        }
                    }
                };
                Settings.prototype.equal = function (src) {
                    if (this.zoomLevel !== src.zoomLevel ||
                        this.selectedDate.valueOf() !== src.selectedDate.valueOf() ||
                        this.showCompletedAndCanceled !== src.showCompletedAndCanceled ||
                        this.showWeekendsAndHolidays !== src.showWeekendsAndHolidays ||
                        this.startWorkingHour !== src.startWorkingHour ||
                        this.endWorkingHour !== src.endWorkingHour ||
                        this.resourceView !== src.resourceView ||
                        this.unscheduledView !== src.unscheduledView ||
                        this.scheduledView !== src.scheduledView ||
                        this.moveStepInMinutes !== src.moveStepInMinutes ||
                        this.roundMinutes !== src.roundMinutes ||
                        this.daysWhenSourcesIsNotOfferedForScheduling !== src.daysWhenSourcesIsNotOfferedForScheduling ||
                        this.defaultTaskDuration !== src.defaultTaskDuration)
                        return false;
                    for (var i = 0; i < Scheduler.FilterList.CustomFilters.length; i++) {
                        var name_1 = Scheduler.FilterList.CustomFilters[i].name;
                        var srcList = src.customFilterSelection[name_1];
                        var dstList = this.customFilterSelection[name_1];
                        if (!Scheduler.arraysAreEqual(srcList, dstList))
                            return false;
                    }
                    return true;
                };
                Settings.prototype.load = function (onLoad, fileName) {
                    var _this = this;
                    Scheduler.IO.read(fileName, function (settings) {
                        if (settings && settings.version == Settings.VERSION) {
                            _this.copy(settings);
                            _this.savedCopy = new Settings(_this);
                        }
                        _this.isDirty = false;
                        onLoad();
                    });
                };
                Settings.prototype.save = function (fileName) {
                    var _this = this;
                    if (fileName && (this.isDirty || !this.savedCopy || !this.equal(this.savedCopy))) {
                        var json = JSON.stringify(this, function (key, value) {
                            if (key == "isDirty" || key == "savedCopy" || key == "idAttribute" || key == "nameAttribute" || key == "nameInPlural")
                                return undefined;
                            else
                                return value;
                        });
                        this.isDirty = false;
                        Scheduler.IO.save(fileName, json, function (err) { _this.savedCopy = new Settings(_this); });
                    }
                };
                return Settings;
            }());
            Settings.VERSION = 1;
            Scheduler.Settings = Settings;
            var Office = (function () {
                function Office() {
                    this._startWorkingTime = 0; // Cannot be undefined, because it is used in workingDayDuration setter!
                    this._workingDayDuration = 0; // Cannot be undefined, because it is used in startWorkingTime setter!
                    this.locationAddress = null;
                    this.location = new Scheduler.Location(undefined);
                    // ensures that Office fields have valid values
                    this.firstDayOfWeek = 1;
                    this.startWorkingTime = 60 * 8;
                    this.workingDayDuration = 60 * 8 + 30;
                    this.breakPerDay = 30;
                    this.workingWeekends = false;
                }
                Object.defineProperty(Office.prototype, "firstDayOfWeek", {
                    get: function () {
                        return this._firstDayOfWeek;
                    },
                    set: function (value) {
                        if (value < 0)
                            value = 0;
                        if (value > 6)
                            value = 6;
                        this._firstDayOfWeek = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Office.prototype, "startWorkingTime", {
                    get: function () {
                        return this._startWorkingTime;
                    },
                    set: function (value) {
                        // startWorkingTime value must be within one day
                        if (value < 0)
                            value = 0;
                        if (value > ((24 * 60) - 1))
                            value = ((24 * 60) - 1);
                        this._startWorkingTime = value;
                        this.workingDayDuration = this.workingDayDuration; // restrict according to the new startWorkingTime value
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Office.prototype, "workingDayDuration", {
                    get: function () {
                        return this._workingDayDuration;
                    },
                    set: function (value) {
                        // workingDayDuration value must be within the same day regarding to the startWorkingTime
                        if (value < 0)
                            value = 0;
                        if ((value + this.startWorkingTime) > (24 * 60))
                            value = (24 * 60) - this.startWorkingTime;
                        this._workingDayDuration = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Office.prototype, "breakPerDay", {
                    get: function () {
                        return this._breakPerDay;
                    },
                    set: function (value) {
                        if (value < 0)
                            value = 0;
                        if (value > (24 * 60))
                            value = (24 * 60);
                        this._breakPerDay = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Office.prototype, "workingWeekends", {
                    get: function () {
                        return this._workingWeekends;
                    },
                    set: function (value) {
                        this._workingWeekends = value ? true : false;
                    },
                    enumerable: true,
                    configurable: true
                });
                Office.prototype.checkWeekendWork = function (timeRange) {
                    if (!this.workingWeekends) {
                        var startDate = new Date(timeRange.start);
                        return !Scheduler.Utilities.isWeekend(startDate.getDay());
                    }
                    return true;
                };
                // !!!Check deeply before use if this and internal respective methods works as expected properly!!!
                Office.prototype.validateWorkingStartTime = function (start, workDuration) {
                    var date = new Date(start);
                    var workDuration = Math.ceil(workDuration / Scheduler.minuteInMiliseconds);
                    var dayInMinutes = date.getHours() * 60 + date.getMinutes();
                    if (workDuration < this.workingDayDuration && (dayInMinutes + workDuration) > (this.startWorkingTime + this.workingDayDuration))
                        return this._getStartWorkingTime(start, 1).valueOf();
                    else if (dayInMinutes < this.startWorkingTime)
                        return this._getStartWorkingTime(start, 0).valueOf();
                    else if (this.workingWeekends === false) {
                        if (date.getDay() === 0)
                            return this._getStartWorkingTime(start, 1).valueOf();
                        else if (date.getDay() === 6)
                            return this._getStartWorkingTime(start, 2).valueOf();
                    }
                    return start;
                };
                Office.prototype.findNextWorkingTimeBegin = function (time) {
                    var timeDate = new Date(time);
                    var startWorkingDate = new Date(timeDate.getFullYear(), timeDate.getMonth(), timeDate.getDate(), 0, this.startWorkingTime);
                    if (time >= startWorkingDate.valueOf()) {
                        startWorkingDate = this._getNextDayDate(startWorkingDate);
                    }
                    if (!this.workingWeekends) {
                        while (Scheduler.Utilities.isHoliday(startWorkingDate)) {
                            startWorkingDate = this._getNextDayDate(startWorkingDate);
                        }
                    }
                    return startWorkingDate.valueOf();
                };
                /**
                 * Returns array of working hours time ranges that input timeRange interval at least partially contains.
                 * Start of first and end of last working hours time range is restricted according to timeRange interval given by argument.
                 * @param timeRange Interval that contains working hours time ranges.
                 */
                Office.prototype.getWorkingSlots = function (timeRange) {
                    if (timeRange.start === undefined || timeRange.start === null)
                        return [];
                    var ranges = this.getWorkingHoursTimeRanges(timeRange);
                    if (ranges.length > 0) {
                        if (ranges[0].start < timeRange.start)
                            ranges[0].start = timeRange.start;
                        if ((ranges[ranges.length - 1].end > timeRange.end))
                            ranges[ranges.length - 1].end = timeRange.end;
                    }
                    return ranges;
                };
                Office.prototype._getStartWorkingTime = function (start, shiftNumOfDays) {
                    var date = new Date(start += shiftNumOfDays * Scheduler.dayInMiliseconds);
                    if (!this.workingWeekends) {
                        if (date.getDay() === 0)
                            date = new Date(start + Scheduler.dayInMiliseconds);
                        else if (date.getDay() === 6)
                            date = new Date(start + 2 * Scheduler.dayInMiliseconds);
                    }
                    var h = this.startWorkingTime / 60;
                    var m = this.startWorkingTime - h * 60;
                    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), h, m, 0);
                };
                /**
                 * Returns time range of the earliest (next) working hours or null if earliest working hours are out of the timeRange.
                 * @param time in milliseconds for which we want to compute earliest working hours (does not need to be within working hours)
                 * @param timeRange that bound time span where earliest working hours should be find
                 */
                Office.prototype.getEarliestWorkingHoursRange = function (time, timeRange) {
                    if (timeRange) {
                        if (time >= timeRange.end)
                            return null;
                        if (time < timeRange.start)
                            time = timeRange.start;
                    }
                    var timeDate = new Date(time);
                    var timeYear = timeDate.getFullYear();
                    var timeMonth = timeDate.getMonth();
                    var timeDay = timeDate.getDate();
                    var startWorkingMinutes = this.startWorkingTime;
                    var endWorkingMinutes = startWorkingMinutes + this.workingDayDuration;
                    var startWorkingDate = new Date(timeYear, timeMonth, timeDay, 0, startWorkingMinutes);
                    var endWorkingDate = new Date(timeYear, timeMonth, timeDay, 0, endWorkingMinutes);
                    if (time >= endWorkingDate.valueOf()) {
                        // move to nextDay
                        startWorkingDate = this._getNextDayDate(startWorkingDate);
                        endWorkingDate = this._getNextDayDate(endWorkingDate);
                    }
                    if (!this.workingWeekends) {
                        while (Scheduler.Utilities.isHoliday(startWorkingDate)) {
                            // move to nextDay
                            startWorkingDate = this._getNextDayDate(startWorkingDate);
                            endWorkingDate = this._getNextDayDate(endWorkingDate);
                        }
                    }
                    return new Scheduler.TimeRange(startWorkingDate.valueOf(), endWorkingDate.valueOf());
                };
                /**
                 * Returns time range of the last (previous) working hours or null if last working hours are out of the timeRange.
                 * @param time in milliseconds for which we want to compute last working hours (does not need to be within working hours)
                 * @param timeRange that bound time span where last working hours should be find
                 */
                Office.prototype.getLastWorkingHoursRange = function (time, timeRange) {
                    if (timeRange) {
                        if (time < timeRange.start)
                            return null;
                        if (time >= timeRange.end)
                            time = timeRange.end - 1; // time must be inside statistic time range interval (where start is included, but end is not included)
                    }
                    var timeDate = new Date(time);
                    var timeYear = timeDate.getFullYear();
                    var timeMonth = timeDate.getMonth();
                    var timeDay = timeDate.getDate();
                    var startWorkingMinutes = this.startWorkingTime;
                    var endWorkingMinutes = startWorkingMinutes + this.workingDayDuration;
                    var startWorkingDate = new Date(timeYear, timeMonth, timeDay, 0, startWorkingMinutes);
                    var endWorkingDate = new Date(timeYear, timeMonth, timeDay, 0, endWorkingMinutes);
                    if (time < startWorkingDate.valueOf()) {
                        // move to previousDay
                        startWorkingDate = this._getPreviousDayDate(startWorkingDate);
                        endWorkingDate = this._getPreviousDayDate(endWorkingDate);
                    }
                    if (!this.workingWeekends) {
                        while (Scheduler.Utilities.isHoliday(startWorkingDate)) {
                            // move to previousDay
                            startWorkingDate = this._getPreviousDayDate(startWorkingDate);
                            endWorkingDate = this._getPreviousDayDate(endWorkingDate);
                        }
                    }
                    return new Scheduler.TimeRange(startWorkingDate.valueOf(), endWorkingDate.valueOf());
                };
                /**
                 * Returns date plus one day.
                 * @param date
                 */
                Office.prototype._getNextDayDate = function (date) {
                    return new Date(date.valueOf() + Scheduler.dayInMiliseconds);
                };
                /**
                 * Returns date minus one day.
                 * @param date
                 */
                Office.prototype._getPreviousDayDate = function (date) {
                    return new Date(date.valueOf() - Scheduler.dayInMiliseconds);
                };
                /**
                 * Returns array of working hours time ranges that input timeRange interval at least partially contains.
                 * @param timeRange Interval that contains working hours time ranges.
                 */
                Office.prototype.getWorkingHoursTimeRanges = function (timeRange) {
                    var ranges = [];
                    var currentRange = this.getEarliestWorkingHoursRange(timeRange.start);
                    while (currentRange.start < timeRange.end) {
                        ranges.push(currentRange);
                        if (currentRange.end >= timeRange.end)
                            break;
                        currentRange = this.getEarliestWorkingHoursRange(currentRange.end);
                    }
                    return ranges;
                };
                /**
                 * Divides work interval into work sub intervals that are placed within working hours only.
                 * These work sub intervals are restricted by travel to and travel from duration, because resource needs to travel
                 * every day to and from the place where the work is performing.
                 * Returns array of time ranges that represent individual work sub intervals.
                 * @param workTimeRange Work interval.
                 * @param travelTo Travel to duration.
                 * @param travelFrom Travel from duration.
                 */
                Office.prototype.getWorkTimeRanges = function (workTimeRange, travelTo, travelFrom) {
                    var ranges = [];
                    var currentRange = this.getEarliestWorkingHoursRange(workTimeRange.start);
                    if (workTimeRange.isInside(currentRange)) {
                        ranges.push(new Scheduler.TimeRange(workTimeRange.start, workTimeRange.end));
                        return ranges;
                    }
                    var duration = workTimeRange.duration();
                    var splitMinWorkTime = Scheduler.Container.constants.viewSplitMinWorkMinutes * Scheduler.minuteInMiliseconds;
                    var start;
                    var end;
                    if (currentRange.timeIsInside(workTimeRange.start)) {
                        if ((workTimeRange.start + splitMinWorkTime) > (currentRange.end - travelFrom)) {
                            currentRange = this.getEarliestWorkingHoursRange(currentRange.end);
                            start = currentRange.start + travelTo;
                            end = currentRange.end - travelFrom;
                        }
                        else {
                            start = workTimeRange.start;
                            end = currentRange.end - travelFrom;
                        }
                    }
                    else {
                        start = currentRange.start + travelTo;
                        end = currentRange.end - travelFrom;
                    }
                    while (true) {
                        if ((start + splitMinWorkTime) > end) {
                            ranges = [];
                            ranges.push(new Scheduler.TimeRange(workTimeRange.start, workTimeRange.end));
                            return ranges;
                        }
                        if ((duration - (end - start)) <= 0) {
                            break;
                        }
                        duration -= end - start;
                        ranges.push(new Scheduler.TimeRange(start, end));
                        currentRange = this.getEarliestWorkingHoursRange(currentRange.end);
                        start = currentRange.start + travelTo;
                        end = currentRange.end - travelFrom;
                    }
                    end = start + duration;
                    ranges.push(new Scheduler.TimeRange(start, end));
                    return ranges;
                };
                /**
                 * Returns time range of the real working day where the time given by argument is present.
                 * This time range represents time span of one day that does not need to begin at 00:00 and end at 00:00 next day, because it is shifted according working shift.
                 * @param time in milliseconds for which we want to compute working day range
                 */
                Office.prototype.getWorkingDayRange = function (time) {
                    var workingTimeDuration = this.workingDayDuration * Scheduler.minuteInMiliseconds;
                    var endWorkingTime = (this.startWorkingTime * Scheduler.minuteInMiliseconds) + workingTimeDuration;
                    var nextWorkingDayOffset = (endWorkingTime + ((Scheduler.dayInMiliseconds - workingTimeDuration) / 2)) % Scheduler.dayInMiliseconds; // offset between day beginning (00:00) and real working day beginning (in the middle of not working time) of the next day
                    var timeDate = new Date(time);
                    var timeYear = timeDate.getFullYear();
                    var timeMonth = timeDate.getMonth();
                    var timeDay = timeDate.getDate();
                    var timeBaseTime = new Date(timeYear, timeMonth, timeDay).valueOf();
                    var timeDayOffset = time - timeBaseTime;
                    var startWorkingDayTime;
                    var endWorkingDayTime;
                    if (timeDayOffset < nextWorkingDayOffset) {
                        endWorkingDayTime = timeBaseTime + nextWorkingDayOffset;
                        startWorkingDayTime = endWorkingDayTime - Scheduler.dayInMiliseconds;
                    }
                    else {
                        startWorkingDayTime = timeBaseTime + nextWorkingDayOffset;
                        endWorkingDayTime = startWorkingDayTime + Scheduler.dayInMiliseconds;
                    }
                    return new Scheduler.TimeRange(startWorkingDayTime, endWorkingDayTime);
                };
                Office.prototype.setFirstDayOfThisWeek = function (date) {
                    var firstDayOfWeek = this.firstDayOfWeek;
                    var weekDay = date.getDay();
                    var diff = (weekDay - firstDayOfWeek) + ((weekDay < firstDayOfWeek) ? 7 : 0);
                    date.setDate(date.getDate() - diff);
                };
                return Office;
            }());
            Scheduler.Office = Office;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
