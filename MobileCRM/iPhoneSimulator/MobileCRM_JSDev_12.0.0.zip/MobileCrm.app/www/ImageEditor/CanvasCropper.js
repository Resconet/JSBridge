var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var CanvasCropper = /** @class */ (function (_super) {
            __extends(CanvasCropper, _super);
            function CanvasCropper(canvas, drawingImage, backgroundImage, canvasProperties, x, y, w, h) {
                return _super.call(this, canvas, drawingImage, backgroundImage, canvasProperties, x, y, w, h) || this;
            }
            // return size and position of the selected area
            CanvasCropper.prototype.GetCroppedImageCanvas = function () {
                var temp_canvas = document.createElement('canvas');
                var temp_ctx = temp_canvas.getContext('2d');
                temp_ctx.canvas.width = this.w * this.canvasProperties.ImageRatio;
                temp_ctx.canvas.height = this.h * this.canvasProperties.ImageRatio;
                temp_ctx.drawImage(this.backgroundImage, this.x * this.canvasProperties.ImageRatio, this.y * this.canvasProperties.ImageRatio, this.w * this.canvasProperties.ImageRatio, this.h * this.canvasProperties.ImageRatio, 0, 0, this.w * this.canvasProperties.ImageRatio, this.h * this.canvasProperties.ImageRatio);
                temp_ctx.drawImage(this.drawingImage, this.x * this.canvasProperties.ImageRatio, this.y * this.canvasProperties.ImageRatio, this.w * this.canvasProperties.ImageRatio, this.h * this.canvasProperties.ImageRatio, 0, 0, this.w * this.canvasProperties.ImageRatio, this.h * this.canvasProperties.ImageRatio);
                this.dispose();
                return temp_canvas;
            };
            CanvasCropper.prototype.afterSelectionDrawn = function () { };
            return CanvasCropper;
        }(ImageEditor.CanvasSelector));
        ImageEditor.CanvasCropper = CanvasCropper;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=CanvasCropper.js.map