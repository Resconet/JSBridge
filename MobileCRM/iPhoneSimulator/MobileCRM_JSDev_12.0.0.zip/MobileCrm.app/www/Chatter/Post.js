/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="User.ts" />
/// <reference path="Localization.ts" />
/// <reference path="Chatter.ts" />
/// <reference path="Reference.ts" />
/// <reference path="MEditor.ts" />
var Chatter;
(function (Chatter) {
    var Post = (function () {
        function Post(id, topic) {
            var _this = this;
            this.id = id;
            this.topic = topic;
            this.content = ko.observable();
            this.modifiedOn = ko.observable();
            this.createdOn = ko.observable();
            this.isExpanded = ko.observable();
            this.user = ko.observable();
            this.reactions = ko.observableArray();
            this.attachments = ko.observableArray();
            this.regarding = ko.observable();
            this.pending = ko.observable(false);
            this.mEditor = null;
            this.isSending = ko.observable(false);
            this.showPrefix = ko.observable(true);
            this.showDateHeader = ko.observable(true);
            this.dateHeader = ko.observable();
            this.modifiedOnLabel = ko.computed(function () {
                return Chatter.Localization.printTime(_this.modifiedOn());
            }, this);
            this.editorEmpty = ko.observable(true);
            this.surveyQuestion = null;
            this.surveyOptions = [];
        }
        Post.prototype.parseSurvey = function () {
            var _this = this;
            var content = this.content();
            if (content && content.substr(0, 5).toLowerCase() == "/poll") {
                var matches = content.replace(/&quot;/g, '"').match(/\x22[^\x22]*\x22/g);
                if (matches.length >= 2) {
                    var trimQuotes = function (s) { var l = s.length; return ((l > 2 && s.charAt(0) == '"') ? s.substr(1, l - 2) : s).replace(/&apos;/g, "'"); };
                    this.surveyQuestion = trimQuotes(matches.shift());
                    var index = 0;
                    this.surveyOptions = matches.map(function (q) { return new SurveyOption(trimQuotes(q), ++index, function (option) { return _this.addReaction(option.index.toString(), null); }); });
                    return true;
                }
            }
            return false;
        };
        Post.prototype.getSurveyQuestion = function () {
            var content = this.content();
            var qStart = content.indexOf('"');
            var qEnd = content.indexOf('"', qStart + 1);
            return qEnd > 0 ? content.substring(qStart + 1, qEnd) : null;
        };
        Post.prototype.addReaction = function (type, user) {
            if (!user)
                user = Chatter.Topic.instance.loggedUser();
            var reaction = null;
            this.reactions().forEach(function (value, index, arr) {
                if (value.name == type)
                    reaction = value;
            });
            if (reaction == null)
                this.reactions.push(reaction = new Reaction(type));
            if (!reaction.users().some(function (u) { return u.id == user.id; })) {
                MobileCRM.bridge.command("addReaction", JSON.stringify([this.id, user.id, type]), function (data) { return reaction.users.push(user); }, Chatter.Topic.onError, this);
            }
        };
        Post.prototype.updateDateHeader = function (visible) {
            var m = this.modifiedOn();
            var d = (visible && m) ? Chatter.Localization.printFriendlyDay(m) : "";
            this.showDateHeader(visible);
            this.dateHeader(d);
        };
        Post.prototype.fromClicked = function (data, event) {
            MobileCRM.bridge.command("fromClicked", data.user().id, null, null, null);
        };
        Post.prototype.updateReactions = function (comments) {
            var reactionsArr = new Array();
            if (comments && comments.length > 0) {
                var reactions = new Object();
                for (var i = 0; i < comments.length; i++) {
                    var comment = comments[i];
                    var reaction = null;
                    var type = comment.text;
                    if (reactions.hasOwnProperty(type))
                        reaction = reactions[type];
                    else
                        reactions[type] = reaction = new Reaction(type);
                    var user = Chatter.Topic.instance.getUser(comment.userId);
                    reaction.users.push(user);
                }
                for (var t in reactions) {
                    reactionsArr.push(reactions[t]);
                }
            }
            this.reactions(reactionsArr);
        };
        Post.prototype.updateAttachments = function (attachments) {
            this.attachments.removeAll();
            if (attachments && attachments.length > 0) {
                var len = attachments.length;
                var arr = new Array(len);
                for (var i = 0; i < len; i++) {
                    var att = attachments[i];
                    if (att.imageData == "images/paperclip.png")
                        this.attachments.push(new Attachment(att.id, att.subject, false, att.imageData, this.onAttachmentClick, this));
                    else
                        this.attachments.push(new Attachment(att.id, att.subject, true, att.imageData, this.onAttachmentClick, this));
                }
            }
        };
        Post.prototype.onAttachmentClick = function (a) {
            var arr = this.attachments;
            MobileCRM.bridge.command("attachmentClick", a.id, function (data) {
                // Update or delete attachment if allowed
            }, MobileCRM.bridge.alert, this);
        };
        return Post;
    }());
    Chatter.Post = Post;
    var Attachment = (function () {
        function Attachment(id, subject, isImage, imageData, onClicked, scope) {
            this.id = id;
            this.subject = subject;
            this.isImage = isImage;
            this.imageData = ko.observable(imageData);
            this.onClicked = onClicked;
            this.scope = scope;
            if (!imageData)
                MobileCRM.bridge.command("downloadAttachment", id, this.onAttachmentDownloaded, null, this);
        }
        Attachment.prototype.onAttachmentDownloaded = function (data) {
            this.imageData(data);
        };
        Attachment.prototype.handleClick = function () {
            this.onClicked.call(this.scope, this);
        };
        return Attachment;
    }());
    Chatter.Attachment = Attachment;
    var SurveyOption = (function () {
        function SurveyOption(text, index, onClick) {
            this.index = index;
            this.text = text;
            this.clickHandler = onClick;
        }
        SurveyOption.prototype.onClick = function () {
            this.clickHandler(this);
        };
        return SurveyOption;
    }());
    Chatter.SurveyOption = SurveyOption;
    var Reaction = (function () {
        function Reaction(reaction) {
            this.name = reaction;
            this.users = ko.observableArray();
        }
        return Reaction;
    }());
    Chatter.Reaction = Reaction;
})(Chatter || (Chatter = {}));
